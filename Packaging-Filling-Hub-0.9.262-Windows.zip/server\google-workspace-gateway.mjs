import { createReadStream, existsSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import { createServer } from "node:http";
import { dirname, extname, join, normalize, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { CentralAuthService, readCookie } from "./central-auth.mjs";
import { PACKAGING_TARGET_RANGES, packagingTargetValues } from "./packaging-targets.mjs";
import { lithuanianCalendarDay } from "../src/domain/lithuanian-calendar.js";
import { vacationAccruedAfterSnapshot, vacationMonthlyRate } from "../src/domain/vacation-accrual.js";
import { isVacationChargeableDay, vacationUnitCount } from "../src/domain/vacation-policy.js";
import { MAINTENANCE_LINES, calculateMaintenanceDue } from "../src/domain/maintenance-due.js";
import { productionLineCredits, productionShiftGroups, productionShiftRoleCredits, splitProductionParticipants } from "../src/domain/production-credit.js";
import { calculateRecordPlansByLine, calculateShiftEfficiency } from "../src/domain/shift-efficiency.js";
import { hasWorkedAttendance } from "../src/domain/attendance-work.js";
import { shouldAutomaticallyCloseCentralShift } from "../src/domain/central-shift-close.js";
import { FIRST_PRODUCTION_START_TIME, minimumProductionStartTime } from "../src/domain/production-timing.js";
import { productionReportStatistics } from "../src/domain/production-report-statistics.js";

const projectRoot = normalize(join(fileURLToPath(new URL(".", import.meta.url)), ".."));
loadEnvironment(join(projectRoot, ".env"));

const appVersion = JSON.parse(readFileSync(join(projectRoot, "package.json"), "utf8")).version;
// A runtime marker, separate from package.json, lets installers verify that the
// gateway code containing the production-summary write guard is actually live.
const productionWriteGuard = "stable-summary-insert-v2";
const port = numberFromEnvironment("PORT", 4173);
const host = process.env.HOST || "127.0.0.1";
const writesEnabled = process.env.GOOGLE_WRITES_ENABLED === "true";
const centralMode = process.env.DEPLOYMENT_MODE === "central";
const workstationRole = normalizeWorkstationRole(process.env.WORKSTATION_ROLE);
const workstationId = normalizeWorkstationId(process.env.WORKSTATION_ID);
const workstationLabel = normalizeWorkstationLabel(process.env.WORKSTATION_LABEL);
const updateManifestUrl = process.env.UPDATE_MANIFEST_URL || "https://raw.githubusercontent.com/brazhkoanatolii/Packaging-Filling-Hub-Updates/main/update-manifest.json";
const updateManifestFallbackUrl = "https://api.github.com/repos/brazhkoanatolii/Packaging-Filling-Hub-Updates/contents/update-manifest.json?ref=main";
const updateRepositoryCommitUrl = "https://api.github.com/repos/brazhkoanatolii/Packaging-Filling-Hub-Updates/commits/main";
const maintenanceProductionSpreadsheetId = "1_BTwm21m1edVoNew6m5GJirPdUsxnJYE_Xv9qB32c5c";
const maintenanceProductionRange = "'Станки'!A7:J1515";
const maintenanceServiceSpreadsheetId = "1SRirurDOMqyGEXj2oo_V81CQ5jKnnvg9nN8G21QAFAY";
const maintenanceServiceRanges = Object.freeze(Array.from({ length: 16 }, (_, index) => `'ТО ${String(index + 1).padStart(2, "0")}'!A5:A1000`));
const repairsSpreadsheetId = "1pg2Y9Hnc-5BCU3QaF3k9VwOJjqNwdkXbE3qFAnY6Qw8";
const repairsDictionaryRange = "'Справочники'!A1:D1000";
const packagingSpreadsheetId = "1n7OfVi8__XWRJhj5jtlRUbrU6O9wGLmlDDf0e9-UKoI";
const packagingSheetName = "Лист";
// The packaging journal contains exactly the date and eleven packaging totals (A:L).
// The former contributor column was deliberately removed from the workbook.
const packagingRange = "'Лист'!A2:L";
const packagingReceiptPrefix = "PFH_PACKAGING_V1:";
const packagingKeys = Object.freeze(["garantBox430", "garantBox570", "dochemsPaper", "killaCanClear", "killaCanGreen", "killaLidGreen", "dzCanClear", "dzCanGreen", "dzLidBlack", "dzLidWhite", "dzLidGreen"]);
const packagingPendingPath = process.env.PACKAGING_PENDING_PATH
  ? resolve(process.env.PACKAGING_PENDING_PATH)
  : join(projectRoot, ".runtime", "packaging-pending.json");
const packagingWarehouseSpreadsheetId = "1mv7W6IcetxpSNMlTvQclPMIs15ZWZw7Q3ZE_g_NXVok";
const packagingWarehouseSheetName = "Операции";
const packagingWarehouseRange = "'Операции'!A6:F";
const packagingWarehouseSummaryRange = "'Склад упаковки'!A6:I";
const partsWarehouseSpreadsheetId = "1jj1tdaNLU5s8KowvB6AdQe7JKDbeGsv0rKK7CB2swyc";
const partsWarehouseSheetName = "Склад";
const partsWarehouseOperationsSheetName = "Операции";
const partsWarehouseRange = "'Склад'!A2:H";
const partsWarehouseOperationsRange = "'Операции'!A2:J";
const partsWarehouseCategories = Object.freeze(["Подшипники и сальники", "Механические запчасти", "Электрические компоненты", "Пневматические компоненты", "Другое"]);
let partsWarehouseWriteTail = Promise.resolve();
const ppeWarehouseSpreadsheetId = "1Kr012QFC4AOOE4mL3WKr-uJHA7NcTNptLlzCJgr35K0";
const ppeWarehouseSummaryRange = "'Сводная'!A1:AQ35";
const ppeWarehouseTargetRange = "'Фасовка'!A1:K35";
const ppeJournalSpreadsheetId = "13QGPCIlgp5GAbVfBc1Q6AaHuvxQNWEdYLP8KEHZ3Bc4";
const ppeJournalSheetName = "Лист1";
const ppeJournalRange = "'Лист1'!A2:N";
const ppeMonthNames = Object.freeze(["январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"]);
const rawMaterialsSpreadsheetId = "1jXf8oZLrFLGEJo15VoFQBe_FjC0_dz_3p0cVxgV4xGo";
const rawMaterialsSheetName = "Расход сырья";
const rawMaterialsRange = PACKAGING_TARGET_RANGES.rawMaterials;
const cansSpreadsheetId = "1-rEj8fvmBE4A5GO8o1ZXU1Ke0-ppK-gwKwCZt_kpwV4";
const cansSheetName = "Банки";
const cansRange = PACKAGING_TARGET_RANGES.cans;
const productionSpreadsheetId = "1zHYsa1pO7xLuSbBC43J_IPChlVfZaxt4L_rI9MtKwqA";
const productionSheetName = "Учет продукции и брака";
// AA:AC stores the replacement mechanic and AD:AI stores machine intervals.
// Reading through AI keeps those fields intact when a production day is sorted
// or rebuilt.
const productionSecondRange = `'${productionSheetName}'!A2:AI`;
const productionCreateLocks = new Map();
const productionCreateReceiptPath = process.env.PRODUCTION_CREATE_RECEIPT_PATH
  ? resolve(process.env.PRODUCTION_CREATE_RECEIPT_PATH)
  : join(projectRoot, ".runtime", "production-create-receipts.json");
let productionWriteTail = Promise.resolve();
const productionReportSyncRevisions = new Map();
const productionReportSpreadsheetId = "1_BTwm21m1edVoNew6m5GJirPdUsxnJYE_Xv9qB32c5c";
// The report contains daily rows through December 2029.  The exporter only
// needs the date column to locate a day, so read all prepared dates without
// downloading every empty calculated cell from the five report sheets.
const productionMachineRange = "'Станки'!A7:A1515";
const productionPackerRange = "'Упаковщики'!A7:A1515";
const productionScrapRange = "'Брак'!A7:A1515";
const productionMassRange = "'Масса'!A7:A1515";
const productionMechanicsSheetName = "Механики";
const productionMechanicsLegacySheetName = "Механики-операторы";
const productionMechanicsRange = "'Механики'!A7:A1515";
const productionReportedMasses = Object.freeze([11.8, 13.5, 15.4, 11, 14, 10]);
const productionMachineColumns = Object.freeze({ A: 2, B: 3, D: 4, F: 5, H: 6, K: 7, L: 8, M: 9 });
const nonconformitySpreadsheetId = "1ovuf2QW5KC4_CI1wAEUcufhZXfLreeJhN2PNVPtjlrk";
const nonconformitySheetName = "Журнал";
const nonconformityRange = "'Журнал'!A2:H";
const nonconformityDictionaryRange = "'Справочник несоответсвий'!A2:C";
const incidentSpreadsheetId = "1Km6ItHVRT6tW0d_jYdgwJ3RbBpN_fGwg0PoiT4YSDHA";
const incidentSheetName = "Журнал инцидентов";
const incidentRange = "'Журнал инцидентов'!A1:K";
const incidentDirectoryRange = "'Справочник инцидентов'!A4:K";
const shiftTaskSpreadsheetId = "1wZ4YdTdjm4dFq3mgdCCKocugPMpG9fJ7ReQCWxJp50A";
const shiftTaskSheetName = "Сменное задание";
const shiftTaskRange = "'Сменное задание'!A1:N";
const shiftTaskPhotoFolderPath = join(projectRoot, ".runtime", "shift-task-photo-folder.json");
const maximumShiftTaskPhotoBytes = 8 * 1024 * 1024;
// The Apps Script remains the canonical reader for this journal.  A direct,
// receipt-backed Sheets write is available only when its optional write switch
// was left disabled in the deployed script.  This keeps an already-created
// local record from being stranded by an Apps Script deployment setting.
const cycloneSpreadsheetId = "1jEpmScclwvmIhhiHnBi0EE5kRBGNLtfmP4zepkAMQDU";
const cycloneSheetName = "Очистка циклонов";
const cycloneReceiptPrefix = "PFH_CYCLONE_V1:";
const scaleJournalSpreadsheetId = "1An019JRwrya4wl9EtqY4zNELfRNzaq26sidhQce3Tc8";
const scaleJournalSheetName = "Контроль 50г";
const scaleJournalAuthorSheetName = "Реестр весов";
const scaleJournalAuthorStartRow = 25;
const scaleJournalAuthorEndRow = 1000;
const scaleJournalAuthorColumn = "I";
const scaleJournalAuthorValidationEndRow = 6016;
const automaticDailyExportHour = hourFromEnvironment("AUTOMATIC_DAILY_EXPORT_HOUR", 7);
const automaticDailyExportsEnabled = String(process.env.AUTOMATIC_DAILY_EXPORT_ENABLED || "false").trim().toLowerCase() === "true";
const workforceSpreadsheetIds = Object.freeze({
  personnel: "1r1opRywv4upVl4oMrUlOqmRsjAuETUu3-JFMUqjRu04",
  attendance: "1eJphWAgaxNb5N--tDrwv4uTzmiAs19NOLSAQlSn3dk0",
  vacations: "1zenc0sBGtD8KHQdrBxULsoA9jSaUcZeW83XIiz5YxSo"
});
const workforceVacationYears = Object.freeze([2026, 2027, 2028, 2029]);
const vacationBalanceSheetName = "Остатки отпусков";
const maximumBodyBytes = 1024 * 1024;
const types = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".webmanifest": "application/manifest+json; charset=utf-8"
};
const publicFiles = new Set(["index.html", "manifest.webmanifest", "service-worker.js"]);
const publicDirectories = ["assets/", "src/"];
const centralAccountsPath = process.env.CENTRAL_ACCOUNTS_PATH
  ? resolve(process.env.CENTRAL_ACCOUNTS_PATH)
  : join(projectRoot, ".runtime", "central-accounts.json");
const centralShiftStatePath = process.env.CENTRAL_SHIFT_STATE_PATH
  ? resolve(process.env.CENTRAL_SHIFT_STATE_PATH)
  : join(projectRoot, ".runtime", "central-shift-state.json");
const centralMachineStatusesPath = process.env.CENTRAL_MACHINE_STATUSES_PATH
  ? resolve(process.env.CENTRAL_MACHINE_STATUSES_PATH)
  : join(projectRoot, ".runtime", "central-machine-statuses.json");
const centralAuth = centralMode
  ? new CentralAuthService({ accountsPath: centralAccountsPath })
  : null;
if (centralAuth) {
  centralAuth.initialize({
    manager: process.env.CENTRAL_MANAGER_PASSWORD,
    "senior-mechanic": process.env.CENTRAL_SENIOR_PASSWORD
  });
}
if (centralMode) {
  closeExpiredCentralShift();
  setInterval(closeExpiredCentralShift, 60_000).unref();
}

let tokenCache = null;
let tokenRefreshPromise = null;
let maintenanceDueSnapshotCache = null;
let maintenanceDueSnapshotPromise = null;
const maintenanceDueSnapshotCacheMs = 60_000;
let automaticDailyExportCompletedDate = null;
let automaticDailyExportAttemptAt = 0;
let automaticDailyProductionExportCompletedDate = null;
let automaticDailyProductionExportAttemptAt = 0;
let automaticUpdateAttemptAt = 0;
let automaticUpdateRunning = false;
const updateActivitySessions = new Map();
const updateActivityTtlMs = 5 * 60_000;
const automaticUpdateNotBefore = Date.now() + 3 * 60_000;
let cachedFallbackManifest = null;
// Repair and scale journals keep strict Google Sheets source lists.  One queue
// serialises their refresh so a personnel edit and a journal entry cannot
// overwrite each other's list.
let personnelReferenceSyncTail = Promise.resolve();
let scaleJournalAuthorValidationReady = false;
let fallbackManifestCheckedAt = 0;

// Background work must never terminate the central server.  In particular,
// Google can reject an automatic daily export when a target range has been
// protected after the server was configured.  Log the failure and leave the
// API available so that the responsible person can correct the spreadsheet.
function runBackgroundTask(label, task) {
  void Promise.resolve()
    .then(task)
    .catch(error => console.error(`[gateway] Фоновая задача «${label}» завершилась с ошибкой: ${error?.message || error}`));
}

process.on("unhandledRejection", error => {
  console.error(`[gateway] Необработанная фоновая ошибка: ${error?.message || error}`);
});

createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host || `${host}:${port}`}`);

    if (url.pathname === "/runtime-config.js") {
      return sendJavaScript(response, `globalThis.__PACKAGING_FILLING_CONFIG__ = Object.freeze(${JSON.stringify({
        mode: "gateway",
        googleWritesEnabled: writesEnabled,
        gatewayBaseUrl: "",
        workstationRole: centralMode ? null : workstationRole,
        workstationId: centralMode ? null : workstationId,
        workstationLabel: centralMode ? "Центральный сервер участка" : workstationLabel,
        version: appVersion,
        centralAuth: centralMode
      })});`);
    }

    if (url.pathname === "/api/health" && request.method === "GET") {
      return sendJson(response, 200, {
        ok: true,
        version: appVersion,
        productionWriteGuard,
        configured: missingGoogleSettings().length === 0,
        writesEnabled,
        deploymentMode: centralMode ? "central" : "workstation",
        workstationRole: centralMode ? null : workstationRole,
        workstationConfigured: centralMode || workstationRole !== null,
        workstationId,
        workstationLabel,
        missing: missingGoogleSettings()
      });
    }

    if (url.pathname === "/api/google-status" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await googleConnectionStatus());
    }

    if (url.pathname === "/api/auth/session" && request.method === "GET") {
      return sendJson(response, 200, { ok: true, account: centralAuth ? actorFromRequest(request) : null });
    }
    if (url.pathname === "/api/auth/login" && request.method === "POST") {
      if (!centralAuth) return sendJson(response, 404, { ok: false, message: "Центральный вход не настроен" });
      const input = await readJsonBody(request);
      const session = centralAuth.login(input.accountId, input.password);
      return sendJson(response, 200, { ok: true, account: session.account }, {
        "Set-Cookie": sessionCookie(session.token, session.expiresAt)
      });
    }
    if (url.pathname === "/api/auth/logout" && request.method === "POST") {
      if (centralAuth) centralAuth.logout(readCookie(request, "PFH_SESSION"));
      return sendJson(response, 200, { ok: true }, { "Set-Cookie": expiredSessionCookie() });
    }
    if (url.pathname === "/api/auth/password" && request.method === "POST") {
      const actor = requireActor(request);
      if (!centralAuth) return sendJson(response, 404, { ok: false, message: "Центральный вход не настроен" });
      const input = await readJsonBody(request);
      centralAuth.changePassword(actor, input.accountId, input.currentPassword, input.nextPassword);
      return sendJson(response, 200, { ok: true });
    }

    // The active shift is operational state, not a Google Sheets row and not
    // browser data. Every central-mode client therefore reads the same record.
    if (url.pathname === "/api/shift-state" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, { ok: true, shift: await currentCentralShiftState() });
    }
    if (url.pathname === "/api/shift-state" && request.method === "POST") {
      const actor = requireActor(request, ["manager", "senior"]);
      const input = await readJsonBody(request);
      return sendJson(response, 200, { ok: true, shift: await updateCentralShiftState(input, actor) });
    }

    // Machine status is shared operational state. It is intentionally kept on
    // the central server rather than in a browser or Google Sheets.
    if (url.pathname === "/api/machine-statuses" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      const statuses = readCentralMachineStatuses();
      return sendJson(response, 200, { ok: true, configured: statuses !== null, statuses: statuses ?? defaultMachineStatuses() });
    }
    if (url.pathname === "/api/machine-statuses" && request.method === "PUT") {
      const actor = requireActor(request, ["manager", "senior"]);
      const statuses = writeCentralMachineStatuses((await readJsonBody(request)).statuses, actor);
      return sendJson(response, 200, { ok: true, configured: true, statuses });
    }

    if (url.pathname === "/api/update-status" && request.method === "GET") {
      return sendJson(response, 200, await getUpdateStatus());
    }
    if (url.pathname === "/api/update-activity" && request.method === "POST") {
      recordUpdateActivity(await readJsonBody(request));
      return sendJson(response, 200, { ok: true, ...updateInstallationSafety() });
    }
    if (url.pathname === "/api/update-safety" && request.method === "GET") {
      const allowQueuedOperations = url.searchParams.get("allowQueuedOperations") === "true";
      return sendJson(response, 200, { ok: true, ...updateInstallationSafety({ allowQueuedOperations }) });
    }
    if (url.pathname === "/api/update" && request.method === "POST") {
      const input = await readJsonBody(request);
      const force = input?.force === true;
      recordUpdateActivity(input?.activity);
      const safety = updateInstallationSafety({ allowQueuedOperations: force });
      if (!safety.safe) return sendJson(response, 409, { ok: false, message: safety.message });
      const update = await getUpdateStatus();
      if (!update.available && !force) return sendJson(response, 409, { ok: false, message: "Новой версии нет" });
      if (!update.packageUrl || !update.sha256 || !update.version) return sendJson(response, 503, { ok: false, message: "Не удалось получить проверенный пакет обновления" });
      if (process.platform !== "win32") return sendJson(response, 501, { ok: false, message: "Автообновление доступно только в Windows" });
      startVerifiedUpdate(update, force ? "принудительный запуск" : "ручной запуск");
      return sendJson(response, 202, { ok: true, version: update.version });
    }

    if (url.pathname === "/api/cyclone-records") {
      const actor = requireActor(request, ["manager", "senior"]);
      if (request.method === "GET") return sendJson(response, 200, await runAppsScript("listCycloneRecords"));
      if (request.method === "POST") {
        if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
        const input = await readJsonBody(request);
        const record = {
          requestId: input.requestId, recordId: input.recordId, date: input.date, performer: input.performer,
          role: actor.role, workstationId: workstationId || actor.id
        };
        let result;
        try {
          result = await runAppsScript("createCycloneRecord", [record]);
        } catch (error) {
          if (!isCycloneScriptWriteSwitchDisabled(error)) throw error;
          result = await createCycloneRecordDirectly(record);
        }
        return sendJson(response, result?.ok === false ? 400 : 200, result);
      }
      return sendJson(response, 405, { ok: false, message: "Допускаются только чтение и добавление очисток" });
    }

    if (url.pathname === "/api/scale-records" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      const result = await runAppsScript("listScaleRecords");
      return sendJson(response, 200, result);
    }

    if (url.pathname === "/api/workforce" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getWorkforceSnapshot());
    }
    if (url.pathname === "/api/workforce" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена" });
      const payload = await readJsonBody(request);
      const actor = requireActor(request, payload.kind === "attendance" ? ["manager", "senior"] : ["manager"]);
      const result = payload.kind === "attendance"
        ? await saveWorkforceAttendance(payload, actor)
        : payload.kind === "personnel"
          ? await saveWorkforcePerson(payload, actor)
        : payload.kind === "vacations"
          ? await saveWorkforceVacation(payload, actor)
        : await runAppsScript("writeWorkforceOperation", [{ ...payload, role: actor.role }]);
      return sendJson(response, result?.ok === false ? (result.status || 400) : 200, result);
    }

    if (url.pathname === "/api/maintenance" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      const result = await runAppsScript("getMaintenanceSnapshot");
      return sendJson(response, result?.ok === false ? 400 : 200, result);
    }
    if (url.pathname === "/api/maintenance-due" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getMaintenanceDueSnapshot());
    }
    if (url.pathname === "/api/maintenance" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена Администрацией" });
      const actor = requireActor(request, ["manager", "senior"]);
      const payload = await readJsonBody(request);
      if (payload.journal === "repair") return sendJson(response, 200, await createRepairRecord(payload, actor));
      const functionName = payload.journal === "service" ? "createMaintenanceRecord" : null;
      if (!functionName) return sendJson(response, 400, { ok: false, message: "Укажите журнал: ТО или ремонт" });
      const result = await runAppsScript(functionName, [{ ...payload, role: actor.role, workstationId: workstationId || actor.id }]);
      return sendJson(response, result?.ok === false ? (result.status || 400) : 200, result);
    }

    if (url.pathname === "/api/production-records" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      const result = await getProductionSnapshot();
      return sendJson(response, result?.ok === false ? 400 : 200, result);
    }
    if (url.pathname === "/api/statistics" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      const year = Number(url.searchParams.get("year")) || new Date().getFullYear();
      const month = String(url.searchParams.get("month") || "").replace(/\D/g, "").slice(0, 2);
      return sendJson(response, 200, await getStatisticsSnapshot(year, month));
    }
    if (url.pathname === "/api/production-records" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена Администрацией" });
      const actor = requireActor(request, ["manager", "senior"]);
      const input = await readJsonBody(request);
      return sendJson(response, 200, { ok: true, record: await createProductionRecord(input, actor) });
    }
    if (url.pathname === "/api/production-records" && request.method === "PUT") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена Администрацией" });
      const actor = requireActor(request, ["manager", "senior"]);
      const input = await readJsonBody(request);
      return sendJson(response, 200, { ok: true, record: await updateProductionRecord(input, actor) });
    }
    if (url.pathname === "/api/production-records" && request.method === "DELETE") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      requireActor(request, ["manager", "senior"]);
      await deleteProductionRecord(await readJsonBody(request));
      return sendJson(response, 200, { ok: true });
    }

    if (url.pathname === "/api/packaging-records" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getPackagingSnapshot());
    }
    if (url.pathname === "/api/packaging-records" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await createPackagingRecord({ ...(await readJsonBody(request)), role: actor.role, workstationId: workstationId || actor.id }));
    }
    if (url.pathname === "/api/packaging-records" && request.method === "DELETE") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await deletePackagingRecord(await readJsonBody(request)));
    }
    if (url.pathname === "/api/packaging-warehouse-records" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getPackagingWarehouseSnapshot());
    }
    if (url.pathname === "/api/packaging-warehouse-records" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await savePackagingWarehouseRecord({ ...(await readJsonBody(request)), author: actor.title || actor.id }));
    }
    if (url.pathname === "/api/packaging-warehouse-records" && request.method === "PUT") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager"]);
      return sendJson(response, 200, await savePackagingWarehouseRecord({ ...(await readJsonBody(request)), author: actor.title || actor.id }));
    }
    if (url.pathname === "/api/packaging-warehouse-records" && request.method === "DELETE") {
      requireActor(request, ["manager"]);
      return sendJson(response, 200, await deletePackagingWarehouseRecord(await readJsonBody(request)));
    }
    if (url.pathname === "/api/parts-warehouse" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getPartsWarehouseSnapshot());
    }
    if (url.pathname === "/api/parts-warehouse" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена Администрацией" });
      const actor = requireActor(request, ["manager"]);
      return sendJson(response, 200, await savePartsWarehouseOperation({ ...(await readJsonBody(request)), author: actor.title || actor.id }));
    }
    if (url.pathname === "/api/ppe-warehouse-records" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getPpeWarehouseSnapshot());
    }
    if (url.pathname === "/api/ppe-warehouse-records" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager"]);
      return sendJson(response, 200, await createPpeWarehouseIssue({ ...(await readJsonBody(request)), author: actor.title || actor.id }));
    }
    if (url.pathname === "/api/ppe-warehouse-records/retry" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      requireActor(request, ["manager"]);
      return sendJson(response, 200, await retryPpeWarehouseIssue(await readJsonBody(request)));
    }
    if (url.pathname === "/api/nonconformities" && request.method === "GET") {
      requireActor(request, ["manager", "senior", "mechanic"]);
      return sendJson(response, 200, await getNonconformitySnapshot());
    }
    if (url.pathname === "/api/nonconformities/dictionary" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      requireActor(request, ["manager"]);
      return sendJson(response, 200, await createNonconformityDictionaryEntry(await readJsonBody(request)));
    }
    if (url.pathname === "/api/nonconformities/dictionary" && request.method === "DELETE") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      requireActor(request, ["manager"]);
      return sendJson(response, 200, await deleteNonconformityDictionaryEntry(await readJsonBody(request)));
    }
    if (url.pathname === "/api/nonconformities" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const input = await readJsonBody(request);
      await requireNonconformityWriter(request, input);
      return sendJson(response, 200, await createNonconformityRecord(input));
    }
    if (url.pathname === "/api/nonconformities" && request.method === "PUT") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const input = await readJsonBody(request);
      await requireNonconformityWriter(request, input);
      return sendJson(response, 200, await updateNonconformityRecord(input));
    }
    if (url.pathname === "/api/nonconformities" && request.method === "DELETE") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      await requireNonconformityWriter(request);
      return sendJson(response, 200, await deleteNonconformityRecord(await readJsonBody(request)));
    }
    if (url.pathname === "/api/incidents" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getIncidentSnapshot());
    }
    if (url.pathname === "/api/incidents" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const input = await readJsonBody(request);
      await requireIncidentWriter(request, input);
      return sendJson(response, 200, await createIncidentRecord(input));
    }
    if (url.pathname === "/api/incidents" && request.method === "PUT") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const input = await readJsonBody(request);
      await requireIncidentWriter(request, input);
      return sendJson(response, 200, await updateIncidentRecord(input));
    }
    if (url.pathname === "/api/incidents" && request.method === "DELETE") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      requireActor(request, ["manager"]);
      return sendJson(response, 200, await deleteIncidentRecord(await readJsonBody(request)));
    }
    if (url.pathname === "/api/shift-tasks" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await getShiftTaskSnapshot());
    }
    if (url.pathname === "/api/shift-tasks" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager"]);
      return sendJson(response, 200, await createShiftTask(await readJsonBody(request, 12 * 1024 * 1024), actor));
    }
    if (url.pathname === "/api/shift-tasks" && request.method === "PUT") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager", "senior"]);
      return sendJson(response, 200, await updateShiftTask(await readJsonBody(request), actor));
    }
    if (url.pathname === "/api/shift-tasks" && request.method === "DELETE") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      requireActor(request, ["manager"]);
      return sendJson(response, 200, await deleteShiftTask(await readJsonBody(request)));
    }
    if (url.pathname.startsWith("/api/shift-task-photo/") && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      return sendShiftTaskPhoto(response, decodeURIComponent(url.pathname.slice("/api/shift-task-photo/".length)));
    }
    if (url.pathname === "/api/specifications" && request.method === "GET") {
      requireActor(request, ["manager", "senior"]);
      const specifications = await runAppsScript("listProductSpecifications");
      return sendJson(response, 200, { ok: true, specifications: Array.isArray(specifications) ? specifications : [] });
    }
    if (url.pathname === "/api/specifications" && request.method === "POST") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager"]);
      const specification = await runAppsScript("saveProductSpecification", [{ ...(await readJsonBody(request)), role: actor.role }]);
      return sendJson(response, 200, { ok: true, specification });
    }
    if (url.pathname === "/api/specifications" && request.method === "DELETE") {
      if (!writesEnabled) return sendJson(response, 403, { ok: false, message: "Запись в Google выключена начальником участка" });
      const actor = requireActor(request, ["manager"]);
      const result = await runAppsScript("deleteProductSpecification", [{ ...(await readJsonBody(request)), role: actor.role }]);
      return sendJson(response, 200, result);
    }

    if (url.pathname === "/api/scale-records" && request.method === "POST") {
      if (!writesEnabled) {
        return sendJson(response, 403, { ok: false, message: "Запись в Google пока выключена начальником участка" });
      }
      requireActor(request, ["manager", "senior"]);
      const payload = await readJsonBody(request);
      await ensureScaleJournalAuthor(payload?.author);
      const result = await runAppsScript("writeScaleRecordV2", [payload]);
      return sendJson(response, result?.conflict ? 409 : 200, result);
    }

    if (url.pathname.startsWith("/api/")) {
      return sendJson(response, 404, { ok: false, message: "Команда шлюза не найдена" });
    }

    return serveStatic(url.pathname, response);
  } catch (error) {
    const status = error.statusCode || 500;
    console.error(`[gateway] ${error.name}: ${error.message}`);
    return sendJson(response, status, {
      ok: false,
      message: error.name === "GoogleApiError" || status >= 500 ? (error.publicMessage || "Не удалось выполнить запрос к Google") : error.message
    });
  }
}).listen(port, host, () => {
  console.log(`Packaging-Filling-Hub: http://${host}:${port}`);
  console.log(`Рабочее место: ${workstationLabel || workstationId || workstationRole || "не назначено"}`);
  console.log(`Google: ${missingGoogleSettings().length ? "требуется настройка" : "настроен"}; запись: ${writesEnabled ? "включена" : "выключена"}`);
  if (centralMode || workstationRole === "manager") {
    if (writesEnabled && !missingGoogleSettings().length) {
      runBackgroundTask("сверка журналов расхода упаковки", migrateAndReconcilePackagingRecords);
    }
    if (automaticDailyExportsEnabled) {
      console.log(`Суточный перенос расхода упаковки: ежедневно после ${String(automaticDailyExportHour).padStart(2, "0")}:00 (Europe/Vilnius)`);
      runBackgroundTask("суточный перенос расхода упаковки", runAutomaticDailyPackagingExport);
      setInterval(() => runBackgroundTask("суточный перенос расхода упаковки", runAutomaticDailyPackagingExport), 5 * 60_000).unref();
      console.log(`Суточная сводка продукции: ежедневно после ${String(automaticDailyExportHour).padStart(2, "0")}:00 (Europe/Vilnius)`);
      runBackgroundTask("суточная сводка продукции", runAutomaticDailyProductionExport);
      setInterval(() => runBackgroundTask("суточная сводка продукции", runAutomaticDailyProductionExport), 5 * 60_000).unref();
    } else {
      console.log("Суточный перенос итогов отключён: фактические записи остаются в рабочих журналах.");
    }
    // Исторический журнал — первичный источник данных. Не пересчитываем все
    // дни при каждом запуске шлюза: такой массовый проход уже приводил к
    // перезаписи старых строк. Новая/исправленная запись пересчитывает только
    // собственную дату в обработчиках create/update/delete ниже.
    // Personal production reports are rebuilt only for the date changed by a
    // create, update or delete below. A full historical rebuild at every
    // gateway restart creates dozens of Sheets reads and can use up Google's
    // per-minute quota before an operator saves a new record.
    runBackgroundTask("приведение табеля и графика отпусков", repairWorkforceGoogleLayouts);
  }
  if (process.platform === "win32") {
    console.log("Автообновление: проверка каждую минуту; подтверждённая версия устанавливается автоматически.");
    runBackgroundTask("автообновление", runAutomaticUpdate);
    setInterval(() => runBackgroundTask("автообновление", runAutomaticUpdate), 60_000).unref();
  }
});

async function runAutomaticUpdate() {
  if (automaticUpdateRunning || Date.now() - automaticUpdateAttemptAt < 55_000) return;
  automaticUpdateAttemptAt = Date.now();
  // The installer preserves IndexedDB and .runtime, so a local retry queue
  // survives an update. A queued Google operation must never block a release.
  const safety = updateInstallationSafety({ allowQueuedOperations: true });
  if (!safety.safe) return;
  const update = await getUpdateStatus();
  if (!update.available) return;
  automaticUpdateRunning = true;
  try {
    startVerifiedUpdate(update, "автоматический запуск");
  } catch (error) {
    automaticUpdateRunning = false;
    console.error(`[update] Не удалось запустить обновление: ${error.message}`);
  }
}

function recordUpdateActivity(input) {
  const sessionId = String(input?.sessionId || "").trim();
  if (!/^[a-zA-Z0-9-]{16,128}$/.test(sessionId)) return;
  if (input?.closed === true) {
    updateActivitySessions.delete(sessionId);
    return;
  }
  updateActivitySessions.set(sessionId, {
    dirty: input?.dirty === true,
    submitting: input?.submitting === true,
    pending: Math.max(0, Math.min(10_000, Number(input?.pending) || 0)),
    lastInteractionAt: Math.min(Date.now(), Math.max(0, Number(input?.lastInteractionAt) || Date.now())),
    seenAt: Date.now()
  });
}

function updateInstallationSafety({ allowQueuedOperations = false } = {}) {
  const now = Date.now();
  for (const [sessionId, session] of updateActivitySessions) {
    if (now - session.seenAt > updateActivityTtlMs) updateActivitySessions.delete(sessionId);
  }
  if (now < automaticUpdateNotBefore) {
    return { safe: false, message: "Ожидание подключения программы перед проверкой обновления" };
  }
  // Merely viewing the program must not block an update. Only an actual
  // draft, an in-flight save, or a queued operation can put data at risk.
  const blockers = [...updateActivitySessions.values()].filter(session => session.dirty
    || session.submitting
    || (!allowQueuedOperations && session.pending > 0));
  if (!blockers.length) return { safe: true, message: "Можно устанавливать обновление" };
  const hasDraft = blockers.some(session => session.dirty || session.submitting);
  const hasQueue = blockers.some(session => session.pending > 0);
  return {
    safe: false,
    message: hasDraft
      ? "Обновление отложено: в программе есть несохранённый ввод"
      : hasQueue
        ? "Обновление отложено: есть записи в очереди отправки"
        : "Обновление отложено: пользователь работает в программе"
  };
}

function startVerifiedUpdate(update, source) {
  const updater = join(projectRoot, "scripts", "windows", "update-program.ps1");
  if (!existsSync(updater)) throw new Error("Не найден сценарий обновления");
  console.log(`[update] ${source}: версия ${update.version}.`);
  const windowsPowerShell = process.env.SystemRoot
    ? join(process.env.SystemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    : "powershell.exe";
  const shell = existsSync(windowsPowerShell) ? windowsPowerShell : "powershell.exe";
  const psLiteral = value => `'${String(value).replace(/'/g, "''")}'`;
  // A directly detached process is silently discarded by Windows on some
  // managed desktops.  Start-Process creates an independent installer, while
  // this tiny launcher can safely exit as soon as Windows accepts the job.
  const command = `Start-Process -FilePath ${psLiteral(shell)} -ArgumentList @(${[
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", updater,
    "-InstallRoot", projectRoot, "-PackageUrl", update.packageUrl,
    "-ExpectedSha256", update.sha256
  ].map(psLiteral).join(", ")}) -WindowStyle Hidden`;
  const child = spawn(shell, ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command], {
    stdio: "ignore",
    windowsHide: true
  });
  child.once("error", error => console.error(`[update] PowerShell не запущен: ${error.message}`));
  child.unref();
}

async function getUpdateStatus() {
  const base = { ok: true, currentVersion: appVersion, available: false, message: "Новая версия не найдена" };
  try {
    const primary = await readUpdateManifest(updateManifestUrl);
    const primaryStatus = updateStatusFromManifest(base, primary);
    if (primaryStatus?.available || process.env.UPDATE_MANIFEST_URL) return primaryStatus || { ...base, message: "Сведения об обновлении не прошли проверку" };

    // Some corporate proxies retain the raw GitHub file after a release. The
    // fallback reads the same manifest through GitHub's API at most once per
    // five minutes and still applies the identical URL and SHA validation.
    const fallback = await readFreshUpdateManifest();
    return updateStatusFromManifest(base, fallback) || primaryStatus || { ...base, message: "Не удалось проверить обновление" };
  } catch {
    return { ...base, message: "Не удалось проверить обновление" };
  }
}

async function readUpdateManifest(url) {
  const target = new URL(url);
  target.searchParams.set("pfh-update", String(Date.now()));
  const response = await fetch(target, {
    headers: { Accept: "application/json", "Cache-Control": "no-cache" },
    signal: AbortSignal.timeout(7_000)
  });
  if (!response.ok) return null;
  return response.json();
}

async function readFreshUpdateManifest() {
  if (Date.now() - fallbackManifestCheckedAt < 60_000) return cachedFallbackManifest;
  fallbackManifestCheckedAt = Date.now();
  try {
    const cacheKey = String(Date.now());
    const response = await fetch(`${updateManifestFallbackUrl}&pfh-update=${cacheKey}`, {
      headers: { Accept: "application/vnd.github+json", "User-Agent": "Packaging-Filling-Hub" },
      signal: AbortSignal.timeout(7_000)
    });
    if (!response.ok) return cachedFallbackManifest;
    const payload = await response.json();
    const content = Buffer.from(String(payload.content || "").replace(/\s/g, ""), "base64").toString("utf8");
    const manifest = JSON.parse(content);
    const commitResponse = await fetch(`${updateRepositoryCommitUrl}?pfh-update=${cacheKey}`, {
      headers: { Accept: "application/vnd.github+json", "User-Agent": "Packaging-Filling-Hub" },
      signal: AbortSignal.timeout(7_000)
    });
    const commit = commitResponse.ok ? await commitResponse.json() : null;
    cachedFallbackManifest = isSafeUpdateManifest(manifest)
      ? pinUpdatePackageToCommit(manifest, commit?.sha)
      : null;
  } catch {
    // The ordinary raw manifest remains the primary update path.
  }
  return cachedFallbackManifest;
}

function updateStatusFromManifest(base, manifest) {
  if (!isSafeUpdateManifest(manifest)) return null;
  const update = { ...base, version: manifest.version, packageUrl: manifest.packageUrl, sha256: manifest.sha256 };
  return compareVersions(manifest.version, appVersion) > 0
    ? { ...update, available: true, message: `Доступна версия ${manifest.version}` }
    : { ...update, message: "Установлена актуальная версия" };
}

function pinUpdatePackageToCommit(manifest, commit) {
  if (!/^[a-f0-9]{40}$/i.test(String(commit || ""))) return manifest;
  try {
    const packageUrl = new URL(manifest.packageUrl);
    const prefix = "/brazhkoanatolii/Packaging-Filling-Hub-Updates/main/";
    if (packageUrl.hostname !== "raw.githubusercontent.com" || !packageUrl.pathname.startsWith(prefix)) return manifest;
    packageUrl.pathname = packageUrl.pathname.replace(prefix, `/brazhkoanatolii/Packaging-Filling-Hub-Updates/${commit}/`);
    return { ...manifest, packageUrl: packageUrl.toString() };
  } catch {
    return manifest;
  }
}

function isSafeUpdateManifest(manifest) {
  if (!manifest || typeof manifest !== "object" || !/^\d+\.\d+\.\d+$/.test(manifest.version || "") || !/^[A-Fa-f0-9]{64}$/.test(manifest.sha256 || "")) return false;
  try {
    const packageUrl = new URL(manifest.packageUrl);
    return packageUrl.protocol === "https:"
      && packageUrl.hostname === "raw.githubusercontent.com"
      && /^\/brazhkoanatolii\/(Packaging-Filling-Hub|Packaging-Filling-Hub-Updates)\/.+\.zip$/.test(packageUrl.pathname);
  } catch {
    return false;
  }
}

function compareVersions(left, right) {
  const leftParts = left.split(".").map(Number);
  const rightParts = right.split(".").map(Number);
  for (let index = 0; index < 3; index += 1) {
    if (leftParts[index] !== rightParts[index]) return leftParts[index] > rightParts[index] ? 1 : -1;
  }
  return 0;
}

function isCycloneScriptWriteSwitchDisabled(error) {
  return /запись очисток в google выключена/i.test(String(error?.message || ""));
}

async function createCycloneRecordDirectly(input) {
  const record = await validateDirectCycloneRecord(input);
  // Ask the canonical reader first.  Its receipt makes retrying a request
  // idempotent even if the previous HTTP response was interrupted.
  const current = await runAppsScript("listCycloneRecords");
  const existing = (current?.records || []).find(item => item.requestId === record.requestId || item.id === record.recordId);
  if (existing) {
    if (existing.requestId !== record.requestId || existing.id !== record.recordId || existing.date !== record.date || existing.performer !== record.performer) {
      throw requestError("Повторный идентификатор относится к другой записи");
    }
    return { ok: true, record: existing };
  }
  const accessToken = await getAccessToken();
  const sheetId = await getSheetId(cycloneSpreadsheetId, cycloneSheetName, accessToken);
  const serial = Math.round((Date.parse(`${record.date}T00:00:00Z`) - Date.UTC(1899, 11, 30)) / 86_400_000);
  const receipt = {
    id: record.recordId,
    requestId: record.requestId,
    createdAt: new Date().toISOString(),
    workstationId: record.workstationId
  };
  await batchGoogleSheetRequests(cycloneSpreadsheetId, accessToken, [{ appendCells: {
    sheetId,
    rows: [{ values: [
      { userEnteredValue: { numberValue: serial }, note: `${cycloneReceiptPrefix}${JSON.stringify(receipt)}`, userEnteredFormat: { numberFormat: { type: "DATE", pattern: "dd.MM.yyyy" } } },
      { userEnteredValue: { stringValue: record.performer } }
    ] }],
    fields: "userEnteredValue,note,userEnteredFormat.numberFormat"
  } }], "Не удалось сохранить очистку циклонов");
  return { ok: true, record: { ...receipt, date: record.date, performer: record.performer } };
}

async function validateDirectCycloneRecord(input) {
  if (!input || !["manager", "senior"].includes(input.role)) throw requestError("Недостаточно прав", 403);
  const requestId = String(input.requestId || "");
  const recordId = String(input.recordId || "");
  if (![requestId, recordId].every(value => /^[a-zA-Z0-9_-]{8,160}$/.test(value))) throw requestError("Некорректный идентификатор запроса");
  const date = String(input.date || "");
  const parsedDate = new Date(`${date}T12:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== date || date > vilniusDate()) throw requestError("Некорректная дата очистки");
  const performer = String(input.performer || "").trim();
  if (!performer || performer.length > 180 || /^[=+@-]/.test(performer)) throw requestError("Выберите исполнителя");
  const workforce = await getWorkforceSnapshot();
  if (!(workforce.personnel || []).some(person => person.active !== false && person.fullName === performer)) throw requestError("Исполнитель отсутствует в действующем персонале");
  return { requestId, recordId, date, performer, role: input.role, workstationId: String(input.workstationId || "") };
}

async function runAppsScript(functionName, parameters = []) {
  assertGoogleConfigured();
  const accessToken = await getAccessToken();
  const deploymentId = process.env.GOOGLE_SCRIPT_DEPLOYMENT_ID;
  const response = await fetch(`https://script.googleapis.com/v1/scripts/${encodeURIComponent(deploymentId)}:run`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ function: functionName, parameters, devMode: false }),
    signal: AbortSignal.timeout(35_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Google Apps Script недоступен");
  if (payload.error) {
    const detail = payload.error.details?.[0]?.errorMessage || payload.error.message;
    throw googleError(502, detail || "Функция Google завершилась с ошибкой");
  }
  return payload.response?.result ?? null;
}

async function getAccessToken() {
  if (tokenCache && Date.now() < tokenCache.expiresAt - 60_000) return tokenCache.value;
  if (!tokenRefreshPromise) {
    tokenRefreshPromise = (async () => {
      const response = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: process.env.GOOGLE_OAUTH_CLIENT_ID,
          client_secret: process.env.GOOGLE_OAUTH_CLIENT_SECRET,
          refresh_token: process.env.GOOGLE_OAUTH_REFRESH_TOKEN,
          grant_type: "refresh_token"
        }),
        signal: AbortSignal.timeout(15_000)
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.access_token) {
        throw googleError(response.status || 502, payload.error_description || "Не удалось обновить доступ к Google");
      }
      tokenCache = {
        value: payload.access_token,
        expiresAt: Date.now() + Number(payload.expires_in || 3600) * 1000
      };
      return tokenCache.value;
    })().finally(() => { tokenRefreshPromise = null; });
  }
  return tokenRefreshPromise;
}

async function getMaintenanceDueSnapshot() {
  const now = Date.now();
  if (maintenanceDueSnapshotCache && now - maintenanceDueSnapshotCache.cachedAt < maintenanceDueSnapshotCacheMs) {
    return maintenanceDueSnapshotCache.value;
  }
  if (maintenanceDueSnapshotPromise) return maintenanceDueSnapshotPromise;

  maintenanceDueSnapshotPromise = (async () => {
  const [serviceRows, productionRows] = await Promise.all([
    getGoogleSheetRanges(maintenanceServiceSpreadsheetId, maintenanceServiceRanges),
    getGoogleSheetRanges(maintenanceProductionSpreadsheetId, [maintenanceProductionRange])
  ]);
  const serviceRecords = serviceRows.flatMap((rows, index) => (rows || []).map(row => ({ machine: index + 1, date: googleSheetDate(row?.[0]) })).filter(record => record.date));
  const productionByLine = (productionRows[0] || []).flatMap(row => {
    const date = googleSheetDate(row?.[0]);
    if (!date) return [];
    return MAINTENANCE_LINES.map((config, index) => ({ date, line: config.line, boxes: googleNumber(row[index + 2]) || 0 }));
  });
  const snapshot = {
    ok: true,
    records: calculateMaintenanceDue({ serviceRecords, productionRows: productionByLine, asOfDate: vilniusDate() })
  };
  maintenanceDueSnapshotCache = { value: snapshot, cachedAt: Date.now() };
  return snapshot;
  })().catch(error => {
    // Do not mark the journal unavailable during a short Google quota limit
    // when this gateway has already received a verified snapshot.
    if (maintenanceDueSnapshotCache?.value) return maintenanceDueSnapshotCache.value;
    throw error;
  }).finally(() => { maintenanceDueSnapshotPromise = null; });

  return maintenanceDueSnapshotPromise;
}

async function createRepairRecord(input) {
  const record = await validateRepairRecord(input);
  const parts = await validateRepairParts(input?.parts);
  const accessToken = await getAccessToken();
  const sheetName = `Ремонт ${String(record.machine).padStart(2, "0")}`;
  const range = `'${sheetName}'!A5:E`;
  const endpoint = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(repairsSpreadsheetId)}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ values: [[displayDate(record.date), record.category, record.work, record.performer, record.note]] }),
    signal: AbortSignal.timeout(20_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw repairWriteError(response.status, payload?.error?.message);
  const rowNumber = Number(String(payload.updates?.updatedRange || "").match(/!(?:[A-Z]+)(\d+):/)?.[1]);
  const repairId = `repair-${record.machine}-${rowNumber || Date.now()}`;
  if (parts.length) await writeOffRepairParts(parts, { repairId, record });
  return { ok: true, record: { ...record, id: repairId, rowNumber }, partsWrittenOff: parts.length };
}

async function validateRepairRecord(input) {
  const text = (key, label, limit = 5000) => {
    const value = String(input?.[key] || "").trim();
    if (!value) throw requestError(`Заполните поле «${label}»`);
    if (value.length > limit) throw requestError(`Поле «${label}» слишком длинное`);
    return value;
  };
  const date = String(input?.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw requestError("Выберите корректную дату ремонта");
  const machine = Number(input?.machine);
  if (!Number.isInteger(machine) || machine < 1 || machine > 16) throw requestError("Выберите станок от 1 до 16");
  const category = text("category", "Категория работ", 180);
  const selectedWorks = [...new Set(text("work", "Вид работ", 500).split(";").map(value => value.trim()).filter(Boolean))];
  if (!selectedWorks.length) throw requestError("Выберите хотя бы один вид работ");
  const work = selectedWorks.join("; ");
  const performer = text("performer", "Исполнитель", 180);
  const note = String(input?.note || "").trim();
  if (note.length > 5000) throw requestError("Поле «Примечание» слишком длинное");
  if (selectedWorks.some(value => /(описать|какого).*примечани|примечани.*(описать|какого)/i.test(value)) && !note) throw requestError("Для выбранного вида работ заполните примечание");

  const [rows, workforce] = await Promise.all([
    getGoogleSheetRanges(repairsSpreadsheetId, [repairsDictionaryRange]).then(result => result[0] ?? []),
    getWorkforceSnapshot()
  ]);
  const dictionary = rows.slice(1);
  const performers = new Set(dictionary.map(row => String(row[0] || "").trim()).filter(Boolean));
  const eligiblePerformers = new Set((workforce.personnel ?? [])
    .filter(person => person.active !== false && (
      person.fullName === "Anatolii Brazhko"
      || ["senior-mechanic", "mechanic"].includes(person.role)
    ))
    .map(person => String(person.fullName || "").trim())
    .filter(Boolean));
  const categories = new Set(dictionary.map(row => String(row[3] || "").trim()).filter(Boolean));
  const workColumn = category === "Настройка" ? 1 : category === "Ремонт" ? 2 : -1;
  if (!categories.has(category) || workColumn < 0) throw requestError("Категория работ отсутствует в справочнике журнала ремонта");
  const works = new Set(dictionary.map(row => String(row[workColumn] || "").trim()).filter(Boolean));
  if (selectedWorks.some(workItem => !works.has(workItem))) throw requestError("Один из выбранных видов работ отсутствует в справочнике журнала ремонта");
  if (!performers.has(performer)) throw requestError("Исполнитель отсутствует в справочнике журнала ремонта");
  if (!eligiblePerformers.has(performer)) throw requestError("В журнале ремонта можно выбрать только Anatolii Brazhko, старшего механика или механика");
  return { date, machine, category, work, performer, note };
}

async function getPartsWarehouseSnapshot() {
  const [inventoryRows = [], operationRows = []] = await getGoogleSheetRanges(partsWarehouseSpreadsheetId, [partsWarehouseRange, partsWarehouseOperationsRange]);
  return {
    ok: true,
    categories: [...partsWarehouseCategories],
    items: inventoryRows.map((row, index) => partsWarehouseItemFromRow(row, index + 2)).filter(Boolean),
    operations: operationRows.map((row, index) => partsWarehouseOperationFromRow(row, index + 2)).filter(Boolean)
  };
}

function partsWarehouseItemFromRow(row, rowNumber) {
  const code = String(row?.[0] || "").trim(); const category = String(row?.[1] || "").trim(); const name = String(row?.[2] || "").trim();
  const quantity = googleNumber(row?.[4]);
  if (!code || !partsWarehouseCategories.includes(category) || !name || !Number.isFinite(quantity) || quantity < 0) return null;
  return { id: code, rowNumber, category, name, unit: String(row?.[3] || "шт.").trim() || "шт.", quantity, minimum: Number.isFinite(googleNumber(row?.[5])) ? googleNumber(row?.[5]) : 0, note: String(row?.[6] || "").trim(), updatedAt: String(row?.[7] || "").trim() };
}
function partsWarehouseOperationFromRow(row, rowNumber) {
  const type = String(row?.[1] || "").trim(); const code = String(row?.[2] || "").trim(); const quantity = googleNumber(row?.[5]);
  if (!code || !["Приход", "Списание ремонта", "Корректировка"].includes(type) || !Number.isFinite(quantity) || quantity <= 0) return null;
  return { id: `parts-operation-${rowNumber}`, rowNumber, date: googleSheetDate(row?.[0]) || "", type, code, category: String(row?.[3] || ""), name: String(row?.[4] || ""), quantity, balance: googleNumber(row?.[6]), source: String(row?.[7] || ""), author: String(row?.[8] || ""), note: String(row?.[9] || "") };
}
function partsWarehouseText(value, label, limit = 500) { const text = String(value || "").trim(); if (!text || text.length > limit) throw requestError(`Проверьте поле «${label}»`); return text; }
function partsWarehouseQuantity(value, label = "Количество") { const number = Number(value); if (!Number.isFinite(number) || number <= 0 || number > 1_000_000) throw requestError(`Укажите корректное «${label}»`); return number; }
function partCodeFromRows(rows) { const largest = rows.map(row => Number(String(row?.[0] || "").match(/^SP-(\d+)$/)?.[1] || 0)).reduce((max, value) => Math.max(max, value), 0); return `SP-${String(largest + 1).padStart(4, "0")}`; }
async function savePartsWarehouseOperation(input) {
  return queuePartsWarehouseWrite(async () => {
    const action = String(input?.action || "");
    const author = partsWarehouseText(input?.author, "Исполнитель", 180);
    const [rows = []] = await getGoogleSheetRanges(partsWarehouseSpreadsheetId, [partsWarehouseRange]);
    const items = rows.map((row, index) => partsWarehouseItemFromRow(row, index + 2)).filter(Boolean);
    if (action === "add") {
      const category = partsWarehouseText(input?.category, "Раздел", 180); if (!partsWarehouseCategories.includes(category)) throw requestError("Выберите раздел склада");
      const name = partsWarehouseText(input?.name, "Запчасть", 180); if (items.some(item => item.category === category && item.name.toLocaleLowerCase("ru") === name.toLocaleLowerCase("ru"))) throw requestError("Такая запчасть уже есть в выбранном разделе");
      const quantity = partsWarehouseQuantity(input?.quantity); const minimum = Number(input?.minimum || 0); if (!Number.isFinite(minimum) || minimum < 0) throw requestError("Проверьте минимальный остаток");
      const item = { id: partCodeFromRows(rows), category, name, unit: String(input?.unit || "шт.").trim().slice(0, 60) || "шт.", quantity, minimum, note: String(input?.note || "").trim().slice(0, 500), updatedAt: new Date().toISOString() };
      await writePartsWarehouseChange({ item, quantity, type: "Приход", source: "Первичное добавление", author, note: item.note });
    } else if (action === "receive" || action === "adjust") {
      const item = items.find(entry => entry.id === String(input?.id || "")); if (!item) throw requestError("Запчасть не найдена на складе");
      const quantity = partsWarehouseQuantity(input?.quantity); const next = action === "receive" ? item.quantity + quantity : quantity;
      await writePartsWarehouseChange({ item: { ...item, quantity: next, updatedAt: new Date().toISOString() }, quantity: action === "receive" ? quantity : Math.abs(next - item.quantity), type: action === "receive" ? "Приход" : "Корректировка", source: "Ручная операция", author, note: String(input?.note || "").trim().slice(0, 500) });
    } else throw requestError("Неизвестная операция склада");
    return getPartsWarehouseSnapshot();
  });
}
async function validateRepairParts(raw) {
  if (!raw) return []; if (!Array.isArray(raw)) throw requestError("Некорректный список запчастей");
  const requested = raw.map(value => ({ id: String(value?.id || "").trim(), quantity: partsWarehouseQuantity(value?.quantity) })).filter(value => value.id);
  if (requested.length !== raw.length) throw requestError("Выберите запчасть для списания");
  const duplicates = new Set(); for (const part of requested) { if (duplicates.has(part.id)) throw requestError("Одна запчасть добавлена дважды"); duplicates.add(part.id); }
  const snapshot = await getPartsWarehouseSnapshot();
  return requested.map(part => { const item = snapshot.items.find(entry => entry.id === part.id); if (!item) throw requestError("Выбранная запчасть отсутствует на складе"); if (item.quantity < part.quantity) throw requestError(`Недостаточно запчасти «${item.name}»: доступно ${item.quantity} ${item.unit}`); return { ...part, item }; });
}
async function writeOffRepairParts(parts, context) {
  return queuePartsWarehouseWrite(async () => {
    const [rows = []] = await getGoogleSheetRanges(partsWarehouseSpreadsheetId, [partsWarehouseRange]);
    const items = rows.map((row, index) => partsWarehouseItemFromRow(row, index + 2)).filter(Boolean);
    for (const part of parts) {
      const item = items.find(entry => entry.id === part.id); if (!item || item.quantity < part.quantity) throw requestError(`Не удалось списать «${part.item.name}»: остаток изменился. Ремонт уже сохранён, проверьте склад.`);
      await writePartsWarehouseChange({ item: { ...item, quantity: item.quantity - part.quantity, updatedAt: new Date().toISOString() }, quantity: part.quantity, type: "Списание ремонта", source: context.repairId, author: context.record.performer, note: `Станок ${context.record.machine}: ${context.record.work}` });
    }
  });
}
async function queuePartsWarehouseWrite(work) { const next = partsWarehouseWriteTail.then(work, work); partsWarehouseWriteTail = next.catch(() => {}); return next; }
async function writePartsWarehouseChange({ item, quantity, type, source, author, note }) {
  const accessToken = await getAccessToken(); const [inventoryId, operationsId] = await Promise.all([getSheetId(partsWarehouseSpreadsheetId, partsWarehouseSheetName, accessToken), getSheetId(partsWarehouseSpreadsheetId, partsWarehouseOperationsSheetName, accessToken)]);
  const now = new Date().toISOString(); const values = [
    { userEnteredValue: { stringValue: item.id } }, { userEnteredValue: { stringValue: item.category } }, { userEnteredValue: { stringValue: item.name } }, { userEnteredValue: { stringValue: item.unit } }, { userEnteredValue: { numberValue: item.quantity } }, { userEnteredValue: { numberValue: item.minimum } }, { userEnteredValue: { stringValue: item.note || "" } }, { userEnteredValue: { stringValue: now } }
  ]; const update = item.rowNumber
    ? { updateCells: { start: { sheetId: inventoryId, rowIndex: item.rowNumber - 1, columnIndex: 0 }, rows: [{ values }], fields: "userEnteredValue" } }
    : { appendCells: { sheetId: inventoryId, rows: [{ values }], fields: "userEnteredValue" } };
  const operation = { appendCells: { sheetId: operationsId, rows: [{ values: [
    { userEnteredValue: { stringValue: displayDate(vilniusDate()) } }, { userEnteredValue: { stringValue: type } }, { userEnteredValue: { stringValue: item.id } }, { userEnteredValue: { stringValue: item.category } }, { userEnteredValue: { stringValue: item.name } }, { userEnteredValue: { numberValue: quantity } }, { userEnteredValue: { numberValue: item.quantity } }, { userEnteredValue: { stringValue: source } }, { userEnteredValue: { stringValue: author } }, { userEnteredValue: { stringValue: note || "" } }
  ] }], fields: "userEnteredValue" } };
  await batchGoogleSheetRequests(partsWarehouseSpreadsheetId, accessToken, [update, operation], "Не удалось сохранить операцию склада запчастей");
}

function requestError(message, statusCode = 400) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function repairWriteError(statusCode, googleMessage) {
  const message = String(googleMessage || "");
  const error = googleError(statusCode, message || "Не удалось внести запись о ремонте");
  if (/protected|защищён/i.test(message)) error.publicMessage = "Google не разрешил запись в защищённый диапазон журнала ремонта. Проверьте права корпоративной учётной записи на нужный лист.";
  else if (/permission|permission denied|недостаточно прав|нет разреш/i.test(message)) error.publicMessage = "У корпоративной учётной записи нет права записи в журнал ремонта.";
  else error.publicMessage = "Google не принял запись о ремонте. Повторите позже или проверьте подключение Google.";
  return error;
}

function googleNumber(value) {
  const source = String(value ?? "").trim();
  const negative = /^\(.+\)$/.test(source);
  const normalized = source.replace(/[()\s]/g, "").replace(",", ".");
  const number = Number(normalized);
  return Number.isFinite(number) ? (negative ? -number : number) : NaN;
}

async function getWorkforceSnapshot(requestedYear = new Date().getFullYear()) {
  const year = Number(requestedYear) || new Date().getFullYear();
  const [masterRanges, attendanceRanges, vacationRanges] = await Promise.all([
    getGoogleSheetRanges(workforceSpreadsheetIds.personnel, ["'Смены'!A6:H", "'Персонал'!A6:P"]),
    getGoogleSheetRanges(workforceSpreadsheetIds.attendance, [`'${year}'!A6:AR`]),
    getGoogleSheetRanges(workforceSpreadsheetIds.vacations, [...workforceVacationYears.map(item => `'${item}'!A6:N`), `'${vacationBalanceSheetName}'!A4:K`])
  ]);
  const teams = (masterRanges[0] ?? []).filter(row => row[6]).map(workforceTeam);
  const personnel = (masterRanges[1] ?? []).filter(row => row[7]).map(row => workforcePerson(row, teams));
  const attendance = workforceAttendance(attendanceRanges[0] ?? [], personnel, teams, year);
  const vacations = workforceVacationYears.flatMap((item, index) => workforceVacations(vacationRanges[index] ?? [], item, personnel));
  const rawVacationBalances = vacationRanges[workforceVacationYears.length] ?? [];
  const vacationBalances = await reconcileWorkforceVacationAccruals({
    personnel, teams, vacations, balanceRows: rawVacationBalances, vacationRows: vacationRanges.slice(0, workforceVacationYears.length)
  });
  return {
    ok: true, ready: true, personnel, shiftTeams: teams.filter(team => team.id !== "office"),
    officeSchedule: teams.find(team => team.id === "office") ?? null, attendance, vacations, vacationBalances,
    years: workforceVacationYears, timeZone: "Europe/Vilnius"
  };
}

async function getStatisticsSnapshot(year, month = "") {
  const [workforce, reportRanges, productionRows, specifications] = await Promise.all([
    getWorkforceSnapshot(year),
    getGoogleSheetRanges(productionReportSpreadsheetId, [
      "'Механики'!A6:BK1515",
      "'Упаковщики'!A6:V1515",
      "'Брак'!A6:V1515"
    ]),
    getProductionShiftRows(),
    runAppsScript("listProductSpecifications")
  ]);
  const [mechanicsRows, packerRows, scrapRows] = reportRanges;
  const records = productionRows.second.filter(record => record && statisticsRecordInPeriod(record, year, month));
  const sourceRows = productionReportStatistics({ mechanicsRows, packerRows, scrapRows, year, month, excludedDates: new Set(records.map(record => record.date)) });
  return {
    ok: true,
    year,
    month,
    years: workforceVacationYears,
    personnel: workforce.personnel,
    shiftTeams: workforce.shiftTeams,
    attendance: workforce.attendance,
    production: mergeProductionStatistics(sourceRows, productionJournalStatistics(records, specifications), workforce.personnel)
  };
}

function mergeProductionStatistics(reportRows, journalRows, personnel) {
  const peopleByName = new Map(personnel.map(person => [person.fullName, person]));
  const totals = new Map();
  const add = row => {
    const fullName = String(row.fullName || "").trim();
    const role = row.role || peopleByName.get(fullName)?.role;
    if (!fullName || !role) return;
    const key = `${fullName}:${role}`;
    const total = totals.get(key) ?? { fullName, role, boxes: 0, scrapKg: 0, grossMassKg: 0, days: 0 };
    total.boxes += Number(row.boxes || 0);
    total.scrapKg += Number(row.scrapKg || 0);
    total.grossMassKg += Number(row.grossMassKg || 0);
    total.days += Number(row.days || 0);
    totals.set(key, total);
  };
  reportRows.forEach(add); journalRows.forEach(add);
  return [...totals.values()];
}

function productionJournalStatistics(records, specifications) {
  const rows = new Map();
  const add = (name, role, record, fraction = 1) => {
    const fullName = String(name || "").trim();
    if (!fullName || !role || !fraction) return;
    const key = `${fullName}:${role}`;
    const row = rows.get(key) ?? { fullName, role, boxes: 0, scrapKg: 0, grossMassKg: 0, dates: new Set() };
    const boxes = Number(record.quantity || 0) / 240;
    const scrapKg = Number(record.scrapKg || 0);
    let finishedKg = boxes * 3;
    try { finishedKg = productionRecordMass(record, specifications)?.kg || finishedKg; }
    catch (error) { console.warn(`Для статистики не найден вес продукции в строке ${record.rowNumber}: ${error.message}`); }
    row.boxes += boxes * fraction;
    row.scrapKg += scrapKg * fraction;
    row.grossMassKg += (finishedKg + scrapKg) * fraction;
    row.dates.add(record.date);
    rows.set(key, row);
  };
  productionShiftGroups(records).forEach(group => {
    group.records.forEach(record => {
      add(record.packer, "packer", record);
      productionLineCredits(record).forEach(({ name, fraction }) => add(name, "mechanic-operator", record, fraction));
    });
    productionShiftRoleCredits(group).forEach(({ name, role, fraction }) => {
      group.records.forEach(record => add(name, role, record, fraction));
    });
  });
  return [...rows.values()].map(row => ({ ...row, days: row.dates.size }));
}

function statisticsRecordInPeriod(record, year, month = "") {
  const date = String(record?.date || "");
  return date.startsWith(`${year}-${month || ""}`);
}

async function reconcileWorkforceVacationAccruals({ personnel, teams, vacations, balanceRows, vacationRows }) {
  const today = todayInVilnius();
  const peopleById = new Map(personnel.map(person => [person.id, person]));
  const balances = workforceVacationBalances(balanceRows, personnel).map(balance => {
    const employee = peopleById.get(balance.employeeId);
    const accruedAfterSnapshot = employee ? vacationAccruedAfterSnapshot(employee, balance.asOfDate, today) : 0;
    const usedDates = new Set();
    vacations.filter(vacation => vacation.employeeId === balance.employeeId && Number(vacation.year) === balance.year && vacation.status !== "Аннулирован")
      .forEach(vacation => {
        for (let cursor = new Date(`${vacation.startDate}T12:00:00Z`), end = new Date(`${vacation.endDate}T12:00:00Z`); cursor <= end; cursor.setUTCDate(cursor.getUTCDate() + 1)) {
          const date = cursor.toISOString().slice(0, 10);
          if (date <= balance.asOfDate || date > today || !employee || !isWorkforceIsoDate(date)) continue;
          if (isVacationChargeableDay(employee, date, teams)) usedDates.add(date);
        }
      });
    const usedAfterSnapshot = usedDates.size;
    const currentRemaining = Math.max(0, Number((Number(balance.factualRemaining) + accruedAfterSnapshot + Number(balance.adjustment || 0) - usedAfterSnapshot).toFixed(2)));
    return { ...balance, accruedAfterSnapshot, usedAfterSnapshot, currentRemaining, calculatedAt: today, monthlyRate: vacationMonthlyRate(employee) };
  });
  if (!writesEnabled || missingGoogleSettings().length) return balances;

  const writes = [{ range: `'${vacationBalanceSheetName}'!D4:K4`, values: [["Фактический остаток (смены / раб. дн.)", "Дата фиксации", "Корректировка", "Комментарий", "Начислено после фиксации (смены / раб. дн.)", "Использовано после фиксации (смены / раб. дн.)", "Остаток на сегодня (смены / раб. дн.)", "Рассчитан"]] }];
  balances.forEach(balance => {
    writes.push({ range: `'${vacationBalanceSheetName}'!H${balance.sourceRow}:K${balance.sourceRow}`, values: [[balance.accruedAfterSnapshot, balance.usedAfterSnapshot, balance.currentRemaining, workforceGoogleDate(balance.calculatedAt)]] });
  });
  const balanceByEmployeeAndYear = new Map(balances.map(balance => [`${balance.year}:${balance.employeeId}`, balance.currentRemaining]));
  vacationRows.forEach((rows, index) => rows.forEach((row, rowIndex) => {
    const record = workforceVacations([row], workforceVacationYears[index], personnel)[0];
    const remaining = record ? balanceByEmployeeAndYear.get(`${record.year}:${record.employeeId}`) : undefined;
    if (Number.isFinite(remaining)) writes.push({ range: `'${workforceVacationYears[index]}'!N${rowIndex + 6}`, values: [[remaining]] });
  }));
  try {
    await setGoogleSheetRanges(workforceSpreadsheetIds.vacations, await getAccessToken(), writes);
  } catch (error) {
    console.warn("[gateway] Не удалось обновить ежемесячные остатки отпусков:", error.message);
  }
  return balances;
}

async function repairWorkforceGoogleLayouts() {
  if (!writesEnabled || missingGoogleSettings().length) return { migratedVacations: 0, removedGroups: 0 };
  const accessToken = await getAccessToken();
  const [personnelRows, vacationMetadata] = await Promise.all([
    getGoogleSheetRanges(workforceSpreadsheetIds.personnel, ["'Персонал'!A6:P"]).then(rows => rows[0] ?? []),
    getGoogleSheetStructure(workforceSpreadsheetIds.vacations, accessToken)
  ]);
  const personnelByName = new Map(personnelRows.map(row => [String(row[0] || "").trim().toLocaleLowerCase(), { id: String(row[7] || ""), role: String(row[1] || "") }]));
  let migratedVacations = 0;
  for (const year of [2025, 2026, 2027, 2028, 2029]) {
    const rows = (await getGoogleSheetRanges(workforceSpreadsheetIds.vacations, [`'${year}'!A6:H`]))[0] ?? [];
    const writes = [];
    rows.forEach((row, index) => {
      // Older rows did not have the role column: B was shift and H stored the operation ID.
      // Keep that eight-column Google Table intact and only move visible values into its current schema.
      if (!String(row[7] || "").startsWith("vacation:") || !/^\s*Смена\s+[AB]\s*$/i.test(String(row[1] || ""))) return;
      const employee = personnelByName.get(String(row[0] || "").trim().toLocaleLowerCase());
      writes.push({ range: `'${year}'!A${index + 6}:H${index + 6}`, values: [[
        row[0] || "", employee?.role || "", row[1] || "", row[2] || "", row[3] || "", row[4] || "", row[5] || "", row[7] || ""
      ]] });
    });
    if (writes.length) { await setGoogleSheetRanges(workforceSpreadsheetIds.vacations, accessToken, writes); migratedVacations += writes.length; }
  }
  let groupRequests = [];
  try {
    const attendanceMetadata = await getGoogleSheetStructure(workforceSpreadsheetIds.attendance, accessToken);
    const attendanceGroups = attendanceMetadata.filter(sheet => /^20\d\d$/.test(sheet.title)).flatMap(sheet => sheet.rowGroups || []);
    groupRequests = attendanceGroups.map(group => ({ deleteDimensionGroup: { range: group.range } }));
    for (let index = 0; index < groupRequests.length; index += 50) {
      if (groupRequests.slice(index, index + 50).length) await batchGoogleSheetRequests(workforceSpreadsheetIds.attendance, accessToken, groupRequests.slice(index, index + 50), "Не удалось убрать сворачивание месяцев в табеле");
    }
  } catch (error) {
    console.warn("[gateway] Не удалось убрать сворачивание месяцев в табеле:", error.message);
  }
  const attendanceValues = [...Array.from({ length: 48 }, (_, index) => String((index + 1) / 2)), "A", "NA", "MA", "G", "PV", "M", "K", "L", "NS", "KV", "P", "VV"];
  const attendanceValidation = { condition: { type: "ONE_OF_LIST", values: attendanceValues.map(userEnteredValue => ({ userEnteredValue })) }, strict: true, showCustomUi: true };
  const attendanceValidationRequests = [];
  try {
    const attendanceMetadata = await getGoogleSheetStructure(workforceSpreadsheetIds.attendance, accessToken);
    attendanceMetadata.filter(sheet => /^20\d\d$/.test(sheet.title)).forEach(sheet => attendanceValidationRequests.push({ setDataValidation: { range: { sheetId: sheet.sheetId, startRowIndex: 5, endRowIndex: 1500, startColumnIndex: 3, endColumnIndex: 34 }, rule: attendanceValidation } }));
    if (attendanceValidationRequests.length) await batchGoogleSheetRequests(workforceSpreadsheetIds.attendance, accessToken, attendanceValidationRequests, "Не удалось обновить список часов в табеле");
  } catch (error) {
    console.warn("[gateway] Не удалось обновить список часов в табеле:", error.message);
  }
  const vacationRequests = vacationMetadata.filter(sheet => /^20\d\d$/.test(sheet.title)).flatMap(sheet => [
    { repeatCell: { range: { sheetId: sheet.sheetId, startRowIndex: 5, startColumnIndex: 3, endColumnIndex: 5 }, cell: { userEnteredFormat: { numberFormat: { type: "DATE", pattern: "dd.MM.yyyy" } } }, fields: "userEnteredFormat.numberFormat" } },
    { repeatCell: { range: { sheetId: sheet.sheetId, startRowIndex: 5, startColumnIndex: 5, endColumnIndex: 6 }, cell: { userEnteredFormat: { numberFormat: { type: "NUMBER", pattern: "0" } } }, fields: "userEnteredFormat.numberFormat" } }
  ]);
  if (vacationRequests.length) await batchGoogleSheetRequests(workforceSpreadsheetIds.vacations, accessToken, vacationRequests, "Не удалось оформить график отпусков");
  return { migratedVacations, removedGroups: groupRequests.length };
}

async function getGoogleSheetStructure(spreadsheetId, accessToken) {
  const fields = "sheets(properties(sheetId,title),rowGroups(range))";
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}?fields=${encodeURIComponent(fields)}`, { headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(12_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось прочитать структуру рабочего журнала");
  return (payload.sheets || []).map(sheet => ({ sheetId: sheet.properties?.sheetId, title: sheet.properties?.title || "", rowGroups: sheet.rowGroups || [] }));
}

// Attendance is read from Sheets by this gateway, so it must also be written
// here.  Sending the write to a separately deployed Apps Script made the
// optimistic revision depend on two different readers and produced false
// conflicts for any employee, not only the employee currently displayed.
async function saveWorkforceAttendance(payload, actor) {
  const record = payload?.record || {};
  const date = String(record.date || "");
  const year = Number(date.slice(0, 4)), month = Number(date.slice(5, 7)), day = Number(date.slice(8, 10));
  const value = normalizeWorkforceAttendanceValue(record.value);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isInteger(month) || !Number.isInteger(day) || !value) {
    return workforceWriteFailure("Проверьте дату и значение табеля");
  }
  if (actor.role === "senior" && date !== todayInVilnius()) return workforceWriteFailure("Старший механик может исправлять табель только за текущий день смены.");
  if (String(record.id || "") !== `${date}:${record.shiftTeamId}:${record.employeeId}`) return workforceWriteFailure("Некорректный ID табеля");

  const workforce = await getWorkforceSnapshot();
  const employee = workforce.personnel.find(person => person.id === String(record.employeeId || ""));
  const team = workforce.shiftTeams.find(item => item.id === String(record.shiftTeamId || ""));
  if (!employee || employee.shiftTeamId === "office" || !team) return workforceWriteFailure("Проверьте сотрудника и смену");

  const desired = {
    id: String(record.id), date, employeeId: employee.id, shiftTeamId: team.id, value,
    overtime: record.overtime === true, substitutionReason: String(record.substitutionReason || ""),
    homeShiftTeamId: String(record.homeShiftTeamId || "")
  };
  const current = workforce.attendance.find(item => item.id === desired.id);
  if (employee.active === false && !current) {
    return workforceWriteFailure("Уволенного сотрудника нельзя добавить в новый день табеля. Сохранённые строки можно исправить без удаления истории.");
  }
  if (sameWorkforceAttendance(current, desired)) return { ok: true, record: current };
  if ((current?.revision || "empty") !== String(payload.expectedRevision || "empty")) {
    return { ok: false, status: 409, conflict: true, message: "Эта строка табеля уже изменилась в Google. Обновите данные и повторите только нужное исправление." };
  }

  const rows = (await getGoogleSheetRanges(workforceSpreadsheetIds.attendance, [`'${year}'!A6:AR`]))[0] ?? [];
  const rowIndex = rows.findIndex(row => Number(row[0]) === month && String(row[38] || "") === employee.id
    && (String(row[43] || "") === team.id || String(row[2] || "") === team.name));
  const rowNumber = rowIndex < 0 ? Math.max(6, rows.length + 6) : rowIndex + 6;
  const row = rowIndex < 0 ? Array(44).fill("") : [...rows[rowIndex], ...Array(Math.max(0, 44 - rows[rowIndex].length)).fill("")];
  if (rowIndex < 0) {
    row[0] = month; row[1] = employee.fullName; row[2] = team.name; row[38] = employee.id; row[43] = team.id;
    for (let index = new Date(year, month, 0).getDate() + 1; index <= 31; index += 1) row[index + 2] = "—";
  }
  row[day + 2] = numericWorkforceAttendance(value);
  row[37] = mergeWorkforceSubstituteNote(row[37], day, desired.substitutionReason, desired.homeShiftTeamId);
  const overtime = new Set(String(row[42] || "").split(",").filter(Boolean));
  if (desired.overtime) overtime.add(String(day)); else overtime.delete(String(day));
  row[39] = Number(row[39] || 0) + 1; row[40] = new Date().toISOString(); row[41] = actor.performer || actor.title || actor.id; row[42] = [...overtime].sort((left, right) => Number(left) - Number(right)).join(","); row[43] = team.id;
  const accessToken = await getAccessToken();
  if (rowIndex < 0) {
    await setGoogleSheetRanges(workforceSpreadsheetIds.attendance, accessToken, [{ range: `'${year}'!A${rowNumber}:AR${rowNumber}`, values: [row] }]);
  } else {
    await setGoogleSheetRanges(workforceSpreadsheetIds.attendance, accessToken, [
      { range: `'${year}'!${columnLetter(day + 2)}${rowNumber}:${columnLetter(day + 2)}${rowNumber}`, values: [[row[day + 2]]] },
      { range: `'${year}'!AL${rowNumber}:AR${rowNumber}`, values: [[row[37], row[38], row[39], row[40], row[41], row[42], row[43]]] }
    ]);
  }
  return { ok: true, record: { ...desired, revision: workforceRevision([value, desired.overtime, desired.substitutionReason, desired.homeShiftTeamId]), updatedAt: new Date().toISOString(), updatedBy: row[41] } };
}

function workforceWriteFailure(message) { return { ok: false, status: 400, message }; }

function sameWorkforcePerson(left, right) {
  if (!left || !right) return false;
  const text = value => String(value || "").trim();
  const isPacker = right.role === "packer";
  return left.fullName === text(right.fullName)
    && left.role === text(right.role)
    && left.shiftTeamId === text(right.shiftTeamId)
    && left.active === (right.active !== false)
    && left.note === text(right.note)
    && left.pakNumber === (isPacker ? text(right.pakNumber) : "")
    && left.pakCode === (isPacker ? text(right.pakCode) : "")
    && left.birthday === text(right.birthday)
    && left.hireDate === text(right.hireDate)
    && left.phone === text(right.phone)
    && left.email === text(right.email);
}

function sameWorkforcePersonName(left, right) {
  return String(left || "").trim().replace(/\s+/g, " ").toLocaleLowerCase()
    === String(right || "").trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

// Personnel is read from Google Sheets by this gateway.  Keeping its writes
// here too makes the optimistic revision identical on both sides; Apps Script
// otherwise serializes date cells differently and rejects a valid overwrite.
async function saveWorkforcePerson(payload, actor) {
  const record = payload?.record || {};
  const allowedRoles = new Set(["head-of-area", "production-manager", "administrator", "warehouse-manager", "senior-mechanic", "mechanic", "mechanic-operator", "packer"]);
  const id = String(record.id || "").trim();
  if (!id || !allowedRoles.has(record.role) || String(record.fullName || "").trim().length < 2) return workforceWriteFailure("Проверьте ФИО и должность сотрудника");

  const workforce = await getWorkforceSnapshot();
  const team = workforce.shiftTeams.find(item => item.id === String(record.shiftTeamId || ""));
  if (!team) return workforceWriteFailure("Проверьте смену сотрудника");
  const current = workforce.personnel.find(person => person.id === id);
  if (workforce.personnel.some(person => person.id !== id && sameWorkforcePersonName(person.fullName, record.fullName))) {
    return workforceWriteFailure("Сотрудник с таким ФИО уже есть в персонале. Оставьте одну карточку, чтобы записи в Google не перепутались.");
  }
  if (sameWorkforcePerson(current, record)) {
    await synchronizePersonnelReferences(workforce.personnel);
    return { ok: true, record: current };
  }
  if ((current?.revision || "empty") !== String(payload.expectedRevision || "empty")) {
    return { ok: false, status: 409, conflict: true, message: "Эту запись уже изменили. Обновите данные и выберите, какие исправления сохранить." };
  }

  const rows = (await getGoogleSheetRanges(workforceSpreadsheetIds.personnel, ["'Персонал'!A6:P"]))[0] ?? [];
  const rowIndex = rows.findIndex(row => String(row[7] || "") === id);
  const rowNumber = rowIndex < 0 ? Math.max(6, rows.length + 6) : rowIndex + 6;
  const previous = rowIndex < 0 ? [] : rows[rowIndex];
  const text = value => String(value || "").trim();
  const date = value => text(value) ? workforceGoogleDate(text(value)) : "";
  const isPacker = record.role === "packer";
  const saved = [
    text(record.fullName), workforceRoleLabel(record.role), team.name,
    isPacker ? text(record.pakNumber) : "", isPacker ? text(record.pakCode) : "",
    record.active === false ? "Не работает" : "Работает", text(record.note), id,
    Number(previous[8] || 0) + 1, new Date().toISOString(), actor.performer, team.id,
    date(record.birthday), date(record.hireDate), text(record.phone), text(record.email)
  ];
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(workforceSpreadsheetIds.personnel, accessToken, [{ range: `'Персонал'!A${rowNumber}:P${rowNumber}`, values: [saved] }]);
  const refreshed = await getWorkforceSnapshot();
  const result = refreshed.personnel.find(person => person.id === id);
  if (!result) throw new Error("Не удалось подтвердить сохранение сотрудника в Google");
  await synchronizePersonnelReferences(refreshed.personnel);
  return { ok: true, record: result };
}

// Vacation records are read from Google Sheets by this gateway.  Writing them
// through another deployed Apps Script left two independent revision formats
// and caused false errors while saving an otherwise valid period.
async function saveWorkforceVacation(payload, actor) {
  const input = payload?.record || {};
  const year = Number(input.year);
  const startDate = String(input.startDate || "");
  const endDate = String(input.endDate || "");
  const id = String(input.id || "");
  if (!/^vacation:[a-zA-Z0-9-]{8,128}$/.test(id) || ![2025, 2026, 2027, 2028, 2029].includes(year)) {
    return workforceWriteFailure("Проверьте номер периода и год отпуска");
  }
  if (!input.deleted && (!isWorkforceIsoDate(startDate) || !isWorkforceIsoDate(endDate) || startDate > endDate || startDate.slice(0, 4) !== String(year) || endDate.slice(0, 4) !== String(year))) {
    return workforceWriteFailure("Укажите начало и окончание отпуска в пределах выбранного года");
  }

  const workforce = await getWorkforceSnapshot();
  const employee = workforce.personnel.find(person => person.id === String(input.employeeId || ""));
  const team = workforce.shiftTeams.find(item => item.id === employee?.shiftTeamId);
  const effectiveTeam = employee?.shiftTeamId === "office" ? (workforce.officeSchedule || { id: "office", name: "Администрация" }) : team;
  if (!employee || !effectiveTeam) return workforceWriteFailure("Проверьте сотрудника и его смену");

  const current = workforce.vacations.find(item => item.id === id);
  if (!input.deleted && employee.active === false && !current) {
    return workforceWriteFailure("Нельзя запланировать новый отпуск для уволенного сотрудника. Его прежние записи сохраняются в графике.");
  }
  if ((current?.revision || "empty") !== String(payload.expectedRevision || "empty")) {
    return { ok: false, status: 409, conflict: true, message: "Этот период отпуска уже изменили в Google. Обновите данные и повторите только нужное исправление." };
  }
  if (input.deleted) {
    if (!current) return workforceWriteFailure("Период отпуска не найден в Google");
  } else if (sameWorkforceVacation(current, input)) {
    return { ok: true, record: current };
  }

  const rows = (await getGoogleSheetRanges(workforceSpreadsheetIds.vacations, [`'${year}'!A6:M`]))[0] ?? [];
  const rowIndex = rows.findIndex(row => String(row[8] || row[7] || "") === id);
  if (input.deleted && rowIndex < 0) return workforceWriteFailure("Период отпуска не найден в Google");
  const rowNumber = rowIndex < 0 ? Math.max(6, rows.length + 6) : rowIndex + 6;
  const prior = rowIndex < 0 ? [] : rows[rowIndex];
  const nextRevision = Number(prior[10] || 0) + 1;
  const days = vacationUnitCount(employee, startDate, endDate, [...workforce.shiftTeams, workforce.officeSchedule].filter(Boolean));
  const values = input.deleted ? Array(13).fill("") : [[
    employee.fullName,
    workforceRoleLabel(employee.role),
    effectiveTeam.name,
    workforceGoogleDate(startDate),
    workforceGoogleDate(endDate),
    days,
    input.status === "Аннулирован" ? "Аннулирован" : "Запланирован",
    String(input.note || "").trim(),
    id,
    employee.id,
    nextRevision,
    new Date().toISOString(),
    actor.performer || actor.title || actor.id
  ]];
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(workforceSpreadsheetIds.vacations, accessToken, [{
    range: `'${year}'!A${rowNumber}:M${rowNumber}`,
    values: input.deleted ? [values] : values
  }]);
  if (input.deleted) return { ok: true, record: { id, deleted: true } };
  if (values[0][6] !== "Аннулирован") await applyVacationToWorkforceAttendance(employee, effectiveTeam, startDate, endDate, workforce.shiftTeams);
  const saved = values[0];
  return {
    ok: true,
    record: {
      id, employeeId: employee.id, year, startDate, endDate, days, status: saved[6], note: saved[7],
      revision: workforceVacationRevision(saved), updatedAt: saved[11], updatedBy: saved[12]
    }
  };
}

async function applyVacationToWorkforceAttendance(employee, team, startDate, endDate, teams) {
  const year = Number(startDate.slice(0, 4));
  const rows = (await getGoogleSheetRanges(workforceSpreadsheetIds.attendance, [`'${year}'!A6:AR`]))[0] ?? [];
  const byMonth = new Map();
  for (let timestamp = Date.parse(`${startDate}T12:00:00Z`); timestamp <= Date.parse(`${endDate}T12:00:00Z`); timestamp += 86_400_000) {
    const date = new Date(timestamp), month = date.getUTCMonth() + 1, day = date.getUTCDate();
    if (!isVacationChargeableDay(employee, date.toISOString().slice(0, 10), [...teams, team])) continue;
    if (!byMonth.has(month)) byMonth.set(month, []);
    byMonth.get(month).push(day);
  }
  const writes = [];
  for (const [month, days] of byMonth) {
    const rowIndex = rows.findIndex(row => Number(row[0]) === month && String(row[38] || "") === employee.id
      && (String(row[43] || "") === team.id || String(row[2] || "") === team.name));
    const rowNumber = rowIndex < 0 ? Math.max(6, rows.length + 6 + writes.filter(write => write.newRow).length) : rowIndex + 6;
    const row = rowIndex < 0 ? Array(44).fill("") : [...rows[rowIndex], ...Array(Math.max(0, 44 - rows[rowIndex].length)).fill("")];
    if (rowIndex < 0) {
      row[0] = month; row[1] = employee.fullName; row[2] = team.name; row[38] = employee.id; row[43] = team.id;
      for (let index = new Date(year, month, 0).getDate() + 1; index <= 31; index += 1) row[index + 2] = "—";
    }
    let changed = rowIndex < 0;
    for (const day of days) {
      if (!String(row[day + 2] || "").trim() || row[day + 2] === "—") { row[day + 2] = "A"; changed = true; }
    }
    if (changed) writes.push({ range: `'${year}'!A${rowNumber}:AR${rowNumber}`, values: [row], newRow: rowIndex < 0 });
  }
  if (!writes.length) return;
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(workforceSpreadsheetIds.attendance, accessToken, writes.map(({ range, values }) => ({ range, values })));
}

function isWorkforceIsoDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function workforceGoogleDate(value) { const [year, month, day] = String(value).split("-"); return `${day}.${month}.${year}`; }
function workforceRoleLabel(role) { return ({ "head-of-area": "Администрация", "production-manager": "Начальник производства", administrator: "Администратор", "warehouse-manager": "Начальник склада", "senior-mechanic": "Старший механик", mechanic: "Механик", "mechanic-operator": "Механик-оператор", packer: "Упаковщик" })[role] || ""; }
function isWorkdayInLithuania(date) { const weekday = new Date(`${date}T12:00:00Z`).getUTCDay(); return weekday !== 0 && weekday !== 6 && !lithuanianCalendarDay(date).isHoliday; }
function sameWorkforceVacation(left, right) {
  return Boolean(left) && left.employeeId === String(right.employeeId || "") && left.startDate === String(right.startDate || "")
    && left.endDate === String(right.endDate || "") && left.status === (right.status === "Аннулирован" ? "Аннулирован" : "Запланирован")
    && left.note === String(right.note || "").trim();
}
function normalizeWorkforceAttendanceValue(value) {
  const source = String(value ?? "").trim();
  if (["A", "NA", "MA", "G", "PV", "M", "K", "L", "NS", "KV", "P", "VV"].includes(source)) return source;
  const hours = Number(source.replace(",", "."));
  return Number.isFinite(hours) && hours >= 0.5 && hours <= 24 && Math.round(hours * 2) === hours * 2 ? String(hours) : "";
}
function numericWorkforceAttendance(value) { return /^\d+(?:\.5)?$/.test(value) ? Number(value) : value; }
function sameWorkforceAttendance(left, right) {
  return Boolean(left) && normalizeWorkforceAttendanceValue(left.value) === normalizeWorkforceAttendanceValue(right.value)
    && Boolean(left.overtime) === Boolean(right.overtime)
    && String(left.substitutionReason || "") === String(right.substitutionReason || "")
    && String(left.homeShiftTeamId || "") === String(right.homeShiftTeamId || "");
}
function mergeWorkforceSubstituteNote(note, day, reason, homeShiftTeamId) {
  const current = String(note || "");
  if (!reason) return current;
  const team = String(homeShiftTeamId || "").endsWith("-b") ? "B" : "A";
  const matcher = /Подменный выход \(штатная смена ([AB])\):\s*([^\n]+)/;
  const match = current.match(matcher);
  const entries = match ? match[2].split(";").map(item => item.trim()).filter(Boolean) : [];
  const withoutDay = entries.filter(item => !item.startsWith(`${day} — `));
  withoutDay.push(`${day} — ${reason}`);
  withoutDay.sort((left, right) => Number(left.split(" ")[0]) - Number(right.split(" ")[0]));
  const replacement = `Подменный выход (штатная смена ${team}): ${withoutDay.join("; ")}`;
  return match ? current.replace(match[0], replacement) : `${current}${current ? "\n" : ""}${replacement}`;
}

async function getPackagingSnapshot() {
  const [records, pending] = await Promise.all([getPackagingSheetRecords(), Promise.resolve(readPackagingPendingRecords())]);
  const byDate = new Map(records.map(record => [record.date, record]));
  for (const record of pending) byDate.set(record.date, record);
  return { ok: true, records: [...byDate.values()].sort((left, right) => left.date.localeCompare(right.date)) };
}

async function getPackagingSheetRecords() {
  const values = await getGoogleSheetRanges(packagingSpreadsheetId, [packagingRange]);
  const rows = values[0] ?? [];
  const headers = rows[0] ?? [];
  if (headers.length < 12 || String(headers[0]).trim() !== "Дата") {
    throw new Error("Изменилась структура журнала расхода упаковки");
  }
  const notes = await getPackagingDateNotes();
  return rows.slice(1).map((row, index) => packagingRecordFromRow(row, index + 3, notes[index] || "")).filter(Boolean);
}

async function createPackagingRecord(input) {
  const record = validatePackagingRecord(input);
  const existing = (await getPackagingSheetRecords()).find(item => item.date === record.date);
  const saved = await writePackagingRecordToSheet(record, existing);
  await syncPackagingTargets(saved);
  return { ok: true, record: saved };
}

async function writePackagingRecordToSheet(record, existing = null) {
  const accessToken = await getAccessToken();
  const sheetId = await getPackagingSheetId(accessToken);
  const serial = Math.round((Date.parse(`${record.date}T00:00:00Z`) - Date.UTC(1899, 11, 30)) / 86_400_000);
  const receipt = `${packagingReceiptPrefix}${JSON.stringify({ id: record.id, requestId: record.requestId, workstationId: record.workstationId, createdAt: new Date().toISOString() })}`;
  const cells = [
    { userEnteredValue: { numberValue: serial }, note: receipt, userEnteredFormat: { numberFormat: { type: "DATE", pattern: "dd.MM.yyyy" } } },
    ...packagingKeys.map(key => ({ userEnteredValue: { numberValue: record.values[key] } }))
  ];
  let rowNumber = existing?.rowNumber ?? (await getNextPackagingRowNumber());
  const requests = [];
  if (!existing && rowNumber > 3) {
    requests.push({ insertDimension: {
      range: { sheetId, dimension: "ROWS", startIndex: rowNumber - 1, endIndex: rowNumber }, inheritFromBefore: true
    } });
    rowNumber += 1;
  }
  if (!existing && rowNumber > 3) {
    requests.push({ copyPaste: {
      source: { sheetId, startRowIndex: rowNumber - 2, endRowIndex: rowNumber - 1, startColumnIndex: 0, endColumnIndex: 12 },
      destination: { sheetId, startRowIndex: rowNumber - 1, endRowIndex: rowNumber, startColumnIndex: 0, endColumnIndex: 12 },
      pasteType: "PASTE_FORMAT", pasteOrientation: "NORMAL"
    } });
  }
  requests.push({ updateCells: { start: { sheetId, rowIndex: rowNumber - 1, columnIndex: 0 }, rows: [{ values: cells }], fields: "userEnteredValue,note,userEnteredFormat.numberFormat" } });
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(packagingSpreadsheetId)}:batchUpdate`, {
    method: "POST", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ requests }),
    signal: AbortSignal.timeout(20_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось записать расход упаковки");
  return { id: `packaging-day-${record.date}`, requestId: record.requestId, rowNumber, date: record.date, values: record.values };
}

async function deletePackagingRecord(input) {
  const id = String(input?.id || ""); if (!/^packaging-day-\d{4}-\d{2}-\d{2}$/.test(id)) throw new Error("Некорректный идентификатор дневной записи");
  const date = id.slice("packaging-day-".length);
  const emptyRecord = { date, values: Object.fromEntries(packagingKeys.map(key => [key, 0])) };
  const pending = readPackagingPendingRecords();
  if (pending.some(item => item.date === date)) {
    writePackagingPendingRecords(pending.filter(item => item.date !== date));
    await syncPackagingTargets(emptyRecord);
    return { ok: true };
  }
  const record = (await getPackagingSheetRecords()).find(item => item.id === id);
  if (record) {
    const accessToken = await getAccessToken(); const sheetId = await getPackagingSheetId(accessToken);
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(packagingSpreadsheetId)}:batchUpdate`, { method: "POST", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" }, body: JSON.stringify({ requests: [{ deleteDimension: { range: { sheetId, dimension: "ROWS", startIndex: record.rowNumber - 1, endIndex: record.rowNumber } } }] }), signal: AbortSignal.timeout(20_000) });
    const payload = await response.json().catch(() => ({})); if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось удалить дневной расход упаковки");
  }
  await syncPackagingTargets(emptyRecord);
  return { ok: true };
}

async function getPackagingWarehouseSnapshot() {
  const [rows = [], summaryRows = []] = await getGoogleSheetRanges(packagingWarehouseSpreadsheetId, [packagingWarehouseRange, packagingWarehouseSummaryRange]);
  return {
    ok: true,
    records: rows.map((row, index) => packagingWarehouseRecordFromRow(row, index + 6)).filter(Boolean),
    summary: summaryRows.map(packagingWarehouseSummaryFromRow).filter(Boolean)
  };
}

async function savePackagingWarehouseRecord(input) {
  const record = validatePackagingWarehouseRecord(input);
  const accessToken = await getAccessToken();
  const sheetId = await getSheetId(packagingWarehouseSpreadsheetId, packagingWarehouseSheetName, accessToken);
  const serial = Math.round((Date.parse(`${record.date}T00:00:00Z`) - Date.UTC(1899, 11, 30)) / 86_400_000);
  const cells = [
    { userEnteredValue: { numberValue: serial }, userEnteredFormat: { numberFormat: { type: "DATE", pattern: "dd.MM.yyyy" } } },
    { userEnteredValue: { stringValue: record.type } }, { userEnteredValue: { stringValue: record.item } },
    { userEnteredValue: { numberValue: record.quantity } }, { userEnteredValue: { stringValue: record.author } },
    { userEnteredValue: { stringValue: record.note } }
  ];
  const request = record.rowNumber
    ? { updateCells: { start: { sheetId, rowIndex: record.rowNumber - 1, columnIndex: 0 }, rows: [{ values: cells }], fields: "userEnteredValue,userEnteredFormat.numberFormat" } }
    : { appendCells: { sheetId, rows: [{ values: cells }], fields: "userEnteredValue,userEnteredFormat.numberFormat" } };
  await batchGoogleSheetRequests(packagingWarehouseSpreadsheetId, accessToken, [request], "Не удалось сохранить движение склада упаковки");
  return { ok: true };
}

async function deletePackagingWarehouseRecord(input) {
  const rowNumber = warehouseRowNumber(input?.id);
  const accessToken = await getAccessToken();
  const sheetId = await getSheetId(packagingWarehouseSpreadsheetId, packagingWarehouseSheetName, accessToken);
  await batchGoogleSheetRequests(packagingWarehouseSpreadsheetId, accessToken, [{ deleteDimension: { range: { sheetId, dimension: "ROWS", startIndex: rowNumber - 1, endIndex: rowNumber } } }], "Не удалось удалить движение склада упаковки");
  return { ok: true };
}

function validatePackagingWarehouseRecord(input) {
  const date = String(input?.date || ""); const type = String(input?.type || ""); const item = String(input?.item || "");
  const quantity = Number(input?.quantity); const note = String(input?.note || "").trim(); const author = String(input?.author || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw new Error("Некорректная дата движения склада");
  if (!["Приход", "Расход"].includes(type) || !item || !Number.isInteger(quantity) || quantity <= 0 || note.length > 500 || !author) throw new Error("Проверьте операцию, наименование и количество");
  const id = String(input?.id || ""); return { date, type, item, quantity, note, author, rowNumber: id ? warehouseRowNumber(id) : null };
}

function warehouseRowNumber(id) { const match = String(id || "").match(/^warehouse-(\d{1,4})$/); if (!match || Number(match[1]) < 6) throw new Error("Некорректный идентификатор движения склада"); return Number(match[1]); }
function packagingWarehouseRecordFromRow(row, rowNumber) { const date = googleSheetDate(row?.[0]); const type = String(row?.[1] || ""); const item = String(row?.[2] || ""); const quantity = Number(row?.[3] || 0); if (!date || !["Приход", "Расход"].includes(type) || !item || !Number.isFinite(quantity) || quantity <= 0) return null; return { id: `warehouse-${rowNumber}`, rowNumber, date, type, item, quantity, author: String(row?.[4] || ""), note: String(row?.[5] || "") }; }
function packagingWarehouseSummaryFromRow(row) { const item = String(row?.[0] || "").trim(); if (!item) return null; const number = index => { const value = String(row?.[index] ?? "").trim().replace(",", "."); return value === "" ? null : (Number.isFinite(Number(value)) ? Number(value) : null); }; return { item, unit: String(row?.[1] || "").trim(), opening: number(2) ?? 0, received: number(3) ?? 0, issued: number(4) ?? 0, calculated: number(5) ?? 0, actual: number(6), difference: number(7), note: String(row?.[8] || "").trim() }; }

async function getPpeWarehouseSnapshot() {
  const [summaryResult, journalResult] = await Promise.allSettled([
    getGoogleSheetRanges(ppeWarehouseSpreadsheetId, [ppeWarehouseSummaryRange]),
    getGoogleSheetRanges(ppeJournalSpreadsheetId, [ppeJournalRange])
  ]);
  if (summaryResult.status === "rejected") throw ppeAccessError(summaryResult.reason, "таблице остатков СИЗ («Сводная»)");
  const [summaryRows = []] = summaryResult.value;
  if (journalResult.status === "rejected") {
    return {
      ok: true,
      items: ppeSummaryItems(summaryRows),
      records: [],
      warning: "Нет доступа к промежуточному журналу выдач СИЗ. Остатки показаны, но выдача временно недоступна. Откройте для учётной записи центрального компьютера доступ редактора к таблице «Склад СИЗ»."
    };
  }
  const [journalRows = []] = journalResult.value;
  return { ok: true, items: ppeSummaryItems(summaryRows), records: journalRows.map((row, index) => ppeJournalRecord(row, index + 2)).filter(Boolean) };
}

function ppeAccessError(cause, target) {
  const error = new Error(String(cause?.message || "Google отклонил запрос"));
  error.statusCode = 503;
  error.publicMessage = `Нет доступа к ${target}. Откройте для учётной записи центрального компьютера доступ редактора и обновите страницу.`;
  return error;
}

async function createPpeWarehouseIssue(input) {
  const record = validatePpeWarehouseIssue(input);
  const [summaryRows = [], targetRows = [], journalRows = []] = await Promise.all([
    getGoogleSheetRanges(ppeWarehouseSpreadsheetId, [ppeWarehouseSummaryRange]).then(rows => rows[0] || []),
    getGoogleSheetRanges(ppeWarehouseSpreadsheetId, [ppeWarehouseTargetRange]).then(rows => rows[0] || []),
    getGoogleSheetRanges(ppeJournalSpreadsheetId, [ppeJournalRange]).then(rows => rows[0] || [])
  ]);
  const existingIndex = journalRows.findIndex(row => String(row?.[0] || "") === record.id);
  if (existingIndex >= 0) return syncPpeWarehouseIssue(ppeJournalRecord(journalRows[existingIndex], existingIndex + 2), summaryRows, targetRows);
  const item = ppeSummaryItems(summaryRows).find(row => row.item === record.item);
  if (!item) throw new Error("Выберите позицию из текущего остатка склада СИЗ");
  if (record.quantity > item.quantity) throw new Error(`На складе доступно только ${item.quantity} ${item.unit || "шт."}`);
  const destination = ppeTargetDestination(record, targetRows);
  const accessToken = await getAccessToken();
  const sheetId = await getSheetId(ppeJournalSpreadsheetId, ppeJournalSheetName, accessToken);
  const values = [
    record.id, displayDate(record.date), record.item, item.unit, record.quantity, record.author, record.note,
    destination.month, "В очереди", "Фасовка", destination.columnLetter, new Date().toISOString(), "", ""
  ].map(value => ({ userEnteredValue: typeof value === "number" ? { numberValue: value } : { stringValue: String(value) } }));
  await batchGoogleSheetRequests(ppeJournalSpreadsheetId, accessToken, [{ appendCells: { sheetId, rows: [{ values }], fields: "userEnteredValue" } }], "Не удалось сохранить выдачу в промежуточном журнале СИЗ");
  const [updatedJournalRows = []] = await getGoogleSheetRanges(ppeJournalSpreadsheetId, [ppeJournalRange]);
  const savedIndex = updatedJournalRows.findIndex(row => String(row?.[0] || "") === record.id);
  if (savedIndex < 0) throw new Error("Выдача сохранена в журнале СИЗ, но не найдена для передачи");
  return syncPpeWarehouseIssue(ppeJournalRecord(updatedJournalRows[savedIndex], savedIndex + 2), summaryRows, targetRows);
}

async function retryPpeWarehouseIssue(input) {
  const id = String(input?.id || "");
  if (!/^[a-zA-Z0-9_-]{8,160}$/.test(id)) throw new Error("Некорректный идентификатор выдачи СИЗ");
  const [summaryRows = [], targetRows = [], journalRows = []] = await Promise.all([
    getGoogleSheetRanges(ppeWarehouseSpreadsheetId, [ppeWarehouseSummaryRange]).then(rows => rows[0] || []),
    getGoogleSheetRanges(ppeWarehouseSpreadsheetId, [ppeWarehouseTargetRange]).then(rows => rows[0] || []),
    getGoogleSheetRanges(ppeJournalSpreadsheetId, [ppeJournalRange]).then(rows => rows[0] || [])
  ]);
  const index = journalRows.findIndex(row => String(row?.[0] || "") === id);
  if (index < 0) throw new Error("Запись не найдена в промежуточном журнале СИЗ");
  const record = ppeJournalRecord(journalRows[index], index + 2);
  if (!record || record.status === "Отправлено") return { ok: true, status: "Отправлено" };
  if (!["В очереди", "Ошибка"].includes(record.status)) throw new Error("Эта выдача требует ручной проверки: повторная отправка может задвоить расход");
  return syncPpeWarehouseIssue(record, summaryRows, targetRows);
}

async function syncPpeWarehouseIssue(record, summaryRows, targetRows) {
  const destination = ppeTargetDestination(record, targetRows);
  const accessToken = await getAccessToken();
  const journalSheetId = await getSheetId(ppeJournalSpreadsheetId, ppeJournalSheetName, accessToken);
  let targetWritten = false;
  try {
    await batchGoogleSheetRequests(ppeJournalSpreadsheetId, accessToken, [{ updateCells: { start: { sheetId: journalSheetId, rowIndex: record.rowNumber - 1, columnIndex: 8 }, rows: [{ values: [{ userEnteredValue: { stringValue: "Отправляется" } }, { userEnteredValue: { stringValue: "Фасовка" } }, { userEnteredValue: { stringValue: destination.columnLetter } }] }], fields: "userEnteredValue" } }], "Не удалось отметить выдачу СИЗ перед передачей");
    const targetSheetId = await getSheetId(ppeWarehouseSpreadsheetId, "Фасовка", accessToken);
    const previous = googleNumber(targetRows[destination.rowNumber - 1]?.[destination.columnIndex]) || 0;
    await batchGoogleSheetRequests(ppeWarehouseSpreadsheetId, accessToken, [{ updateCells: { start: { sheetId: targetSheetId, rowIndex: destination.rowNumber - 1, columnIndex: destination.columnIndex }, rows: [{ values: [{ userEnteredValue: { numberValue: previous + record.quantity } }] }], fields: "userEnteredValue" } }], "Не удалось внести расход в лист «Фасовка»");
    targetWritten = true;
    await batchGoogleSheetRequests(ppeJournalSpreadsheetId, accessToken, [{ updateCells: { start: { sheetId: journalSheetId, rowIndex: record.rowNumber - 1, columnIndex: 8 }, rows: [{ values: [{ userEnteredValue: { stringValue: "Отправлено" } }, { userEnteredValue: { stringValue: "Фасовка" } }, { userEnteredValue: { stringValue: destination.columnLetter } }, {}, { userEnteredValue: { stringValue: new Date().toISOString() } }, { userEnteredValue: { stringValue: "" } }] }], fields: "userEnteredValue" } }], "Не удалось подтвердить передачу выдачи СИЗ");
    return { ok: true, status: "Отправлено" };
  } catch (error) {
    const message = String(error?.message || "Не удалось передать выдачу в лист «Фасовка»");
    const status = targetWritten ? "Требует проверки" : "Ошибка";
    await batchGoogleSheetRequests(ppeJournalSpreadsheetId, accessToken, [{ updateCells: { start: { sheetId: journalSheetId, rowIndex: record.rowNumber - 1, columnIndex: 8 }, rows: [{ values: [{ userEnteredValue: { stringValue: status } }, {}, {}, {}, {}, { userEnteredValue: { stringValue: message } }] }], fields: "userEnteredValue" } }], "Не удалось сохранить ошибку промежуточного журнала СИЗ").catch(() => {});
    return { ok: true, status, message };
  }
}

function validatePpeWarehouseIssue(input) {
  const date = String(input?.date || ""); const item = String(input?.item || "").trim(); const quantity = Number(input?.quantity); const note = String(input?.note || "").trim(); const author = String(input?.author || "").trim(); const id = String(input?.id || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw new Error("Некорректная дата выдачи СИЗ");
  if (!item || !Number.isInteger(quantity) || quantity <= 0 || note.length > 500 || !author || !/^[a-zA-Z0-9_-]{8,160}$/.test(id)) throw new Error("Проверьте позицию, количество и примечание выдачи СИЗ");
  return { id, date, item, quantity, note, author };
}

function ppeSummaryItems(rows) {
  const header = rows[0] || [];
  const balanceColumns = header.map((value, index) => /^остаток/i.test(String(value || "").trim()) ? index : -1).filter(index => index >= 0);
  const balanceColumn = balanceColumns.at(-1);
  if (balanceColumn === undefined) throw new Error("В листе «Сводная» не найден столбец остатка СИЗ");
  return rows.slice(1).map(row => ({ item: String(row?.[0] || "").trim(), unit: String(row?.[1] || "").trim(), quantity: googleNumber(row?.[balanceColumn]) })).filter(row => row.item && Number.isFinite(row.quantity));
}

function ppeTargetDestination(record, targetRows) {
  const header = targetRows[0] || [];
  const month = ppeMonthNames[Number(String(record.date).slice(5, 7)) - 1];
  const year = String(record.date).slice(0, 4);
  const columnIndex = header.findIndex(value => String(value || "").trim().toLocaleLowerCase("ru").includes(`расход ${month} ${year}`));
  const rowIndex = targetRows.findIndex((row, index) => index > 0 && String(row?.[0] || "").trim() === record.item);
  if (columnIndex < 0) throw new Error(`В листе «Фасовка» нет столбца «Расход ${month} ${year}»`);
  if (rowIndex < 0) throw new Error(`Позиция «${record.item}» не найдена в листе «Фасовка»`);
  return { rowNumber: rowIndex + 1, columnIndex, columnLetter: columnName(columnIndex), month: `${month[0].toUpperCase()}${month.slice(1)} ${year}` };
}

function ppeJournalRecord(row, rowNumber) {
  const id = String(row?.[0] || "").trim(); const date = googleSheetDate(row?.[1]); const item = String(row?.[2] || "").trim(); const quantity = googleNumber(row?.[4]);
  if (!id || !date || !item || !Number.isFinite(quantity) || quantity <= 0) return null;
  return { id, rowNumber, date, item, unit: String(row?.[3] || ""), quantity, author: String(row?.[5] || ""), note: String(row?.[6] || ""), month: String(row?.[7] || ""), status: String(row?.[8] || "В очереди"), targetColumn: String(row?.[10] || ""), error: String(row?.[13] || "") };
}

function columnName(index) { let value = index + 1, result = ""; while (value) { const mod = (value - 1) % 26; result = String.fromCharCode(65 + mod) + result; value = Math.floor((value - mod - 1) / 26); } return result; }

async function getNonconformitySnapshot() {
  const [journalRows, dictionaryRows] = await getGoogleSheetRanges(nonconformitySpreadsheetId, [nonconformityRange, nonconformityDictionaryRange]);
  const rows = journalRows ?? [];
  const headers = rows[0] ?? [];
  if (headers.length < 8 || String(headers[0]).trim() !== "Дата" || String(headers[1]).trim() !== "Время" || String(headers[2]).trim() !== "Смена" || String(headers[7]).trim() !== "Кто сделал запись") throw new Error("Изменилась структура журнала несоответствий");
  return { ok: true, records: rows.slice(1).map((row, index) => nonconformityRecordFromRow(row, index + 3)).filter(Boolean), dictionary: { categories: (dictionaryRows ?? []).slice(1).map((row, index) => ({ id: "nonconformity-dictionary-" + (index + 3), category: String(row[0] || "").trim(), type: String(row[1] || "").trim(), active: String(row[2] || "").trim().toLowerCase() !== "нет" })).filter(item => item.category && item.type && item.active) } };
}

function nonconformityRecordFromRow(row, rowNumber) {
  if (!row?.some(value => String(value || "").trim())) return null;
  const date = googleSheetDate(row[0]);
  if (!date) throw new Error("Проверьте дату в строке " + rowNumber + " журнала несоответствий");
  return { id: "nonconformity-" + rowNumber, rowNumber, date, time: String(row[1] || "").trim(), shift: String(row[2] || "").trim(), category: String(row[3] || "").trim(), type: String(row[4] || "").trim(), cause: String(row[5] || "").trim(), correctiveAction: String(row[6] || "").trim(), reportedBy: String(row[7] || "").trim() };
}

function validateNonconformityRecord(input) {
  const text = (key, label, limit = 5000) => { const value = String(input?.[key] || "").trim(); if (!value) throw new Error("Заполните поле «" + label + "»"); if (value.length > limit) throw new Error("Поле «" + label + "» слишком длинное"); return value; };
  const date = String(input?.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw new Error("Некорректная дата несоответствия");
  const time = String(input?.time || "");
  if (time && !/^\d{2}:\d{2}$/.test(time)) throw new Error("Некорректное время несоответствия");
  const shift = text("shift", "Смена", 2).toUpperCase();
  if (!["A", "B"].includes(shift)) throw new Error("Смена должна быть A или B");
  return { date, time, shift, category: text("category", "Категория несоответствия", 180), type: text("type", "Вид несоответствия", 500), cause: text("cause", "Предполагаемая причина появления"), correctiveAction: text("correctiveAction", "Корректирующие действия"), reportedBy: text("reportedBy", "Кто сделал запись", 180) };
}

async function createNonconformityRecord(input) {
  const clock = vilniusClock();
  const record = validateNonconformityRecord({ ...input, date: clock.date, time: `${clock.hour}:${clock.minute}` });
  const accessToken = await getAccessToken();
  const endpoint = "https://sheets.googleapis.com/v4/spreadsheets/" + encodeURIComponent(nonconformitySpreadsheetId) + "/values/" + encodeURIComponent("'Журнал'!A:H") + ":append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS";
  const response = await fetch(endpoint, { method: "POST", headers: { Authorization: "Bearer " + accessToken, "Content-Type": "application/json" }, body: JSON.stringify({ values: [[displayDate(record.date), record.time, record.shift, record.category, record.type, record.cause, record.correctiveAction, record.reportedBy]] }), signal: AbortSignal.timeout(20_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось внести несоответствие");
  const rowNumber = Number(String(payload.updates?.updatedRange || "").match(/!(?:[A-Z]+)(\d+):/)?.[1]);
  return { ok: true, record: { ...record, id: "nonconformity-" + rowNumber, rowNumber } };
}

async function updateNonconformityRecord(input) {
  const record = validateNonconformityRecord(input);
  const id = String(input?.id || "");
  const rowNumber = Number(id.match(/^nonconformity-(\d+)$/)?.[1]);
  if (!Number.isInteger(rowNumber) || rowNumber < 3) throw new Error("Некорректный идентификатор записи");
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(nonconformitySpreadsheetId, accessToken, [{ range: "'Журнал'!A" + rowNumber + ":H" + rowNumber, values: [[displayDate(record.date), record.time, record.shift, record.category, record.type, record.cause, record.correctiveAction, record.reportedBy]] }]);
  return { ok: true, record: { ...record, id, rowNumber } };
}

async function deleteNonconformityRecord(input) {
  const rowNumber = Number(String(input?.id || "").match(/^nonconformity-(\d+)$/)?.[1]);
  if (!Number.isInteger(rowNumber) || rowNumber < 3) throw new Error("Некорректный идентификатор записи");
  const accessToken = await getAccessToken();
  const sheetId = await getSheetId(nonconformitySpreadsheetId, nonconformitySheetName, accessToken);
  const response = await fetch("https://sheets.googleapis.com/v4/spreadsheets/" + encodeURIComponent(nonconformitySpreadsheetId) + ":batchUpdate", { method: "POST", headers: { Authorization: "Bearer " + accessToken, "Content-Type": "application/json" }, body: JSON.stringify({ requests: [{ deleteDimension: { range: { sheetId, dimension: "ROWS", startIndex: rowNumber - 1, endIndex: rowNumber } } }] }), signal: AbortSignal.timeout(20_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось удалить несоответствие");
  return { ok: true };
}

function validateNonconformityDictionaryEntry(input) {
  const category = String(input?.category || "").trim();
  const type = String(input?.type || "").trim();
  if (!category || category.length > 180) throw new Error("Укажите категорию несоответствия");
  if (!type || type.length > 500) throw new Error("Укажите вид несоответствия");
  return { category, type };
}

async function createNonconformityDictionaryEntry(input) {
  const entry = validateNonconformityDictionaryEntry(input);
  const snapshot = await getNonconformitySnapshot();
  if (snapshot.dictionary.categories.some(item => item.category === entry.category && item.type === entry.type)) throw new Error("Такой вид уже есть в справочнике");
  const accessToken = await getAccessToken();
  const endpoint = "https://sheets.googleapis.com/v4/spreadsheets/" + encodeURIComponent(nonconformitySpreadsheetId) + "/values/" + encodeURIComponent("'Справочник несоответсвий'!A:C") + ":append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS";
  const response = await fetch(endpoint, { method: "POST", headers: { Authorization: "Bearer " + accessToken, "Content-Type": "application/json" }, body: JSON.stringify({ values: [[entry.category, entry.type, "Да"]] }), signal: AbortSignal.timeout(20_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось добавить вид несоответствия");
  const rowNumber = Number(String(payload.updates?.updatedRange || "").match(/!(?:[A-Z]+)(\d+):/)?.[1]);
  return { ok: true, entry: { id: "nonconformity-dictionary-" + rowNumber, ...entry } };
}

async function deleteNonconformityDictionaryEntry(input) {
  const rowNumber = Number(String(input?.id || "").match(/^nonconformity-dictionary-(\d+)$/)?.[1]);
  if (!Number.isInteger(rowNumber) || rowNumber < 3) throw new Error("Некорректный идентификатор вида несоответствия");
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(nonconformitySpreadsheetId, accessToken, [{ range: "'Справочник несоответсвий'!C" + rowNumber, values: [["Нет"]] }]);
  return { ok: true };
}

async function getIncidentSnapshot() {
  const [journalRows, directoryRows] = await getGoogleSheetRanges(incidentSpreadsheetId, [incidentRange, incidentDirectoryRange]);
  const rows = journalRows ?? [];
  const headers = rows[0] ?? [];
  if (headers.length < 11 || String(headers[0]).trim() !== "№" || String(headers[1]).trim() !== "Дата" || String(headers[6]).trim() !== "Случай" || String(headers[10]).trim() !== "Старший механик") throw new Error("Изменилась структура журнала инцидентов");
  const templates = (directoryRows ?? []).slice(1).map(incidentResponsibilityFromRow).filter(item => item?.active);
  return { ok: true, records: rows.slice(1).map((row, index) => incidentRecordFromRow(row, index + 2)).filter(Boolean), dictionary: { categories: [...new Set(templates.map(item => item.category))], templates } };
}

function incidentResponsibilityFromRow(row) {
  const category = String(row?.[1] || "").trim();
  const type = String(row?.[2] || "").trim();
  if (!category || !type || category === "Категория") return null;
  return {
    category,
    type,
    responsible: String(row?.[3] || "").trim(),
    explanation: String(row?.[4] || "").trim(),
    severity: String(row?.[5] || "").trim(),
    active: String(row?.[6] || "").trim() === "Активен",
    detectionAndFix: String(row?.[7] || "").trim(),
    notify: String(row?.[8] || "").trim(),
    note: String(row?.[9] || "").trim(),
    immediateAction: String(row?.[10] || "").trim(),
    reporter: "Старший механик вносит запись в журнал после проверки фактов."
  };
}

function incidentRecordFromRow(row, rowNumber) {
  if (!row?.some(value => String(value || "").trim())) return null;
  const date = googleSheetDate(row[1]);
  if (!date) throw new Error("Проверьте дату в строке " + rowNumber + " журнала инцидентов");
  return { id: "incident-" + rowNumber, rowNumber, date, time: String(row[2] || "").trim(), shift: String(row[3] || "").trim(), equipment: String(row[4] || "").trim(), category: String(row[5] || "").trim(), type: String(row[6] || "").trim(), description: String(row[7] || "").trim(), immediateAction: String(row[8] || "").trim(), notifiedTo: String(row[9] || "").trim(), seniorMechanic: String(row[10] || "").trim() };
}

function validateIncidentRecord(input) {
  const text = (key, label, limit = 5000) => { const value = String(input?.[key] || "").trim(); if (!value) throw new Error("Заполните поле «" + label + "»"); if (value.length > limit) throw new Error("Поле «" + label + "» слишком длинное"); return value; };
  const date = String(input?.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw new Error("Некорректная дата инцидента");
  const time = text("time", "Время", 5);
  if (!/^\d{2}:\d{2}$/.test(time)) throw new Error("Время укажите в формате ЧЧ:ММ");
  const shift = text("shift", "Смена", 2).toUpperCase();
  if (!["A", "B"].includes(shift)) throw new Error("Смена должна быть A или B");
  return { date, time, shift, equipment: text("equipment", "Линия или оборудование", 180), category: text("category", "Категория", 180), type: text("type", "Случай", 1000), description: text("description", "Фактические обстоятельства"), immediateAction: text("immediateAction", "Меры старшего механика"), notifiedTo: text("notifiedTo", "Кому сообщил старший механик", 1000), seniorMechanic: text("seniorMechanic", "Старший механик", 180) };
}

function incidentValues(record) { return [displayDate(record.date), record.time, record.shift, record.equipment, record.category, record.type, record.description, record.immediateAction, record.notifiedTo, record.seniorMechanic]; }

function firstVacantIncidentRow(rows) {
  for (let index = 1; index < rows.length; index += 1) if (!String(rows[index]?.[1] || "").trim()) return index + 1;
  return Math.max(2, rows.length + 1);
}

async function createIncidentRecord(input) {
  const record = validateIncidentRecord(input);
  const accessToken = await getAccessToken();
  const [rows] = await getGoogleSheetRanges(incidentSpreadsheetId, [incidentRange]);
  const rowNumber = firstVacantIncidentRow(rows || []);
  if (rowNumber > 1000) throw new Error("В журнале инцидентов нет свободных строк");
  await setGoogleSheetRanges(incidentSpreadsheetId, accessToken, [{ range: "'Журнал инцидентов'!B" + rowNumber + ":K" + rowNumber, values: [incidentValues(record)] }]);
  return { ok: true, record: { ...record, id: "incident-" + rowNumber, rowNumber } };
}

async function updateIncidentRecord(input) {
  const record = validateIncidentRecord(input);
  const rowNumber = Number(String(input?.id || "").match(/^incident-(\d+)$/)?.[1]);
  if (!Number.isInteger(rowNumber) || rowNumber < 2) throw new Error("Некорректный идентификатор записи");
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(incidentSpreadsheetId, accessToken, [{ range: "'Журнал инцидентов'!B" + rowNumber + ":K" + rowNumber, values: [incidentValues(record)] }]);
  return { ok: true, record: { ...record, id: "incident-" + rowNumber, rowNumber } };
}

async function deleteIncidentRecord(input) {
  const rowNumber = Number(String(input?.id || "").match(/^incident-(\d+)$/)?.[1]);
  if (!Number.isInteger(rowNumber) || rowNumber < 2) throw new Error("Некорректный идентификатор записи");
  const accessToken = await getAccessToken();
  await setGoogleSheetRanges(incidentSpreadsheetId, accessToken, [{ range: "'Журнал инцидентов'!B" + rowNumber + ":K" + rowNumber, values: [Array(10).fill("")] }]);
  return { ok: true };
}

async function getShiftTaskSnapshot() {
  const [rows] = await getGoogleSheetRanges(shiftTaskSpreadsheetId, [shiftTaskRange]);
  const values = rows || [];
  const headers = values[0] || [];
  if (headers.length < 14 || String(headers[0]).trim() !== "ID" || String(headers[2]).trim() !== "Задание" || String(headers[3]).trim() !== "Статус" || String(headers[10]).trim() !== "Фото" || String(headers[11]).trim() !== "Для смены") {
    throw new Error("Изменилась структура таблицы «Сменное задание»");
  }
  return { ok: true, records: values.slice(1).map((row, index) => shiftTaskFromRow(row, index + 2)).filter(Boolean) };
}

function shiftTaskFromRow(row, rowNumber) {
  if (!row?.some(value => String(value || "").trim())) return null;
  const id = String(row[0] || "").trim();
  const task = String(row[2] || "").trim();
  if (!id || !task) throw new Error(`Проверьте строку ${rowNumber} таблицы «Сменное задание»`);
  const status = String(row[3] || "Открыто").trim();
  const photoUrl = String(row[10] || "").trim();
  const shiftTarget = normalizeShiftTaskTarget(row[11]);
  const completionA = String(row[12] || "").trim();
  const completionB = String(row[13] || "").trim();
  return { id, rowNumber, createdDate: googleSheetDate(row[1]), task, status: shiftTarget === "A и B" && !(completionA && completionB) ? "Открыто" : status, completedBy: String(row[4] || "").trim(), completedDate: googleSheetDate(row[5]), completionNote: String(row[6] || "").trim(), createdBy: String(row[7] || "").trim(), revision: Number(row[8] || 0), updatedAt: String(row[9] || ""), photoUrl, photoFileId: shiftTaskPhotoFileId(photoUrl), shiftTarget, completionA, completionB };
}

function normalizeShiftTaskTarget(value) {
  const target = String(value || "").trim();
  return ["A", "B", "A,B", "A и B"].includes(target) ? target : "A,B";
}

function validateShiftTaskCreate(input) {
  const task = String(input?.task || "").trim();
  if (!task || task.length > 5000) throw new Error("Заполните задание: не более 5000 символов");
  if (/^[=+@-]/.test(task)) throw new Error("Некорректный текст задания");
  return task;
}

function validateShiftTaskPhoto(input) {
  if (!input) return null;
  const match = String(input.dataUrl || "").match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/i);
  if (!match) throw new Error("Прикрепите фотографию в формате JPG, PNG или WebP");
  const bytes = Buffer.from(match[2], "base64");
  if (!bytes.length || bytes.length > maximumShiftTaskPhotoBytes) throw new Error("Размер фотографии не должен превышать 8 МБ");
  const mimeType = match[1].toLowerCase();
  return { bytes, mimeType, extension: mimeType === "image/jpeg" ? "jpg" : mimeType.slice("image/".length) };
}

function shiftTaskValues(record) {
  return [record.id, displayDate(record.createdDate), record.task, record.status, record.completedBy, record.completedDate ? displayDate(record.completedDate) : "", record.completionNote, record.createdBy, record.revision, record.updatedAt, record.photoUrl || "", record.shiftTarget, record.completionA || "", record.completionB || ""];
}

async function createShiftTask(input, actor) {
  const task = validateShiftTaskCreate(input);
  const photo = validateShiftTaskPhoto(input?.photo);
  const shiftTarget = normalizeShiftTaskTarget(input?.shiftTarget);
  const now = vilniusDateTime();
  const record = { id: `shift-task-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`, createdDate: vilniusDate(), task, status: "Открыто", completedBy: "", completedDate: "", completionNote: "", createdBy: actor.performer || actor.title || actor.id, revision: 1, updatedAt: now, photoUrl: "", photoFileId: "", shiftTarget, completionA: "", completionB: "" };
  const accessToken = await getAccessToken();
  if (photo) {
    const uploaded = await uploadShiftTaskPhoto(accessToken, record, photo);
    record.photoFileId = uploaded.id;
    record.photoUrl = `https://drive.google.com/file/d/${uploaded.id}/view`;
  }
  const endpoint = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(shiftTaskSpreadsheetId)}/values/${encodeURIComponent("'Сменное задание'!A:N")}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`;
  const response = await fetch(endpoint, { method: "POST", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" }, body: JSON.stringify({ values: [shiftTaskValues(record)] }), signal: AbortSignal.timeout(20_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (record.photoFileId) await deleteDriveFile(accessToken, record.photoFileId).catch(() => {});
    throw googleError(response.status, payload?.error?.message || "Не удалось сохранить сменное задание");
  }
  const rowNumber = Number(String(payload.updates?.updatedRange || "").match(/!(?:[A-Z]+)(\d+):/)?.[1]);
  return { ok: true, record: { ...record, rowNumber } };
}

function shiftTaskPhotoFileId(photoUrl) {
  return String(photoUrl || "").match(/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)/)?.[1] || "";
}

function readShiftTaskPhotoFolderId() {
  if (!existsSync(shiftTaskPhotoFolderPath)) return "";
  try {
    return String(JSON.parse(readFileSync(shiftTaskPhotoFolderPath, "utf8"))?.folderId || "").trim();
  } catch {
    return "";
  }
}

function saveShiftTaskPhotoFolderId(folderId) {
  mkdirSync(dirname(shiftTaskPhotoFolderPath), { recursive: true });
  const temporaryPath = `${shiftTaskPhotoFolderPath}.${process.pid}.tmp`;
  writeFileSync(temporaryPath, JSON.stringify({ folderId }), "utf8");
  renameSync(temporaryPath, shiftTaskPhotoFolderPath);
}

async function getShiftTaskPhotoFolderId(accessToken) {
  const cached = readShiftTaskPhotoFolderId();
  if (cached) return cached;
  const response = await fetch("https://www.googleapis.com/drive/v3/files", {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ name: "PFH · Фото сменных заданий", mimeType: "application/vnd.google-apps.folder" }),
    signal: AbortSignal.timeout(20_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || !payload?.id) throw googleError(response.status, payload?.error?.message || "Не удалось создать папку для фотографий сменных заданий");
  saveShiftTaskPhotoFolderId(payload.id);
  return payload.id;
}

async function uploadShiftTaskPhoto(accessToken, record, photo) {
  const folderId = await getShiftTaskPhotoFolderId(accessToken);
  const boundary = `pfh-${randomBytes(18).toString("hex")}`;
  const metadata = Buffer.from(JSON.stringify({
    name: `Сменное задание ${displayDate(record.createdDate)} — ${record.id}.${photo.extension}`,
    mimeType: photo.mimeType,
    parents: [folderId]
  }), "utf8");
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`, "utf8"), metadata,
    Buffer.from(`\r\n--${boundary}\r\nContent-Type: ${photo.mimeType}\r\n\r\n`, "utf8"), photo.bytes,
    Buffer.from(`\r\n--${boundary}--\r\n`, "utf8")
  ]);
  const response = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id", {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": `multipart/related; boundary=${boundary}` },
    body,
    signal: AbortSignal.timeout(45_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || !payload?.id) throw googleError(response.status, payload?.error?.message || "Не удалось загрузить фотографию");
  return payload;
}

async function deleteDriveFile(accessToken, fileId) {
  const response = await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`, { method: "DELETE", headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(20_000) });
  if (!response.ok && response.status !== 404) throw googleError(response.status, "Не удалось удалить фотографию без задания");
}

async function sendShiftTaskPhoto(response, photoFileId) {
  if (!/^[A-Za-z0-9_-]{10,}$/.test(photoFileId)) {
    const error = new Error("Фотография не найдена");
    error.statusCode = 404;
    throw error;
  }
  const snapshot = await getShiftTaskSnapshot();
  if (!snapshot.records.some(record => record.photoFileId === photoFileId)) {
    const error = new Error("Фотография не найдена");
    error.statusCode = 404;
    throw error;
  }
  const accessToken = await getAccessToken();
  const download = await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(photoFileId)}?alt=media`, { headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(45_000) });
  if (!download.ok || !download.body) throw googleError(download.status, "Не удалось открыть фотографию");
  response.writeHead(200, { "Content-Type": download.headers.get("content-type") || "image/jpeg", "Cache-Control": "private, max-age=300", "X-Content-Type-Options": "nosniff" });
  for await (const chunk of download.body) response.write(chunk);
  response.end();
}

async function updateShiftTask(input, actor) {
  if (actor.role === "senior") {
    const allowedFields = new Set(["id", "expectedRevision", "status", "shiftCode", "completionNote"]);
    const forbiddenField = Object.keys(input || {}).find(field => !allowedFields.has(field));
    if (forbiddenField || input?.status !== "Выполнено") {
      const error = new Error("Старший механик может только отметить выполнение задания");
      error.statusCode = 403;
      throw error;
    }
  }
  const snapshot = await getShiftTaskSnapshot();
  const current = snapshot.records.find(record => record.id === String(input?.id || ""));
  if (!current) throw new Error("Сменное задание не найдено");
  if (input?.expectedRevision !== undefined && Number(input.expectedRevision) !== Number(current.revision)) {
    const error = new Error("Задание уже изменили на другом компьютере. Обновите журнал и повторите действие.");
    error.statusCode = 409;
    throw error;
  }
  const complete = input?.status === "Выполнено";
  if (!["Открыто", "Выполнено"].includes(String(input?.status || ""))) throw new Error("Выберите статус задания");
  if (actor.role === "senior" && !complete) throw new Error("Старший механик может отметить только выполнение задания");
  const task = actor.role === "manager" ? validateShiftTaskCreate({ task: input?.task || current.task }) : current.task;
  const note = String(input?.completionNote || "").trim();
  if (note.length > 5000) throw new Error("Примечание слишком длинное");
  if (/^[=+@-]/.test(note)) throw new Error("Некорректный текст примечания");
  const now = vilniusDateTime();
  const record = { ...current, task, completionNote: note, revision: Number(current.revision || 0) + 1, updatedAt: now };
  if (!complete) {
    record.status = "Открыто";
    record.completedBy = "";
    record.completedDate = "";
  } else if (current.shiftTarget === "A и B") {
    const shiftCode = String(input?.shiftCode || "").trim();
    if (!["A", "B"].includes(shiftCode)) throw new Error("Отметку можно сделать только из смены A или B");
    const mark = `${actor.performer || actor.title || actor.id} · ${now}`;
    if (shiftCode === "A") record.completionA = mark;
    else record.completionB = mark;
    const completeForBoth = Boolean(record.completionA && record.completionB);
    record.status = completeForBoth ? "Выполнено" : "Открыто";
    record.completedBy = completeForBoth ? `${record.completionA}; ${record.completionB}` : "";
    record.completedDate = completeForBoth ? vilniusDate() : "";
  } else {
    record.status = "Выполнено";
    record.completedBy = actor.performer || actor.title || actor.id;
    record.completedDate = vilniusDate();
  }
  const accessToken = await getAccessToken();
  await setShiftTaskRow(accessToken, current.rowNumber, record);
  return { ok: true, record };
}

async function deleteShiftTask(input) {
  const snapshot = await getShiftTaskSnapshot();
  const current = snapshot.records.find(record => record.id === String(input?.id || ""));
  if (!current) throw new Error("Сменное задание не найдено");
  if (input?.expectedRevision !== undefined && Number(input.expectedRevision) !== Number(current.revision)) {
    const error = new Error("Задание уже изменили на другом компьютере. Обновите журнал и повторите действие.");
    error.statusCode = 409;
    throw error;
  }
  const accessToken = await getAccessToken();
  const sheetId = await getSheetId(shiftTaskSpreadsheetId, shiftTaskSheetName, accessToken);
  await batchGoogleSheetRequests(shiftTaskSpreadsheetId, accessToken, [{ deleteDimension: { range: { sheetId, dimension: "ROWS", startIndex: current.rowNumber - 1, endIndex: current.rowNumber } } }], "Не удалось удалить сменное задание");
  return { ok: true };
}

async function exportPackagingDaily(input) {
  const date = String(input?.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date >= vilniusDate()) throw new Error("Передавать можно только завершённый день");
  const source = (await getPackagingSnapshot()).records.find(record => record.date === date);
  if (!source) throw new Error(`В журнале упаковки нет итогов за ${displayDate(date)}`);
  return syncPackagingTargets(source);
}

async function syncPackagingTargets(source) {
  const date = String(source?.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Некорректная дата переноса расхода упаковки");
  const targetValues = packagingTargetValues(source.values);
  const [rawRow, cansRow] = await Promise.all([
    getDailyTargetRow(rawMaterialsSpreadsheetId, rawMaterialsRange, date, 3, "Расход сырья"),
    getDailyTargetRow(cansSpreadsheetId, cansRange, date, 4, "Банки")
  ]);
  const accessToken = await getAccessToken();
  const [rawSheetId, cansSheetId] = await Promise.all([
    getSheetId(rawMaterialsSpreadsheetId, rawMaterialsSheetName, accessToken),
    getSheetId(cansSpreadsheetId, cansSheetName, accessToken)
  ]);
  // Write exact daily totals rather than deltas. Retries are therefore safe,
  // and any correction in the source journal is mirrored without duplication.
  await updateSheetCells(rawMaterialsSpreadsheetId, accessToken, { sheetId: rawSheetId, rowIndex: rawRow.rowNumber - 1, columnIndex: 1 }, targetValues.rawMaterials);
  await updateSheetCells(cansSpreadsheetId, accessToken, { sheetId: cansSheetId, rowIndex: cansRow.rowNumber - 1, columnIndex: 1 }, targetValues.cansPrimary);
  await updateSheetCells(cansSpreadsheetId, accessToken, { sheetId: cansSheetId, rowIndex: cansRow.rowNumber - 1, columnIndex: 5 }, targetValues.cansSecondary);
  return { ok: true, date, rawMaterials: { rowNumber: rawRow.rowNumber }, cans: { rowNumber: cansRow.rowNumber } };
}

async function runAutomaticDailyPackagingExport() {
  if (!writesEnabled || missingGoogleSettings().length) return;
  const clock = vilniusClock();
  if (clock.hour < automaticDailyExportHour || automaticDailyExportCompletedDate === clock.date) return;
  if (Date.now() - automaticDailyExportAttemptAt < 60 * 60_000) return;
  automaticDailyExportAttemptAt = Date.now();
  const date = previousCalendarDate(clock.date);
  try {
    await flushPendingPackagingRecord(date);
    await exportPackagingDaily({ date });
    automaticDailyExportCompletedDate = clock.date;
    console.log(`Суточный перенос расхода упаковки выполнен: ${date}`);
  } catch (error) {
    console.warn(`Суточный перенос расхода упаковки не выполнен за ${date}: ${error.message}`);
  }
}

async function getProductionSnapshot() {
  const rows = await getProductionShiftRows();
  const records = rows.second.map(record => ({ ...record, id: productionRecordId(record.rowNumber) }));
  return {
    ok: true,
    records
  };
}

function scheduleCurrentProductionReportSync(records) {
  const date = vilniusDate();
  const todayRecords = records.filter(record => record.date === date);
  const revision = createHash("sha256").update(JSON.stringify(todayRecords.map(record => [
    record.id, record.quantity, record.scrapKg, record.canScrapKg, record.packer, record.operator
  ])), "utf8").digest("base64url");
  if (productionReportSyncRevisions.get(date) === revision) return;
  productionReportSyncRevisions.set(date, revision);
  while (productionReportSyncRevisions.size > 14) productionReportSyncRevisions.delete(productionReportSyncRevisions.keys().next().value);
  scheduleProductionReportSync([date]);
}

async function withProductionWriteLock(task) {
  const previous = productionWriteTail;
  let release;
  productionWriteTail = new Promise(resolve => { release = resolve; });
  await previous;
  try {
    return await task();
  } finally {
    release();
  }
}

function readProductionCreateReceipt(requestId) {
  if (!requestId || !existsSync(productionCreateReceiptPath)) return null;
  try {
    const receipts = JSON.parse(readFileSync(productionCreateReceiptPath, "utf8"));
    const receipt = receipts?.[requestId];
    return receipt?.record && typeof receipt.record === "object" ? receipt.record : null;
  } catch {
    // A local non-secret receipt cache must never block production records.
    return null;
  }
}

function writeProductionCreateReceipt(requestId, record) {
  if (!requestId || !record?.id) return;
  let receipts = {};
  try {
    const value = existsSync(productionCreateReceiptPath)
      ? JSON.parse(readFileSync(productionCreateReceiptPath, "utf8"))
      : {};
    if (value && typeof value === "object" && !Array.isArray(value)) receipts = value;
  } catch {
    // Replace a damaged receipt cache with the current successful receipt.
  }
  receipts[requestId] = { savedAt: new Date().toISOString(), record };
  const retained = Object.entries(receipts)
    .sort((left, right) => String(right[1]?.savedAt || "").localeCompare(String(left[1]?.savedAt || "")))
    .slice(0, 500);
  const directory = dirname(productionCreateReceiptPath);
  mkdirSync(directory, { recursive: true });
  const temporary = `${productionCreateReceiptPath}.${process.pid}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(Object.fromEntries(retained), null, 2)}\n`, "utf8");
  renameSync(temporary, productionCreateReceiptPath);
}

async function createProductionRecord(input) {
  const candidate = validateGatewayProductionRecord(input);
  const completed = readProductionCreateReceipt(candidate.requestId);
  if (completed) return completed;
  // Coalesce both an identical production record and a retry of the same
  // browser request while this gateway is still processing it. The receipt
  // above also covers a retry after the original Google write succeeded but
  // its HTTP response did not reach the workstation.
  const keys = [productionDuplicateKey(candidate), `request:${candidate.requestId}`];
  const active = keys.map(key => productionCreateLocks.get(key)).find(Boolean);
  if (active) return active;
  const task = withProductionWriteLock(async () => {
    const receipt = readProductionCreateReceipt(candidate.requestId);
    if (receipt) return receipt;
    return createProductionRecordOnce(input, candidate);
  });
  keys.forEach(key => productionCreateLocks.set(key, task));
  try {
    return await task;
  } finally {
    keys.forEach(key => { if (productionCreateLocks.get(key) === task) productionCreateLocks.delete(key); });
  }
}

async function createProductionRecordOnce(input, record) {
  await assertProductionCatalogSchema();
  const leaders = await productionShiftLeaders(record.date, record.shift, input.leadership);
  const rows = await getProductionShiftRows();
  assertNewProductionStartTime(record, rows.second);
  const existing = findExistingProductionRecord(rows, record);
  if (existing) {
    const saved = { ...record, id: productionRecordId(existing.rowNumber), line: record.machineLine, seniorMechanic: existing.seniorMechanic || leaders.seniorMechanic, mechanic: existing.mechanic || leaders.mechanic };
    writeProductionCreateReceipt(record.requestId, saved);
    return saved;
  }
  const accessToken = await getAccessToken();
  const appended = await appendProductionRecordBeforeSummary(accessToken, record, leaders, rows);
  if (appended) {
    writeProductionCreateReceipt(record.requestId, appended);
    scheduleProductionReportSync([record.date]);
    return appended;
  }
  let secondRowNumber = nextProductionRowNumber(rows.second, 2, rows.secondSummaries);
  if (needsDateSeparator(rows.second, record.date)) {
    await insertProductionDateSeparator(accessToken, secondRowNumber);
    secondRowNumber += PRODUCTION_DATE_SEPARATOR_ROWS;
  }
  // A product must never replace a written shift total.  This check is made
  // against the live sheet immediately before the write, not just the earlier
  // in-memory snapshot used to choose the next row.
  await assertProductionRecordTarget(accessToken, secondRowNumber);
  await preserveProductionRowFormatting(accessToken, secondRowNumber);
  await writeProductionRecord(accessToken, record, leaders, secondRowNumber);
  writeProductionCreateReceipt(record.requestId, { ...record, id: productionRecordId(secondRowNumber), line: record.machineLine, ...leaders });
  const persisted = await waitForProductionWrite(record, secondRowNumber);
  if (!persisted) {
    // Do not schedule a later journal rebuild here.  A delayed rebuild can
    // start after another operator has already added a product and then write
    // an outdated shift total into the new product row.  The fact itself is
    // already saved; a later explicit save will refresh its calculations.
    console.warn(`Запись продукции ${secondRowNumber} сохранена, но Google ещё не вернул её для синхронного пересчёта.`);
    return { ...record, id: productionRecordId(secondRowNumber), line: record.machineLine, ...leaders };
  }
  let sorted = await sortProductionDayByLine(accessToken, record.date, persisted);
  if (await removeDuplicateProductionRecords(accessToken, sorted)) sorted = await sortProductionDayByLine(accessToken, record.date);
  const stored = await productionStoredRecord(sorted, record);
  scheduleProductionReportSync([record.date]);
  const saved = { ...record, id: productionRecordId(stored.rowNumber), line: record.machineLine, ...leaders };
  writeProductionCreateReceipt(record.requestId, saved);
  return saved;
}

async function appendProductionRecordBeforeSummary(accessToken, record, leaders, rows) {
  const summary = rows.secondSummaries.find(item => item.date === record.date);
  if (!summary) return null;
  const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  const storedRecord = { ...record, line: record.machineLine, mechanic: leaders.mechanic, seniorMechanic: leaders.seniorMechanic };
  const dayRecords = [...rows.second.filter(item => item.date === record.date), storedRecord];
  const specifications = await runAppsScript("listProductSpecifications");
  const recordPlans = calculateRecordPlansByLine(dayRecords, Array.isArray(specifications) ? specifications : []);
  const rowNumber = summary.rowNumber;

  // The old total is moved down as a sheet row before the product is written.
  // No sorting or read-after-write is needed, so a delayed Google snapshot
  // cannot point a total at the new product row.
  await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, [{ insertDimension: {
    range: { sheetId, dimension: "ROWS", startIndex: rowNumber - 1, endIndex: rowNumber },
    inheritFromBefore: true
  } }], "Не удалось подготовить строку для выпуска");
  await preserveProductionRowFormatting(accessToken, rowNumber);
  await setGoogleSheetRanges(productionSpreadsheetId, accessToken, [
    ...productionRecordRowWrites(record, leaders, rowNumber, recordPlans.get(storedRecord)),
    ...productionSummaryRowWrites(rowNumber + 1, productionSummaryLabel(record.date), productionShiftSummary(dayRecords, Array.isArray(specifications) ? specifications : []))
  ]);
  return { ...record, id: productionRecordId(rowNumber), line: record.machineLine, ...leaders };
}

function assertNewProductionStartTime(record, existingRecords) {
  if (String(record.startTime || "") < FIRST_PRODUCTION_START_TIME) {
    throw new Error(`Первый продукт можно начать не раньше ${FIRST_PRODUCTION_START_TIME}`);
  }
  const minimum = minimumProductionStartTime(existingRecords, record);
  if (!minimum) throw new Error("В этой смене уже недостаточно рабочего времени для нового продукта");
  if (String(record.startTime || "") < minimum) {
    throw new Error(`Начало выпуска возможно не раньше ${minimum}: учтены подготовка и переход`);
  }
}

async function updateProductionRecord(input) {
  // Creation, editing and deletion all move or rebuild a date block.  They
  // must use one queue; otherwise an edit can write into a row while a create
  // operation is moving that day's total.
  return withProductionWriteLock(async () => {
  await assertProductionCatalogSchema();
  const { secondRowNumber } = parseProductionRecordId(input?.id);
  const record = validateGatewayProductionRecord(input);
  const leaders = await productionShiftLeaders(record.date, record.shift, input.leadership);
  const before = await getProductionShiftRows();
  const target = before.second.find(row => row.rowNumber === secondRowNumber);
  if (!target || !["A", "B"].includes(String(target.shift || "").trim().toUpperCase())) {
    throw new Error("Эта строка не является корректной записью выпуска. Обновите журнал: итог смены редактировать нельзя.");
  }
  const previousDate = target.date;
  const accessToken = await getAccessToken();
  await writeProductionRecord(accessToken, record, leaders, secondRowNumber);
  const persisted = await waitForProductionWrite(record, secondRowNumber);
  if (!persisted) {
    // See createProductionRecordOnce: never queue a delayed journal rewrite
    // after Google has acknowledged the source write but has not returned it
    // in time for this request.
    console.warn(`Изменение записи продукции ${secondRowNumber} сохранено, но Google ещё не вернуло его для синхронного пересчёта.`);
    return { ...record, id: productionRecordId(secondRowNumber), line: record.machineLine, ...leaders };
  }
  let sorted = await sortProductionDaysByLine(accessToken, [previousDate, record.date], persisted);
  if (await removeDuplicateProductionRecords(accessToken, sorted)) sorted = await sortProductionDaysByLine(accessToken, [previousDate, record.date]);
  const stored = await productionStoredRecord(sorted, record);
  scheduleProductionReportSync([previousDate, record.date]);
  return { ...record, id: productionRecordId(stored.rowNumber), line: record.machineLine, ...leaders };
  });
}

async function deleteProductionRecord(input) {
  return withProductionWriteLock(async () => {
    await assertProductionCatalogSchema();
    const { secondRowNumber } = parseProductionRecordId(input?.id);
    const before = await getProductionShiftRows();
    const previousDate = before.second.find(row => row.rowNumber === secondRowNumber)?.date;
    const accessToken = await getAccessToken();
    const remainingForDate = before.second.filter(row => row.date === previousDate && row.rowNumber !== secondRowNumber);
    const previousSummary = before.secondSummaries.find(summary => summary.date === previousDate);

    // When the last record for a date is removed, remove its record and written
    // total as sheet rows.  Clearing cells alone would leave an orphan total
    // whose date can no longer be determined after the source row disappears.
    if (previousDate && !remainingForDate.length) {
      await deleteProductionRows(accessToken, [secondRowNumber, previousSummary?.rowNumber]);
      scheduleProductionReportSync([previousDate]);
      return;
    }
    await clearProductionRecords(accessToken, [secondRowNumber]);

    // A shift total is a written value, not a Sheet formula.  After deleting a
    // row, rebuild this date immediately; otherwise the removed output stays
    // in the visible "Итог смены" row until another record is saved.
    if (previousDate) await sortProductionDaysByLine(accessToken, [previousDate]);
    scheduleProductionReportSync([previousDate]);
  });
}

async function removeDuplicateProductionRecords(accessToken, rows = null) {
  const snapshot = rows ?? await getProductionShiftRows();
  const duplicates = duplicateProductionPairs(snapshot);
  if (!duplicates.length) return 0;
  // Совпадение полей не доказывает, что запись ошибочна: две фактические
  // операции могут выглядеть одинаково. Автоматически ничего не очищаем.
  // Дубликаты остаются видимыми для ручной проверки в журнале.
  console.warn(`Обнаружены похожие записи продукции: ${duplicates.length}. Автоочистка отключена.`);
  return 0;
}

function duplicateProductionPairs(rows) {
  const seen = new Set();
  const duplicates = [];
  for (const record of rows.second) {
    const key = productionDuplicateKey(record);
    if (seen.has(key)) duplicates.push(record.rowNumber);
    else seen.add(key);
  }
  return duplicates;
}

async function clearProductionRecords(accessToken, rowNumbers) {
  // A deleted row must leave no calculated remnants behind.  In particular,
  // keeping U (plan) or V (product efficiency) lets an old result be shown
  // after a later sort places another record in the same position.
  // The rebuild restores I explicitly for every remaining record.
  const ranges = rowNumbers.map(secondRowNumber => ({
    range: `'${productionSheetName}'!A${secondRowNumber}:AI${secondRowNumber}`,
    values: [Array(35).fill("")]
  }));
  for (let index = 0; index < ranges.length; index += 100) {
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, ranges.slice(index, index + 100));
  }
}

async function deleteProductionRows(accessToken, rowNumbers) {
  const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  const rows = [...new Set(rowNumbers.map(Number).filter(Number.isInteger))].sort((left, right) => right - left);
  if (!rows.length) return;
  await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, rows.map(rowNumber => ({ deleteDimension: {
    range: { sheetId, dimension: "ROWS", startIndex: rowNumber - 1, endIndex: rowNumber }
  } })), "Не удалось удалить освобождённые строки журнала продукции");
}

async function writeProductionRecord(accessToken, record, leaders, secondRowNumber) {
  await setGoogleSheetRanges(productionSpreadsheetId, accessToken, productionRecordRowWrites(record, leaders, secondRowNumber));
}

async function assertProductionRecordTarget(accessToken, rowNumber) {
  const [snapshot] = await getGoogleSheetRanges(
    productionSpreadsheetId,
    [`'${productionSheetName}'!A${rowNumber}:F${rowNumber}`],
    { valueRenderOption: "UNFORMATTED_VALUE" }
  );
  const row = snapshot?.[0] ?? [];
  const label = String(row[0] || "").trim();
  const product = String(row[5] || "").trim();
  if (label.startsWith("Итог") || label || product) {
    throw new Error(`Новая запись не сохранена: строка ${rowNumber} уже занята. Обновите журнал и попробуйте ещё раз.`);
  }
}

function productionRecordRowWrites(record, leaders, secondRowNumber, plannedBoxes = undefined) {
  const second = productionSecondValues(record, leaders);
  // U and V always describe the same product row.  Do not accept a stale
  // percentage from an earlier summary calculation: derive it from the plan
  // being written to U in this exact request.
  const recordPlan = Number(plannedBoxes);
  const rowEfficiency = Number.isFinite(recordPlan) && recordPlan > 0
    ? Number(record.quantity || 0) / 240 / recordPlan
    : null;
  return [
    { range: `'${productionSheetName}'!A${secondRowNumber}:H${secondRowNumber}`, values: [second.beforeBoxes] },
    // The formula must be restored explicitly when a production row replaces
    // a former total during a day-block compaction.
    { range: `'${productionSheetName}'!I${secondRowNumber}`, values: [[`=IF(H${secondRowNumber}="";"";H${secondRowNumber}/240)`]] },
    { range: `'${productionSheetName}'!J${secondRowNumber}:K${secondRowNumber}`, values: [[second.scrapKg, record.scrapPercent ?? ""]] },
    { range: `'${productionSheetName}'!L${secondRowNumber}:T${secondRowNumber}`, values: [second.afterBoxes] },
    { range: `'${productionSheetName}'!U${secondRowNumber}`, values: [[Number.isFinite(recordPlan) ? recordPlan : ""]] },
    // V is the result of this product row, never the common result of a line
    // or a shift total that previously occupied this position.
    { range: `'${productionSheetName}'!V${secondRowNumber}`, values: [[rowEfficiency ?? ""]] },
    { range: `'${productionSheetName}'!W${secondRowNumber}`, values: [[""]] },
    { range: `'${productionSheetName}'!X${secondRowNumber}:Z${secondRowNumber}`, values: [second.efficiencyDetails] },
    { range: `'${productionSheetName}'!AA${secondRowNumber}:AC${secondRowNumber}`, values: [second.replacementDetails] },
    { range: `'${productionSheetName}'!AD${secondRowNumber}:AI${secondRowNumber}`, values: [second.machineIntervals] }
  ];
}

function productionSecondValues(record, leaders) {
  return {
    beforeBoxes: [displayDate(record.date), record.machineLine, record.startTime, record.time, record.catalogLine, record.product, record.strength, record.quantity],
    // J is written separately because I is the calculated box count. Keep the
    // product scrap with this row; otherwise Google receives an empty J cell
    // while K still contains the calculated percentage.
    scrapKg: record.scrapKg,
    afterBoxes: [record.canScrapKg, record.shift, record.packer, record.operator, leaders.mechanic, leaders.seniorMechanic, record.note, record.operatorSecondStartTime || "", record.operatorSecondEndTime || ""],
    efficiencyDetails: [(record.activeMachines || []).join(", "), record.operatorStartTime || record.startTime || "", record.operatorEndTime || record.time || ""],
    replacementDetails: [record.operatorReplacement || "", record.operatorReplacementStartTime || "", record.operatorReplacementEndTime || ""],
    machineIntervals: (record.activeMachines || []).slice(0, 3).flatMap(machine => [record.machineStartTimes?.[machine] || record.startTime || "", record.machineEndTimes?.[machine] || record.time || ""]).concat(["", "", "", "", "", ""]).slice(0, 6)
  };
}

function productionSortValue(record) {
  return String(record.line || record.machineLine || "").trim().toLocaleUpperCase("en");
}

async function productionStoredRecord(rows, record) {
  const signature = productionSignature({ ...record, line: record.machineLine });
  // Google Sheets can return the preceding snapshot immediately after a batch
  // update. The write has already completed, so retry only the read instead of
  // asking the operator to submit the production record again.
  let snapshot = rows;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const record = snapshot.second.find(row => productionSignature(row) === signature);
    if (record) return { rowNumber: record.rowNumber };
    if (attempt < 3) {
      await new Promise(resolve => setTimeout(resolve, 300));
      snapshot = await getProductionShiftRows();
    }
  }
  throw new Error("Запись продукции сохранена, но не удалось сразу обновить её положение после сортировки. Обновите журнал, не создавая запись повторно.");
}

function productionRecordWasWritten(stored, record) {
  if (!stored || productionSignature(stored) !== productionSignature({ ...record, line: record.machineLine })) return false;
  return ["quantity", "scrapKg", "canScrapKg"].every(key => Math.abs(Number(stored[key] || 0) - Number(record[key] || 0)) < 0.000_001);
}

async function waitForProductionWrite(record, rowNumber) {
  let rows = await getProductionShiftRows();
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const stored = rows.second.find(item => item.rowNumber === rowNumber);
    if (productionRecordWasWritten(stored, record)) return rows;
    if (attempt < 4) {
      await new Promise(resolve => setTimeout(resolve, 350));
      rows = await getProductionShiftRows();
    }
  }
  return null;
}

async function sortProductionDayByLine(accessToken, date, rows = null) {
  return sortProductionDaysByLine(accessToken, [date], rows);
}

async function rebuildProductionShiftSummaries() {
  if (!writesEnabled || missingGoogleSettings().length) return { updated: 0 };
  const accessToken = await getAccessToken();
  let rows = await getProductionShiftRows();
  if (await removeDuplicateProductionRecords(accessToken, rows)) rows = await getProductionShiftRows();
  const dates = [...new Set(rows.second.map(row => row.date).filter(Boolean))];
  const snapshot = await sortProductionDaysByLine(accessToken, dates);
  return { updated: dates.length, records: snapshot.second.length };
}

async function sortProductionDaysByLine(accessToken, dates, initialRows = null) {
  const targetDates = [...new Set(dates.filter(Boolean))];
  if (!targetDates.length) return getProductionShiftRows();
  let rows = initialRows ?? await getProductionShiftRows();
  rows = await ensureProductionSummaryRows(accessToken, rows, targetDates);
  const specifications = await runAppsScript("listProductSpecifications");
  const efficiencySpecifications = Array.isArray(specifications) ? specifications : [];
  const layouts = productionDayLayouts(rows, targetDates).map(layout => {
    const recordPlans = calculateRecordPlansByLine(layout.records, efficiencySpecifications);
    return {
      ...layout,
      records: layout.records.map(record => ({
        ...record,
        plannedBoxes: recordPlans.get(record) ?? null,
        productEfficiency: Number(recordPlans.get(record)) > 0
          ? Number(record.quantity || 0) / 240 / Number(recordPlans.get(record))
          : null
      }))
    };
  });
  const datesWithRecords = new Set(layouts.map(layout => layout.date));
  const orphanSummaries = rows.secondSummaries.filter(summary => targetDates.includes(summary.date) && !datesWithRecords.has(summary.date));
  const ranges = [
    ...layouts.flatMap(layout => [{
    // Rebuild only this day's occupied block.  The intentionally blank rows
    // before the first record are date separators and are never included.
    range: `'${productionSheetName}'!A${layout.startRowNumber}:AI${layout.endRowNumber}`,
    values: Array.from({ length: layout.endRowNumber - layout.startRowNumber + 1 }, () => Array(35).fill(""))
    }]),
    // If the last record of a date was deleted, remove its written total too.
    ...orphanSummaries.map(summary => ({ range: `'${productionSheetName}'!A${summary.rowNumber}:AI${summary.rowNumber}`, values: [Array(35).fill("")] }))
  ];
  if (ranges.length) await setGoogleSheetRanges(productionSpreadsheetId, accessToken, ranges);
  await clearProductionSummaryFormatting(accessToken, orphanSummaries);
  await copyProductionRecordFormats(accessToken, layouts);
  const recordWrites = layouts.flatMap(layout => layout.records.flatMap((row, index) => productionRecordRowWrites(
    { ...row, machineLine: row.line },
    { mechanic: row.mechanic, seniorMechanic: row.seniorMechanic },
    layout.startRowNumber + index,
    row.plannedBoxes
  )));
  for (let index = 0; index < recordWrites.length; index += 100) {
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, recordWrites.slice(index, index + 100));
  }
  // Google Sheets can briefly return the pre-sort snapshot after the records
  // above were moved.  Do not calculate a total from that snapshot: it can
  // still point at the former total row and overwrite fields of a product.
  rows = await waitForProductionLayouts(layouts);
  const summaryPlans = productionShiftSummaryPlans(rows, targetDates, efficiencySpecifications);
  // The target row is checked from the live sheet immediately before the
  // total is written.  A shift total must never overwrite a record that
  // appeared after this server's earlier read.
  await assertProductionSummaryTargets(summaryPlans);
  const summaryWrites = summaryPlans.flatMap(plan => productionSummaryRowWrites(plan.rowNumber, plan.label, plan.summary));
  if (summaryWrites.length) await setGoogleSheetRanges(productionSpreadsheetId, accessToken, summaryWrites);
  await restoreProductionReportFormatting(accessToken, rows, targetDates, efficiencySpecifications, layouts);
  // Keep unused rows in place.  Removing them during an automatic rebuild can
  // shift later dates and delete production data that was not part of the
  // requested recalculation.  Explicit removal of the last record still uses
  // deleteProductionRows above, where the exact two rows are known.
  return getProductionShiftRows();
}

async function waitForProductionLayouts(layouts) {
  let snapshot = await getProductionShiftRows();
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const confirmed = layouts.every(layout => layout.records.every((record, index) => {
      const stored = snapshot.second.find(row => row.rowNumber === layout.startRowNumber + index);
      return productionRecordWasWritten(stored, { ...record, machineLine: record.line });
    }));
    if (confirmed) return snapshot;
    if (attempt < 7) {
      await new Promise(resolve => setTimeout(resolve, 350));
      snapshot = await getProductionShiftRows();
    }
  }
  throw productionConsistencyError("Запись продукции сохранена, но Google ещё не подтвердил перестановку строк. Обновите журнал, не создавая запись повторно.");
}

function productionConsistencyError(message) {
  const error = new Error(message);
  error.statusCode = 409;
  return error;
}

function productionDayLayouts(rows, dates) {
  return dates.flatMap(date => {
    const records = rows.second.filter(row => row.date === date).sort((a, b) => productionSortValue(a).localeCompare(productionSortValue(b), "en"));
    if (!records.length) return [];
    const summaries = rows.secondSummaries.filter(summary => summary.date === date);
    const rowNumbers = [...records.map(row => row.rowNumber), ...summaries.map(summary => summary.rowNumber)];
    return [{
      date,
      records,
      // The first production row anchors the day.  Do not compact into the
      // date separator that precedes it.
      startRowNumber: Math.min(...records.map(row => row.rowNumber)),
      endRowNumber: Math.max(...rowNumbers),
      templateRowNumber: records[0].rowNumber
    }];
  });
}

async function copyProductionRecordFormats(accessToken, layouts) {
  if (!layouts.length) return;
  const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  const requests = layouts.flatMap(layout => layout.records.map((_, index) => ({ copyPaste: {
    source: { sheetId, startRowIndex: layout.templateRowNumber - 1, endRowIndex: layout.templateRowNumber, startColumnIndex: 0, endColumnIndex: 29 },
    destination: { sheetId, startRowIndex: layout.startRowNumber + index - 1, endRowIndex: layout.startRowNumber + index, startColumnIndex: 0, endColumnIndex: 29 },
    pasteType: "PASTE_FORMAT", pasteOrientation: "NORMAL"
  } })));
  if (requests.length) await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, requests, "Не удалось оформить записи продукции после сортировки");
}

async function clearProductionSummaryFormatting(accessToken, summaries) {
  if (!summaries.length) return;
  const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  const blankRow = { userEnteredFormat: {
    backgroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } },
    textFormat: { bold: false, foregroundColorStyle: { rgbColor: { red: 0, green: 0, blue: 0 } } }
  } };
  const requests = summaries.map(summary => ({ repeatCell: {
    range: { sheetId, startRowIndex: summary.rowNumber - 1, endRowIndex: summary.rowNumber, startColumnIndex: 0, endColumnIndex: 29 },
    cell: blankRow,
    fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold,userEnteredFormat.textFormat.foregroundColorStyle"
  } }));
  await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, requests, "Не удалось очистить оформление пустого итога продукции");
}

function productionShiftSummaryPlans(rows, dates, specifications = []) {
  const plans = [];
  for (const date of dates) {
    const second = rows.second.filter(row => row.date === date);
    if (!second.length) continue;
    const summary = productionShiftSummary(second, specifications);
    const rowNumber = Math.max(...second.map(row => row.rowNumber)) + 1;
    plans.push({ rowNumber, label: productionSummaryLabel(date), summary });
  }
  return plans;
}

async function assertProductionSummaryTargets(plans) {
  if (!plans.length) return;
  const ranges = plans.map(plan => `'${productionSheetName}'!A${plan.rowNumber}:F${plan.rowNumber}`);
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const snapshots = await getGoogleSheetRanges(productionSpreadsheetId, ranges, { valueRenderOption: "UNFORMATTED_VALUE" });
    const occupied = plans.find((plan, index) => {
      const row = snapshots[index]?.[0] ?? [];
      const label = String(row[0] || "").trim();
      return label || String(row[5] || "").trim().length > 0 || Boolean(googleSheetDate(row[0]));
    });
    // A previous total is not an exception here. The rebuild cleared it before
    // this point; seeing it now means Google returned a stale snapshot.
    if (!occupied) return;
    if (attempt < 7) {
      await new Promise(resolve => setTimeout(resolve, 350));
      continue;
    }
    throw productionConsistencyError(`Итог смены не записан: строка ${occupied.rowNumber} не стала пустой после перестановки. Обновите журнал, не создавая запись повторно.`);
  }
}
function productionSummaryRowWrites(rowNumber, label, summary) {
  const efficiencyText = formatProductionEfficiency(summary.efficiency);
  return [
    { range: `'${productionSheetName}'!A${rowNumber}`, values: [[label]] },
    { range: `'${productionSheetName}'!F${rowNumber}`, values: [["Общий итог смены"]] },
    { range: `'${productionSheetName}'!H${rowNumber}:I${rowNumber}`, values: [[summary.quantity, summary.boxes]] },
    { range: `'${productionSheetName}'!J${rowNumber}:L${rowNumber}`, values: [[summary.scrapKg, summary.percent ?? "", Number(summary.canScrapKg || 0)]] },
    { range: `'${productionSheetName}'!M${rowNumber}`, values: [[`Эфф.: ${efficiencyText}`]] },
    { range: `'${productionSheetName}'!R${rowNumber}`, values: [[`План: ${formatProductionSummaryNumber(summary.plannedBoxes)} кор. · Эффективность: ${efficiencyText}`]] },
    { range: `'${productionSheetName}'!U${rowNumber}:W${rowNumber}`, values: [[summary.plannedBoxes, summary.efficiency ?? "", summary.lostMinutes || ""]] }
  ];
}
function formatProductionSummaryNumber(value) { return new Intl.NumberFormat("ru-RU", { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(Number(value || 0)); }
function formatProductionEfficiency(value) { return Number.isFinite(value) ? `${new Intl.NumberFormat("ru-RU", { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(value * 100)}%` : "Нет данных"; }
function productionShiftSummary(records, specifications = []) {
  const quantity = records.reduce((sum, record) => sum + Number(record.quantity || 0), 0);
  const scrapKg = records.reduce((sum, record) => sum + Number(record.scrapKg || 0), 0);
  const canScrapKg = records.reduce((sum, record) => sum + Number(record.canScrapKg || 0), 0);
  const equivalent = records.reduce((sum, record) => {
    const percent = Number(record.scrapPercent);
    const quantity = Number(record.quantity || 0);
    return Number.isFinite(percent) && percent >= 0 && percent < 1 ? sum + quantity * percent / (1 - percent) : sum;
  }, 0);
  const efficiency = calculateShiftEfficiency(records, specifications);
  return { quantity, boxes: quantity / 240, scrapKg, canScrapKg, percent: quantity + equivalent > 0 ? equivalent / (quantity + equivalent) : null, plannedBoxes: efficiency.plannedBoxes, efficiency: efficiency.efficiency, lostMinutes: efficiency.lostMinutes };
}

function productionStrengthNumberPattern(value) {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue)) return "0.##";
  if (Number.isInteger(numericValue)) return "0";
  return Math.abs(numericValue * 10 - Math.round(numericValue * 10)) < 1e-7 ? "0.0" : "0.00";
}

function productionEfficiencyFormat(efficiency) {
  const value = Number(efficiency);
  if (!Number.isFinite(value) || value < 0.7) return { backgroundColorStyle: { rgbColor: { red: 0.8627451, green: 0.20784314, blue: 0.27058825 } }, textFormat: { bold: true, foregroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } } } };
  if (value < 0.9) return { backgroundColorStyle: { rgbColor: { red: 1, green: 0.75686276, blue: 0.023529412 } }, textFormat: { bold: true, foregroundColorStyle: { rgbColor: { red: 0.09803922, green: 0.15686275, blue: 0.26666668 } } } };
  if (value <= 1) return { backgroundColorStyle: { rgbColor: { red: 0.15686275, green: 0.654902, blue: 0.2784314 } }, textFormat: { bold: true, foregroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } } } };
  return { backgroundColorStyle: { rgbColor: { red: 0.54509807, green: 0.36078432, blue: 0.9647059 } }, textFormat: { bold: true, foregroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } } } };
}

function blankProductionRowFormattingRequests(sheetId, startRowIndex, endRowIndex, whiteRecord, blankEfficiencyCell) {
  if (endRowIndex <= startRowIndex) return [];
  return [
    { repeatCell: { range: { sheetId, startRowIndex, endRowIndex, startColumnIndex: 0, endColumnIndex: 21 }, cell: whiteRecord, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold" } },
    { repeatCell: { range: { sheetId, startRowIndex, endRowIndex, startColumnIndex: 21, endColumnIndex: 22 }, cell: blankEfficiencyCell, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold,userEnteredFormat.textFormat.foregroundColorStyle" } },
    { repeatCell: { range: { sheetId, startRowIndex, endRowIndex, startColumnIndex: 22, endColumnIndex: 29 }, cell: whiteRecord, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold" } }
  ];
}

async function restoreProductionReportFormatting(accessToken, rows, dates, specifications = [], layouts = []) {
  const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  const layoutsByDate = new Map(layouts.map(layout => [layout.date, layout]));
  const whiteRecord = { userEnteredFormat: { backgroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } }, textFormat: { bold: false } } };
  const blankEfficiencyCell = { userEnteredFormat: { backgroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } }, textFormat: { bold: false, foregroundColorStyle: { rgbColor: { red: 0, green: 0, blue: 0 } } } } };
  const summaryRow = { userEnteredFormat: { backgroundColorStyle: { rgbColor: { red: 0.9647059, green: 0.83137256, blue: 0.60784316 } }, textFormat: { bold: true } } };
  const requests = [];
  for (const date of dates) {
    const records = rows.second.filter(row => row.date === date);
    if (!records.length) continue;
    const startRowIndex = Math.min(...records.map(row => row.rowNumber)) - 1;
    const endRowIndex = Math.max(...records.map(row => row.rowNumber));
    requests.push(...blankProductionRowFormattingRequests(sheetId, startRowIndex, endRowIndex, whiteRecord, blankEfficiencyCell));
    const recordPlans = calculateRecordPlansByLine(records, specifications);
    records.forEach(record => requests.push({ repeatCell: {
      range: { sheetId, startRowIndex: record.rowNumber - 1, endRowIndex: record.rowNumber, startColumnIndex: 6, endColumnIndex: 7 },
      cell: { userEnteredFormat: { numberFormat: { type: "NUMBER", pattern: productionStrengthNumberPattern(record.strength) } } },
      fields: "userEnteredFormat.numberFormat"
    } }));
    records.forEach(record => {
      const plannedBoxes = Number(recordPlans.get(record));
      const productEfficiency = plannedBoxes > 0 ? Number(record.quantity || 0) / 240 / plannedBoxes : null;
      requests.push({ repeatCell: {
        range: { sheetId, startRowIndex: record.rowNumber - 1, endRowIndex: record.rowNumber, startColumnIndex: 21, endColumnIndex: 22 },
        cell: { userEnteredFormat: { ...productionEfficiencyFormat(productEfficiency), numberFormat: { type: "PERCENT", pattern: "0.0%" } } },
        fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold,userEnteredFormat.textFormat.foregroundColorStyle,userEnteredFormat.numberFormat"
      } });
    });
    const summary = productionShiftSummary(records, specifications);
    const summaryRowIndex = endRowIndex;
    requests.push(
      { repeatCell: { range: { sheetId, startRowIndex: summaryRowIndex, endRowIndex: summaryRowIndex + 1, startColumnIndex: 0, endColumnIndex: 21 }, cell: summaryRow, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold" } },
      { repeatCell: { range: { sheetId, startRowIndex: summaryRowIndex, endRowIndex: summaryRowIndex + 1, startColumnIndex: 22, endColumnIndex: 29 }, cell: summaryRow, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold" } },
      { repeatCell: { range: { sheetId, startRowIndex: summaryRowIndex, endRowIndex: summaryRowIndex + 1, startColumnIndex: 21, endColumnIndex: 22 }, cell: { userEnteredFormat: productionEfficiencyFormat(summary.efficiency) }, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold,userEnteredFormat.textFormat.foregroundColorStyle" } }
    );
    const previousBlock = layoutsByDate.get(date);
    const firstVacatedRowIndex = summaryRowIndex + 1;
    if (previousBlock && previousBlock.endRowNumber > firstVacatedRowIndex) {
      requests.push(...blankProductionRowFormattingRequests(sheetId, firstVacatedRowIndex, previousBlock.endRowNumber, whiteRecord, blankEfficiencyCell));
    }
    const nextRecordRowNumber = Math.min(...rows.second.filter(row => row.rowNumber > summaryRowIndex + 1).map(row => row.rowNumber));
    // Every date block has three blank separator rows.  If the current date
    // is the last one, there is no next record to anchor the old cleanup;
    // clear those separator formats directly instead of leaving the colour of
    // a former total or efficiency result in empty cells.
    const separatorEndRowIndex = Number.isFinite(nextRecordRowNumber)
      ? Math.min(nextRecordRowNumber - 1, firstVacatedRowIndex + 3)
      : firstVacatedRowIndex + 3;
    requests.push(...blankProductionRowFormattingRequests(sheetId, firstVacatedRowIndex, separatorEndRowIndex, whiteRecord, blankEfficiencyCell));
  }
  if (requests.length) await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, requests, "Не удалось восстановить оформление журнала продукции");
}

function productionSummaryLabel() { return "\u0418\u0442\u043e\u0433 \u0441\u043c\u0435\u043d\u044b"; }
function productionProductSummaryLabel() { return "\u0418\u0442\u043e\u0433 \u043f\u0440\u043e\u0434\u0443\u043a\u0442\u0430"; }
async function ensureProductionSummaryRows(accessToken, rows, dates) {
  const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  const requests = [];
  for (const date of [...dates].sort((left, right) => right.localeCompare(left))) {
    const records = rows.second.filter(row => row.date === date);
    if (!records.length) continue;
    const existing = rows.secondSummaries.filter(summary => summary.date === date);
    const needed = 1;
    const missing = needed - existing.length;
    if (missing <= 0) continue;
    const lastRow = Math.max(...records.map(row => row.rowNumber), ...existing.map(row => row.rowNumber));
    requests.push({ insertDimension: { range: { sheetId, dimension: "ROWS", startIndex: lastRow, endIndex: lastRow + missing }, inheritFromBefore: true } });
  }
  if (!requests.length) return rows;
  await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, requests, "Could not add production summary rows");
  return getProductionShiftRows();
}
function nextProductionRowNumber(rows, firstDataRow, summaries = []) {
  return Math.max(firstDataRow, ...rows.map(row => row.rowNumber + 1), ...summaries.map(row => row.rowNumber + 1));
}

function needsDateSeparator(rows, date) {
  const latest = rows.reduce((result, row) => !result || row.rowNumber > result.rowNumber ? row : result, null);
  return Boolean(latest && latest.date !== date);
}

const PRODUCTION_DATE_SEPARATOR_ROWS = 3;

async function insertProductionDateSeparator(accessToken, secondRowNumber) {
  const secondSheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, [
    // A date block ends with its single shift total, followed by exactly three
    // blank separator rows.  Insert all three together so a new day cannot
    // inherit a stale total or efficiency from the previous one.
    { insertDimension: { range: { sheetId: secondSheetId, dimension: "ROWS", startIndex: secondRowNumber - 1, endIndex: secondRowNumber - 1 + PRODUCTION_DATE_SEPARATOR_ROWS }, inheritFromBefore: true } },
    // Rows inherit formatting from the preceding shift total. Separators must
    // remain visually empty and must not retain a total or efficiency colour.
    { repeatCell: { range: { sheetId: secondSheetId, startRowIndex: secondRowNumber - 1, endRowIndex: secondRowNumber - 1 + PRODUCTION_DATE_SEPARATOR_ROWS, startColumnIndex: 0, endColumnIndex: 29 }, cell: { userEnteredFormat: { backgroundColorStyle: { rgbColor: { red: 1, green: 1, blue: 1 } }, textFormat: { bold: false, foregroundColorStyle: { rgbColor: { red: 0, green: 0, blue: 0 } } } } }, fields: "userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold,userEnteredFormat.textFormat.foregroundColorStyle" } }
  ], "Не удалось добавить разделитель между днями продукции");
}

async function assertProductionCatalogSchema() {
  const [header] = await getGoogleSheetRanges(productionSpreadsheetId, [`'${productionSheetName}'!A1:AI1`]);
  const ready = String(header?.[0]?.[1] || "").toLocaleLowerCase("ru").includes("линия")
    && String(header?.[0]?.[4] || "").toLocaleLowerCase("ru").includes("линейка")
    && /кор\.|короб/.test(String(header?.[0]?.[8] || "").toLocaleLowerCase("ru"))
    && String(header?.[0]?.[10] || "").toLocaleLowerCase("ru").includes("процент")
    && String(header?.[0]?.[11] || "").toLocaleLowerCase("ru").includes("банок");
  if (!ready) throw new Error("Журнал «Учёт продукции и брака» ещё не подготовлен для новой структуры столбцов.");
  const values = header?.[0] ?? [];
  const secondStartHeader = String(values[18] || "").trim();
  const secondEndHeader = String(values[19] || "").trim();
  if (secondStartHeader !== "Второй механик: с" || secondEndHeader !== "Второй механик: по") {
    const accessToken = await getAccessToken();
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, [{
      range: `'${productionSheetName}'!S1:T1`,
      values: [["Второй механик: с", "Второй механик: по"]]
    }]);
  }
  const details = [String(values[23] || "").trim(), String(values[24] || "").trim(), String(values[25] || "").trim()];
  if (details.join("|") !== "Работавшие машины|Механик: с|Механик: по") {
    const accessToken = await getAccessToken();
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, [{
      range: `'${productionSheetName}'!X1:Z1`,
      values: [["Работавшие машины", "Механик: с", "Механик: по"]]
    }]);
  }
  const replacement = [String(values[26] || "").trim(), String(values[27] || "").trim(), String(values[28] || "").trim()];
  if (replacement.join("|") !== "Замена механика-оператора|Замена: с|Замена: по") {
    const accessToken = await getAccessToken();
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, [{
      range: `'${productionSheetName}'!AA1:AC1`,
      values: [["Замена механика-оператора", "Замена: с", "Замена: по"]]
    }]);
  }
  // Earlier journal layouts ended at AC. The machine intervals need six
  // service columns AD:AI. Add them once before the first write; appending
  // columns does not touch A:AC, formulas, or existing production rows.
  if (values.length < 35) {
    const accessToken = await getAccessToken();
    const sheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
    await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, [{ appendDimension: {
      sheetId,
      dimension: "COLUMNS",
      length: 35 - values.length
    } }], "Не удалось добавить служебные столбцы интервалов машин");
  }
  const machineIntervals = [String(values[29] || "").trim(), String(values[30] || "").trim(), String(values[31] || "").trim(), String(values[32] || "").trim(), String(values[33] || "").trim(), String(values[34] || "").trim()];
  if (machineIntervals.join("|") !== "Машина 1: с|Машина 1: по|Машина 2: с|Машина 2: по|Машина 3: с|Машина 3: по") {
    const accessToken = await getAccessToken();
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, [{
      range: `'${productionSheetName}'!AD1:AI1`,
      values: [["Машина 1: с", "Машина 1: по", "Машина 2: с", "Машина 2: по", "Машина 3: с", "Машина 3: по"]]
    }]);
  }
}
function productionRecordId(secondRowNumber) { return `production:${secondRowNumber}`; }

function parseProductionRecordId(value) {
  const match = String(value || "").match(/^production:(\d+)$/);
  if (!match) throw new Error("Обновите страницу журнала продукции и повторите действие.");
  return { secondRowNumber: Number(match[1]) };
}

async function preserveProductionRowFormatting(accessToken, secondRowNumber) {
  if (secondRowNumber <= 2) return;
  const secondSheetId = await getSheetId(productionSpreadsheetId, productionSheetName, accessToken);
  await batchGoogleSheetRequests(productionSpreadsheetId, accessToken, [{ copyPaste: {
    source: { sheetId: secondSheetId, startRowIndex: secondRowNumber - 2, endRowIndex: secondRowNumber - 1, startColumnIndex: 0, endColumnIndex: 35 },
    destination: { sheetId: secondSheetId, startRowIndex: secondRowNumber - 1, endRowIndex: secondRowNumber, startColumnIndex: 0, endColumnIndex: 35 },
    pasteType: "PASTE_FORMAT", pasteOrientation: "NORMAL"
  } }], "Не удалось оформить новую строку продукции");
}
async function productionShiftLeaders(date, shift, selected = null) {
  const workforce = await getWorkforceSnapshot();
  const fallback = productionShiftLeadersFromWorkforce(workforce, date, shift);
  const teamId = shift === "A" ? "shift-team-a" : "shift-team-b";
  // The shared shift is the authoritative source for a current production
  // entry. A production dialog may have been opened before the senior
  // mechanic was chosen; in that case its browser state is stale and must not
  // erase the mechanic saved in the central shift.
  const sharedShift = readCentralShiftState();
  const sharedLeadership = sharedShift?.active
    && sharedShift.shiftDate === date
    && sharedShift.shiftTeamId === teamId
    ? { seniorMechanic: sharedShift.seniorMechanic, mechanic: sharedShift.mechanic }
    : null;
  const source = String(sharedLeadership?.seniorMechanic || "").trim() ? sharedLeadership : selected;
  const seniorMechanic = String(source?.seniorMechanic || "").trim();
  const mechanic = String(source?.mechanic || "").trim();
  if (!seniorMechanic) return fallback;
  const peopleById = new Map((workforce.personnel ?? []).map(person => [person.id, person]));
  const present = (workforce.attendance ?? []).filter(item => item.date === date && item.shiftTeamId === teamId && hasWorkedAttendance(item.value))
    .map(item => peopleById.get(item.employeeId)).filter(Boolean);
  const seniorPool = present.some(person => person.role === "senior-mechanic")
    ? present.filter(person => person.role === "senior-mechanic")
    : present.filter(person => person.role === "mechanic");
  const directMechanics = present.filter(person => person.role === "mechanic" && person.fullName !== seniorMechanic);
  const mechanicPool = directMechanics.length ? directMechanics : present.filter(person => person.role === "mechanic-operator");
  if (!seniorPool.some(person => person.fullName === seniorMechanic)) throw new Error("Старший механик должен быть отмечен в табеле этой смены.");
  if (mechanic && !mechanicPool.some(person => person.fullName === mechanic)) throw new Error("Механик должен быть отмечен в табеле этой смены.");
  return { seniorMechanic, mechanic };
}

function productionShiftLeadersFromWorkforce(workforce, date, shift) {
  const teamId = shift === "A" ? "shift-team-a" : "shift-team-b";
  const peopleById = new Map((workforce.personnel ?? []).map(person => [person.id, person]));
  const present = (workforce.attendance ?? [])
    .filter(item => item.date === date && item.shiftTeamId === teamId && hasWorkedAttendance(item.value))
    .map(item => peopleById.get(item.employeeId))
    .filter(Boolean);
  const seniorMechanics = present.filter(person => person.role === "senior-mechanic");
  const directMechanics = present.filter(person => person.role === "mechanic");
  const seniorPool = seniorMechanics.length ? seniorMechanics : directMechanics;
  const seniorNames = seniorPool.map(person => person.fullName);
  return {
    seniorMechanic: seniorNames.join("; "),
    mechanic: directMechanics.filter(person => !seniorNames.includes(person.fullName)).map(person => person.fullName).join("; ")
  };
}

async function backfillProductionLeaders() {
  if (!writesEnabled || missingGoogleSettings().length) return { updated: 0 };
  const [snapshot, rows, workforce, accessToken] = await Promise.all([
    getProductionSnapshot(), getProductionShiftRows(), getWorkforceSnapshot(), getAccessToken()
  ]);
  const secondByRow = new Map(rows.second.map(record => [record.rowNumber, record]));
  const updates = [];
  for (const record of snapshot.records) {
    const { secondRowNumber } = parseProductionRecordId(record.id);
    const second = secondByRow.get(secondRowNumber);
    if (!second) continue;
    const leaders = productionShiftLeadersFromWorkforce(workforce, record.date, record.shift);
    if (!leaders.seniorMechanic && !leaders.mechanic) continue;
    const values = [second.seniorMechanic || leaders.seniorMechanic, second.mechanic || leaders.mechanic];
    if (!second.seniorMechanic || !second.mechanic) updates.push({ range: `'${productionSheetName}'!P${secondRowNumber}:Q${secondRowNumber}`, values: [[values[1], values[0]]] });
  }
  for (let index = 0; index < updates.length; index += 100) {
    await setGoogleSheetRanges(productionSpreadsheetId, accessToken, updates.slice(index, index + 100));
  }
  if (updates.length) console.log(`Заполнены старший механик и механик: ${updates.length} строк журнала продукции.`);
  return { updated: updates.length };
}

async function getProductionShiftRows() {
  // The visible journal rounds a strength such as 22.86 to 23. Reading the
  // formatted value breaks the exact specification match and turns a valid
  // plan into zero. Production calculations must use the actual cell value.
  const [secondHeader, secondRows] = await getGoogleSheetRanges(productionSpreadsheetId, [`'${productionSheetName}'!A1:AI1`, productionSecondRange], { valueRenderOption: "UNFORMATTED_VALUE" });
  const hasCatalogLine = String(secondHeader?.[0]?.[4] || "").toLocaleLowerCase("ru").includes("линейка");
  return {
    second: (secondRows ?? []).map((row, index) => productionRowFromSecond(row, index + 2, hasCatalogLine)).filter(Boolean),
    secondSummaries: productionSummaryRows(secondRows, 2)
  };
}
function productionSummaryRows(rows, startRow) {
  const prefix = "\u0418\u0442\u043e\u0433";
  let date = "";
  return (rows ?? []).map((row, index) => {
    const recordDate = googleSheetDate(row?.[0]);
    if (recordDate) date = recordDate;
    const label = String(row?.[0] || "").trim();
    const match = label.match(/(\d{4}-\d{2}-\d{2})/);
    return label.startsWith(prefix) && (match || date) ? {
      rowNumber: startRow + index,
      date: match?.[1] || date,
      plannedBoxes: String(row?.[20] ?? "").trim() ? googleNumber(row[20]) : null,
      productEfficiency: String(row?.[21] ?? "").trim() ? googleNumber(row[21]) : null,
      lostMinutes: String(row?.[22] ?? "").trim() ? googleNumber(row[22]) : null
    } : null;
  }).filter(Boolean);
}

function productionRowFromSecond(row, rowNumber, hasCatalogLine) {
  const date = googleSheetDate(row?.[0]);
  if (!date || !hasCatalogLine || !String(row?.[5] || "").trim()) return null;
  const startTime = productionTimeSignature(row[2]);
  const time = productionTimeSignature(row[3]);
  const operator = String(row[14] || "").trim();
  const hasSecondOperator = splitProductionParticipants(operator).length > 1;
  const activeMachines = String(row[23] || "").split(/\s*,\s*/).map(value => value.trim()).filter(Boolean).map(Number).filter(Number.isInteger);
  const machineStartTimes = Object.fromEntries(activeMachines.map((machine, index) => [machine, productionSecondTimeSignature(row[29 + index * 2]) || startTime]));
  const machineEndTimes = Object.fromEntries(activeMachines.map((machine, index) => [machine, productionSecondTimeSignature(row[30 + index * 2]) || time]));
  return { rowNumber, date, line: String(row[1] || "").trim(), startTime, time, catalogLine: String(row[4] || "").trim(), product: String(row[5] || "").trim(), strength: googleNumber(row[6]) || 0, quantity: googleNumber(row[7]) || 0, scrapKg: googleNumber(row[9]) || 0, scrapPercent: productionScrapPercent(row[10]), canScrapKg: googleNumber(row[11]) || 0, shift: String(row[12] || "").trim().toUpperCase(), packer: String(row[13] || "").trim(), operator, mechanic: String(row[15] || "").trim(), seniorMechanic: String(row[16] || "").trim(), note: String(row[17] || "").trim(), operatorSecondStartTime: hasSecondOperator ? productionSecondTimeSignature(row[18]) : "", operatorSecondEndTime: hasSecondOperator ? productionSecondTimeSignature(row[19]) : "", plannedBoxes: String(row[20] ?? "").trim() ? googleNumber(row[20]) : null, productEfficiency: String(row[21] ?? "").trim() ? googleNumber(row[21]) : null, activeMachines, machineStartTimes, machineEndTimes, operatorStartTime: productionSecondTimeSignature(row[24]) || startTime, operatorEndTime: productionSecondTimeSignature(row[25]) || time, operatorReplacement: String(row[26] || "").trim(), operatorReplacementStartTime: productionSecondTimeSignature(row[27]), operatorReplacementEndTime: productionSecondTimeSignature(row[28]) };
}

function productionScrapPercent(value) {
  const source = String(value ?? "").trim();
  if (!source) return null;
  const formattedAsPercent = source.endsWith("%");
  const percent = googleNumber(source.replace("%", ""));
  return Number.isFinite(percent) ? (formattedAsPercent ? percent / 100 : percent) : null;
}

function productionTimeSignature(value) {
  const source = String(value || "").trim();
  const match = source.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (match) return match[1].padStart(2, "0") + ":" + match[2];
  const serial = Number(source.replace(",", "."));
  if (Number.isFinite(serial) && serial >= 0 && serial < 1) {
    const minutes = Math.round(serial * 24 * 60) % (24 * 60);
    return String(Math.floor(minutes / 60)).padStart(2, "0") + ":" + String(minutes % 60).padStart(2, "0");
  }
  return source;
}

function productionSecondTimeSignature(value) {
  const time = productionTimeSignature(value);
  return time === "00:00" ? "" : time;
}

function productionSignature(record) {
  return [record.date, productionTimeSignature(record.startTime), productionTimeSignature(record.time), record.product, record.packer, record.operator, record.operatorReplacement, record.line || record.machineLine, (record.activeMachines || []).join(","), productionTimeSignature(record.operatorStartTime), productionTimeSignature(record.operatorEndTime), productionTimeSignature(record.operatorReplacementStartTime), productionTimeSignature(record.operatorReplacementEndTime)]
    .map(value => String(value || "").trim().toLocaleLowerCase("ru"))
    .join("\u001f");
}

function productionDuplicateKey(record) {
  return [record.date, productionTimeSignature(record.startTime), productionTimeSignature(record.time), record.catalogLine, record.product, record.strength, record.quantity, record.scrapKg, record.canScrapKg, record.packer, record.operator, record.operatorReplacement, record.line || record.machineLine, (record.activeMachines || []).join(","), productionTimeSignature(record.operatorStartTime), productionTimeSignature(record.operatorEndTime), productionTimeSignature(record.operatorReplacementStartTime), productionTimeSignature(record.operatorReplacementEndTime), record.shift, record.note]
    .map(value => typeof value === "number" ? String(value) : String(value || "").trim().toLocaleLowerCase("ru"))
    .join("\u001f");
}

function productionPairKey(record) {
  return [record.date, productionTimeSignature(record.startTime), productionTimeSignature(record.time), record.catalogLine, record.product, record.strength, record.quantity, record.scrapKg, record.packer, record.operator, record.operatorReplacement, productionTimeSignature(record.operatorStartTime), productionTimeSignature(record.operatorEndTime), productionTimeSignature(record.operatorReplacementStartTime), productionTimeSignature(record.operatorReplacementEndTime), record.line || record.machineLine, record.shift]
    .map(value => typeof value === "number" ? String(value) : String(value || "").trim().toLocaleLowerCase("ru"))
    .join("\u001f");
}

function findExistingProductionRecord(rows, record) {
  const duplicateKey = productionDuplicateKey(record);
  const pairKey = productionPairKey(record);
  const second = rows.second.find(item => productionDuplicateKey(item) === duplicateKey || productionPairKey(item) === pairKey);
  return second || null;
}

function validateGatewayProductionRecord(input) {
  const text = (key, label, limit = 5000) => {
    const value = String(input?.[key] || "").trim();
    if (!value) throw new Error(`Заполните поле «${label}»`);
    if (value.length > limit) throw new Error(`Поле «${label}» слишком длинное`);
    return value;
  };
  const decimal = (key, label, positive = false) => {
    const value = Number(String(input?.[key] ?? "").replace(",", "."));
    if (!Number.isFinite(value) || value < 0 || (positive && value <= 0)) throw new Error(`Поле «${label}» заполнено некорректно`);
    return value;
  };
  const date = text("date", "Дата", 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw new Error("Дата должна быть сегодняшней или более ранней");
  const startTime = text("startTime", "Время начала", 5);
  const time = text("time", "Время окончания", 5);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error("Укажите время в формате ЧЧ:ММ");
  const operator = text("operator", "Механик-оператор", 360);
  const operators = operator.split(/\s*(?:;|\||\+)\s*/).map(value => value.trim()).filter(Boolean);
  const operatorReplacement = String(input?.operatorReplacement || operators[2] || "").trim();
  const operatorSecond = operators[1] && operators[1] !== operatorReplacement ? operators[1] : "";
  if (operators.length > 3 || (operatorReplacement && !operators.includes(operatorReplacement))) throw new Error("Некорректно выбраны механики-операторы");
  const enteredOperatorStartTime = String(input?.operatorStartTime || "").trim();
  const enteredOperatorEndTime = String(input?.operatorEndTime || "").trim();
  if ((enteredOperatorStartTime || enteredOperatorEndTime) && (!enteredOperatorStartTime || !enteredOperatorEndTime)) throw new Error("Укажите время начала и окончания работы механика");
  if (enteredOperatorStartTime || enteredOperatorEndTime) {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(enteredOperatorStartTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(enteredOperatorEndTime)) throw new Error("Укажите время в формате ЧЧ:ММ");
    if (enteredOperatorStartTime < startTime || enteredOperatorEndTime > time || enteredOperatorStartTime >= enteredOperatorEndTime) throw new Error("Время механика должно входить в интервал этой записи");
  }
  const enteredSecondStartTime = String(input?.operatorSecondStartTime || "").trim();
  const enteredSecondEndTime = String(input?.operatorSecondEndTime || "").trim();
  let operatorSecondStartTime = "";
  let operatorSecondEndTime = "";
  if (operatorSecond) {
    if (enteredSecondStartTime || enteredSecondEndTime) {
      if (!enteredSecondStartTime || !enteredSecondEndTime) throw new Error("Укажите время начала и окончания работы второго механика-оператора");
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(enteredSecondStartTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(enteredSecondEndTime)) throw new Error("Укажите время в формате ЧЧ:ММ");
      if (enteredSecondStartTime < startTime || enteredSecondEndTime > time || enteredSecondStartTime >= enteredSecondEndTime) throw new Error("Время второго механика-оператора должно входить в интервал этой записи");
      operatorSecondStartTime = enteredSecondStartTime;
      operatorSecondEndTime = enteredSecondEndTime;
    } else {
      operatorSecondStartTime = startTime;
      operatorSecondEndTime = time;
    }
  }
  const replacementStartTime = String(input?.operatorReplacementStartTime || "").trim();
  const replacementEndTime = String(input?.operatorReplacementEndTime || "").trim();
  if (operatorReplacement) {
    if (!enteredOperatorStartTime || !enteredOperatorEndTime || !replacementStartTime || !replacementEndTime) throw new Error("При смене первого механика-оператора укажите время работы обоих сотрудников");
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(replacementStartTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(replacementEndTime)) throw new Error("Укажите время в формате ЧЧ:ММ");
    if (replacementStartTime < startTime || replacementEndTime > time || replacementStartTime >= replacementEndTime) throw new Error("Время нового механика-оператора должно входить в интервал этой записи");
    if (enteredOperatorEndTime > replacementStartTime) throw new Error("Время первого и нового механика-оператора не должно пересекаться");
  }
  const machineLine = text("machineLine", "Линия (машина)", 4).toUpperCase();
  if (!Object.hasOwn(productionMachineColumns, machineLine)) throw new Error("Выберите линию из рабочего списка");
  const activeMachines = [...new Set((Array.isArray(input?.activeMachines) ? input.activeMachines : String(input?.activeMachines || "").split(","))
    .map(value => Number(String(value).trim())).filter(Number.isInteger))];
  const allowedMachines = { B: [2, 3], D: [4, 5], F: [6, 7], H: [8, 9], L: [11, 12, 13], M: [14, 15, 16] }[machineLine] || [];
  if (allowedMachines.length && (!activeMachines.length || activeMachines.some(machine => !allowedMachines.includes(machine)))) throw new Error(`Отметьте работавшие машины линии ${machineLine}`);
  const rawMachineStartTimes = input?.machineStartTimes && typeof input.machineStartTimes === "object" ? input.machineStartTimes : {};
  const rawMachineEndTimes = input?.machineEndTimes && typeof input.machineEndTimes === "object" ? input.machineEndTimes : {};
  const machineStartTimes = {};
  const machineEndTimes = {};
  activeMachines.forEach(machine => {
    const machineStart = String(rawMachineStartTimes[machine] ?? rawMachineStartTimes[String(machine)] ?? startTime).trim() || startTime;
    const machineEnd = String(rawMachineEndTimes[machine] ?? rawMachineEndTimes[String(machine)] ?? time).trim() || time;
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(machineStart) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(machineEnd)) throw new Error("Укажите время работы машины в формате ЧЧ:ММ");
    if (machineStart < startTime || machineEnd > time || machineStart >= machineEnd) throw new Error(`Время работы машины ${machine} должно входить в интервал этой записи`);
    machineStartTimes[machine] = machineStart;
    machineEndTimes[machine] = machineEnd;
  });
  const shift = text("shift", "Смена", 2).toUpperCase();
  if (!['A', 'B'].includes(shift)) throw new Error("Смена должна быть определена из табеля");
  const requestId = text("requestId", "Идентификатор запроса", 160);
  if (!/^[a-zA-Z0-9_-]{8,160}$/.test(requestId)) throw new Error("Некорректный идентификатор запроса");
  const quantity = decimal("quantity", "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u0433\u043e\u0442\u043e\u0432\u043e\u0439 \u043f\u0440\u043e\u0434\u0443\u043a\u0446\u0438\u0438", true);
  const scrapKg = decimal("scrapKg", "\u0411\u0440\u0430\u043a \u043f\u0440\u043e\u0434\u0443\u043a\u0446\u0438\u0438");
  const rawScrapPercent = input?.scrapPercent;
  const scrapPercent = rawScrapPercent === null || rawScrapPercent === undefined || rawScrapPercent === ""
    ? null
    : decimal("scrapPercent", "\u041f\u0440\u043e\u0446\u0435\u043d\u0442 \u0431\u0440\u0430\u043a\u0430");
  if (scrapPercent !== null && scrapPercent >= 1) throw new Error("\u041f\u0440\u043e\u0446\u0435\u043d\u0442 \u0431\u0440\u0430\u043a\u0430 \u0434\u043e\u043b\u0436\u0435\u043d \u0431\u044b\u0442\u044c \u043c\u0435\u043d\u044c\u0448\u0435 100%");
  return {
    requestId,
    date, startTime, time, catalogLine: text("catalogLine", "Линейка продукта", 180), product: text("product", "Продукт", 180),
    strength: decimal("strength", "Крепость", true), quantity,
    scrapKg, scrapPercent, canScrapKg: decimal("canScrapKg", "Вес бракованных банок"),
    packer: text("packer", "Упаковщик", 180), operator, operatorStartTime: enteredOperatorStartTime || startTime, operatorEndTime: enteredOperatorEndTime || time, operatorSecondStartTime, operatorSecondEndTime, operatorReplacement, operatorReplacementStartTime: operatorReplacement ? replacementStartTime : "", operatorReplacementEndTime: operatorReplacement ? replacementEndTime : "", machineLine, activeMachines, machineStartTimes, machineEndTimes, shift,
    note: String(input?.note || "").trim().slice(0, 5000)
  };
}

async function exportProductionDaily(input) {
  const date = String(input?.date || "");
  const today = vilniusDate();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > today || (date === today && !input?.allowCurrentDay)) throw new Error("Передавать можно только завершённый день");
  const records = (await getProductionSnapshot()).records.filter(record => record.date === date);
  const accessToken = await getAccessToken();
  const mechanics = await ensureProductionMechanicsReportLayout(accessToken, records);
  const [machineRows, packerRows, scrapRows, massRows, mechanicsRows, packerHeaders, scrapHeaders, specifications] = await Promise.all([
    getGoogleSheetRanges(productionReportSpreadsheetId, [productionMachineRange]),
    getGoogleSheetRanges(productionReportSpreadsheetId, [productionPackerRange]),
    getGoogleSheetRanges(productionReportSpreadsheetId, [productionScrapRange]),
    getGoogleSheetRanges(productionReportSpreadsheetId, [productionMassRange]),
    getGoogleSheetRanges(productionReportSpreadsheetId, [productionMechanicsRange]),
    getGoogleSheetRanges(productionReportSpreadsheetId, ["'Упаковщики'!A6:V6"]),
    getGoogleSheetRanges(productionReportSpreadsheetId, ["'Брак'!A6:V6"]),
    records.length ? runAppsScript("listProductSpecifications") : Promise.resolve([])
  ]);
  const machine = machineRows[0] ?? [];
  const packers = packerRows[0] ?? [];
  const scrap = scrapRows[0] ?? [];
  const mass = massRows[0] ?? [];
  const mechanicRows = mechanicsRows[0] ?? [];
  const packerHeader = packerHeaders[0]?.[0] ?? [];
  const scrapHeader = scrapHeaders[0]?.[0] ?? [];
  const mechanicsHeader = mechanicRows.length ? await getGoogleSheetRanges(productionReportSpreadsheetId, ["'Механики'!A6:BN6"]).then(rows => rows[0]?.[0] ?? []) : [];
  const machineTarget = getDailyTargetRowFromRows(machine, date, 7, "Станки");
  const packerTarget = getDailyTargetRowFromRows(packers, date, 7, "Упаковщики");
  const scrapTarget = getDailyTargetRowFromRows(scrap, date, 7, "Брак");
  const massTarget = getDailyTargetRowFromRows(mass, date, 7, "Масса");
  const mechanicsTarget = getDailyTargetRowFromRows(mechanicRows, date, 7, "Механики");
  const machineValues = Array(8).fill(0);
  records.forEach(record => {
    const column = productionMachineColumns[String(record.line || "").toUpperCase()];
    if (column !== undefined) machineValues[column - 2] += Number(record.quantity || 0) / 240;
  });
  const writes = [
    setGoogleSheetRanges(productionReportSpreadsheetId, accessToken, [{ range: `'Станки'!C${machineTarget.rowNumber}:J${machineTarget.rowNumber}`, values: [records.length ? machineValues : Array(8).fill("")] }]),
    updateDailyPeopleValues(productionReportSpreadsheetId, accessToken, "Упаковщики", packerTarget.rowNumber, packerHeader, records, record => Number(record.quantity || 0) / 240),
    updateDailyPeopleValues(productionReportSpreadsheetId, accessToken, "Брак", scrapTarget.rowNumber, scrapHeader, records, record => Number(record.scrapKg || 0)),
    setGoogleSheetRanges(productionReportSpreadsheetId, accessToken, [{ range: `'Масса'!B${massTarget.rowNumber}:G${massTarget.rowNumber}`, values: [productionMassValues(records, specifications)] }]),
    updateDailyMechanicsValues(accessToken, mechanicsTarget.rowNumber, mechanicsHeader, records, specifications)
  ];
  await Promise.all(writes);
  return { ok: true, date, records: records.length };
}

async function syncProductionReportDates(dates) {
  const uniqueDates = [...new Set(dates.filter(date => /^\d{4}-\d{2}-\d{2}$/.test(String(date))))];
  for (const date of uniqueDates) await exportProductionDaily({ date, allowCurrentDay: true });
}

function scheduleProductionReportSync(dates) {
  const uniqueDates = [...new Set(dates.filter(date => /^\d{4}-\d{2}-\d{2}$/.test(String(date))))];
  if (uniqueDates.length) runBackgroundTask(`сводка продукции: ${uniqueDates.join(", ")}`, () => syncProductionReportDates(uniqueDates));
}

async function synchronizeAllProductionReports() {
  const dates = [...new Set((await getProductionSnapshot()).records.map(record => record.date).filter(Boolean))].sort();
  await syncProductionReportDates(dates);
  console.log(`Синхронизированы дневные итоги продукции: ${dates.length} дн.`);
}

function reportRowHasValues(row) {
  return Array.isArray(row) && row.some(value => String(value ?? "").trim() !== "");
}

function nextAvailableReportRow(rows, startRow, occupied) {
  for (let index = 0; index < rows.length; index += 1) {
    const rowNumber = startRow + index;
    if (!occupied.has(rowNumber) && !reportRowHasValues(rows[index])) return rowNumber;
  }
  let rowNumber = startRow + rows.length;
  while (occupied.has(rowNumber)) rowNumber += 1;
  return rowNumber;
}

async function updateDailyPeopleValues(spreadsheetId, accessToken, sheetName, rowNumber, headers, records, valueFor) {
  const totals = new Map();
  records.forEach(record => totals.set(record.packer, (totals.get(record.packer) || 0) + valueFor(record)));
  return updateDailyHeaderValues(spreadsheetId, accessToken, sheetName, rowNumber, headers, totals);
}

function updateDailyHeaderValues(spreadsheetId, accessToken, sheetName, rowNumber, headers, totals) {
  const totalIndex = headers.findIndex(value => String(value).trim().startsWith("Всего,"));
  if (totalIndex < 2) throw new Error("Изменилась структура дневной сводки по сотрудникам");
  const people = headers.slice(1, totalIndex);
  return setGoogleSheetRanges(spreadsheetId, accessToken, [{
    range: `'${sheetName}'!B${rowNumber}:${columnLetter(totalIndex - 1)}${rowNumber}`,
    values: [people.map(name => totals.get(String(name).trim()) ?? "")]
  }]);
}

async function ensureProductionMechanicsReportLayout(accessToken, records) {
  let sheetId;
  let sourceName = productionMechanicsSheetName;
  try {
    sheetId = await getSheetId(productionReportSpreadsheetId, productionMechanicsSheetName, accessToken);
  } catch {
    sourceName = productionMechanicsLegacySheetName;
    sheetId = await getSheetId(productionReportSpreadsheetId, productionMechanicsLegacySheetName, accessToken);
  }
  const [mechanicsHeaderRows, leadersHeaderRows] = await Promise.all([
    getGoogleSheetRanges(productionReportSpreadsheetId, [`'${sourceName}'!A6:V6`]),
    getGoogleSheetRanges(productionReportSpreadsheetId, ["'Старшие механики и механики'!A6:V6"])
  ]);
  const namesFromHeader = header => {
    const totalIndex = header.findIndex(value => String(value).trim().startsWith("Всего,"));
    return header.slice(1, totalIndex < 0 ? header.length : totalIndex).map(value => String(value || "").trim()).filter(name => name && !/^Резерв\s*\d*$/i.test(name));
  };
  const namesFromRecords = records.flatMap(record => [
    ...splitProductionParticipants(record.operator), String(record.seniorMechanic || "").trim(), String(record.mechanic || "").trim()
  ]).filter(Boolean);
  const people = [...new Set([...namesFromHeader(mechanicsHeaderRows[0]?.[0] ?? []), ...namesFromHeader(leadersHeaderRows[0]?.[0] ?? []), ...namesFromRecords])];
  if (people.length > 18) throw new Error("В листе «Механики» предусмотрено максимум 18 сотрудников; добавьте место в структуре отчёта");
  const columns = [...people, ...Array.from({ length: 18 - people.length }, (_, index) => `Резерв ${index + 1}`)];
  const header = [
    "Дата", ...columns, "Всего, кор.", "Состояние записи", "Примечание",
    "Сотрудник", ...columns, "Всего брака, кг", "Состояние записи", "Примечание",
    "Сотрудник", ...columns, "Средний процент брака", "Состояние записи", "Примечание"
  ];
  if (header.length !== 66) throw new Error("Некорректная структура листа «Механики»");
  const requests = [{ updateSheetProperties: { properties: { sheetId, gridProperties: { columnCount: 66 } }, fields: "gridProperties.columnCount" } }];
  if (sourceName !== productionMechanicsSheetName) requests.push({ updateSheetProperties: { properties: { sheetId, title: productionMechanicsSheetName }, fields: "title" } });
  if (sourceName !== productionMechanicsSheetName) requests.push(
    { copyPaste: { source: { sheetId, startRowIndex: 4, endRowIndex: 1515, startColumnIndex: 0, endColumnIndex: 22 }, destination: { sheetId, startRowIndex: 4, endRowIndex: 1515, startColumnIndex: 22, endColumnIndex: 44 }, pasteType: "PASTE_FORMAT", pasteOrientation: "NORMAL" } },
    { copyPaste: { source: { sheetId, startRowIndex: 4, endRowIndex: 1515, startColumnIndex: 0, endColumnIndex: 22 }, destination: { sheetId, startRowIndex: 4, endRowIndex: 1515, startColumnIndex: 44, endColumnIndex: 66 }, pasteType: "PASTE_FORMAT", pasteOrientation: "NORMAL" } }
  );
  requests.push(
    { repeatCell: { range: { sheetId, startRowIndex: 6, endRowIndex: 1515, startColumnIndex: 23, endColumnIndex: 42 }, cell: { userEnteredFormat: { numberFormat: { type: "NUMBER", pattern: "0.000" } } }, fields: "userEnteredFormat.numberFormat" } },
    { repeatCell: { range: { sheetId, startRowIndex: 6, endRowIndex: 1515, startColumnIndex: 45, endColumnIndex: 64 }, cell: { userEnteredFormat: { numberFormat: { type: "PERCENT", pattern: "0.0%" } } }, fields: "userEnteredFormat.numberFormat" } }
  );
  if (requests.length) await batchGoogleSheetRequests(productionReportSpreadsheetId, accessToken, requests, "Не удалось подготовить лист «Механики»");
  await setGoogleSheetRanges(productionReportSpreadsheetId, accessToken, [
    { range: "'Механики'!A5:A5", values: [["Выпуск, кор."]] },
    { range: "'Механики'!W5:W5", values: [["Брак, кг"]] },
    { range: "'Механики'!AS5:AS5", values: [["Процент брака, %"]] },
    { range: "'Механики'!A6:BN6", values: [header] }
  ]);
  return { sheetId, people: columns };
}

function productionMassValues(records, specifications) {
  const totals = new Map(productionReportedMasses.map(value => [String(value), 0]));
  records.forEach(record => {
    const mass = productionRecordMass(record, specifications);
    if (!mass) return;
    const key = String(mass.grams);
    if (totals.has(key)) totals.set(key, totals.get(key) + mass.kg);
  });
  return productionReportedMasses.map(value => totals.get(String(value)) || "");
}

function productionRecordMass(record, specifications) {
  const normalize = value => String(value || "").trim().toLocaleLowerCase().replace(/\s+/g, "");
  const specification = (Array.isArray(specifications) ? specifications : []).find(item =>
    normalize(item?.line) === normalize(record.catalogLine)
    && normalize(item?.product) === normalize(record.product)
    && Number(item?.variant) === Number(record.strength)
  );
  const wetMass = Number(specification?.wetMass);
  const dryMass = Number(specification?.dryMass);
  const grams = wetMass > 0 ? wetMass : dryMass > 0 ? dryMass : 0;
  if (!grams && Number(record.quantity || 0) > 0) throw new Error(`Не найден вес банки для «${record.product}», ${record.strength}`);
  return grams ? { grams, kg: Number(record.quantity || 0) * grams / 1000 } : null;
}

async function updateDailyMechanicsValues(accessToken, rowNumber, headers, records, specifications) {
  const people = headers.slice(1, 19).map(value => String(value || "").trim());
  if (headers.length !== 66 || people.length !== 18 || headers[0] !== "Дата") throw new Error("Изменилась структура листа «Механики»");
  const totals = new Map();
  const add = (name, share) => {
    if (!name || !people.includes(name)) return;
    const current = totals.get(name) ?? { boxes: 0, scrapKg: 0, finishedKg: 0 };
    current.boxes += share.boxes;
    current.scrapKg += share.scrapKg;
    current.finishedKg += share.finishedKg;
    totals.set(name, current);
  };
  productionShiftGroups(records).forEach(group => {
    const shiftTotal = { boxes: 0, scrapKg: 0, finishedKg: 0 };
    const lineTotals = new Map();
    const addLineCredit = (name, share) => {
      const current = lineTotals.get(name) ?? { boxes: 0, scrapKg: 0, finishedKg: 0 };
      current.boxes += share.boxes;
      current.scrapKg += share.scrapKg;
      current.finishedKg += share.finishedKg;
      lineTotals.set(name, current);
      add(name, share);
    };
    group.records.forEach(record => {
      const finishedKg = productionRecordMass(record, specifications)?.kg || 0;
      const boxes = Number(record.quantity || 0) / 240;
      const scrapKg = Number(record.scrapKg || 0);
      productionLineCredits(record).forEach(({ name, fraction }) => addLineCredit(name, { boxes: boxes * fraction, scrapKg: scrapKg * fraction, finishedKg: finishedKg * fraction }));
      shiftTotal.boxes += boxes;
      shiftTotal.scrapKg += scrapKg;
      shiftTotal.finishedKg += finishedKg;
    });
    productionShiftRoleCredits(group).forEach(({ name, fraction }) => {
      // One report column represents one person. If that person also stood at
      // a line, replace that line share for this shift with the full result of
      // the selected shift role instead of adding the production twice.
      const line = lineTotals.get(name) ?? { boxes: 0, scrapKg: 0, finishedKg: 0 };
      add(name, {
        boxes: shiftTotal.boxes * fraction - line.boxes,
        scrapKg: shiftTotal.scrapKg * fraction - line.scrapKg,
        finishedKg: shiftTotal.finishedKg * fraction - line.finishedKg
      });
    });
  });
  const values = name => totals.get(name);
  const display = (name, key) => values(name) ? values(name)[key] : "";
  const percent = name => {
    const value = values(name);
    return value && value.finishedKg + value.scrapKg > 0 ? value.scrapKg / (value.finishedKg + value.scrapKg) : "";
  };
  // T:V, AP:AR and BL:BN are report formulas.  Keep them intact: they are
  // responsible for the daily totals and status, while the exporter owns only
  // the per-person distribution cells.
  await setGoogleSheetRanges(productionReportSpreadsheetId, accessToken, [
    { range: `'Механики'!B${rowNumber}:S${rowNumber}`, values: [people.map(name => display(name, "boxes"))] },
    { range: `'Механики'!X${rowNumber}:AO${rowNumber}`, values: [people.map(name => display(name, "scrapKg"))] },
    { range: `'Механики'!AT${rowNumber}:BK${rowNumber}`, values: [people.map(percent)] }
  ]);
}

function columnLetter(index) {
  let value = index + 1;
  let text = "";
  while (value) { const remainder = (value - 1) % 26; text = String.fromCharCode(65 + remainder) + text; value = Math.floor((value - 1) / 26); }
  return text;
}

function findDailyShiftRow(rows, date, shift, startRow, label) {
  const index = rows.findIndex(row => googleSheetDate(row[0]) === date && String(row[1] || "").trim().toUpperCase() === shift);
  if (index < 0) throw new Error(`В листе «${label}» не найдена строка ${displayDate(date)} · смена ${shift}`);
  return { rowNumber: startRow + index };
}

function getDailyTargetRowFromRows(rows, date, startRow, label) {
  const index = rows.findIndex(row => googleSheetDate(row[0]) === date);
  if (index < 0) throw new Error(`В листе «${label}» не найдена строка даты ${displayDate(date)}`);
  return { rowNumber: startRow + index };
}

async function runAutomaticDailyProductionExport() {
  if (!writesEnabled || missingGoogleSettings().length) return;
  const clock = vilniusClock();
  if (clock.hour < automaticDailyExportHour || automaticDailyProductionExportCompletedDate === clock.date) return;
  if (Date.now() - automaticDailyProductionExportAttemptAt < 60 * 60_000) return;
  automaticDailyProductionExportAttemptAt = Date.now();
  const date = previousCalendarDate(clock.date);
  try {
    const result = await exportProductionDaily({ date });
    automaticDailyProductionExportCompletedDate = clock.date;
    console.log(result.empty ? `Сводка продукции: записей за ${date} нет` : `Суточная сводка продукции выполнена: ${date}`);
  } catch (error) {
    console.warn(`Суточная сводка продукции не выполнена за ${date}: ${error.message}`);
  }
}

async function getDailyTargetRow(spreadsheetId, range, date, startRow, label) {
  const rows = (await getGoogleSheetRanges(spreadsheetId, [range]))[0] ?? [];
  const index = rows.findIndex(row => googleSheetDate(row[0]) === date);
  if (index < 0) throw new Error(`В листе «${label}» не найдена строка даты ${displayDate(date)}`);
  return { rowNumber: startRow + index };
}

async function updateSheetCells(spreadsheetId, accessToken, start, values) {
  const request = { updateCells: { start, rows: [{ values: values.map(value => ({ userEnteredValue: { numberValue: Number(value || 0) } })) }], fields: "userEnteredValue" } };
  await batchGoogleSheetRequests(spreadsheetId, accessToken, [request], "Не удалось передать суточные итоги");
}

async function batchGoogleSheetRequests(spreadsheetId, accessToken, requests, fallbackMessage) {
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}:batchUpdate`, { method: "POST", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" }, body: JSON.stringify({ requests }), signal: AbortSignal.timeout(20_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || fallbackMessage);
}

function validatePackagingRecord(input) {
  if (!input || !["manager", "senior"].includes(input.role)) throw new Error("Недостаточно прав");
  const id = String(input.recordId || ""); const requestId = String(input.requestId || "");
  if (!/^[a-zA-Z0-9_-]{8,160}$/.test(id) || !/^[a-zA-Z0-9_-]{8,160}$/.test(requestId)) throw new Error("Некорректный идентификатор записи");
  const date = String(input.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > vilniusDate()) throw new Error("Некорректная дата расхода упаковки");
  const values = Object.fromEntries(packagingKeys.map(key => {
    const value = Number(input.values?.[key]);
    if (!Number.isFinite(value) || value < 0) throw new Error("Некорректный расход упаковки");
    return [key, value];
  }));
  if (!Object.values(values).some(value => value > 0)) throw new Error("Не указан расход упаковки");
  return { id, requestId, date, values, workstationId: String(input.workstationId || "") };
}

function readPackagingPendingRecords() {
  if (!existsSync(packagingPendingPath)) return [];
  try {
    const value = JSON.parse(readFileSync(packagingPendingPath, "utf8"));
    if (!Array.isArray(value?.records)) return [];
    return value.records.map(item => {
      const date = String(item?.date || "");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
      const values = Object.fromEntries(packagingKeys.map(key => [key, Number(item?.values?.[key] || 0)]));
      if (!Object.values(values).some(number => Number.isFinite(number) && number > 0)) return null;
      return {
        id: `packaging-day-${date}`,
        requestId: String(item?.requestId || ""),
        date,
        values,
        workstationId: String(item?.workstationId || ""),
        pending: true
      };
    }).filter(Boolean);
  } catch {
    return [];
  }
}

function writePackagingPendingRecords(records) {
  const directory = dirname(packagingPendingPath);
  mkdirSync(directory, { recursive: true });
  const temporary = `${packagingPendingPath}.${process.pid}.tmp`;
  writeFileSync(temporary, `${JSON.stringify({ records }, null, 2)}\n`, "utf8");
  renameSync(temporary, packagingPendingPath);
}

async function flushPendingPackagingRecord(date) {
  const pending = readPackagingPendingRecords();
  const record = pending.find(item => item.date === date);
  if (!record) return false;
  const existing = (await getPackagingSheetRecords()).find(item => item.date === date);
  await writePackagingRecordToSheet(record, existing);
  writePackagingPendingRecords(pending.filter(item => item.date !== date));
  return true;
}

async function migratePendingPackagingRecords() {
  const pending = readPackagingPendingRecords();
  if (!pending.length) return false;
  const existingByDate = new Map((await getPackagingSheetRecords()).map(record => [record.date, record]));
  for (const record of pending) {
    const saved = await writePackagingRecordToSheet(record, existingByDate.get(record.date) || null);
    existingByDate.set(record.date, saved);
  }
  writePackagingPendingRecords([]);
  console.log(`Перенесено ранее не отправленных записей расхода упаковки: ${pending.length}`);
  return true;
}

async function migrateAndReconcilePackagingRecords() {
  await migratePendingPackagingRecords();
  const records = await getPackagingSheetRecords();
  for (const record of records) await syncPackagingTargets(record);
  if (records.length) console.log(`Сверены целевые журналы расхода упаковки: ${records.length}`);
}

async function getNextPackagingRowNumber() {
  const records = await getPackagingSheetRecords();
  return Math.max(2, ...records.map(record => record.rowNumber)) + 1;
}

async function getPackagingDateNotes() {
  assertGoogleConfigured();
  const accessToken = await getAccessToken();
  const query = new URLSearchParams({ includeGridData: "true", ranges: `'${packagingSheetName}'!A3:A`, fields: "sheets(data(rowData(values(note))))" });
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(packagingSpreadsheetId)}?${query}`, { headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(12_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось прочитать журнал расхода упаковки");
  return payload.sheets?.[0]?.data?.[0]?.rowData?.map(row => row.values?.[0]?.note || "") ?? [];
}

async function getPackagingSheetId(accessToken) { return getSheetId(packagingSpreadsheetId, packagingSheetName, accessToken); }

async function getSheetId(spreadsheetId, sheetName, accessToken) {
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}?fields=sheets(properties(sheetId,title))`, { headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(12_000) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось открыть рабочий журнал");
  const sheet = payload.sheets?.find(item => item.properties?.title === sheetName);
  if (!sheet) throw new Error(`Не найден лист «${sheetName}»`);
  return sheet.properties.sheetId;
}

/**
 * Repair and scale journals use strict Google Sheets source lists.  They are
 * derived from the personnel directory.  We only append missing people: old
 * dictionary values may be referenced by manually maintained reports, while
 * the server itself rejects a dismissed employee for every new journal row.
 */
function ensureScaleJournalAuthor(author) {
  return queuePersonnelReferenceSync(async () => {
    const workforce = await getWorkforceSnapshot();
    const fullName = String(author || "").trim().replace(/\s+/g, " ");
    const employee = workforce.personnel.find(person => sameWorkforcePersonName(person.fullName, fullName));
    if (!employee || employee.active === false) throw new Error(`Сотрудник «${fullName}» отсутствует среди действующего персонала`);
    await synchronizePersonnelReferencesNow(workforce.personnel);
  });
}

function synchronizePersonnelReferences(personnel) {
  return queuePersonnelReferenceSync(() => synchronizePersonnelReferencesNow(personnel));
}

function queuePersonnelReferenceSync(work) {
  const task = personnelReferenceSyncTail.then(work);
  // A failed refresh must not prevent the next saved employee or journal entry
  // from retrying the same idempotent source lists.
  personnelReferenceSyncTail = task.catch(() => {});
  return task;
}

async function synchronizePersonnelReferencesNow(personnel) {
  const active = (personnel || []).filter(person => person?.active !== false && String(person.fullName || "").trim());
  const scaleAuthors = workforceReferenceNames(active);
  const repairPerformers = workforceReferenceNames(active.filter(person => person.fullName === "Anatolii Brazhko" || ["senior-mechanic", "mechanic"].includes(person.role)));
  if (!scaleAuthors.length) throw new Error("В справочнике персонала нет действующих сотрудников для журналов");
  if (!repairPerformers.length) throw new Error("В справочнике персонала нет действующего механика для журнала ремонта");
  const accessToken = await getAccessToken();
  const [[repairRows], [scaleRows]] = await Promise.all([
    getGoogleSheetRanges(repairsSpreadsheetId, ["'Справочники'!A2:A1000"]),
    getGoogleSheetRanges(scaleJournalSpreadsheetId, [`'${scaleJournalAuthorSheetName}'!${scaleJournalAuthorColumn}${scaleJournalAuthorStartRow}:${scaleJournalAuthorColumn}${scaleJournalAuthorEndRow}`])
  ]);
  await Promise.all([
    appendMissingPersonnelReferences(repairsSpreadsheetId, accessToken, "'Справочники'", "A", 2, repairRows || [], repairPerformers),
    appendMissingPersonnelReferences(scaleJournalSpreadsheetId, accessToken, `'${scaleJournalAuthorSheetName}'`, scaleJournalAuthorColumn, scaleJournalAuthorStartRow, scaleRows || [], scaleAuthors)
  ]);
  await ensureScaleJournalAuthorValidation(accessToken);
}

function workforceReferenceNames(personnel) {
  return [...new Map((personnel || []).map(person => [String(person.fullName || "").trim().toLocaleLowerCase(), String(person.fullName || "").trim()])).values()]
    .filter(Boolean)
    .sort((left, right) => left.localeCompare(right, "lt"));
}

async function appendMissingPersonnelReferences(spreadsheetId, accessToken, sheetName, column, startRow, rows, names) {
  const known = new Set((rows || []).map(row => String(row[0] || "").trim().toLocaleLowerCase()).filter(Boolean));
  const missing = names.filter(name => !known.has(name.toLocaleLowerCase()));
  if (!missing.length) return;
  const emptyRows = (rows || []).map((row, index) => String(row[0] || "").trim() ? -1 : startRow + index).filter(row => row > 0);
  if (emptyRows.length < missing.length) throw new Error("В справочнике Google нет свободного места для новых сотрудников");
  await setGoogleSheetRanges(spreadsheetId, accessToken, missing.map((name, index) => ({
    range: `${sheetName}!${column}${emptyRows[index]}`,
    values: [[name]]
  })));
}

async function ensureScaleJournalAuthorValidation(accessToken) {
  if (scaleJournalAuthorValidationReady) return;
  const sheetId = await getSheetId(scaleJournalSpreadsheetId, scaleJournalSheetName, accessToken);
  await batchGoogleSheetRequests(scaleJournalSpreadsheetId, accessToken, [{
    setDataValidation: {
      range: {
        sheetId,
        startRowIndex: 6,
        endRowIndex: scaleJournalAuthorValidationEndRow,
        startColumnIndex: 7,
        endColumnIndex: 8
      },
      rule: {
        condition: { type: "ONE_OF_RANGE", values: [{ userEnteredValue: `='${scaleJournalAuthorSheetName}'!$${scaleJournalAuthorColumn}$${scaleJournalAuthorStartRow}:$${scaleJournalAuthorColumn}$${scaleJournalAuthorEndRow}` }] },
        strict: true,
        showCustomUi: true
      }
    }
  }], "Не удалось обновить список исполнителей журнала контроля весов");
  scaleJournalAuthorValidationReady = true;
}

function packagingRecordFromRow(row, rowNumber, note) {
  if (!row?.some(value => value !== "" && value !== undefined)) return null;
  const date = googleSheetDate(row[0]);
  if (!date && row.slice(1).every(value => String(value ?? "").trim() === "")) return null;
  if (!date) throw new Error(`Проверьте строку ${rowNumber} журнала расхода упаковки`);
  let receipt = {};
  if (String(note).startsWith(packagingReceiptPrefix)) { try { receipt = JSON.parse(String(note).slice(packagingReceiptPrefix.length)); } catch { throw new Error(`Повреждена служебная отметка в строке ${rowNumber}`); } }
  return { id: `packaging-day-${date}`, requestId: receipt.requestId || "", rowNumber, date, values: Object.fromEntries(packagingKeys.map((key, index) => [key, Number(row[index + 1] || 0)])) };
}

function googleSerialToDate(value) {
  const serial = Number(value); if (!Number.isFinite(serial)) return null;
  return new Date(Date.UTC(1899, 11, 30) + Math.round(serial) * 86_400_000).toISOString().slice(0, 10);
}

function googleSheetDate(value) {
  if (String(value ?? "").trim() === "") return null;
  const serialDate = googleSerialToDate(value); if (serialDate) return serialDate;
  const match = String(value || "").trim().match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/);
  return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}` : null;
}

function displayDate(value) { const [year, month, day] = String(value).split("-"); return `${day}.${month}.${year}`; }

function vilniusDate() {
  return vilniusClock().date;
}

function vilniusDateTime() {
  const clock = vilniusClock();
  return `${displayDate(clock.date)} ${clock.hour}:${clock.minute}:${clock.second}`;
}

function vilniusClock(now = new Date()) {
  const values = Object.fromEntries(new Intl.DateTimeFormat("en", { timeZone: "Europe/Vilnius", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" })
    .formatToParts(now).filter(part => part.type !== "literal").map(part => [part.type, part.value]));
  return { date: `${values.year}-${values.month}-${values.day}`, hour: values.hour, minute: values.minute, second: values.second };
}

function previousCalendarDate(date) { const value = new Date(`${date}T12:00:00Z`); value.setUTCDate(value.getUTCDate() - 1); return value.toISOString().slice(0, 10); }

async function getGoogleSheetRanges(spreadsheetId, ranges, { valueRenderOption = "FORMATTED_VALUE" } = {}) {
  assertGoogleConfigured();
  const accessToken = await getAccessToken();
  const parameters = new URLSearchParams({ valueRenderOption });
  ranges.forEach(range => parameters.append("ranges", range));
  const endpoint = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values:batchGet?${parameters}`;
  const response = await fetch(endpoint, {
    headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" }, signal: AbortSignal.timeout(12_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось прочитать рабочий журнал");
  return (payload.valueRanges ?? []).map(range => range.values ?? []);
}

async function setGoogleSheetRanges(spreadsheetId, accessToken, data) {
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values:batchUpdate`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ valueInputOption: "USER_ENTERED", data }),
    signal: AbortSignal.timeout(20_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось сохранить смену в журнале продукции");
}

async function setShiftTaskRow(accessToken, rowNumber, record) {
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(shiftTaskSpreadsheetId)}/values:batchUpdate`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ valueInputOption: "RAW", data: [{ range: `'${shiftTaskSheetName}'!A${rowNumber}:N${rowNumber}`, values: [shiftTaskValues(record)] }] }),
    signal: AbortSignal.timeout(20_000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw googleError(response.status, payload?.error?.message || "Не удалось сохранить сменное задание");
}

function workforceTeam(row) {
  return {
    id: String(row[6] || ""), name: String(row[0] || ""),
    code: row[6] === "shift-team-a" ? "A" : row[6] === "shift-team-b" ? "B" : "5/2",
    anchorDate: googleDate(row[1]), cycleLengthDays: googleNumber(row[2]),
    workDayOffsets: String(row[3] || "").split(",").map(Number).filter(Number.isFinite),
    shiftDurationHours: googleNumber(row[4]), accountingHours: googleNumber(row[5]), active: true,
    revision: workforceRevision(row)
  };
}

function workforcePerson(row, teams) {
  return {
    id: String(row[7] || ""), fullName: String(row[0] || ""), role: workforceRole(row[1]),
    shiftTeamId: teams.find(team => team.name === String(row[2] || ""))?.id || String(row[11] || ""),
    active: String(row[5] || "") === "Работает", note: String(row[6] || ""),
    pakNumber: String(row[3] || ""), pakCode: String(row[4] || ""), birthday: googleDate(row[12]), hireDate: googleDate(row[13]),
    phone: String(row[14] || ""), email: String(row[15] || ""), revision: workforceRevision(row), updatedAt: googleDate(row[9])
  };
}

function workforceAttendance(rows, personnel, teams, year) {
  const personnelById = new Map(personnel.map(person => [person.id, person]));
  return rows.flatMap(row => {
    const employee = personnelById.get(String(row[38] || ""));
    const month = Number(row[0]);
    if (!employee || !month) return [];
    const shiftTeamId = teams.find(team => team.name === String(row[2] || ""))?.id || String(row[43] || "") || employee.shiftTeamId;
    const overtimeDays = new Set(String(row[42] || "").split(",").filter(Boolean));
    return Array.from({ length: new Date(year, month, 0).getDate() }, (_, index) => {
      const day = index + 1;
      const rawValue = String(row[day + 2] || "");
      // Google returns formatted decimals with a comma in the Lithuanian locale.
      // Keep the internal value canonical so 9,5 selects 9.5 rather than the
      // first option in the browser control after a refresh.
      const value = normalizeWorkforceAttendanceValue(rawValue) || rawValue;
      if (!value || value === "—") return null;
      const substitute = workforceSubstitute(row[37], day);
      return {
        id: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}:${shiftTeamId}:${employee.id}`,
        date: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`, employeeId: employee.id, shiftTeamId, value,
        overtime: overtimeDays.has(String(day)), substitutionReason: substitute?.reason || "", homeShiftTeamId: substitute?.homeShiftTeamId || "",
        revision: workforceRevision([value, overtimeDays.has(String(day)), substitute?.reason || "", substitute?.homeShiftTeamId || ""]),
        updatedAt: googleDate(row[40]), updatedBy: String(row[41] || "")
      };
    }).filter(Boolean);
  });
}

function workforceVacations(rows, year, personnel = []) {
  const employeeByName = new Map(personnel.map(employee => [String(employee.fullName || "").trim().toLocaleLowerCase(), employee.id]));
  return rows.map(row => {
    const legacy = String(row[7] || "").startsWith("vacation:") && !String(row[8] || "").startsWith("vacation:");
    const offset = legacy ? -1 : 0;
    return {
      id: String(row[8 + offset] || ""), employeeId: String(row[9 + offset] || employeeByName.get(String(row[0] || "").trim().toLocaleLowerCase()) || ""), year, startDate: googleDate(row[3 + offset]), endDate: googleDate(row[4 + offset]),
      days: Number.isFinite(googleNumber(row[5 + offset])) ? googleNumber(row[5 + offset]) : null, status: String(row[6 + offset] || ""), note: String(row[7 + offset] || ""),
      revision: workforceVacationRevision(row, offset), updatedAt: googleDate(row[11 + offset]), updatedBy: String(row[12 + offset] || "")
    };
  }).filter(row => row.id && row.startDate && row.endDate);
}

function workforceVacationBalances(rows, personnel = []) {
  const knownPersonnel = new Set(personnel.map(person => person.id));
  return rows.map((row, index) => ({
    sourceRow: index + 4, year: Number(row[0]), employeeId: String(row[1] || "").trim(), factualRemaining: googleNumber(row[3]), asOfDate: googleDate(row[4]), adjustment: googleNumber(row[5]), note: String(row[6] || "").trim(),
    accruedAfterSnapshot: googleNumber(row[7]), usedAfterSnapshot: googleNumber(row[8]), currentRemaining: googleNumber(row[9]), calculatedAt: googleDate(row[10])
  })).filter(row => workforceVacationYears.includes(row.year) && knownPersonnel.has(row.employeeId) && Number.isFinite(row.factualRemaining) && row.asOfDate).map(row => ({ ...row, adjustment: Number.isFinite(row.adjustment) ? row.adjustment : 0 }));
}

function workforceVacationRevision(row, offset = 0) {
  return workforceRevision([row[0], row[1 + offset], row[2 + offset], googleDate(row[3 + offset]), googleDate(row[4 + offset]), row[6 + offset], row[7 + offset], row[8 + offset], row[9 + offset], row[10 + offset]]);
}

function workforceRole(value) {
  return ({ "Администрация": "head-of-area", "Начальник участка": "head-of-area", "Начальник производства": "production-manager", "Администратор": "administrator", "Начальник склада": "warehouse-manager", "Старший механик": "senior-mechanic", "Механик": "mechanic", "Механик-оператор": "mechanic-operator", "Упаковщик": "packer" })[String(value || "")] || "";
}

function workforceSubstitute(note, day) {
  const match = String(note || "").match(/Подменный выход \(штатная смена ([AB])\):\s*([^\n]+)/);
  const item = match?.[2].split(";").map(value => value.trim()).find(value => value.startsWith(`${day} — `));
  return item ? { homeShiftTeamId: `shift-team-${match[1].toLowerCase()}`, reason: item.slice(`${day} — `.length).trim() } : null;
}

function googleDate(value) {
  const text = String(value || "").trim();
  const match = text.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}` : text;
}

function workforceRevision(value) {
  // Must use the exact token generated by workforce-api.gs (wfToken_()).
  // The former base64-encoded payload was only an opaque representation, so
  // Apps Script treated every edit of an existing attendance cell as stale.
  return createHash("sha256").update(JSON.stringify(value), "utf8").digest("base64url");
}


function serveStatic(pathname, response) {
  const relativePath = pathname === "/" ? "index.html" : decodeURIComponent(pathname).replace(/^\/+/, "");
  let filePath = resolve(projectRoot, relativePath);
  const rel = relative(projectRoot, filePath);
  const publicPath = rel.split(sep).join("/");
  const outsideProject = rel.startsWith(`..${sep}`) || rel === "..";
  const allowed = publicFiles.has(publicPath) || publicDirectories.some(directory => publicPath.startsWith(directory));
  if (outsideProject || !allowed || !existsSync(filePath) || statSync(filePath).isDirectory()) {
    response.writeHead(404, {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff"
    });
    response.end("Страница не найдена");
    return;
  }
  response.writeHead(200, {
    "Content-Type": types[extname(filePath)] || "application/octet-stream",
    "Cache-Control": extname(filePath) === ".html" ? "no-cache" : "public, max-age=300",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "same-origin"
  });
  createReadStream(filePath).pipe(response);
}

function readJsonBody(request, maximumBytes = maximumBodyBytes) {
  return new Promise((resolveBody, reject) => {
    let body = "";
    request.setEncoding("utf8");
    request.on("data", chunk => {
      body += chunk;
      if (Buffer.byteLength(body, "utf8") > maximumBytes) {
        const error = new Error("Запрос слишком большой");
        error.statusCode = 413;
        reject(error);
        request.destroy();
      }
    });
    request.on("end", () => {
      try {
        resolveBody(JSON.parse(body || "{}"));
      } catch {
        const error = new Error("Некорректные данные запроса");
        error.statusCode = 400;
        reject(error);
      }
    });
    request.on("error", reject);
  });
}

function sendJson(response, statusCode, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...extraHeaders
  });
  response.end(body);
}

function sendJavaScript(response, body) {
  response.writeHead(200, {
    "Content-Type": "text/javascript; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(body);
}

function assertGoogleConfigured() {
  const missing = missingGoogleSettings();
  if (!missing.length) return;
  const error = new Error(`Не заполнены настройки: ${missing.join(", ")}`);
  error.statusCode = 503;
  error.publicMessage = "На этом компьютере не завершено подключение к Google. Откройте CONNECT-GOOGLE.cmd и войдите в корпоративную учётную запись.";
  throw error;
}

function missingGoogleSettings() {
  return [
    "GOOGLE_OAUTH_CLIENT_ID",
    "GOOGLE_OAUTH_CLIENT_SECRET",
    "GOOGLE_OAUTH_REFRESH_TOKEN",
    "GOOGLE_SCRIPT_DEPLOYMENT_ID"
  ].filter(name => !process.env[name]);
}

function googleError(statusCode, message) {
  const error = new Error(message);
  error.name = "GoogleApiError";
  error.statusCode = statusCode === 401 || statusCode === 403 ? statusCode : 502;
  error.publicMessage = readableGoogleError(message);
  return error;
}

async function googleConnectionStatus() {
  try {
    assertGoogleConfigured();
    await getAccessToken();
  } catch (error) {
    return { ok: true, ready: false, message: error.publicMessage || "Не удалось получить доступ к Google. Записи остаются в очереди.", detail: safeGoogleDiagnostic(error) };
  }
  const checks = await Promise.allSettled([
    runAppsScript("listScaleRecords"),
    runAppsScript("listCycloneRecords")
  ]);
  const scaleReady = checks[0].status === "fulfilled";
  const cycloneReady = checks[1].status === "fulfilled";
  if (scaleReady && cycloneReady) return { ok: true, ready: true, message: "Связь с Google и журналами контроля весов и очистки циклонов работает." };
  const failed = checks.find(item => item.status === "rejected");
  return {
    ok: true,
    ready: false,
    message: failed?.reason?.publicMessage || "Google не ответил на проверку рабочих журналов. Записи остаются в очереди.",
    detail: safeGoogleDiagnostic(failed?.reason),
    journals: { scaleControl: scaleReady, cyclones: cycloneReady }
  };
}

function safeGoogleDiagnostic(error) {
  const detail = String(error?.message || "").trim();
  if (!detail) return "";
  return detail
    .replace(/(authorization:\s*bearer\s+)[^\s]+/gi, "$1[скрыто]")
    .replace(/((?:access|refresh)[_-]?token|client[_-]?secret)\s*[=:]\s*[^\s,;]+/gi, "$1=[скрыто]")
    .slice(0, 500);
}

function readableGoogleError(message) {
  const detail = String(message || "");
  if (/invalid_grant|invalid client|refresh token|токен.*отозван/i.test(detail)) return "Доступ Google истёк или был отозван. На этом компьютере запустите CONNECT-GOOGLE.cmd и войдите в корпоративную учётную запись.";
  if (/исполнитель отсутствует в действующем персонале/i.test(detail)) return "Выбранного исполнителя нет в действующем персонале. Обновите список сотрудников и выберите имя из него.";
  if (/запись очисток в google выключена/i.test(detail)) return "Запись очисток в Google выключена. Включите разрешение для журнала очистки циклонов у администратора.";
  if (/script function not found|function not found|не найдена функция/i.test(detail)) return "В Google Apps Script отсутствует нужная функция журнала. Нужно опубликовать актуальную версию Apps Script из программы.";
  if (/requested entity was not found|not found.*script|deployment/i.test(detail)) return "Не найдено развёртывание Google Apps Script. Проверьте GOOGLE_SCRIPT_DEPLOYMENT_ID в настройках рабочего компьютера.";
  if (/permission|forbidden|insufficient.*permission|caller does not have permission|недостаточно прав|нет разреш/i.test(detail)) return "У учётной записи Google на этом компьютере нет доступа к таблице СИЗ. Запустите CONNECT-GOOGLE.cmd и войдите в учётную запись с правом редактирования «Сводная» и «Фасовка», затем нажмите «Обновить».";
  if (/quota|rate limit|resource exhausted/i.test(detail)) return "Google временно ограничил количество запросов. Очередь сохранена — повторите отправку через несколько минут.";
  if (/timeout|timed out|deadline/i.test(detail)) return "Google не ответил вовремя. Очередь сохранена — повторите отправку.";
  return "Google отклонил запрос. Очередь сохранена на этом компьютере; нажмите «Проверить Google» для повторной проверки.";
}

function numberFromEnvironment(name, fallback) {
  const value = Number(process.env[name] || fallback);
  if (Number.isInteger(value) && value > 0 && value <= 65535) return value;
  throw new Error(`${name} должен быть корректным номером порта`);
}

function hourFromEnvironment(name, fallback) {
  const value = Number(process.env[name] ?? fallback);
  if (Number.isInteger(value) && value >= 0 && value <= 23) return value;
  throw new Error(`${name} должен быть целым числом от 0 до 23`);
}

function normalizeWorkstationRole(value) {
  if (!value) return null;
  if (["manager", "senior"].includes(value)) return value;
  throw new Error("WORKSTATION_ROLE должен иметь значение manager или senior");
}

function normalizeWorkstationId(value) {
  if (!value) return null;
  const result = String(value).trim().toLowerCase();
  if (/^[a-z0-9][a-z0-9-]{1,63}$/.test(result)) return result;
  throw new Error("WORKSTATION_ID должен содержать латинские буквы, цифры и дефисы");
}

function normalizeWorkstationLabel(value) {
  if (!value) return null;
  const result = String(value).trim();
  if (result.length <= 80) return result;
  throw new Error("WORKSTATION_LABEL не должен превышать 80 символов");
}

function actorFromRequest(request) {
  if (centralAuth) return centralAuth.accountForToken(readCookie(request, "PFH_SESSION"));
  if (!workstationRole) return null;
  return {
    id: workstationRole === "manager" ? "manager" : "senior-mechanic",
    role: workstationRole,
    title: workstationRole === "manager" ? "Администрация" : "Старший механик",
    description: workstationLabel || "Рабочее место"
  };
}

function requireActor(request, roles = null) {
  const actor = actorFromRequest(request);
  if (!actor) {
    const error = new Error("Сначала войдите в учётную запись");
    error.statusCode = 401;
    throw error;
  }
  if (roles && !roles.includes(actor.role)) {
    const error = new Error("Недостаточно прав");
    error.statusCode = 403;
    throw error;
  }
  return actor;
}

async function requireNonconformityWriter(request, input = null) {
  const actor = requireActor(request, ["manager", "senior", "mechanic"]);
  if (!centralMode) return actor;
  const shift = await currentCentralShiftState();
  const seniorMechanic = String(shift?.seniorMechanic || shift?.supervisor || "").trim();
  const mechanic = String(shift?.mechanic || "").trim();
  if (!shift?.active || shift.shiftDate !== todayInVilnius() || !seniorMechanic) {
    const error = new Error("Вносить несоответствия можно только во время активной смены.");
    error.statusCode = 403;
    throw error;
  }
  const reporters = [seniorMechanic, mechanic].filter(Boolean);
  if (input?.reportedBy && !reporters.includes(String(input.reportedBy).trim())) {
    const error = new Error("Выберите старшего механика или механика текущей смены.");
    error.statusCode = 403;
    throw error;
  }
  return actor;
}

async function requireIncidentWriter(request, input = null) {
  const actor = requireActor(request, ["manager", "senior"]);
  if (actor.role === "manager") return actor;
  return requireNonconformityWriter(request, input);
}

function readCentralShiftState() {
  if (!centralMode || !existsSync(centralShiftStatePath)) return null;
  try {
    const value = JSON.parse(readFileSync(centralShiftStatePath, "utf8"));
    return value && typeof value === "object" ? value : null;
  } catch {
    // A damaged non-secret status file must not stop the gateway.
    return null;
  }
}

function writeCentralShiftState(value) {
  const directory = dirname(centralShiftStatePath);
  mkdirSync(directory, { recursive: true });
  const temporary = `${centralShiftStatePath}.${process.pid}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  renameSync(temporary, centralShiftStatePath);
  return value;
}

function closeExpiredCentralShift(now = new Date()) {
  const current = readCentralShiftState();
  if (!shouldAutomaticallyCloseCentralShift(current, vilniusClock(now))) return current;
  const reason = current.shiftDate < todayInVilnius() ? "automatic-next-day" : "automatic-23-55";
  const closed = writeCentralShiftState({
    ...current,
    active: false,
    endedAt: now.toISOString(),
    endedBy: "automatic",
    endedReason: reason
  });
  console.log(`[shift] Смена ${current.shiftDate} завершена автоматически (${reason}).`);
  return closed;
}

async function currentCentralShiftState() {
  // The timer is only a background safeguard. Reading the shared state must
  // also close an expired shift, so a restart delay cannot block tomorrow's
  // team from starting work.
  const shift = closeExpiredCentralShift();
  if (!shift?.active || shift.shiftDate !== todayInVilnius()) return shift;
  try {
    const workforce = await getWorkforceSnapshot();
    const actual = new Map((workforce.attendance || [])
      .filter(item => item.date === shift.shiftDate && item.shiftTeamId === shift.shiftTeamId)
      .map(item => [item.employeeId, item]));
    if (!actual.size) return shift;
    // Google Sheets is the authoritative personnel timesheet. The central
    // record coordinates the active shift, but must never show an older status
    // after an attendance entry was saved from another workstation.
    const attendance = (shift.attendance || []).map(item => {
      const record = actual.get(item.employeeId);
      return record ? {
        ...item,
        status: String(record.value || item.status),
        ...(record.substitutionReason ? {
          isSubstitute: true,
          substitutionReason: record.substitutionReason,
          homeShiftTeamId: record.homeShiftTeamId || item.homeShiftTeamId || ""
        } : {})
      } : item;
    });
    return { ...shift, attendance };
  } catch (error) {
    // A temporary Google failure must not make the shared active shift vanish.
    console.warn(`[shift] Не удалось сверить табель с Google: ${error.message}`);
    return shift;
  }
}

function defaultMachineStatuses() {
  return Object.fromEntries(Array.from({ length: 16 }, (_, index) => [index + 1, "work"]));
}

function normalizeMachineStatuses(value) {
  const source = value && typeof value === "object" ? value : {};
  return Object.fromEntries(Array.from({ length: 16 }, (_, index) => {
    const machine = index + 1;
    const status = source[machine];
    return [machine, ["work", "attention", "maintenance", "repair", "inactive"].includes(status) ? status : "work"];
  }));
}

function readCentralMachineStatuses() {
  if (!centralMode || !existsSync(centralMachineStatusesPath)) return null;
  try {
    const value = JSON.parse(readFileSync(centralMachineStatusesPath, "utf8"));
    return normalizeMachineStatuses(value?.statuses ?? value);
  } catch {
    return null;
  }
}

function writeCentralMachineStatuses(input, actor) {
  if (!centralMode) {
    const error = new Error("Общее состояние станков доступно только на центральном сервере");
    error.statusCode = 409;
    throw error;
  }
  const statuses = normalizeMachineStatuses(input);
  const directory = dirname(centralMachineStatusesPath);
  mkdirSync(directory, { recursive: true });
  const temporary = `${centralMachineStatusesPath}.${process.pid}.tmp`;
  writeFileSync(temporary, `${JSON.stringify({ schemaVersion: 1, statuses, updatedAt: new Date().toISOString(), updatedBy: actor.id }, null, 2)}\n`, "utf8");
  renameSync(temporary, centralMachineStatusesPath);
  return statuses;
}

async function updateCentralShiftState(input, actor) {
  if (!centralMode) {
    const error = new Error("Общее состояние смены доступно только на центральном сервере");
    error.statusCode = 409;
    throw error;
  }
  const action = String(input?.action || "");
  // Apply the same safeguard before every mutation. Otherwise a stale shift
  // could prevent the next scheduled team from starting until an operator
  // manually closes it.
  const current = closeExpiredCentralShift();
  if (action === "end") {
    if (!current?.active) return current;
    return writeCentralShiftState({ ...current, active: false, endedAt: new Date().toISOString(), endedBy: actor.id });
  }
  if (action === "complete-scale-control") {
    if (!current?.active) throw new Error("Общая смена не начата");
    const recordCount = Number(input.recordCount);
    if (!current.requiresScaleControl || current.weightsCompletedAt || recordCount < 13) return current;
    return writeCentralShiftState({ ...current, weightsCompletedAt: new Date().toISOString(), scaleControlRecordCount: recordCount, updatedBy: actor.id });
  }
  if (action === "update-attendance") {
    if (!current?.active) throw new Error("Общая смена не начата");
    if (current.shiftDate !== todayInVilnius()) throw new Error("Активная смена относится к другой дате. Сначала завершите её явно.");
    const attendance = normalizeCentralAttendance(input.attendance);
    const leaders = await resolveCentralShiftLeaders(input, attendance);
    return writeCentralShiftState({
      ...current,
      attendance,
      employee: leaders.seniorMechanic,
      supervisor: leaders.seniorMechanic,
      seniorMechanic: leaders.seniorMechanic,
      mechanic: leaders.mechanic,
      attendanceUpdatedAt: new Date().toISOString(),
      updatedBy: actor.id
    });
  }
  if (action !== "start") throw new Error("Неизвестное действие со сменой");
  if (current?.active) throw new Error("На центральном сервере уже есть активная смена. Сначала завершите или исправьте её.");
  const teamId = String(input.shiftTeamId || "");
  const scheduledTeam = await scheduledCentralTeam(todayInVilnius());
  if (!scheduledTeam || scheduledTeam.id !== teamId) {
    const error = new Error("Можно начать только бригаду, назначенную общим графиком на сегодня");
    error.statusCode = 409;
    throw error;
  }
  // The time-based shift selector was removed from the interface. The first
  // shift remains the safe default because it keeps the daily scale check.
  const shiftNumber = [1, 2].includes(Number(input.shiftNumber)) ? Number(input.shiftNumber) : 1;
  const attendance = normalizeCentralAttendance(input.attendance);
  const leaders = await resolveCentralShiftLeaders(input, attendance);
  const startedAt = new Date().toISOString();
  return writeCentralShiftState({
    schemaVersion: 1, active: true, shiftDate: todayInVilnius(), shiftTeamId: teamId,
    employee: leaders.seniorMechanic, supervisor: leaders.seniorMechanic,
    seniorMechanic: leaders.seniorMechanic, mechanic: leaders.mechanic,
    shiftNumber, attendance,
    startedAt, endedAt: null, startedBy: actor.id,
    requiresScaleControl: shiftNumber === 1,
    weightsCompletedAt: shiftNumber === 1 ? null : startedAt
  });
}

async function resolveCentralShiftLeaders(input, attendance) {
  const workforce = await getWorkforceSnapshot();
  const peopleById = new Map((workforce.personnel ?? []).map(person => [person.id, person]));
  const present = attendance.filter(item => ["11", "K"].includes(String(item.status || "").trim()))
    .map(item => peopleById.get(item.employeeId)).filter(Boolean);
  const seniorMechanics = present.filter(person => person.role === "senior-mechanic");
  const directMechanics = present.filter(person => person.role === "mechanic");
  const seniorPool = seniorMechanics.length ? seniorMechanics : directMechanics;
  const seniorMechanic = String(input.seniorMechanic || input.supervisor || seniorPool[0]?.fullName || "").trim();
  const mechanics = directMechanics.filter(person => person.fullName !== seniorMechanic);
  const mechanicPool = mechanics.length ? mechanics : present.filter(person => person.role === "mechanic-operator");
  const mechanic = Object.hasOwn(input, "mechanic")
    ? String(input.mechanic || "").trim()
    : String(mechanicPool[0]?.fullName || "").trim();
  if (!seniorPool.some(person => person.fullName === seniorMechanic)) throw new Error("Старший механик должен быть отмечен присутствующим в табеле.");
  if (mechanic && !mechanicPool.some(person => person.fullName === mechanic)) throw new Error("Механик должен быть отмечен присутствующим в табеле.");
  return { seniorMechanic, mechanic };
}

async function scheduledCentralTeam(date) {
  const workforce = await getWorkforceSnapshot();
  const [year, month] = String(date).split("-").map(Number);
  return (workforce.shiftTeams || []).find(team => {
    const schedule = workforceScheduleMonth(team, year, month - 1);
    return schedule.some(day => day.date === date && day.scheduled);
  }) || null;
}

function workforceScheduleMonth(team, year, monthIndex) {
  const days = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
  return Array.from({ length: days }, (_, index) => {
    const day = index + 1;
    const date = `${year}-${String(monthIndex + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const anchor = String(team.anchorDate || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!anchor) return { date, scheduled: false };
    const difference = Math.round((Date.UTC(year, monthIndex, day) - Date.UTC(Number(anchor[1]), Number(anchor[2]) - 1, Number(anchor[3]))) / 86_400_000);
    const length = Math.max(1, Number(team.cycleLengthDays) || 4);
    const offset = ((difference % length) + length) % length;
    return { date, scheduled: (team.workDayOffsets || [0, 1]).map(Number).includes(offset) };
  });
}

function normalizeCentralAttendance(value) {
  if (!Array.isArray(value) || !value.length) throw new Error("Отметьте присутствие сотрудников");
  const attendance = value.map(item => ({
    employeeId: String(item?.employeeId || ""), status: String(item?.status || ""),
    ...(item?.isSubstitute ? { isSubstitute: true, substitutionReason: String(item.substitutionReason || ""), homeShiftTeamId: String(item.homeShiftTeamId || "") } : {})
  })).filter(item => item.employeeId && item.status);
  if (!attendance.length) throw new Error("Отметьте присутствие сотрудников");
  return attendance;
}

function todayInVilnius() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Vilnius" }).format(new Date());
}

function sessionCookie(token, expiresAt) {
  const maxAge = Math.max(1, Math.floor((expiresAt - Date.now()) / 1000));
  return `PFH_SESSION=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`;
}

function expiredSessionCookie() {
  return "PFH_SESSION=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0";
}

function loadEnvironment(filePath) {
  if (!existsSync(filePath)) return;
  for (const line of readFileSync(filePath, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!match || match[2].startsWith("#") || process.env[match[1]] !== undefined) continue;
    const value = match[2].replace(/^(['"])(.*)\1$/, "$2");
    process.env[match[1]] = value;
  }
}
