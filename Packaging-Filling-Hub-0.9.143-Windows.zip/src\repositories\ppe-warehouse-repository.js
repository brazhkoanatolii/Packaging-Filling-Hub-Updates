export class PpeWarehouseRepository {
  constructor(remote) { this.remote = remote; }
  list() { return this.remote.list(); }
  issue(record) { return this.remote.issue(record); }
  retry(id) { return this.remote.retry(id); }
}
