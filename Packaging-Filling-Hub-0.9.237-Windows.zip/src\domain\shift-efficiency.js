import { productiveMinutesBetween, transitionWorkingMinutes } from "./production-timing.js";

const SHIFT_START_MINUTES = 7 * 60 + 30;
const SHIFT_END_MINUTES = 19 * 60 + 30;
const NET_SHIFT_MINUTES = 600;
const BASE_MACHINE_SPEED = 190;
const BASE_POUCH_COUNT = 27;
const BASE_MACHINE_BOXES = 15;

const EFFICIENCY_INDICATORS = Object.freeze({
  noData: { id: "no-data", color: "#94A3B8", label: "Нет данных", assessment: "" },
  poor: { id: "poor", color: "#DC3545", assessment: "Плохая работа" },
  average: { id: "average", color: "#FFC107", assessment: "Средняя работа" },
  good: { id: "good", color: "#28A745", assessment: "Хорошая работа" },
  overPlan: { id: "over-plan", color: "#8B5CF6", assessment: "Перевыполнение плана" }
});

const LINE_MACHINES = Object.freeze({
  A: { count: 1, speed: 190 }, K: { count: 1, speed: 190 },
  B: { count: 2, speed: 130, machines: [2, 3] },
  D: { count: 2, speed: 190, machines: [4, 5] },
  F: { count: 2, speed: 190, machines: [6, 7] },
  H: { count: 2, speed: 190, machines: [8, 9] },
  L: { count: 2, speed: 190, machines: [11, 12, 13], inferThirdMachine: true },
  M: { count: 2, speed: 190, machines: [14, 15, 16], inferThirdMachine: true }
});

function minutes(value) {
  const match = String(value || "").match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const result = Number(match[1]) * 60 + Number(match[2]);
  return Number.isFinite(result) ? result : null;
}

function interval(record) {
  const recordedStart = minutes(record.startTime);
  const recordedEnd = minutes(record.time);
  if (recordedStart === null || recordedEnd === null || recordedEnd <= recordedStart) return null;
  const start = recordedStart;
  const end = recordedEnd;
  return { start: Math.max(start, SHIFT_START_MINUTES), end: Math.min(end, SHIFT_END_MINUTES) };
}

function productiveMinutes(start, end) { return productiveMinutesBetween(minutesToTime(start), minutesToTime(end)); }

function minutesToTime(value) {
  return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
}

function participants(record) {
  return String(record.operator || "").split(/\s*(?:;|\||\+)\s*/).map(value => value.trim()).filter(Boolean);
}

function activeParticipants(record, start, end) {
  const names = participants(record);
  if (names.length < 2) return names;
  const secondStart = minutes(record.operatorSecondStartTime) ?? minutes(record.startTime);
  const secondEnd = minutes(record.operatorSecondEndTime) ?? minutes(record.time);
  return secondStart !== null && secondEnd !== null && secondStart < end && secondEnd > start ? names : names.slice(0, 1);
}

function normalize(value) {
  // In historical journals names sometimes differ only by spaces: for example,
  // "Mango Lime" and "MangoLime". They are the same product for matching a
  // specification, so spacing must not suppress its production norm.
  return String(value || "").trim().toLocaleLowerCase("ru").replace(/\s+/g, "");
}

function pouchCount(record, specifications) {
  const specification = specifications.find(item => normalize(item?.product) === normalize(record.product)
    && normalize(item?.line) === normalize(record.catalogLine) && Number(item?.variant) === Number(record.strength));
  const result = Number(specification?.pouchCount);
  return Number.isFinite(result) && result > 0 ? result : null;
}

function selectedMachines(record, line) {
  const allowed = LINE_MACHINES[line]?.machines;
  if (!allowed) return [];
  const source = Array.isArray(record.activeMachines) ? record.activeMachines : String(record.activeMachines || "").split(/\s*,\s*/);
  return [...new Set(source.map(Number).filter(machine => allowed.includes(machine)))];
}

function machineStarts(record, line) {
  const selected = selectedMachines(record, line);
  const source = record?.machineStartTimes && typeof record.machineStartTimes === "object" ? record.machineStartTimes : {};
  return new Map(selected.map(machine => [machine, minutes(source[machine]) ?? minutes(record.startTime)]));
}

function machineStartPoints(record, line) {
  return [...machineStarts(record, line).values()].filter(Number.isFinite);
}

function machineCount(line, activeRecords, start, end) {
  const setup = LINE_MACHINES[line];
  if (!setup) return 0;
  if (!setup.machines) return setup.count;
  const explicit = activeRecords.flatMap(record => [...machineStarts(record, line).entries()]);
  if (explicit.length) return new Set(explicit.filter(([, machineStart]) => machineStart <= start).map(([machine]) => machine)).size;
  // Старые записи не содержат перечня станков. Для истории второй одновременно
  // работающий оператор означает третью машину, как было в прежнем расчёте.
  if (!setup.inferThirdMachine) return setup.count;
  const operators = new Set(activeRecords.flatMap(record => activeParticipants(record, start, end)));
  return operators.size >= 2 ? 3 : setup.count;
}

function fullShiftTarget(record, line, machines, specifications) {
  const setup = LINE_MACHINES[line];
  const pouches = pouchCount(record, specifications);
  if (!setup || !pouches || !machines) return null;
  return BASE_MACHINE_BOXES * (setup.speed / BASE_MACHINE_SPEED) * (BASE_POUCH_COUNT / pouches) * machines;
}

function transitionLossMinutes(previous, next) {
  const required = transitionWorkingMinutes(previous.record, next.record);
  if (!required) return 0;
  const gap = productiveMinutesBetween(minutesToTime(previous.slot.end), minutesToTime(next.slot.start));
  return Math.max(0, required - gap);
}

/**
 * План строится по указанным упаковщиком интервалам производства. Плановые
 * паузы вычитаются из каждого интервала, а смена продукта/линии уменьшает
 * план только на время, которое не покрыто фактическим разрывом записей.
 */
export function calculateShiftEfficiency(records, specifications = []) {
  const relevant = records.map(record => ({ record, slot: interval(record) })).filter(item => item.slot && item.slot.end > item.slot.start);
  const actualBoxes = relevant.reduce((sum, { record }) => sum + Number(record.quantity || 0) / 240, 0);
  let plannedBoxes = 0;
  let productChangeCount = 0;
  let lineChangeCount = 0;
  let lostMinutes = 0;
  const missingSpecifications = new Set();

  const byLine = new Map();
  relevant.forEach(item => {
    const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
    if (!LINE_MACHINES[line]) return;
    byLine.set(line, [...(byLine.get(line) || []), item]);
  });
  for (const [line, entries] of byLine) {
    const points = [...new Set(entries.flatMap(({ record, slot }) => [slot.start, slot.end, ...machineStartPoints(record, line)]))].sort((a, b) => a - b);
    for (let index = 0; index < points.length - 1; index += 1) {
      const start = points[index], end = points[index + 1];
      const active = entries.filter(({ slot }) => slot.start < end && slot.end > start).map(({ record }) => record);
      const products = [...new Set(active.map(record => String(record.product || "").trim()).filter(Boolean))];
      if (products.length !== 1) continue;
      const sample = active[0];
      const target = fullShiftTarget(sample, line, machineCount(line, active, start, end), specifications);
      if (target === null) {
        missingSpecifications.add(`${sample.catalogLine || "—"} · ${sample.product || "—"} · ${sample.strength || "—"}`);
        continue;
      }
      plannedBoxes += target * productiveMinutes(start, end) / NET_SHIFT_MINUTES;
    }
  }

  const byGroup = new Map();
  relevant.forEach(item => {
    const key = [String(item.record.packer || "").trim(), ...participants(item.record).sort((a, b) => a.localeCompare(b, "ru"))].join("|");
    if (!key || key === "|") return;
    byGroup.set(key, [...(byGroup.get(key) || []), item]);
  });
  for (const entries of byGroup.values()) {
    const ordered = [...entries].sort((left, right) => left.slot.start - right.slot.start || left.slot.end - right.slot.end);
    let previous = null;
    ordered.forEach(item => {
      const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
      const current = { ...item, line };
      if (previous) {
        const loss = transitionLossMinutes(previous, current);
        if (loss) {
          const target = fullShiftTarget(current.record, line, machineCount(line, [current.record], current.slot.start, current.slot.end), specifications);
          if (target !== null) {
            if (previous.line === line) productChangeCount += 1;
            else lineChangeCount += 1;
            lostMinutes += loss;
            plannedBoxes -= target * loss / NET_SHIFT_MINUTES;
          }
        }
      }
      if (!previous || current.slot.end > previous.slot.end) previous = current;
    });
  }

  plannedBoxes = Math.max(0, plannedBoxes);
  // A partial plan would make the percentage misleading: actual output contains
  // every product, while the missing specification would be absent from the
  // denominator. In this situation the user must see "Нет данных".
  const efficiency = missingSpecifications.size || !plannedBoxes ? null : actualBoxes / plannedBoxes;
  return { actualBoxes, plannedBoxes, efficiency, productChangeCount, lineChangeCount, lostMinutes, missingSpecifications: [...missingSpecifications] };
}

/**
 * Returns the part of a line plan belonging to every production record.
 *
 * The line plan is calculated first, so the result includes every setup loss
 * only once. It is then divided between the products in proportion to their
 * own recorded productive time and machine capacity. Consequently, the plans
 * of all product rows on one line always add up exactly to the line plan.
 */
export function calculateRecordPlansByLine(records, specifications = []) {
  const byLine = new Map();
  records.forEach(record => {
    const line = String(record.line || record.machineLine || "").trim().toUpperCase();
    if (!line) return;
    byLine.set(line, [...(byLine.get(line) || []), record]);
  });

  const plans = new Map();
  for (const lineRecords of byLine.values()) {
    const linePlan = calculateShiftEfficiency(lineRecords, specifications).plannedBoxes;
    const basePlans = lineRecords.map(record => ({ record, plannedBoxes: calculateShiftEfficiency([record], specifications).plannedBoxes }));
    const baseTotal = basePlans.reduce((total, item) => total + Number(item.plannedBoxes || 0), 0);
    basePlans.forEach(({ record, plannedBoxes }) => {
      plans.set(record, baseTotal > 0 && Number.isFinite(linePlan) ? linePlan * plannedBoxes / baseTotal : 0);
    });
  }
  return plans;
}

/**
 * Keeps the visual category separate from the calculation. The raw ratio is
 * deliberately used before formatting, so 100.01% is already over plan.
 */
export function shiftEfficiencyIndicator(efficiency) {
  if (efficiency === null || efficiency === undefined || efficiency === "") return EFFICIENCY_INDICATORS.noData;
  const value = Number(efficiency);
  if (!Number.isFinite(value)) return EFFICIENCY_INDICATORS.noData;
  if (value < 0.7) return { ...EFFICIENCY_INDICATORS.poor, value };
  if (value < 0.9) return { ...EFFICIENCY_INDICATORS.average, value };
  if (value <= 1) return { ...EFFICIENCY_INDICATORS.good, value };
  return { ...EFFICIENCY_INDICATORS.overPlan, value };
}

export { LINE_MACHINES };
