function reportDate(value) {
  const match = String(value || "").trim().match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/);
  return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}` : "";
}

function reportNumber(value) {
  const normalized = String(value ?? "").replace(/[\s()]/g, "").replace(",", ".");
  const number = Number(normalized);
  return Number.isFinite(number) ? number : 0;
}

function inPeriod(date, year, month) {
  return date.startsWith(`${year}-${month || ""}`);
}

/** Builds employee totals only from the prepared production report. */
export function productionReportStatistics({ mechanicsRows = [], packerRows = [], scrapRows = [], year, month = "" }) {
  const rows = new Map();
  const rowFor = name => {
    const key = String(name || "").trim();
    if (!key || /^Резерв\b/i.test(key)) return null;
    if (!rows.has(key)) rows.set(key, { fullName: key, boxes: 0, scrapKg: 0, grossMassKg: 0, dates: new Set() });
    return rows.get(key);
  };
  const add = (name, date, field, value) => {
    const row = rowFor(name), number = reportNumber(value);
    if (!row || !number) return;
    row[field] += number;
    row.dates.add(date);
  };
  const header = mechanicsRows[0] || [];
  mechanicsRows.slice(1).forEach(record => {
    const date = reportDate(record[0]);
    if (!date || !inPeriod(date, year, month)) return;
    for (let index = 0; index < 18; index += 1) add(header[index + 1], date, "boxes", record[index + 1]);
    for (let index = 0; index < 18; index += 1) add(header[index + 23], date, "scrapKg", record[index + 23]);
    for (let index = 0; index < 18; index += 1) {
      const scrap = reportNumber(record[index + 23]);
      const percentText = String(record[index + 45] ?? "").trim();
      const percent = /%$/.test(percentText) ? reportNumber(percentText.replace("%", "")) / 100 : reportNumber(percentText);
      const row = rowFor(header[index + 1]);
      if (row && scrap > 0 && percent > 0) row.grossMassKg += scrap / percent;
    }
  });
  const addPeople = (matrix, field) => {
    const people = matrix[0] || [];
    matrix.slice(1).forEach(record => {
      const date = reportDate(record[0]);
      if (!date || !inPeriod(date, year, month)) return;
      for (let index = 0; index < 18; index += 1) add(people[index + 1], date, field, record[index + 1]);
    });
  };
  addPeople(packerRows, "boxes");
  addPeople(scrapRows, "scrapKg");
  return [...rows.values()].map(row => ({ ...row, days: row.dates.size })).sort((left, right) => left.fullName.localeCompare(right.fullName, "ru"));
}
