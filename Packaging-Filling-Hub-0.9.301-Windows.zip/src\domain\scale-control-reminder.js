import { getScheduleDay } from "../services/workforce-service.js";

// A control is required only for scales actually used during the shift.  The
// journal cannot know that list in advance, so one recorded distinct scale is
// sufficient to confirm that today's operational control has started.
export const SCALE_REMINDER_MINIMUM = 1;

export function getScaleControlReminder({ date, team, records = [], minimum = SCALE_REMINDER_MINIMUM }) {
  if (!team || !getScheduleDay(team, date).scheduled) return null;
  const previousDate = dayBefore(date);
  const firstWorkDay = !getScheduleDay(team, previousDate).scheduled;
  const countFor = value => new Set(records
    .filter(record => record?.date === value && record?.status !== "Аннулировано")
    .map(record => String(record.scaleName || "").trim())
    .filter(Boolean)).size;

  if (firstWorkDay) {
    const recordCount = countFor(date);
    return recordCount >= minimum ? null : { day: 1, recordCount, minimum };
  }

  const firstDayRecordCount = countFor(previousDate);
  // If the first day was missed, the first recorded control on the second day
  // also closes the reminder for the active shift.
  const recordCount = countFor(date);
  if (firstDayRecordCount >= minimum || recordCount >= minimum) return null;
  return { day: 2, recordCount, minimum, firstDayRecordCount };
}

export function dayBefore(date) {
  const match = String(date || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return "";
  const value = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  value.setUTCDate(value.getUTCDate() - 1);
  return value.toISOString().slice(0, 10);
}
