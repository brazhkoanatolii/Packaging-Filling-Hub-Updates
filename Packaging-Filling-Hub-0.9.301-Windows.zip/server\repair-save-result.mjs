export function normalizeRepairRequest(input) {
  const fail = message => { const error = new Error(message); error.statusCode = 400; throw error; };
  const requestId = String(input?.requestId || "").trim();
  if (!/^[a-zA-Z0-9_-]{8,120}$/.test(requestId)) fail("Некорректный идентификатор запроса");
  const record = Object.fromEntries(["date", "machine", "category", "work", "performer", "note"].map(key => [key, String(input?.[key] || "").trim()]));
  record.machine = record.machine === "Другое" ? record.machine : Number(record.machine);
  record.work = [...new Set(record.work.split(";").map(value => value.trim()).filter(Boolean))].join("; ");
  if (input?.parts && !Array.isArray(input.parts)) fail("Некорректный список запчастей");
  const parts = (input?.parts || []).map(part => ({ id: String(part?.id || "").trim(), quantity: Number(part?.quantity) })).sort((a, b) => a.id.localeCompare(b.id));
  if (parts.some(part => !part.id || !Number.isFinite(part.quantity) || part.quantity <= 0 || part.quantity > 1_000_000)) fail("Проверьте запчасти и количество");
  if (new Set(parts.map(part => part.id)).size !== parts.length) fail("Одна запчасть добавлена дважды");
  return { requestId, record, parts };
}

export function repairAppendRequest(sheetId, record, repairId, receiptNote = "") {
  const serial = Math.round((Date.parse(`${record.date}T00:00:00Z`) - Date.UTC(1899, 11, 30)) / 86_400_000);
  return { appendCells: { sheetId, rows: [{ values: [
    { userEnteredValue: { numberValue: serial }, note: `PFH_REPAIR_V1:${repairId}`, userEnteredFormat: { numberFormat: { type: "DATE", pattern: "dd.MM.yyyy" } } },
    ...[record.category, record.work, record.performer, record.note].map((stringValue, index) => ({ userEnteredValue: { stringValue }, ...(index === 3 && receiptNote ? { note: receiptNote } : {}) }))
  ] }], fields: "userEnteredValue,note,userEnteredFormat.numberFormat" } };
}

export async function finalizeRepairSave({ record, repairId, rowNumber, parts, writeOffParts }) {
  const result = { ok: true, record: { ...record, id: repairId, rowNumber } };
  try {
    if (parts.length) await writeOffParts(parts, { repairId, record });
    return { ...result, partsWrittenOff: parts.length, partsWriteOffStatus: "confirmed" };
  } catch {
    return {
      ...result,
      partsWrittenOff: null,
      partsWriteOffStatus: "needs_review",
      warning: "Ремонт сохранён. Не удалось подтвердить списание всех запчастей. Проверьте склад; повторно отправлять ремонт не нужно."
    };
  }
}
