import { productiveMinutesBetween, transitionWorkingMinutes } from "./production-timing.js";

// Production planning starts after the mandatory preparation interval.
// The entry form already enforces 07:45; the calculation must use the same
// boundary for historical records too, otherwise a 07:30 start inflates plan.
const SHIFT_START_MINUTES = 7 * 60 + 45;
const SHIFT_END_MINUTES = 19 * 60 + 30;
const NET_SHIFT_MINUTES = 600;
const BASE_MACHINE_SPEED = 190;
const BASE_POUCH_COUNT = 27;
const BASE_MACHINE_BOXES = 15;

const EFFICIENCY_INDICATORS = Object.freeze({
  noData: { id: "no-data", color: "#94A3B8", label: "Нет данных", assessment: "" },
  poor: { id: "poor", color: "#DC3545", assessment: "Плохая работа" },
  average: { id: "average", color: "#FFC107", assessment: "Средняя работа" },
  good: { id: "good", color: "#28A745", assessment: "Хорошая работа" },
  overPlan: { id: "over-plan", color: "#8B5CF6", assessment: "Перевыполнение плана" }
});

const LINE_MACHINES = Object.freeze({
  A: { count: 1, speed: 190 }, K: { count: 1, speed: 190 },
  B: { count: 2, speed: 130, machines: [2, 3] },
  D: { count: 2, speed: 190, machines: [4, 5] },
  F: { count: 2, speed: 190, machines: [6, 7] },
  H: { count: 2, speed: 190, machines: [8, 9] },
  L: { count: 2, speed: 190, machines: [11, 12, 13], inferThirdMachine: true },
  M: { count: 2, speed: 190, machines: [14, 15, 16], inferThirdMachine: true }
});

function minutes(value) {
  const match = String(value || "").match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const result = Number(match[1]) * 60 + Number(match[2]);
  return Number.isFinite(result) ? result : null;
}

function interval(record) {
  const recordedStart = minutes(record.startTime);
  const recordedEnd = minutes(record.time);
  if (recordedStart === null || recordedEnd === null || recordedEnd <= recordedStart) return null;
  const start = recordedStart;
  const end = recordedEnd;
  return { start: Math.max(start, SHIFT_START_MINUTES), end: Math.min(end, SHIFT_END_MINUTES) };
}

function productiveMinutes(start, end) { return productiveMinutesBetween(minutesToTime(start), minutesToTime(end)); }

function minutesToTime(value) {
  return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
}

function participants(record) {
  return String(record.operator || "").split(/\s*(?:;|\||\+)\s*/).map(value => value.trim()).filter(Boolean);
}

function activeParticipants(record, start, end) {
  const names = participants(record);
  if (names.length < 2) return names;
  const secondStart = minutes(record.operatorSecondStartTime) ?? minutes(record.startTime);
  const secondEnd = minutes(record.operatorSecondEndTime) ?? minutes(record.time);
  return secondStart !== null && secondEnd !== null && secondStart < end && secondEnd > start ? names : names.slice(0, 1);
}

function normalize(value) {
  // In historical journals names sometimes differ only by spaces: for example,
  // "Mango Lime" and "MangoLime". They are the same product for matching a
  // specification, so spacing must not suppress its production norm.
  return String(value || "").trim().toLocaleLowerCase("ru").replace(/\s+/g, "");
}

function pouchCount(record, specifications) {
  const specification = specifications.find(item => normalize(item?.product) === normalize(record.product)
    && normalize(item?.line) === normalize(record.catalogLine) && Number(item?.variant) === Number(record.strength));
  const result = Number(specification?.pouchCount);
  return Number.isFinite(result) && result > 0 ? result : null;
}

function selectedMachines(record, line) {
  const allowed = LINE_MACHINES[line]?.machines;
  if (!allowed) return [];
  const source = Array.isArray(record.activeMachines) ? record.activeMachines : String(record.activeMachines || "").split(/\s*,\s*/);
  return [...new Set(source.map(Number).filter(machine => allowed.includes(machine)))];
}

function machineIntervals(record, line) {
  const selected = selectedMachines(record, line);
  const starts = record?.machineStartTimes && typeof record.machineStartTimes === "object" ? record.machineStartTimes : {};
  const ends = record?.machineEndTimes && typeof record.machineEndTimes === "object" ? record.machineEndTimes : {};
  const recordStart = minutes(record.startTime);
  const recordEnd = minutes(record.time);
  return new Map(selected.map(machine => [machine, {
    start: minutes(starts[machine]) ?? recordStart,
    end: minutes(ends[machine]) ?? recordEnd
  }]));
}

function machineChangePoints(record, line) {
  return [...machineIntervals(record, line).values()]
    .flatMap(interval => [interval.start, interval.end]).filter(Number.isFinite);
}

// A second mechanic-operator can join or leave during a record.  These
// boundaries must split the plan interval, otherwise the additional machine
// would incorrectly be counted from the beginning of the whole record.
function participantChangePoints(record) {
  if (participants(record).length < 2) return [];
  const start = minutes(record.operatorSecondStartTime) ?? minutes(record.startTime);
  const end = minutes(record.operatorSecondEndTime) ?? minutes(record.time);
  return [start, end].filter(Number.isFinite);
}

function machineCount(line, activeRecords, start, end) {
  const setup = LINE_MACHINES[line];
  if (!setup) return 0;
  if (!setup.machines) return setup.count;
  const explicit = activeRecords.flatMap(record => [...machineIntervals(record, line).entries()]);
  if (explicit.length) return new Set(explicit.filter(([, interval]) => interval.start <= start && interval.end > start).map(([machine]) => machine)).size;
  // Старые записи не содержат перечня станков. Для истории второй одновременно
  // работающий оператор означает третью машину, как было в прежнем расчёте.
  if (!setup.inferThirdMachine) return setup.count;
  const operators = new Set(activeRecords.flatMap(record => activeParticipants(record, start, end)));
  return operators.size >= 2 ? 3 : setup.count;
}

function fullShiftTarget(record, line, machines, specifications) {
  const setup = LINE_MACHINES[line];
  const pouches = pouchCount(record, specifications);
  if (!setup || !pouches || !machines) return null;
  return BASE_MACHINE_BOXES * (setup.speed / BASE_MACHINE_SPEED) * (BASE_POUCH_COUNT / pouches) * machines;
}

function transitionLossMinutes(previous, next) {
  const required = transitionWorkingMinutes(previous.record, next.record);
  if (!required) return 0;
  const gap = productiveMinutesBetween(minutesToTime(previous.slot.end), minutesToTime(next.slot.start));
  return Math.max(0, required - gap);
}

/**
 * План строится по указанным упаковщиком интервалам производства. Плановые
 * паузы вычитаются из каждого интервала, а смена продукта/линии уменьшает
 * план только на время, которое не покрыто фактическим разрывом записей.
 */
// This is the interval engine.  It is deliberately kept separate from the
// public shift result so per-record plans can use the same base calculation
// without recursively calling the public function.
function calculateIntervalEfficiency(records, specifications = []) {
  const relevant = records.map(record => ({ record, slot: interval(record) })).filter(item => item.slot && item.slot.end > item.slot.start);
  const actualBoxes = relevant.reduce((sum, { record }) => sum + Number(record.quantity || 0) / 240, 0);
  let plannedBoxes = 0;
  let productChangeCount = 0;
  let lineChangeCount = 0;
  let lostMinutes = 0;
  const missingSpecifications = new Set();
  const plannedBoxesByLine = new Map();

  const byLine = new Map();
  relevant.forEach(item => {
    const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
    if (!LINE_MACHINES[line]) return;
    byLine.set(line, [...(byLine.get(line) || []), item]);
  });
  for (const [line, entries] of byLine) {
    const points = [...new Set(entries.flatMap(({ record, slot }) => [
      slot.start,
      slot.end,
      ...machineChangePoints(record, line),
      ...participantChangePoints(record)
    ]))].sort((a, b) => a - b);
    for (let index = 0; index < points.length - 1; index += 1) {
      const start = points[index], end = points[index + 1];
      const active = entries.filter(({ slot }) => slot.start < end && slot.end > start).map(({ record }) => record);
      const products = [...new Set(active.map(record => String(record.product || "").trim()).filter(Boolean))];
      if (products.length !== 1) continue;
      const sample = active[0];
      const target = fullShiftTarget(sample, line, machineCount(line, active, start, end), specifications);
      if (target === null) {
        missingSpecifications.add(`${sample.catalogLine || "—"} · ${sample.product || "—"} · ${sample.strength || "—"}`);
        continue;
      }
      const planned = target * productiveMinutes(start, end) / NET_SHIFT_MINUTES;
      plannedBoxes += planned;
      plannedBoxesByLine.set(line, Number(plannedBoxesByLine.get(line) || 0) + planned);
    }
  }

  const byGroup = new Map();
  relevant.forEach(item => {
    const key = [String(item.record.packer || "").trim(), ...participants(item.record).sort((a, b) => a.localeCompare(b, "ru"))].join("|");
    if (!key || key === "|") return;
    byGroup.set(key, [...(byGroup.get(key) || []), item]);
  });
  for (const entries of byGroup.values()) {
    const ordered = [...entries].sort((left, right) => left.slot.start - right.slot.start || left.slot.end - right.slot.end);
    let previous = null;
    ordered.forEach(item => {
      const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
      const current = { ...item, line };
      if (previous) {
        const loss = transitionLossMinutes(previous, current);
        if (loss) {
          const target = fullShiftTarget(current.record, line, machineCount(line, [current.record], current.slot.start, current.slot.end), specifications);
          if (target !== null) {
            if (previous.line === line) productChangeCount += 1;
            else lineChangeCount += 1;
            lostMinutes += loss;
            const transitionPlanLoss = target * loss / NET_SHIFT_MINUTES;
            // The cleaning or line move belongs to the next record. If a
            // malformed short record does not have enough of its own plan,
            // take the remaining amount from the preceding counted plan. This
            // keeps every line plan non-negative and its sum equal to the
            // complete shift plan.
            const appliedPlanLoss = deductPlannedLoss(plannedBoxesByLine, line, transitionPlanLoss);
            plannedBoxes -= appliedPlanLoss;
          }
        }
      }
      if (!previous || current.slot.end > previous.slot.end) previous = current;
    });
  }

  plannedBoxes = Math.max(0, plannedBoxes);
  // A partial plan would make the percentage misleading: actual output contains
  // every product, while the missing specification would be absent from the
  // denominator. In this situation the user must see "Нет данных".
  const efficiency = missingSpecifications.size || !plannedBoxes ? null : actualBoxes / plannedBoxes;
  return {
    actualBoxes,
    plannedBoxes,
    efficiency,
    productChangeCount,
    lineChangeCount,
    lostMinutes,
    missingSpecifications: [...missingSpecifications],
    plannedBoxesByLine: Object.fromEntries(plannedBoxesByLine)
  };
}

function deductPlannedLoss(plansByLine, preferredLine, loss) {
  let remaining = Number(loss || 0);
  const order = [preferredLine, ...[...plansByLine.keys()].filter(line => line !== preferredLine)];
  order.forEach(line => {
    if (remaining <= 0) return;
    const available = Math.max(0, Number(plansByLine.get(line) || 0));
    const deduction = Math.min(available, remaining);
    plansByLine.set(line, available - deduction);
    remaining -= deduction;
  });
  return Number(loss || 0) - remaining;
}

/**
 * Returns an independent plan for every production record.
 *
 * A product row must show its own result rather than the result of the whole
 * line. An uncovered product/line transition belongs to the following row:
 * that is when the cleaning or line move happens. This also keeps the sum of
 * rows equal to the line plan without distributing a loss across products.
 */
export function calculateRecordPlansByLine(records, specifications = []) {
  const plans = new Map(records.map(record => [record, calculateIntervalEfficiency([record], specifications).plannedBoxes]));
  const byGroup = new Map();
  records
    .map(record => ({ record, slot: interval(record) }))
    .filter(item => item.slot && item.slot.end > item.slot.start)
    .forEach(item => {
      const key = [String(item.record.packer || "").trim(), ...participants(item.record).sort((a, b) => a.localeCompare(b, "ru"))].join("|");
      if (!key || key === "|") return;
      byGroup.set(key, [...(byGroup.get(key) || []), item]);
    });

  for (const entries of byGroup.values()) {
    const ordered = [...entries].sort((left, right) => left.slot.start - right.slot.start || left.slot.end - right.slot.end);
    let previous = null;
    ordered.forEach(item => {
      const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
      const current = { ...item, line };
      if (previous) {
        const loss = transitionLossMinutes(previous, current);
        if (loss) {
          const target = fullShiftTarget(current.record, line, machineCount(line, [current.record], current.slot.start, current.slot.end), specifications);
          if (target !== null) plans.set(current.record, Math.max(0, Number(plans.get(current.record) || 0) - target * loss / NET_SHIFT_MINUTES));
        }
      }
      if (!previous || current.slot.end > previous.slot.end) previous = current;
    });
  }
  return plans;
}

/**
 * The shift denominator is the sum of the very same plans shown in the
 * product rows.  Previously the interval engine and the per-record plan
 * builder were both capable of applying a transition independently.  Even a
 * harmless delay while saving could therefore leave the total and its rows
 * with different denominators.  The interval engine still supplies the
 * factual loss diagnostics, but the visible plan now has one source only.
 */
export function calculateShiftEfficiency(records, specifications = [], suppliedRecordPlans = null) {
  const intervalCalculation = calculateIntervalEfficiency(records, specifications);
  // The summary and every individual journal row must use the very same
  // denominator.  A caller may pass plans calculated for these exact record
  // objects; otherwise calculate them here.  Do not use the interval engine's
  // independent specification diagnostic to hide an already calculated plan.
  const recordPlans = suppliedRecordPlans instanceof Map
    && records.every(record => suppliedRecordPlans.has(record))
    ? suppliedRecordPlans
    : calculateRecordPlansByLine(records, specifications);
  const plannedBoxes = [...recordPlans.values()].reduce((sum, value) => sum + Math.max(0, Number(value || 0)), 0);
  const hasPlanForEveryRecord = records.length > 0 && records.every(record => Number(recordPlans.get(record) || 0) > 0);
  const plannedBoxesByLine = {};
  records.forEach(record => {
    const line = String(record.line || record.machineLine || "").toUpperCase();
    if (!line) return;
    plannedBoxesByLine[line] = Number(plannedBoxesByLine[line] || 0) + Math.max(0, Number(recordPlans.get(record) || 0));
  });
  return {
    ...intervalCalculation,
    plannedBoxes,
    plannedBoxesByLine,
    efficiency: !hasPlanForEveryRecord || !plannedBoxes
      ? null
      : intervalCalculation.actualBoxes / plannedBoxes
  };
}

/**
 * Keeps the visual category separate from the calculation. The raw ratio is
 * deliberately used before formatting, so 100.01% is already over plan.
 */
export function shiftEfficiencyIndicator(efficiency) {
  if (efficiency === null || efficiency === undefined || efficiency === "") return EFFICIENCY_INDICATORS.noData;
  const value = Number(efficiency);
  if (!Number.isFinite(value)) return EFFICIENCY_INDICATORS.noData;
  if (value < 0.7) return { ...EFFICIENCY_INDICATORS.poor, value };
  if (value < 0.9) return { ...EFFICIENCY_INDICATORS.average, value };
  if (value <= 1) return { ...EFFICIENCY_INDICATORS.good, value };
  return { ...EFFICIENCY_INDICATORS.overPlan, value };
}

export { LINE_MACHINES };
