import { APP_CONFIG, JOURNALS, LANGUAGES, MODULES, SCALES } from "./config/app-config.js";
import { ATTENDANCE_CODES, OFFICE_SCHEDULE, ROLE_LABELS, SUBSTITUTE_ONLY_EMPLOYEE_IDS } from "./config/workforce-config.js";
import { calculateResult, formatDate as formatJournalDate, formatDateTime as formatJournalDateTime } from "./domain/scale-check.js";
import { formatPersonnelAge, formatPersonnelExperience } from "./domain/personnel-dates.js";
import { getScaleControlReminder } from "./domain/scale-control-reminder.js";
import { lithuanianCalendarDay } from "./domain/lithuanian-calendar.js";
import { getBirthdayReminders } from "./domain/birthday-reminders.js";
import { distributePersonnel } from "./domain/personnel-distribution.js";
import { findVacationConflicts } from "./domain/vacation-conflicts.js";
import { vacationMonthlyRate } from "./domain/vacation-accrual.js";
import { OFFICE_VACATION_ALLOWANCE, SHIFT_VACATION_ALLOWANCE, isVacationChargeableDay, vacationUnitLabel } from "./domain/vacation-policy.js";
import { hasProductionSecondMechanicInterval, productionLineCredits, productionShiftGroups, productionShiftRoleCredits, splitProductionParticipants } from "./domain/production-credit.js";
import { calculateRecordPlansByLine, calculateShiftEfficiency, shiftEfficiencyIndicator } from "./domain/shift-efficiency.js";
import { FIRST_PRODUCTION_START_TIME, minimumProductionStartTime } from "./domain/production-timing.js";
import { IndexedDbDataProvider } from "./providers/indexed-db-data-provider.js";
import { GoogleSheetsGatewayProvider } from "./providers/google-sheets-gateway-provider.js";
import { JournalRepository } from "./repositories/journal-repository.js";
import { AuthService } from "./services/auth-service.js";
import { JournalService } from "./services/journal-service.js";
import { ShiftService } from "./services/shift-service.js";
import { hasWorkedAttendance } from "./domain/attendance-work.js";
import { CentralShiftGatewayProvider } from "./providers/central-shift-gateway-provider.js";
import { MachineStatusGatewayProvider } from "./providers/machine-status-gateway-provider.js";
import { WorkforceService, getScheduleMonth } from "./services/workforce-service.js";
import { WorkforceGatewayProvider } from "./providers/workforce-gateway-provider.js";
import { WorkforceRepository } from "./repositories/workforce-repository.js";
import { WORKSPACE_JOURNALS, WORKFORCE_YEARS } from "./config/workspace-journals.js";
import { ProductSpecificationGatewayProvider } from "./providers/product-specification-gateway-provider.js";
import { ProductSpecificationService } from "./services/product-specification-service.js?v=0.8.1";
import { PRODUCT_SPECIFICATION_SOURCE } from "./config/product-specification-config.js";
import { CycloneGatewayProvider } from "./providers/cyclone-gateway-provider.js";
import { CycloneRepository } from "./repositories/cyclone-repository.js";
import { CycloneService, cycloneStatistics, pendingCycloneCleaningDates } from "./services/cyclone-service.js";
import { ProductionGatewayProvider } from "./providers/production-gateway-provider.js";
import { ProductionRepository } from "./repositories/production-repository.js";
import { ProductionService, LINES as PRODUCTION_LINES, productionFinishedMassKg, productionGrossMassKg } from "./services/production-service.js";
import { PackagingGatewayProvider } from "./providers/packaging-gateway-provider.js";
import { PackagingRepository } from "./repositories/packaging-repository.js";
import { PackagingService, PACKAGING_DISPLAY_FIELDS, PACKAGING_FIELDS } from "./services/packaging-service.js";
import { NonconformityGatewayProvider } from "./providers/nonconformity-gateway-provider.js";
import { NonconformityRepository } from "./repositories/nonconformity-repository.js";
import { NonconformityService } from "./services/nonconformity-service.js";
import { IncidentGatewayProvider } from "./providers/incident-gateway-provider.js";
import { IncidentRepository } from "./repositories/incident-repository.js";
import { IncidentService } from "./services/incident-service.js";
import { PackagingWarehouseGatewayProvider } from "./providers/packaging-warehouse-gateway-provider.js";
import { PackagingWarehouseRepository } from "./repositories/packaging-warehouse-repository.js";
import { PackagingWarehouseService } from "./services/packaging-warehouse-service.js";
import { PartsWarehouseGatewayProvider } from "./providers/parts-warehouse-gateway-provider.js";
import { PartsWarehouseRepository } from "./repositories/parts-warehouse-repository.js";
import { PartsWarehouseService } from "./services/parts-warehouse-service.js";
import { PpeWarehouseGatewayProvider } from "./providers/ppe-warehouse-gateway-provider.js";
import { PpeWarehouseRepository } from "./repositories/ppe-warehouse-repository.js";
import { PpeWarehouseService } from "./services/ppe-warehouse-service.js";
import { localizeElement, translateUiText } from "./i18n.js";

const root = document.querySelector("#app");
const journal = JOURNALS[0];
const SHELL_TEXT = Object.freeze({
  ru: { home: "Главная", online: "Сеть доступна", offline: "Нет интернета", refresh: "Обновить данные", logout: "Выйти", account: "Рабочая учётная запись", test: "Безопасный тестовый режим", theme: "Сменить тему", language: "Сменить язык" },
  en: { home: "Home", online: "Online", offline: "Offline", refresh: "Refresh data", logout: "Sign out", account: "Work account", test: "Safe test mode", theme: "Change theme", language: "Change language" },
  lt: { home: "Pagrindinis", online: "Ryšys yra", offline: "Nėra interneto", refresh: "Atnaujinti duomenis", logout: "Atsijungti", account: "Darbo paskyra", test: "Saugus bandomasis režimas", theme: "Keisti temą", language: "Keisti kalbą" }
});
const state = {
  account: null,
  shift: null,
  legacyShift: null,
  records: [],
  journalError: null,
  operations: [],
  page: "dashboard",
  recordMonth: today().slice(0, 7),
  loading: true,
  syncing: false,
  googleDiagnostics: null,
  syncTransfer: { active: false, source: "" },
  refreshing: false,
  startupSync: { active: false, completed: 0, total: 11, current: "", failed: [], completedAt: null },
  lastRefresh: null,
  attendanceMonth: today().slice(0, 7),
  statisticsYear: Number(today().slice(0, 4)),
  statisticsMonth: "",
  statisticsProductionSort: { key: "quantity", direction: "desc" },
  statistics: { years: [], personnel: [], shiftTeams: [], attendance: [], production: [], error: null },
  attendanceView: "start",
  settingsTab: "overview",
  selectedShiftTeamId: null,
  shiftResponsible: null,
  shiftGuests: [],
  personnelDistribution: null,
  specifications: { specifications: [], source: "loading", cachedAt: null },
  cyclones: { records: [], operations: [], lastReadAt: null, error: null },
  maintenance: { service: { records: [], statistics: {} }, repair: { records: [], statistics: {} }, error: null },
  machineStatuses: {},
  maintenanceDue: { records: [], source: "loading", cachedAt: null, error: null },
  maintenanceView: "repair",
  production: { records: [], source: "loading", cachedAt: null, error: null },
  productionLoading: false,
  packaging: { records: [], operations: [], lastReadAt: null, error: null },
  packagingEntryItem: "",
  packagingWarehouse: { records: [], summary: [], error: null },
  partsWarehouse: { items: [], operations: [], categories: [], error: null },
  ppeWarehouse: { items: [], records: [], error: null },
  nonconformities: { records: [], dictionary: { categories: [] }, source: "loading", cachedAt: null, error: null },
  nonconformityLoading: false,
  incidents: { records: [], dictionary: { categories: [], statuses: [] }, source: "loading", cachedAt: null, error: null },
  incidentLoading: false,
  shiftTasks: { records: [], error: null },
  update: { checked: false, available: false, installing: false, version: null, message: null },
  cycloneYear: Number(today().slice(0, 4)),
  vacationYear: Number(today().slice(0, 4)),
  specificationSelection: { line: "", product: "", variant: "" },
  specificationSearch: "",
  workforce: { personnel: [], shiftTeams: [], attendance: [] },
  language: "ru",
  theme: "light"
};

let store;
let authService;
let shiftService;
let machineStatusGateway;
let legacyShiftService;
let repository;
let journalService;
let productionRefreshPromise = null;
let refreshFromSourcePromise = null;
let startupSyncPromise = null;
let startupSyncRetryTimer;
let startupSyncRetryCount = 0;
let workforceService;
let workforceRepository;
let productSpecificationService;
let cycloneService;
let productionService;
let packagingService;
let packagingWarehouseService;
let partsWarehouseService;
let ppeWarehouseService;
let nonconformityService;
let nonconformityRefreshPromise = null;
let incidentService;
let incidentRefreshPromise = null;
let workforceActor = {};
let refreshTimer;
let clockTimer;
function createRuntimeId() {
  if (typeof globalThis.crypto?.randomUUID === "function") return globalThis.crypto.randomUUID();
  const bytes = globalThis.crypto?.getRandomValues ? globalThis.crypto.getRandomValues(new Uint32Array(2)) : null;
  return `runtime-${Date.now().toString(36)}-${bytes ? `${bytes[0].toString(36)}${bytes[1].toString(36)}` : Math.random().toString(36).slice(2)}`;
}
const updateActivity = {
  sessionId: createRuntimeId(),
  lastInteractionAt: Date.now(),
  submittingUntil: 0,
  heartbeatTimer: null
};

registerServiceWorker();
bootstrap().catch(error => renderFatalError(error));

async function bootstrap() {
  root.textContent = "Открываем локальные данные…";
  store = await new IndexedDbDataProvider().init();
  const cycloneStore = await new IndexedDbDataProvider("packaging-filling-hub-cyclones").init();
  cycloneService = new CycloneService(new CycloneRepository(cycloneStore,
    new CycloneGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })));
  state.cyclones = await cycloneService.snapshot();
  const packagingStore = await new IndexedDbDataProvider("packaging-filling-hub-packaging").init();
  packagingService = new PackagingService(new PackagingRepository(packagingStore,
    new PackagingGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })));
  state.packaging = await packagingService.snapshot();
  packagingWarehouseService = new PackagingWarehouseService(new PackagingWarehouseRepository(
    new PackagingWarehouseGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })
  ));
  partsWarehouseService = new PartsWarehouseService(new PartsWarehouseRepository(
    new PartsWarehouseGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })
  ));
  ppeWarehouseService = new PpeWarehouseService(new PpeWarehouseRepository(
    new PpeWarehouseGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })
  ));
  incidentService = new IncidentService(store, new IncidentRepository(new IncidentGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })));
  state.incidents = await incidentService.snapshot();
  state.machineStatuses = normalizeMachineStatuses(await store.preference("machineStatuses", {}));
  nonconformityService = new NonconformityService(store, new NonconformityRepository(new NonconformityGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })));
  state.maintenanceDue = await store.preference("maintenanceDueCache", state.maintenanceDue);
  const remoteProvider = createRemoteProvider();
  repository = new JournalRepository(store, remoteProvider);
  authService = new AuthService(store, {
    allowedRole: APP_CONFIG.workstationRole,
    apiBaseUrl: APP_CONFIG.integration.gatewayBaseUrl,
    remote: APP_CONFIG.centralAuth
  });
  legacyShiftService = new ShiftService(store);
  shiftService = APP_CONFIG.centralAuth
    ? new ShiftService(store, new CentralShiftGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl }))
    : legacyShiftService;
  machineStatusGateway = APP_CONFIG.centralAuth
    ? new MachineStatusGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })
    : null;
  workforceRepository = APP_CONFIG.integration.mode === "gateway" ? new WorkforceRepository(store,
    new WorkforceGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl, writesEnabled: APP_CONFIG.integration.googleWritesEnabled }),
    () => ({ ...workforceActor, workstationId: APP_CONFIG.workstationId, account: state.account?.id })) : null;
  workforceService = new WorkforceService(store, workforceRepository);
  productSpecificationService = new ProductSpecificationService(store, APP_CONFIG.integration.mode === "gateway"
    ? new ProductSpecificationGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl }) : null);
  productionService = new ProductionService(store, new ProductionRepository(
    new ProductionGatewayProvider({ baseUrl: APP_CONFIG.integration.gatewayBaseUrl })
  ));
  journalService = new JournalService(repository, journal, {
    workstationId: APP_CONFIG.workstationId,
    workstationLabel: APP_CONFIG.workstationLabel
  });

  await repository.init();
  state.account = await authService.current();
  if (state.account) await synchronizeMachineStatuses();
  state.packagingWarehouse = await packagingWarehouseService.refresh();
  state.partsWarehouse = await partsWarehouseService.refresh();
  state.ppeWarehouse = await ppeWarehouseService.refresh();
  state.legacyShift = APP_CONFIG.centralAuth ? await legacyShiftService.current() : null;
  state.shift = state.account ? await shiftService.current() : null;
  // Do not hold the whole interface on a slow Google request.  A fresh
  // attendance snapshot is still required immediately before each save below.
  state.workforce = await workforceService.snapshot();
  state.specifications = await productSpecificationService.snapshot();
  state.production = await productionService.snapshot();
  state.nonconformities = await nonconformityService.snapshot();
  state.shiftResponsible = await store.preference("sessionShiftResponsible", null);
  // A completed or yesterday's shared shift must not pin the attendance page
  // to its old team.  Outside the active shift, always open today's team.
  state.selectedShiftTeamId = isCurrentSharedShift(state.shift)
    ? state.shift.shiftTeamId
    : scheduledTeam()?.id ?? state.workforce.shiftTeams[0]?.id ?? null;
  state.language = normalizeLanguage(await store.preference("interfaceLanguage", "ru"));
  state.theme = (await store.preference("interfaceTheme", "light")) === "dark" ? "dark" : "light";
  await reloadLocalState();
  state.loading = false;
  state.lastRefresh = new Date().toISOString();
  render();
  bindGlobalEvents();
  startUpdateSafetyHeartbeat();
  startAutomaticRefresh();
  startClock();
  registerServiceWorker();
  void checkForUpdate();
  if (navigator.onLine && (!APP_CONFIG.centralAuth || state.account)) void startStartupJournalSync().finally(() => syncInBackground());
}

function createRemoteProvider() {
  return new GoogleSheetsGatewayProvider({
    baseUrl: APP_CONFIG.integration.gatewayBaseUrl,
    writesEnabled: APP_CONFIG.integration.googleWritesEnabled
  });
}

function bindGlobalEvents() {
  root.addEventListener("click", handleClick);
  root.addEventListener("input", handleInput);
  root.addEventListener("change", handleChange);
  root.addEventListener("submit", handleSubmit);
  // Dialogues are mounted outside #app, so protect their unfinished forms too.
  document.addEventListener("input", noteUpdateFormInput, true);
  document.addEventListener("change", noteUpdateFormInput, true);
  document.addEventListener("submit", noteUpdateFormSubmit, true);
  document.addEventListener("reset", event => {
    const form = event.target instanceof HTMLFormElement ? event.target : null;
    if (form) window.setTimeout(() => delete form.dataset.updateDirty, 0);
  }, true);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) noteUpdateInteraction();
    else void sendUpdateSafetyHeartbeat({ keepalive: true });
  });
  // A page reload or a closed window must not leave a stale "unsaved form"
  // marker at the local gateway for the next five minutes.
  window.addEventListener("pagehide", () => clearUpdateSafetySession());
  window.addEventListener("keydown", event => {
    if (event.ctrlKey && !event.altKey && !event.shiftKey && event.key === "F5") {
      event.preventDefault();
      refreshFromSource();
    }
  });
  window.addEventListener("online", async () => {
    render();
    toast("Интернет появился. Отправляем сохранённые записи…", "success");
    await syncRecords({ silent: true });
  });
  window.addEventListener("offline", () => {
    render();
    toast("Нет интернета. Новые записи сохранятся на этом компьютере.", "warning");
  });
}

function noteUpdateFormInput(event) {
  const field = event.target instanceof Element ? event.target : null;
  if (!field?.matches("input:not([type=hidden]), select, textarea")) return;
  const form = field.closest("form");
  if (form) form.dataset.updateDirty = "true";
  noteUpdateInteraction();
}

function noteUpdateFormSubmit(event) {
  if (!(event.target instanceof HTMLFormElement)) return;
  updateActivity.submittingUntil = Date.now() + 90_000;
  noteUpdateInteraction();
}

function noteUpdateInteraction() {
  updateActivity.lastInteractionAt = Date.now();
  void sendUpdateSafetyHeartbeat();
}

function pendingUpdateOperations() {
  return (state.operations?.length || 0)
    + (state.workforce?.pending?.length || 0)
    + (state.packaging?.operations?.length || 0)
    + (state.cyclones?.operations?.length || 0);
}

function updateSafetyPayload() {
  return {
    sessionId: updateActivity.sessionId,
    dirty: hasUnsavedUpdateForm(),
    submitting: Date.now() < updateActivity.submittingUntil,
    pending: pendingUpdateOperations(),
    lastInteractionAt: updateActivity.lastInteractionAt,
    visible: !document.hidden
  };
}

function hasUnsavedUpdateForm() {
  return [...document.querySelectorAll("form[data-update-dirty='true']")].some(form => {
    const dialog = form.closest("dialog");
    return !dialog || dialog.open;
  });
}

function clearUpdateSafetySession() {
  if (!state.account || !navigator.onLine) return;
  const payload = JSON.stringify({ sessionId: updateActivity.sessionId, closed: true });
  const url = `${APP_CONFIG.integration.gatewayBaseUrl}/api/update-activity`;
  if (navigator.sendBeacon) {
    navigator.sendBeacon(url, new Blob([payload], { type: "application/json" }));
    return;
  }
  void fetch(url, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: payload,
    keepalive: true
  });
}

async function sendUpdateSafetyHeartbeat({ keepalive = false } = {}) {
  if (!state.account || !navigator.onLine) return;
  try {
    await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/update-activity`, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify(updateSafetyPayload()),
      keepalive
    });
  } catch {
    // A temporary gateway restart is expected while an update is installed.
  }
}

function startUpdateSafetyHeartbeat() {
  if (updateActivity.heartbeatTimer) clearInterval(updateActivity.heartbeatTimer);
  void sendUpdateSafetyHeartbeat();
  updateActivity.heartbeatTimer = window.setInterval(() => void sendUpdateSafetyHeartbeat(), 15_000);
}

function handleInput(event) {
  if (event.target.matches("[data-personnel-filter]")) filterPersonnelCards();
  if (event.target.matches("[data-parts-filter]")) filterPartsWarehouseRows();
  if (event.target.matches("[data-specification-search]")) {
    const cursor = event.target.selectionStart ?? event.target.value.length;
    state.specificationSearch = event.target.value;
    render();
    const search = root.querySelector("[data-specification-search]");
    if (search) { search.focus(); search.setSelectionRange(cursor, cursor); }
  }
  if (event.target.matches("[data-attendance-status]")) {
    updateAttendanceStatusTone(event.target);
    updateAttendanceCounter(event.target.form);
    updateShiftLeadershipOptions(event.target.form);
  }
}

async function handleChange(event) {
  if (event.target.matches("[data-parts-filter]")) {
    filterPartsWarehouseRows();
    return;
  }
  if (event.target.matches("[data-attendance-status]")) {
    updateAttendanceStatusTone(event.target);
    updateAttendanceCounter(event.target.form);
    updateShiftLeadershipOptions(event.target.form);
    return;
  }
  if (event.target.matches("[data-specification-select]")) {
    const field = event.target.dataset.specificationSelect;
    const nextSelection = { ...state.specificationSelection, [field]: event.target.value };
    state.specificationSelection = normalizeSpecificationSelection(
      state.specifications?.specifications ?? [],
      nextSelection,
      field
    );
    render();
    return;
  }

  if (event.target.matches("[data-cyclone-year]")) {
    state.cycloneYear = Number(event.target.value);
    render();
    return;
  }
  if (event.target.matches("[data-vacation-year]")) {
    state.vacationYear = Number(event.target.value);
    render();
    return;
  }
  if (event.target.matches("[data-record-month]")) {
    state.recordMonth = event.target.value;
    render();
    return;
  }
  if (event.target.matches("[data-statistics-year]")) {
    state.statisticsYear = Number(event.target.value);
    await refreshStatistics();
    render();
    return;
  }
  if (event.target.matches("[data-statistics-month]")) {
    state.statisticsMonth = event.target.value;
    await refreshStatistics();
    render();
    return;
  }
  if (event.target.matches("[data-login-responsible]")) {
    const otherField = event.target.form?.querySelector("[data-login-responsible-other]");
    if (otherField) otherField.hidden = event.target.value !== "other";
    return;
  }
  if (event.target.matches("[data-start-team]")) {
    state.selectedShiftTeamId = event.target.value;
    state.shiftGuests = [];
    state.personnelDistribution = null;
    render();
    return;
  }
  if (event.target.matches("[data-timesheet-cell]")) {
    const select = event.target;
    try {
      if (!canEditTimesheetDate(select.dataset.date)) {
        throw new Error("Старший механик может исправлять табель только за текущий день смены.");
      }
      await withWorkforceActor(() => workforceService.saveAttendance({
        date: select.dataset.date,
        shiftTeamId: select.dataset.shiftTeamId,
        employeeId: select.dataset.employeeId,
        value: select.value,
        overtime: select.dataset.overtime === "true"
      }));
      state.workforce = await workforceService.snapshot();
      render();
      toast("Табель сохранён.", "success");
      sendWorkforceInBackground();
    } catch (error) {
      toast(error.message || "Не удалось сохранить табель.", "error");
    }
  }
}

async function handleSubmit(event) {
  const form = event.target.closest("[data-form]");
  if (!form) return;
  event.preventDefault();
  if (form.dataset.form === "personnel-distribution") {
    const data = new FormData(form);
    const teamId = String(data.get("teamId") || "");
    const members = shiftStartMembers(teamId);
    const attendance = attendanceForShiftStart(teamId, isCurrentSharedShift() ? state.shift : null);
    const present = new Map(members
      .filter(employee => attendanceCode(attendance.get(employee.id)) === "11")
      .map(employee => [employee.id, employee]));
    const lines = data.getAll("line").map(String).filter(line => PRODUCTION_LINES.includes(line));
    const operatorIds = data.getAll("operator").map(String).filter(id => present.get(id)?.role === "mechanic-operator");
    const packerIds = data.getAll("packer").map(String).filter(id => present.get(id)?.role === "packer");
    const runNumber = nextPersonnelDistributionRun(teamId);
    state.personnelDistribution = {
      teamId,
      lines,
      operatorIds,
      packerIds,
      result: { ...distributePersonnel({ teamId, lines, operatorIds, packerIds }), runNumber }
    };
    render();
    return;
  }
  if (form.dataset.form === "packaging-quick") {
    const data = Object.fromEntries(new FormData(form));
    const submit = form.querySelector('[type="submit"]');
    submit.disabled = true;
    try {
      await packagingService.add({ date: today(), ...data }, state.account);
      state.packaging = await packagingService.snapshot();
      state.packagingEntryItem = String(data.item || "");
      render();
      focusPackagingQuantity();
      toast("Расход сохранён. Итог за сегодня обновлён.", "success");
      // Не только перечитываем журнал: сразу отправляем новую локальную запись.
      // При ошибке сервис сохранит её в очереди для следующей попытки.
      if (navigator.onLine) {
        void packagingService.sync().then((snapshot) => {
          state.packaging = snapshot;
          render();
        });
      }
    } catch (error) {
      showFormError(form, error.message || "Не удалось сохранить расход.");
      submit.disabled = false;
    }
    return;
  }
  if (form.dataset.form === "login") {
    const data = new FormData(form);
    try {
      const accountId = String(data.get("accountId") || "");
      state.account = await authService.login(accountId, String(data.get("password") || ""));
      state.shiftResponsible = null;
      state.shift = await shiftService.current();
      await synchronizeMachineStatuses();
      state.page = "dashboard";
      render();
      if (navigator.onLine) void startStartupJournalSync().finally(() => syncInBackground());
    } catch (error) {
      const panel = form.querySelector("[data-login-error]");
      if (panel) { panel.textContent = error.message || "Не удалось выполнить вход"; panel.hidden = false; }
    }
    return;
  }
  if (form.dataset.form === "password-change") {
    if (state.account?.role !== "manager") return;
    const data = new FormData(form);
    const nextPassword = String(data.get("nextPassword") || "");
    if (nextPassword !== String(data.get("repeatPassword") || "")) {
      toast("Новый пароль и повтор не совпадают.", "error");
      return;
    }
    try {
      await authService.changePassword(String(data.get("accountId") || ""), String(data.get("currentPassword") || ""), nextPassword);
      form.reset();
      toast(APP_CONFIG.centralAuth ? "Пароль учётной записи изменён на центральном сервере." : "Пароль учётной записи изменён на этом компьютере.", "success");
    } catch (error) {
      toast(error.message || "Не удалось изменить пароль.", "error");
    }
    return;
  }
  if (form.dataset.form === "shift-settings") {
    try {
      const data = Object.fromEntries(new FormData(form));
      await withWorkforceActor(() => workforceService.saveShiftTeam(data));
      state.workforce = await workforceService.snapshot();
      render();
      toast("Настройки смены сохранены.", "success");
      sendWorkforceInBackground();
    } catch (error) {
      toast(error.message || "Не удалось сохранить настройки смены.", "error");
    }
    return;
  }
  if (form.dataset.form !== "shift-attendance") return;
  const data = new FormData(form);
  const teamId = String(data.get("shiftTeamId") || state.selectedShiftTeamId || "");
  const members = shiftStartMembers(teamId);
  const attendance = members.map(employee => ({
    employeeId: employee.id,
    status: String(data.get(`attendance-${employee.id}`) || ""),
    isSubstitute: employee.isSubstitute === true,
    substitutionReason: employee.substitutionReason || "",
    homeShiftTeamId: employee.homeShiftTeamId || ""
  }));
  if (attendance.some(item => !item.status)) {
    showInlineFormError(form, "Отметьте каждого сотрудника");
    return;
  }
  try {
    const changes = attendanceChanges(teamId, attendance);
    if (changes.length && !window.confirm(attendanceChangeMessage(changes))) return;
    if (isCurrentSharedShift()) {
      const leadership = shiftLeadershipFromForm(form, teamId);
      state.shift = await shiftService.updateAttendance(attendance, leadership);
      await saveShiftAttendanceToTimesheet(teamId, attendance, changes);
      state.shiftGuests = [];
      state.workforce = await workforceService.snapshot();
      render();
      toast("Табель смены обновлён.", "success");
      return;
    }
    const leadership = shiftLeadershipFromForm(form, teamId);
    state.shift = await shiftService.start({
      supervisor: leadership.seniorMechanic,
      seniorMechanic: leadership.seniorMechanic,
      mechanic: leadership.mechanic,
      shiftDate: today(),
      shiftNumber: 1,
      shiftTeamId: teamId,
      attendance
    });
    await saveShiftAttendanceToTimesheet(teamId, attendance, changes);
    state.shiftGuests = [];
    state.workforce = await workforceService.snapshot();
    state.page = state.shift.requiresScaleControl ? "journals" : "dashboard";
    render();
    if (state.shift.requiresScaleControl) {
      toast("Табель сохранён. Теперь выполните контроль весов.", "success");
      setTimeout(() => openScaleWalkDialog(), 0);
    } else {
      toast("Вторая смена начата. Контроль весов не требуется.", "success");
    }
  } catch (error) {
    showInlineFormError(form, error.message || "Не удалось начать смену");
  }
}

async function handleClick(event) {
  const actionElement = event.target.closest("[data-action]");
  if (!actionElement) return;
  const { action, id, page, accountId, item } = actionElement.dataset;

  try {
    if (action === "new-cyclone") { await openCycloneDialog(); return; }
    if (action === "add-shift-task") { if (state.account?.role === "manager") openShiftTaskDialog(); return; }
    if (action === "edit-shift-task") { const record = state.shiftTasks.records.find(item => item.id === id); if (state.account?.role === "manager" && record) openShiftTaskDialog(record); return; }
    if (action === "complete-shift-task") { const record = state.shiftTasks.records.find(item => item.id === id); if (record) openShiftTaskCompletionDialog(record); return; }
    if (action === "delete-shift-task") {
      const record = state.shiftTasks.records.find(item => item.id === id);
      if (state.account?.role !== "manager") return;
      if (!record || !window.confirm("Удалить сменное задание?")) return;
      await requestShiftTask("DELETE", { id: record.id, expectedRevision: record.revision }); await refreshShiftTasks(); render(); toast("Сменное задание удалено.", "success"); return;
    }
    if (action === "refresh-shift-tasks") { await refreshShiftTasks(); render(); toast(state.shiftTasks.error || "Сменные задания обновлены.", state.shiftTasks.error ? "warning" : "success"); return; }
    if (action === "open-mobile-menu") { openMobileMenu(); return; }
    if (action === "add-incident") { openIncidentDialog(); return; }
    if (action === "edit-incident") { const record = state.incidents.records.find(item => item.id === id); if (record) openIncidentDialog(record); return; }
    if (action === "delete-incident") {
      const record = state.incidents.records.find(item => item.id === id);
      if (!record || !window.confirm(`Удалить инцидент от ${formatDate(record.date)}?`)) return;
      await incidentService.remove(record.id); await refreshIncidents(); render(); toast("Инцидент удалён из журнала.", "success"); return;
    }
    if (action === "refresh-incidents") {
      if (state.incidentLoading) return; state.incidentLoading = true; render();
      try { await refreshIncidents(); toast(state.incidents.error || "Журнал инцидентов обновлён.", state.incidents.error ? "warning" : "success"); }
      finally { state.incidentLoading = false; render(); }
      return;
    }
    if (action === "add-nonconformity") { openNonconformityDialog(); return; }
    if (action === "manage-nonconformity-dictionary") { openNonconformityDictionaryDialog(); return; }
    if (action === "edit-nonconformity") { const record = state.nonconformities.records.find(item => item.id === id); if (record) openNonconformityDialog(record); return; }
    if (action === "delete-nonconformity") {
      if (state.account?.role !== "manager") { toast("Удалять несоответствия может только администрация.", "warning"); return; }
      const record = state.nonconformities.records.find(item => item.id === id);
      if (!record || !window.confirm(`Удалить несоответствие «${record.type}» от ${formatDate(record.date)}?`)) return;
      await nonconformityService.remove(record.id); await refreshNonconformities(); render(); toast("Запись удалена из журнала.", "success"); return;
    }
    if (action === "refresh-nonconformities") {
      if (state.nonconformityLoading) return; state.nonconformityLoading = true; render();
      try { await refreshNonconformities(); toast(state.nonconformities.error || "Журнал несоответствий обновлён.", state.nonconformities.error ? "warning" : "success"); }
      finally { state.nonconformityLoading = false; render(); }
      return;
    }
    if (action === "new-packaging") { openPackagingDialog(); return; }
    if (action === "select-packaging-item") {
      state.packagingEntryItem = String(item || "");
      render();
      focusPackagingQuantity();
      return;
    }
    if (action === "edit-packaging") { const record = state.packaging.records.find(item => item.id === id); if (record) openPackagingEditDialog(record); return; }
    if (action === "add-packaging-stock") { openPackagingWarehouseDialog(); return; }
    if (action === "refresh-packaging-warehouse") { await refreshPackagingWarehouse(); render(); toast(state.packagingWarehouse.error || "Склад упаковки обновлён", state.packagingWarehouse.error ? "warning" : "success"); return; }
    if (action === "add-parts-stock") { openPartsWarehouseDialog(); return; }
    if (action === "receive-parts-stock") { const part = state.partsWarehouse.items.find(item => item.id === id); if (part) openPartsWarehouseMovementDialog(part, "receive"); return; }
    if (action === "adjust-parts-stock") { const part = state.partsWarehouse.items.find(item => item.id === id); if (part) openPartsWarehouseMovementDialog(part, "adjust"); return; }
    if (action === "refresh-parts-warehouse") { await refreshPartsWarehouse(); render(); toast(state.partsWarehouse.error || "Склад запчастей обновлён", state.partsWarehouse.error ? "warning" : "success"); return; }
    if (action === "refresh-ppe-warehouse") { await refreshPpeWarehouse(); render(); toast(state.ppeWarehouse.error || "Склад СИЗ обновлён", state.ppeWarehouse.error ? "warning" : "success"); return; }
    if (action === "add-ppe-issue") { openPpeIssueDialog(); return; }
    if (action === "retry-ppe-issue") { state.ppeWarehouse = await ppeWarehouseService.retry(id); render(); toast(state.ppeWarehouse.error || "Повторная отправка выполнена", state.ppeWarehouse.error ? "warning" : "success"); return; }
    if (action === "edit-packaging-stock") { const record = state.packagingWarehouse.records.find(item => item.id === id); if (record) openPackagingWarehouseDialog(record); return; }
    if (action === "delete-packaging-stock") {
      if (state.account?.role !== "manager") throw new Error("Удалять движения склада может только начальник участка.");
      const record = state.packagingWarehouse.records.find(item => item.id === id);
      if (!record || !window.confirm(`Удалить движение «${record.item}» от ${formatDate(record.date)}?`)) return;
      state.packagingWarehouse = await packagingWarehouseService.remove(id);
      render(); toast("Движение удалено из журнала склада.", "success"); return;
    }
    if (action === "delete-packaging") { const record = state.packaging.records.find(item => item.id === id); if (record && window.confirm(`Удалить весь расход упаковки за ${formatDate(record.date)}?`)) { await packagingService.remove(record); state.packaging = await packagingService.snapshot(); render(); if (navigator.onLine) void packagingService.sync().then(snapshot => { state.packaging = snapshot; render(); }); } return; }
    if (action === "sync-packaging") {
      state.packaging = await packagingService.sync(); render();
      toast(state.packaging.error || "Журнал расхода упаковки обновлён", state.packaging.error ? "warning" : "success");
      return;
    }
    if (action === "sync-cyclones") {
      await reconcileCycloneQueuePerformers();
      state.cyclones = await cycloneService.sync();
      render();
      toast(state.cyclones.error || "Журнал очистки циклонов обновлён", state.cyclones.error ? "warning" : "success");
      return;
    }
    if (action === "login") {
      state.account = await authService.login(accountId);
      state.page = "dashboard";
      await refreshShiftTasks();
      render();
      return;
    }
    if (action === "logout") {
      await authService.logout();
      await store.setPreference("sessionShiftResponsible", null);
      state.account = null;
      state.shift = null;
      state.shiftResponsible = null;
      render();
      return;
    }
    if (action === "navigate") {
      actionElement.closest("dialog")?.close();
      await navigateToPage(page);
      return;
    }
    if (action === "new-record") {
      if (state.account.role === "senior" && !isCurrentSharedShift()) {
        toast("Сначала нажмите «Начать смену».", "warning");
        return;
      }
      openRecordDialog();
      return;
    }
    if (action === "start-scale-walk") {
      if (state.account.role === "senior" && !isCurrentSharedShift()) {
        toast("Сначала нажмите «Начать смену».", "warning");
        return;
      }
      openScaleWalkDialog();
      return;
    }
    if (action === "edit-record") {
      openRecordDialog(id);
      return;
    }
    if (action === "annul-record") {
      openAnnulDialog(id);
      return;
    }
    if (action === "start-shift") {
      state.page = "attendance";
      render();
      return;
    }
    if (action === "end-shift") {
      const shift = state.shift;
      const team = teamLabel(shift?.shiftTeamId);
      if (!window.confirm(`Завершить общую смену ${team}?\n\nЭто закроет только общий статус смены на центральном сервере. Уже сохранённые отметки табеля и записи Google не будут удалены или изменены.`)) return;
      await shiftService.end();
      state.shift = await shiftService.current();
      render();
      toast("Смена завершена.", "success");
      return;
    }
    if (action === "archive-legacy-shift") {
      await archiveLegacyShift();
      render();
      toast("Локальная незавершённая смена сохранена в архиве. Отметки табеля не менялись.", "success");
      return;
    }
    if (action === "refresh-and-reload") {
      if (state.page === "dashboard") {
        await startStartupJournalSync();
      } else {
        await refreshFromSource();
      }
      // Once Google data has been read, reload the interface just as F5 would.
      // This also makes sure that the newest interface files are displayed.
      window.location.reload();
      return;
    }
    if (action === "refresh") {
      await refreshFromSource();
      return;
    }
    if (action === "sync-all-journals") {
      await startStartupJournalSync();
      return;
    }
    if (action === "check-update") {
      await checkForUpdate({ announce: true });
      return;
    }
    if (action === "install-update") {
      if (state.update.installing) return;
      state.update.installing = true;
      render();
      // Send the exact state of this screen first. It prevents an old value
      // from a just-closed dialogue from blocking the requested update.
      await sendUpdateSafetyHeartbeat();
      const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/update`, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ force: true, activity: updateSafetyPayload() })
      });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || "Не удалось запустить обновление");
      toast("Обновление скачивается и проверяется. Ожидаем запуск новой версии…", "success");
      await waitForInstalledUpdate(result.version);
      return;
    }
    if (action === "refresh-maintenance") {
      await refreshMaintenance();
      render();
      return;
    }
    if (action === "toggle-machine-status") {
      if (!['manager', 'senior'].includes(state.account?.role)) throw new Error("Изменять состояние станков могут только Администрация и Старший механик.");
      const machine = Number(actionElement.dataset.machine);
      if (!Number.isInteger(machine) || machine < 1 || machine > 16) return;
      const statuses = ["work", "attention", "maintenance", "repair", "inactive"];
      const current = normalizeMachineStatuses(state.machineStatuses)[machine];
      const next = statuses[(statuses.indexOf(current) + 1) % statuses.length];
      state.machineStatuses = {
        ...state.machineStatuses,
        [machine]: next
      };
      await store.setPreference("machineStatuses", state.machineStatuses);
      if (machineStatusGateway) {
        const shared = await machineStatusGateway.save(state.machineStatuses);
        state.machineStatuses = normalizeMachineStatuses(shared.statuses);
      }
      render();
      const label = { work: "рабочая", attention: "требует внимания", maintenance: "на ТО", repair: "в ремонте", inactive: "не в работе" }[next];
      toast(`Станок ${machine}: ${label}.`, ["attention", "maintenance", "repair", "inactive"].includes(next) ? "warning" : "success");
      return;
    }
    if (action === "refresh-production") {
      if (state.productionLoading) return;
      state.productionLoading = true;
      render();
      try {
        await refreshProduction();
        toast(state.production.error || "Журнал продукции обновлён из Google Sheets.", state.production.error ? "warning" : "success");
      } finally {
        state.productionLoading = false;
        render();
      }
      return;
    }
    if (action === "sort-statistics-production") {
      const key = String(actionElement.dataset.sortKey || "");
      if (!["quantity", "scrapKg", "scrapPercent"].includes(key)) return;
      const current = state.statisticsProductionSort;
      state.statisticsProductionSort = current.key === key
        ? { key, direction: current.direction === "desc" ? "asc" : "desc" }
        : { key, direction: "desc" };
      render();
      return;
    }
    if (action === "add-production") { openProductionDialog(); return; }
    if (action === "edit-production") {
      const record = state.production.records.find(item => item.id === id);
      if (record) openProductionDialog(record);
      return;
    }
    if (action === "delete-production") {
      const record = state.production.records.find(item => item.id === id);
      if (!record || !window.confirm(`Удалить запись «${record.product}» (${formatDate(record.date)} ${record.time}) из журнала?`)) return;
      try {
        await productionService.remove(record.id);
        await refreshProduction(); render();
        toast("Запись удалена из журнала.", "success");
      } catch (error) { toast(error.message, "warning"); }
      return;
    }
    if (action === "refresh-specifications") {
      state.specifications = await productSpecificationService.initialize();
      render();
      toast(state.specifications.error || "Каталог продуктов обновлён из Google Sheets.", state.specifications.error ? "warning" : "success");
      return;
    }
    if (action === "select-specification") {
      const specification = state.specifications.specifications.find(item => item.id === id);
      if (!specification) return;
      state.specificationSelection = { line: specification.line, product: specification.product, variant: String(specification.variant) };
      render();
      return;
    }
    if (action === "add-maintenance-service") { openMaintenanceDialog("service"); return; }
    if (action === "add-maintenance-repair") { openMaintenanceDialog("repair"); return; }
    if (action === "maintenance-view") {
      state.maintenanceView = actionElement.dataset.view || "repair";
      render();
      return;
    }
    if (action === "sync") {
      await syncRecords();
      return;
    }
    if (action === "google-diagnostics") {
      await checkGoogleConnection();
      return;
    }
    if (action === "sync-queue-source") {
      await syncQueueSource(actionElement.dataset.source);
      return;
    }
    if (action === "queue-discard") {
      const source = actionElement.dataset.source;
      const entry = queueEntries().find(item => item.source === source && item.id === id);
      if (!entry) { toast("Запись уже отсутствует в очереди.", "warning"); return; }
      if (!window.confirm(`Удалить «${entry.title}» из очереди? Она не будет отправлена в Google. Черновик останется в локальном архиве этого компьютера.`)) return;
      if (source === "checks") await repository.discardOperation(id);
      else if (source === "cyclones") state.cyclones = await cycloneService?.discardOperation(id);
      else { toast("Удаление из очереди для этого журнала пока недоступно.", "warning"); return; }
      await reloadLocalState();
      render();
      toast("Запись удалена из очереди и сохранена в локальном архиве.", "success");
      return;
    }
    if (action === "queue-accept-remote") {
      if (!window.confirm("Оставить версию Google? Локальный черновик будет сохранён только в журнале истории этого компьютера.")) return;
      await repository.acceptRemoteOperation(id);
      await reloadLocalState();
      render();
      toast("Оставлена версия Google. Локальный черновик сохранён в истории.", "success");
      return;
    }
    if (action === "attendance-month") {
      state.attendanceMonth = shiftMonth(state.attendanceMonth, Number(actionElement.dataset.offset || 0));
      render();
      return;
    }
    if (action === "attendance-view") {
      state.attendanceView = actionElement.dataset.view;
      openAttendanceForCurrentMonth();
      return;
    }
    if (action === "settings-tab") {
      state.settingsTab = actionElement.dataset.tab;
      render();
      return;
    }
    if (["add-employee", "edit-employee", "toggle-employee", "add-specification", "edit-specification", "delete-specification"].includes(action) && state.account.role !== "manager") {
      toast("Редактировать справочник персонала может только начальник участка.", "error");
      return;
    }
    if (action === "add-shift-guest") {
      openShiftGuestDialog();
      return;
    }
    if (action === "remove-shift-guest") {
      if (state.shift?.active && state.shift.attendance?.some(item => item.employeeId === id && item.isSubstitute)) {
        toast("Подменный выход уже сохранён. Для исправления обратитесь к начальнику участка.", "warning");
        return;
      }
      state.shiftGuests = state.shiftGuests.filter(item => item.employeeId !== id);
      render();
      return;
    }
    if (action === "add-employee") {
      openEmployeeDialog();
      return;
    }
    if (action === "edit-employee") {
      openEmployeeDialog(id);
      return;
    }
    if (action === "toggle-employee") {
      await withWorkforceActor(() => workforceService.toggleEmployee(id));
      state.workforce = await workforceService.snapshot();
      render();
      toast("Статус сотрудника изменён.", "success");
      sendWorkforceInBackground();
      return;
    }
    if (action === "add-specification") {
      openSpecificationDialog();
      return;
    }
    if (action === "edit-specification") {
      openSpecificationDialog(id);
      return;
    }
    if (action === "delete-specification") {
      await deleteSpecification(id);
      return;
    }
    if (action === "workforce-accept-remote") {
      await workforceRepository?.acceptRemote(id);
      state.workforce = await workforceService.snapshot(); render(); return;
    }
    if (action === "workforce-overwrite-vacation") {
      await workforceRepository?.overwriteVacationConflict(id);
      state.workforce = await workforceService.snapshot();
      render();
      toast("Версия программы отправлена в Google.", "success");
      return;
    }
    if (action === "workforce-overwrite-personnel") {
      await workforceRepository?.overwritePersonnelConflict(id);
      state.workforce = await workforceService.snapshot();
      render();
      toast("Версия программы отправлена в Google.", "success");
      return;
    }
    if (action === "workforce-retry-missing-attendance") {
      await workforceRepository?.retryMissingAttendance(id);
      state.workforce = await workforceService.snapshot();
      render();
      toast("Строка табеля проверена и отправлена в Google.", "success");
      return;
    }
    if (action === "edit-vacation" || action === "add-vacation") {
      if (state.account.role !== "manager") { toast("График отпусков доступен для редактирования только начальнику участка.", "error"); return; }
      openVacationDialog(action === "edit-vacation" ? id : null); return;
    }
    if (action === "cancel-vacation" || action === "delete-vacation") {
      if (state.account.role !== "manager") { toast("График отпусков доступен для редактирования только начальнику участка.", "error"); return; }
      const vacation = (state.workforce.vacations || []).find(item => item.id === id);
      if (!vacation) { toast("Период отпуска не найден.", "error"); return; }
      const remove = action === "delete-vacation";
      const question = remove ? "Удалить этот период из программы и Google?" : "Отменить этот период? Он останется в журнале со статусом «Аннулирован».";
      if (!globalThis.confirm(question)) return;
      await withWorkforceActor(() => remove ? workforceService.deleteVacation(vacation) : workforceService.cancelVacation(vacation));
      state.workforce = await workforceService.snapshot();
      render();
      toast(remove ? "Период отпуска удалён." : "Период отпуска отменён.", "success");
      sendWorkforceInBackground();
      return;
    }
    if (action === "cycle-language") {
      const index = LANGUAGES.findIndex(language => language.code === state.language);
      state.language = LANGUAGES[(index + 1) % LANGUAGES.length].code;
      await store.setPreference("interfaceLanguage", state.language);
      render();
      startClock();
      return;
    }
    if (action === "toggle-theme") {
      state.theme = state.theme === "dark" ? "light" : "dark";
      await store.setPreference("interfaceTheme", state.theme);
      render();
      startClock();
      return;
    }
    if (action === "close-dialog") {
      actionElement.closest("dialog")?.close();
      return;
    }

  } catch (error) {
    toast(error.message || "Не удалось выполнить действие", "error");
  }
}

async function navigateToPage(page) {
  state.page = page;
  if (page === "attendance") {
    openAttendanceForCurrentMonth();
  } else {
    render();
  }
  if (page === "maintenance") await refreshMaintenance();
  if (page === "production") await refreshProduction();
  if (page === "statistics") await refreshStatistics();
  if (page === "packaging") await refreshPackaging();
  if (page === "packaging-warehouse") await refreshPackagingWarehouse();
  if (page === "parts-warehouse") await refreshPartsWarehouse();
  if (page === "ppe-warehouse") await refreshPpeWarehouse();
  if (page === "nonconformities") await refreshNonconformities();
  if (page === "incidents") await refreshIncidents();
  if (page === "shift-tasks") await refreshShiftTasks();
  if (["maintenance", "production", "statistics", "packaging", "packaging-warehouse", "parts-warehouse", "ppe-warehouse", "nonconformities", "incidents", "shift-tasks"].includes(page)) render();
}

async function reloadLocalState() {
  state.records = await journalService.list();
  state.operations = await repository.pendingOperations();
}

function hasNonWorkingMachineStatus(statuses) {
  return Object.values(normalizeMachineStatuses(statuses)).some(status => status !== "work");
}

async function synchronizeMachineStatuses() {
  if (!machineStatusGateway || !state.account) return state.machineStatuses;
  const shared = await machineStatusGateway.current();
  if (shared.configured) {
    state.machineStatuses = normalizeMachineStatuses(shared.statuses);
    await store.setPreference("machineStatuses", state.machineStatuses);
    return state.machineStatuses;
  }
  // The senior mechanic's existing non-green browser state becomes the first
  // shared state. A manager's untouched all-green view must never overwrite it.
  if (state.account.role === "senior" && hasNonWorkingMachineStatus(state.machineStatuses)) {
    const saved = await machineStatusGateway.save(state.machineStatuses);
    state.machineStatuses = normalizeMachineStatuses(saved.statuses);
  }
  return state.machineStatuses;
}

async function syncWorkforce() {
  if (!workforceRepository) return state.workforce;
  state.workforce = await workforceRepository.sync();
  return state.workforce;
}

async function refreshSpecifications() {
  state.specifications = await productSpecificationService.initialize();
  return state.specifications;
}

async function refreshCyclones(sync = false) {
  state.cyclones = sync ? await cycloneService.sync() : await cycloneService.refresh();
  return state.cyclones;
}

async function refreshPackaging(sync = false) {
  state.packaging = sync ? await packagingService.sync() : await packagingService.refresh();
  return state.packaging;
}

async function refreshPackagingWarehouse() {
  state.packagingWarehouse = await packagingWarehouseService.refresh();
  return state.packagingWarehouse;
}

async function refreshPartsWarehouse() {
  state.partsWarehouse = await partsWarehouseService.refresh();
  return state.partsWarehouse;
}

async function refreshPpeWarehouse() {
  state.ppeWarehouse = await ppeWarehouseService.refresh();
  return state.ppeWarehouse;
}

async function refreshNonconformities() {
  if (!nonconformityRefreshPromise) {
    nonconformityRefreshPromise = nonconformityService.refresh()
      .then(snapshot => { state.nonconformities = snapshot; return snapshot; })
      .finally(() => { nonconformityRefreshPromise = null; });
  }
  return nonconformityRefreshPromise;
}

async function refreshIncidents() {
  if (!incidentRefreshPromise) {
    incidentRefreshPromise = incidentService.refresh()
      .then(snapshot => { state.incidents = snapshot; return snapshot; })
      .finally(() => { incidentRefreshPromise = null; });
  }
  return incidentRefreshPromise;
}

async function requestShiftTask(method = "GET", body = null) {
  let response;
  try {
    response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/shift-tasks`, {
      method,
      headers: { Accept: "application/json", ...(body ? { "Content-Type": "application/json" } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {})
    });
  } catch {
    throw new Error("Нет связи с журналом сменных заданий в Google");
  }
  const payload = await response.json().catch(() => null);
  if (!response.ok || payload?.ok !== true) throw new Error(payload?.message || "Журнал сменных заданий недоступен");
  return payload;
}

async function refreshShiftTasks() {
  try {
    const payload = await requestShiftTask();
    state.shiftTasks = { records: Array.isArray(payload.records) ? payload.records : [], error: null };
  } catch (error) {
    state.shiftTasks = { ...state.shiftTasks, error: error.message };
  }
  return state.shiftTasks;
}

async function refreshMaintenance() {
  try {
    const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/maintenance`, { headers: { Accept: "application/json" } });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload?.ok) throw new Error(payload?.message || "Не удалось загрузить журналы ремонта и ТО");
    state.maintenance = { service: payload.service ?? state.maintenance.service, repair: payload.repair ?? state.maintenance.repair, error: null };
  } catch (error) { state.maintenance = { ...state.maintenance, error: error.message }; }
  return state.maintenance;
}

async function refreshStatistics() {
  await Promise.all([
    refreshStatisticsSource(), refreshMaintenance(), refreshCyclones(),
    repository.refresh().then(() => reloadLocalState())
  ]);
}

async function refreshStatisticsSource() {
  try {
    const query = new URLSearchParams({ year: String(state.statisticsYear), month: state.statisticsMonth });
    const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/statistics?${query}`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(30_000) });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload?.ok) throw new Error(payload?.message || "Не удалось загрузить рабочие источники статистики");
    state.statistics = { ...payload, source: "production-report", error: null };
  } catch (error) {
    state.statistics = { ...state.statistics, error: error.message };
  }
  return state.statistics;
}

async function refreshProduction() {
  if (!productionRefreshPromise) {
    productionRefreshPromise = productionService.refresh()
      .then(snapshot => {
        state.production = snapshot;
        return snapshot;
      })
      .finally(() => { productionRefreshPromise = null; });
  }
  return productionRefreshPromise;
}

async function refreshFromSource({ silent = false } = {}) {
  if (!navigator.onLine) {
    if (!silent) toast("Нет интернета. Показаны последние сохранённые данные.", "warning");
    return;
  }
  if (refreshFromSourcePromise) {
    if (!silent) toast("Обновление уже выполняется. Можно продолжать работу.", "warning");
    return refreshFromSourcePromise;
  }
  state.refreshing = true;
  render();
  refreshFromSourcePromise = refreshCurrentPage()
    .then(() => {
      state.lastRefresh = new Date().toISOString();
      if (!silent) toast("Текущий раздел обновлён.", "success");
    })
    .catch(error => {
      if (!silent) toast(error.message || "Не удалось обновить текущий раздел.", "warning");
    })
    .finally(() => {
      state.refreshing = false;
      refreshFromSourcePromise = null;
      render();
    });
  return refreshFromSourcePromise;
}

async function refreshMaintenanceDue() {
  try {
    let payload = null;
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/maintenance-due`, {
          headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12_000)
        });
        payload = await response.json().catch(() => null);
        if (!response.ok || !Array.isArray(payload?.records)) throw new Error(payload?.message || "Не удалось загрузить сводку ТО");
        lastError = null;
        break;
      } catch (error) {
        lastError = error;
        const message = String(error?.message || "").toLowerCase();
        if (!/quota|rate limit|429|слишком много/.test(message) || attempt === 2) break;
        await new Promise(resolve => setTimeout(resolve, (attempt + 1) * 2_000));
      }
    }
    if (lastError || !Array.isArray(payload?.records)) throw lastError || new Error("Не удалось загрузить сводку ТО");
    state.maintenanceDue = { records: payload.records, source: "google", cachedAt: new Date().toISOString(), error: null };
    await store.setPreference("maintenanceDueCache", state.maintenanceDue);
  } catch (error) {
    const cached = await store.preference("maintenanceDueCache", state.maintenanceDue);
    const hasVerifiedSnapshot = Array.isArray(cached?.records) && cached.records.length > 0;
    state.maintenanceDue = hasVerifiedSnapshot
      ? { ...cached, source: "cache", error: null }
      : { ...cached, error: error.message || "Не удалось загрузить сводку ТО" };
  }
  return state.maintenanceDue;
}

function startupSyncErrorMessage(error) {
  const message = String(error?.message || "Не удалось получить ответ от Google").replace(/\s+/g, " ").trim();
  return message.length > 150 ? `${message.slice(0, 147)}…` : message;
}

function scheduleStartupSyncRetry() {
  clearTimeout(startupSyncRetryTimer);
  if (!navigator.onLine || !state.account || !state.startupSync.failed.length || startupSyncRetryCount >= 3) return;
  const delay = [20_000, 60_000, 180_000][startupSyncRetryCount] ?? 180_000;
  startupSyncRetryCount += 1;
  startupSyncRetryTimer = window.setTimeout(() => {
    if (navigator.onLine && state.account && state.page === "dashboard" && !isEditingField()) {
      void startStartupJournalSync();
    }
  }, delay);
}

async function startStartupJournalSync() {
  if (startupSyncPromise) return startupSyncPromise;
  const tasks = [
    ["Табель и персонал", async () => { state.workforce = workforceRepository ? await workforceRepository.refresh() : await workforceService.snapshot(); }],
    ["Контроль весов", async () => { await repository.refresh(); await reloadLocalState(); }],
    ["Спецификации продуктов", async () => { await refreshSpecifications(); if (state.specifications.error) throw new Error(state.specifications.error); }],
    ["Учёт продукции и брака", async () => { await refreshProduction(); if (state.production.error) throw new Error(state.production.error); }],
    ["Расход упаковки", async () => { state.packaging = await packagingService.sync(); if (state.packaging.error) throw new Error(state.packaging.error); }],
    ["Ремонт и ТО", async () => { await refreshMaintenance(); if (state.maintenance.error) throw new Error(state.maintenance.error); }],
    ["Склад запчастей", async () => { await refreshPartsWarehouse(); if (state.partsWarehouse.error) throw new Error(state.partsWarehouse.error); }],
    ["Сводка ТО", async () => { await refreshMaintenanceDue(); if (state.maintenanceDue.error) throw new Error(state.maintenanceDue.error); }],
    ["Очистка циклонов", async () => { await reconcileCycloneQueuePerformers(); await refreshCyclones(); if (state.cyclones.error) throw new Error(state.cyclones.error); }],
    ["Журнал инцидентов", async () => { await refreshIncidents(); if (state.incidents.error) throw new Error(state.incidents.error); }],
    ["Сменные задания", async () => { await refreshShiftTasks(); if (state.shiftTasks.error) throw new Error(state.shiftTasks.error); }]
  ];
  clearTimeout(startupSyncRetryTimer);
  state.startupSync = { active: true, completed: 0, total: tasks.length, current: tasks[0][0], failed: [], completedAt: null };
  render();
  startupSyncPromise = (async () => {
    for (const [label, load] of tasks) {
      state.startupSync.current = label;
      render();
      let lastError;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
          await load();
          lastError = null;
          break;
        } catch (error) {
          lastError = error;
          if (attempt === 0 && navigator.onLine) await new Promise(resolve => window.setTimeout(resolve, 1_500));
        }
      }
      if (lastError) state.startupSync.failed.push({ label, message: startupSyncErrorMessage(lastError) });
      state.startupSync.completed += 1;
    }
    state.startupSync.active = false;
    state.startupSync.current = "";
    state.startupSync.completedAt = new Date().toISOString();
    state.lastRefresh = state.startupSync.completedAt;
    if (state.account) state.shift = await shiftService.current();
    render();
    if (state.startupSync.failed.length) scheduleStartupSyncRetry();
    else startupSyncRetryCount = 0;
  })().finally(() => { startupSyncPromise = null; });
  return startupSyncPromise;
}

async function refreshCurrentPage() {
  if (state.page === "journals") {
    await repository.refresh();
    state.journalError = null;
    await reloadLocalState();
    return;
  }
  if (state.page === "attendance" || state.page === "personnel" || state.page === "vacations" || state.page === "settings") {
    state.workforce = workforceRepository ? await workforceRepository.refresh() : await workforceService.snapshot();
    if (state.account) state.shift = await shiftService.current();
    return;
  }
  if (state.page === "cyclones") { await refreshCyclones(); return; }
  if (state.page === "packaging") { await refreshPackaging(); return; }
  if (state.page === "packaging-warehouse") { await refreshPackagingWarehouse(); return; }
  if (state.page === "parts-warehouse") { await refreshPartsWarehouse(); return; }
  if (state.page === "ppe-warehouse") { await refreshPpeWarehouse(); return; }
  if (state.page === "nonconformities") { await refreshNonconformities(); return; }
  if (state.page === "incidents") { await refreshIncidents(); return; }
  if (state.page === "shift-tasks") { await refreshShiftTasks(); return; }
  if (state.page === "maintenance") { await refreshMaintenance(); return; }
  if (state.page === "production") { await refreshProduction(); return; }
  if (state.page === "statistics") { await refreshStatistics(); return; }
  if (state.page === "specifications") { await refreshSpecifications(); return; }
  await reloadLocalState();
}

async function checkForUpdate({ announce = false } = {}) {
  try {
    const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/update-status`, { headers: { Accept: "application/json" } });
    const result = await response.json();
    state.update.checked = true;
    state.update.available = response.ok && result.available === true;
    state.update.version = state.update.available ? result.version : null;
    state.update.message = state.update.available
      ? `Доступна версия ${result.version}`
      : String(result.message || "Новая версия не найдена");
    if (state.update.available && announce) toast(`Доступна версия ${result.version}. Нажмите «Обновить программу» в верхней панели.`, "warning");
    if (!state.update.available && announce) toast(state.update.message, "success");
    render();
  } catch {
    state.update.checked = true;
    state.update.available = false;
    state.update.message = "Не удалось проверить обновление";
    if (announce) toast(state.update.message, "warning");
    render();
  }
}

async function waitForInstalledUpdate(expectedVersion) {
  const deadline = Date.now() + 45_000;
  while (Date.now() < deadline) {
    await new Promise(resolve => window.setTimeout(resolve, 1_000));
    try {
      const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/health`, { cache: "no-store" });
      const health = await response.json();
      if (response.ok && health.ok && health.version === expectedVersion) {
        window.location.reload();
        return;
      }
    } catch {
      // The old gateway is expected to be briefly unavailable while it is replaced.
    }
  }
  state.update.installing = false;
  render();
  toast("Файлы обновления получены, но новая версия не запустилась. Перезапустите программу и сообщите, если версия не изменилась.", "warning");
}

async function syncRecords({ silent = false } = {}) {
  if (state.syncing) return;
  if (!navigator.onLine) {
    if (!silent) toast("Нет интернета. Записи останутся в очереди.", "warning");
    return;
  }
  state.syncing = true;
  state.syncTransfer = { active: true, source: "Контроль весов, табель и персонал, расход упаковки, очистка циклонов" };
  if (!(silent && isEditingField())) render();
  try {
    await reconcileCycloneQueuePerformers();
    const checks = await Promise.allSettled([repository.sync(), syncWorkforce(), packagingService?.sync(), cycloneService?.sync()]);
    const result = checks[0].status === "fulfilled" ? checks[0].value : { sent: 0, conflicts: 0 };
    if (checks[2]?.status === "fulfilled" && checks[2].value) state.packaging = checks[2].value;
    if (checks[3]?.status === "fulfilled" && checks[3].value) state.cyclones = checks[3].value;
    const rejected = checks.filter(item => item.status === "rejected");
    await reloadLocalState();
    state.lastRefresh = new Date().toISOString();
    const queued = queueEntries();
    const hasFailedWrites = Boolean(
      result.failed || rejected.length || state.packaging?.error || state.cyclones?.error || queued.some(entry => entry.error)
    );
    const outcome = { sent: result.sent || 0, conflicts: result.conflicts || 0, pending: queued.length, failed: hasFailedWrites };
    if (hasFailedWrites) await checkGoogleConnection({ announce: false });
    if (!(silent && isEditingField())) render();
    if (!silent) {
      if (hasFailedWrites) toast(`Не удалось отправить ${queued.filter(entry => entry.error).length || "часть"} записей. Причина показана выше; очередь сохранена.`, "warning");
      else if (result.conflicts) toast(`Обнаружено конфликтов: ${result.conflicts}.`, "warning");
      else if (result.sent) toast(`Отправлено записей: ${result.sent}.`, "success");
      else if (queued.length) toast(`В очереди осталось записей: ${queued.length}.`, "warning");
      else toast("Очередь синхронизации пуста.", "success");
    }
    return outcome;
  } catch (error) {
    const outcome = { sent: 0, conflicts: 0, pending: queueEntries().length, failed: true };
    await checkGoogleConnection({ announce: false });
    if (!silent) toast(error.message || "Не удалось выполнить синхронизацию. Очередь сохранена.", "warning");
    return outcome;
  } finally {
    state.syncing = false;
    state.syncTransfer = { active: false, source: "" };
    if (!(silent && isEditingField())) render();
  }
}

async function checkGoogleConnection({ announce = true } = {}) {
  if (!navigator.onLine) {
    state.googleDiagnostics = { tone: "warning", message: "Нет интернета. Проверка Google будет доступна после восстановления сети." };
    render();
    return state.googleDiagnostics;
  }
  state.googleDiagnostics = { busy: true, tone: "neutral", message: "Проверяем доступ к Google и рабочим журналам…" };
  render();
  try {
    const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/google-status`, { headers: { Accept: "application/json" }, cache: "no-store" });
    const payload = await response.json().catch(() => ({}));
    state.googleDiagnostics = {
      tone: response.ok && payload.ready ? "success" : "warning",
      message: payload.message || "Не удалось проверить доступ к Google.",
      detail: payload.detail || ""
    };
    if (announce) toast(state.googleDiagnostics.message, state.googleDiagnostics.tone);
  } catch {
    state.googleDiagnostics = { tone: "warning", message: "Нет связи с локальным шлюзом Google. Очередь сохранена на этом компьютере." };
    if (announce) toast(state.googleDiagnostics.message, "warning");
  }
  render();
  return state.googleDiagnostics;
}

async function syncQueueSource(source) {
  if (!navigator.onLine) {
    toast("Нет интернета. Запись останется в очереди.", "warning");
    return;
  }
  if (source === "checks") {
    await syncRecords();
    return;
  }
  try {
    if (source === "workforce") state.workforce = await syncWorkforce();
    if (source === "packaging") state.packaging = await packagingService?.sync();
    if (source === "cyclones") state.cyclones = await cycloneService?.sync();
    await reloadLocalState();
    state.lastRefresh = new Date().toISOString();
    const remaining = queueEntries().filter(entry => entry.source === source);
    const failed = remaining.some(entry => entry.error)
      || (source === "packaging" && state.packaging?.error)
      || (source === "cyclones" && state.cyclones?.error);
    if (failed) {
      await checkGoogleConnection({ announce: false });
      render();
      toast("Журнал не отправлен в Google. Точная причина показана выше; очередь сохранена.", "warning");
      return;
    }
    render();
    toast(remaining.length ? `В очереди этого журнала осталось записей: ${remaining.length}.` : "Очередь выбранного журнала отправлена в Google.", remaining.length ? "warning" : "success");
  } catch (error) {
    await reloadLocalState();
    render();
    toast(error.message || "Не удалось отправить очередь.", "warning");
  }
}

function syncInBackground() {
  if (!navigator.onLine) return;
  // All forms have already committed their data to IndexedDB.  Do not keep a
  // completed form waiting on Google; one running sync is shared by later saves.
  void syncRecords({ silent: true });
}

function startAutomaticRefresh() {
  clearInterval(refreshTimer);
  refreshTimer = setInterval(async () => {
    if (!state.account || document.hidden || !navigator.onLine) return;
    try {
      await synchronizeMachineStatuses();
      await refreshShiftTasks();
      // Replacing the whole application while a native select is open returns
      // its option list to the top.  Keep the user's current picker intact.
      if (!isEditingField()) render();
    } catch {}
    syncInBackground();
  }, APP_CONFIG.refreshIntervalMs);
}

function isEditingField() {
  return document.activeElement instanceof HTMLElement
    && document.activeElement.matches("input, select, textarea, [contenteditable='true']");
}

function setBusy(value) {
  state.loading = value;
  document.body.classList.toggle("is-busy", value);
}

function render() {
  const navigationScrollTop = root.querySelector(".main-nav")?.scrollTop ?? 0;
  document.documentElement.dataset.theme = state.theme;
  document.documentElement.lang = state.language;
  document.title = state.account
    ? `${pageTitle()} — ${APP_CONFIG.name}`
    : APP_CONFIG.name;
  root.innerHTML = state.account ? renderApplication() : renderLogin();
  localizeElement(root, state.language);
  const navigation = root.querySelector(".main-nav");
  if (navigation) navigation.scrollTop = navigationScrollTop;
}

function openAttendanceForCurrentMonth() {
  state.attendanceMonth = today().slice(0, 7);
  render();
  requestAnimationFrame(revealTodayInAttendanceTables);
}

function revealTodayInAttendanceTables() {
  root.querySelectorAll(".attendance-scroll").forEach(scroller => {
    const todayCell = scroller.querySelector(".attendance-table .today");
    if (!(todayCell instanceof HTMLElement)) return;
    const cellRect = todayCell.getBoundingClientRect();
    const scrollRect = scroller.getBoundingClientRect();
    const offset = cellRect.left - scrollRect.left - Math.max(18, (scroller.clientWidth - todayCell.offsetWidth) / 2);
    scroller.scrollLeft = Math.max(0, scroller.scrollLeft + offset);
  });
}

function renderLogin() {
  const accounts = authService.availableAccounts();
  return `
    <main class="login-shell">
      <section class="login-brand" aria-labelledby="login-title">
        <div class="brand-emblem large" aria-hidden="true">${brandIcon()}</div>
        <p class="eyebrow">Электронные журналы производства</p>
        <h1 id="login-title">Packaging-<br>Filling-Hub</h1>
        <p class="login-lead">Заполняйте журналы быстро, продолжайте работу без интернета и не переносите данные вручную.</p>
        <ul class="feature-list">
          <li><span>✓</span> Google Sheets остаётся главным источником</li>
          <li><span>✓</span> Автоматическая отправка при появлении сети</li>
          <li><span>✓</span> Автор каждой записи сохраняется</li>
        </ul>
      </section>
      <section class="login-panel" aria-label="Выбор учётной записи">
        <div class="panel-heading">
          <h2>Кто работает?</h2>
          <p>${APP_CONFIG.centralAuth ? "Выберите рабочую учётную запись. Права определяются центральным сервером." : APP_CONFIG.workstationRole ? "Вход разрешён только для роли, назначенной этому компьютеру." : "Выберите рабочую учётную запись."}</p>
        </div>
        <div class="account-list">
          ${accounts.map(account => `
            <form class="account-card" data-form="login">
              <input type="hidden" name="accountId" value="${account.id}">
              <span class="account-icon">${account.role === "manager" ? "А" : "СМ"}</span>
              <span class="account-copy">
                <strong>${account.title}</strong>
                <small>${account.description}</small>
                <label class="login-password"><span>Пароль</span><input name="password" type="password" inputmode="numeric" minlength="4" required autocomplete="current-password" placeholder="Введите пароль"></label>
                <small class="login-error" data-login-error hidden></small>
              </span>
              <button class="account-login-button" type="submit">Войти</button>
            </form>
          `).join("")}
        </div>
        <p class="privacy-note">${APP_CONFIG.centralAuth ? "Пароли хранятся только на центральном сервере. Администрация меняет их в «Настройках»." : "Первый пароль для каждой учётной записи: <b>0000</b>. Администрация меняет пароли в «Настройках"} ${APP_CONFIG.integration.mode === "demo" ? "Рабочие данные этого прототипа хранятся только в браузере и не отправляются в Google." : "Данные синхронизируются через защищённый шлюз участка."}</p>
      </section>
    </main>`;
}

function renderApplication() {
  const language = LANGUAGES.find(item => item.code === state.language) ?? LANGUAGES[0];
  return `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand-row">
          <div class="brand-emblem">${brandIcon()}</div>
          <div><strong>Packaging-</strong><strong>Filling-Hub</strong><small class="company-name">UAB Kordula</small></div>
        </div>
        <nav class="main-nav" aria-label="Основное меню">
          ${modulesForAccount().map(module => navItem(module.id, moduleLabel(module), moduleIcon(module.icon), sidebarNotificationCount(module.id))).join("")}
        </nav>
        <div class="sidebar-footer">
          <div class="signed-user">
            <span class="avatar">${state.account.role === "manager" ? "А" : "СМ"}</span>
            <span><strong>${state.account.title}</strong><small>${escapeHtml(accountWorkstationLabel(state.account))}</small><small class="app-version">Версия ${escapeHtml(APP_CONFIG.version)}</small></span>
          </div>
          <button class="text-button" data-action="logout">${ui("logout")}</button>
        </div>
      </aside>
      <main class="workspace">
        <header class="topbar">
          <div class="topbar-title"><p class="eyebrow">${APP_CONFIG.name}</p><h1>${pageTitle()}</h1></div>
          <div class="topbar-actions">
            <time class="clock-panel" data-clock datetime=""><span data-clock-date>${headerDate()}</span><strong data-clock-time>${headerTime()}</strong></time>
            <button class="utility-button language-button" data-action="cycle-language" title="${ui("language")}" aria-label="${ui("language")}"><b>${language.label}</b><span>${language.name}</span></button>
            <button class="icon-button theme-button" data-action="toggle-theme" title="${ui("theme")}" aria-label="${ui("theme")}">${state.theme === "dark" ? sunIcon() : moonIcon()}</button>
            ${connectionBadge()}
            <button class="utility-button ${state.update.available ? "update-available" : ""}" data-action="install-update" title="${escapeHtml(state.update.message || "Скачать и установить опубликованную версию программы")}" ${state.update.installing ? "disabled" : ""}>${state.update.installing ? "Обновляем…" : state.update.available ? `Обновить ${escapeHtml(state.update.version)}` : "Обновить программу"}</button>
            <button class="icon-button" data-action="refresh-and-reload" title="Обновить данные и экран (как F5)" aria-label="Обновить данные и экран" ${(state.refreshing || state.startupSync.active) ? "disabled" : ""}>${(state.refreshing || state.startupSync.active) ? "…" : refreshIcon()}</button>
          </div>
        </header>

        ${renderPreparationReminder()}
        <section class="page-content">
          ${renderWorkforceConnection()}
          ${state.journalError ? `<p class="form-error" role="status">Контроль весов: ${escapeHtml(state.journalError)}. Показаны сохранённые на этом компьютере записи.</p>` : ""}
          ${renderPage()}
        </section>
      </main>
      ${renderMobileNav()}
    </div>
    <div id="toast-region" class="toast-region" aria-live="assertive"></div>`;
}

function renderWorkforceConnection() {
  if (!workforceRepository) return "";
  const pending = state.workforce?.pending ?? [];
  const conflicts = pending.filter(item => item.status === "conflict" || item.status === "error");
  if (!pending.length && !state.workforce?.syncError) return "";
  const message = state.workforce?.syncError
    ? `Журналы персонала: ${state.workforce.syncError}`
    : conflicts.length
      ? `Журналы персонала: ${conflicts.length} измен. требуют внимания.`
      : `Журналы персонала: ожидают отправки ${pending.length} измен.`;
  return `<div class="workforce-connection ${conflicts.length || state.workforce?.syncError ? "warning" : ""}"><span>${conflicts.length || state.workforce?.syncError ? "!" : "↥"}</span><p>${escapeHtml(message)}</p>${conflicts.length ? `<button class="small-button" data-action="navigate" data-page="sync">Открыть синхронизацию</button>` : ""}</div>`;
}

function renderPage() {
  if (state.page === "journals") return renderJournalsPage();
  if (state.page === "attendance") return renderAttendancePage();
  if (state.page === "personnel") return renderPersonnelPage();
  if (state.page === "sync") return renderSyncPage();
  if (state.page === "vacations") return renderVacationsPage();
  if (state.page === "specifications") return renderSpecificationsPage();
  if (state.page === "statistics" && ["manager", "senior"].includes(state.account.role)) return renderStatisticsPage();
  if (state.page === "settings" && state.account.role === "manager") return renderSettingsPage();
  if (state.page === "cyclones") return renderCyclonesPage();
  if (state.page === "packaging") return renderPackagingPage();
  if (state.page === "packaging-warehouse") return renderPackagingWarehousePage();
  if (state.page === "parts-warehouse") return renderPartsWarehousePage();
  if (state.page === "ppe-warehouse") return renderPpeWarehousePage();
  if (state.page === "nonconformities") return renderNonconformitiesPage();
  if (state.page === "incidents") return renderIncidentsPage();
  if (state.page === "shift-tasks") return renderShiftTasksPage();
  if (state.page === "maintenance") return renderMaintenancePage();
  if (state.page === "production") return renderProductionPage();
  if (state.page !== "dashboard" && MODULES.some(module => module.id === state.page)) return renderPlannedModulePage();
  return renderDashboard();
}

function renderMaintenancePage() {
  const service = state.maintenance.service ?? { records: [], statistics: {} };
  const repair = state.maintenance.repair ?? { records: [], statistics: {} };
  const view = state.maintenanceView;
  const tabs = [["repair", "Журнал ремонта"], ["service", "Журнал ТО"], ["statistics", "Статистика"]];
  const content = view === "service"
    ? renderMaintenanceTable("Журнал ТО", service.records, "ТО", false, true)
    : view === "statistics"
      ? renderMaintenanceStatistics(service, repair)
      : renderMaintenanceTable("Журнал ремонта", repair.records, "Ремонт", false, true);
  return `<section class="section-heading maintenance-page-heading"><div><p class="eyebrow">Ремонт и ТО</p><h2>Станки</h2></div><button class="secondary-button" data-action="refresh-maintenance">Обновить</button></section>
    ${state.maintenance.error ? `<p class="form-error">${escapeHtml(state.maintenance.error)}</p>` : ""}
    ${renderMachineStatusPanel({ interactive: true })}
    <nav class="settings-tabs card maintenance-tabs" aria-label="Разделы журналов">${tabs.map(([key, label]) => `<button class="${view === key ? "active" : ""}" data-action="maintenance-view" data-view="${key}"><strong>${label}</strong></button>`).join("")}</nav>
    ${content}`;
}

function renderProductionPage() {
  const all = state.production.records ?? [];
  const records = all.filter(record => record.date === today()).sort((left, right) =>
    String(left.line).localeCompare(String(right.line), "ru") || String(left.time).localeCompare(String(right.time)) || String(left.product).localeCompare(String(right.product), "ru"));
  const recordPlans = calculateRecordPlansByLine(records, state.specifications.specifications ?? []);
  const totalQuantity = records.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const totalFinishedMassKg = records.reduce((sum, item) => sum + productionRecordMassKg(item), 0);
  const totalScrap = records.reduce((sum, item) => sum + Number(item.scrapKg || 0), 0);
  const totalCanScrap = records.reduce((sum, item) => sum + Number(item.canScrapKg || 0), 0);
  const canAdd = state.account?.role === "manager" || state.account?.role === "senior";
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · единый журнал</p><h2>Учёт продукции и брака</h2><p>Каждый упаковщик вносит свой выпуск отдельно. Итоги линии и машины программа складывает без двойного учёта.</p></div><div class="header-actions"><button class="secondary-button" data-action="refresh-production" ${state.productionLoading ? "disabled" : ""}>${state.productionLoading ? "Обновляем…" : "Обновить"}</button>${canAdd ? `<button class="primary-button" data-action="add-production" ${state.productionLoading ? "disabled" : ""}>+ Внести мой выпуск</button>` : ""}</div></section>
    ${state.productionLoading ? '<p class="module-note" role="status">Получаем данные из Google Sheets. Это может занять до 30 секунд.</p>' : ""}
    ${state.production.error ? `<p class="form-error">${escapeHtml(state.production.error)}</p>` : ""}
    <div class="dashboard-grid production-metrics"><article class="metric-card"><span>Готовая продукция</span><strong>${formatNumber(totalQuantity)} <small>шт.</small></strong><small>${formatNumber(totalFinishedMassKg)} кг смеси за сегодня · ${formatBoxes(totalQuantity / 240)} кор.</small></article><article class="metric-card"><span>Брак продукции</span><strong>${formatNumber(totalScrap)}</strong><small>кг за сегодня</small></article><article class="metric-card"><span>Брак банок</span><strong>${formatNumber(totalCanScrap)}</strong><small>кг за сегодня</small></article></div>
    <section class="card table-card"><div class="table-toolbar"><strong>Сегодня · ${formatDate(today())}</strong><span>${records.length} ${plural(records.length, "запись", "записи", "записей")} · 240 шт. = 1 кор.</span></div><div class="table-scroll"><table class="production-records-table"><thead><tr><th class="col-line">Линия</th><th class="col-time">Начало</th><th class="col-time">Окончание</th><th class="col-catalog">Линейка<br>продукта</th><th class="col-product">Продукт</th><th class="col-number">Крепость,<br>mg/g</th><th class="col-number">Готово,<br>шт.</th><th class="col-number">Коробки<br><small>240 шт.</small></th><th class="col-number">План,<br><small>кор.</small></th><th class="col-efficiency">Эфф.,<br>% продукта</th><th class="col-number">Брак прод.,<br>кг</th><th class="col-number">%<br>брака</th><th class="col-number">Брак банок,<br>кг</th><th class="col-person">Упаковщик</th><th class="col-operator">Механики<br>у линии</th><th class="col-person">Старший<br>механик</th><th class="col-person">Механик</th><th class="col-note">Примечание</th>${canAdd ? "<th></th>" : ""}</tr></thead><tbody>${records.length ? records.map(record => `${(() => { const plannedBoxes = recordPlans.get(record); const efficiency = plannedBoxes > 0 ? Number(record.quantity || 0) / 240 / plannedBoxes : null; const indicator = shiftEfficiencyIndicator(efficiency); const label = efficiency === null || efficiency === undefined ? "—" : `${new Intl.NumberFormat(localeCode(), { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(efficiency * 100)}%`; return `<tr><td class="col-line"><strong>${escapeHtml(record.line)}</strong></td><td class="col-time">${escapeHtml(record.startTime || "—")}</td><td class="col-time">${escapeHtml(record.time || "—")}</td><td class="col-catalog">${escapeHtml(record.catalogLine || "—")}</td><td class="col-product">${escapeHtml(record.product)}</td><td class="col-number">${formatNumber(record.strength)}</td><td class="col-number">${formatNumber(record.quantity)}</td><td class="col-number">${formatBoxes(record.quantity / 240)}</td><td class="col-number">${plannedBoxes === undefined ? "—" : formatBoxes(plannedBoxes)}</td><td class="col-efficiency"><strong class="production-line-efficiency" style="--efficiency-color: ${attribute(indicator.color)}">${label}</strong></td><td class="col-number">${formatNumber(record.scrapKg)}</td><td class="col-number production-scrap-percent">${record.scrapPercent === null ? "—" : scrapPercentLabel(record.scrapPercent * 100)}</td><td class="col-number">${formatNumber(record.canScrapKg)}</td><td class="col-person">${escapeHtml(record.packer)}</td><td class="col-operator">${escapeHtml(record.operator)}${hasProductionSecondMechanicInterval(record) ? `<br><small>2-й: ${escapeHtml(record.operatorSecondStartTime)}–${escapeHtml(record.operatorSecondEndTime)}</small>` : ""}</td><td class="col-person">${escapeHtml(record.seniorMechanic || "—")}</td><td class="col-person">${escapeHtml(record.mechanic || "—")}</td><td class="col-note">${escapeHtml(record.note || "—")}</td>${canAdd ? `<td><div class="row-actions"><button class="small-button" data-action="edit-production" data-id="${attribute(record.id)}">Исправить</button><button class="more-button" data-action="delete-production" data-id="${attribute(record.id)}" title="Удалить">×</button></div></td>` : ""}</tr>`; })()}`).join("") : `<tr><td colspan="${canAdd ? 19 : 18}">За сегодня записей пока нет.</td></tr>`}</tbody></table></div></section>
    ${renderProductionPeopleSummary(records)}`;
}

function productionLineEfficiencies(records) {
  const byLine = new Map();
  records.forEach(record => {
    const line = String(record.line || record.machineLine || "").trim().toUpperCase();
    if (!line) return;
    byLine.set(line, [...(byLine.get(line) || []), record]);
  });
  return new Map([...byLine].map(([line, lineRecords]) => [line, calculateShiftEfficiency(lineRecords, state.specifications.specifications ?? []).efficiency]));
}

function renderProductionPeopleSummary(records) {
  const packers = new Map();
  const operators = new Map();
  const personalPlans = productionPersonalPlans(records);
  const add = (bucket, name, record, fraction = 1) => {
    if (!name) return;
    const value = bucket.get(name) ?? { quantity: 0, scrapKg: 0, grossProductMassKg: 0, plannedBoxes: 0 };
    value.quantity += Number(record.quantity || 0) * fraction;
    value.scrapKg += Number(record.scrapKg || 0) * fraction;
    value.grossProductMassKg += productionRecordGrossMassKg(record) * fraction;
    value.plannedBoxes += Number(personalPlans.get(record) || 0) * fraction;
    bucket.set(name, value);
  };
  records.forEach(record => {
    add(packers, record.packer, record);
    productionLineCredits(record).forEach(({ name, fraction }) => add(operators, name, record, fraction));
  });
  const leaderEntries = productionLeaderEntries(records);
  const rows = (title, entries, suffix = "", efficiencyHeading = "") => entries.length ? `<article class="${efficiencyHeading ? "with-efficiency" : ""}"><h3>${title}</h3><table><thead><tr><th>Сотрудник</th><th>Выпуск,<br>шт.</th><th>Коробки<br><small>240 шт.</small></th>${efficiencyHeading ? `<th>${efficiencyHeading}</th>` : ""}<th>Брак продукции,<br>кг</th><th>%<br>брака</th></tr></thead><tbody>${entries.map(([name, values]) => { const scrapPercent = values.grossProductMassKg > 0 ? values.scrapKg / values.grossProductMassKg * 100 : null; const efficiency = values.plannedBoxes > 0 ? values.quantity / 240 / values.plannedBoxes : null; const indicator = shiftEfficiencyIndicator(efficiency); const efficiencyLabel = efficiency === null ? "—" : `${formatPercent(efficiency * 100)}%`; return `<tr><td>${escapeHtml(name)}${suffix}</td><td>${formatNumber(values.quantity)}</td><td>${formatBoxes(values.quantity / 240)}</td>${efficiencyHeading ? `<td><strong class="production-line-efficiency" style="--efficiency-color: ${attribute(indicator.color)}">${efficiencyLabel}</strong></td>` : ""}<td>${formatNumber(values.scrapKg)}</td><td class="production-scrap-percent">${scrapPercent === null ? "—" : scrapPercentLabel(scrapPercent)}</td></tr>`; }).join("")}</tbody></table></article>` : "";
  // Выпуск и брак продукции смены засчитываются руководителям, указанным
  // в самих записях. Это исключает привязку сегодняшней смены к старой смене.
  // Брак банок остаётся отдельным показателем журнала и сюда не включается.
  if (!packers.size && !operators.size && !leaderEntries.length) return "";
  return `<section class="card table-card production-people-summary"><div class="section-heading"><div><p class="eyebrow">Смена · персональные показатели</p><h2>Кому засчитывается выпуск</h2></div><span class="status-pill neutral">Итог линии не удваивается</span></div><div class="production-people-grid">${rows("Упаковщики", [...packers.entries()].sort((left, right) => left[0].localeCompare(right[0], "ru")), "", "Эфф.,<br>%")}${rows("Механики-операторы", [...operators.entries()].sort((left, right) => left[0].localeCompare(right[0], "ru")), "", "Эфф.,<br>%")}${rows("Старший механик и Механик", leaderEntries, " · сменный итог", "Эфф.<br>смены, %")}</div></section>`;
}

function productionPersonalPlans(records) {
  return calculateRecordPlansByLine(records, state.specifications.specifications ?? []);
}

function productionLeaderEntries(records) {
  const byShift = new Map();
  records.forEach(record => {
    const shift = String(record.shift || "").trim().toUpperCase();
    const group = byShift.get(shift) ?? { quantity: 0, scrapKg: 0, grossProductMassKg: 0, records: [], names: new Set() };
    group.quantity += Number(record.quantity || 0);
    group.scrapKg += Number(record.scrapKg || 0);
    group.grossProductMassKg += productionRecordGrossMassKg(record);
    group.records.push(record);
    [record.seniorMechanic, record.mechanic]
      .map(value => String(value || "").trim())
      .filter(Boolean)
      .forEach(name => group.names.add(name));
    byShift.set(shift, group);
  });

  const leaders = new Map();
  byShift.forEach((group, shiftCode) => {
    // Old rows may have no leader columns yet. Use a current shift only when
    // it has the same code as the production records; never use yesterday's shift.
    if (!group.names.size && isCurrentSharedShift() && productionShiftCode() === shiftCode) {
      [state.shift.seniorMechanic || state.shift.supervisor, state.shift.mechanic]
        .map(value => String(value || "").trim())
        .filter(Boolean)
        .forEach(name => group.names.add(name));
    }
    const shiftPlan = calculateShiftEfficiency(group.records, state.specifications.specifications ?? []).plannedBoxes;
    group.names.forEach(name => {
      const values = leaders.get(name) ?? { quantity: 0, scrapKg: 0, grossProductMassKg: 0, plannedBoxes: 0 };
      values.quantity += group.quantity;
      values.scrapKg += group.scrapKg;
      values.grossProductMassKg += group.grossProductMassKg;
      values.plannedBoxes += Number(shiftPlan || 0);
      leaders.set(name, values);
    });
  });
  return [...leaders.entries()].sort((left, right) => left[0].localeCompare(right[0], "ru"));
}

function renderMaintenanceTable(title, records, type, compact, canAdd = false) {
  const visible = compact ? records.slice(0, 10) : records;
  const empty = '<tr><td colspan="6">Записей пока нет.</td></tr>';
  const action = type === "ТО" ? "add-maintenance-service" : "add-maintenance-repair";
  const add = canAdd ? `<button class="primary-button" data-action="${action}">+ Добавить ${type === "ТО" ? "ТО" : "ремонт"}</button>` : "";
  const label = compact ? `Последние ${Math.min(10, records.length)} из ${records.length} записей` : `${records.length} записей`;
  return `<section class="card table-card"><div class="section-heading"><div><p class="eyebrow">${escapeHtml(type)}</p><h2>${title}</h2></div><div class="header-actions">${add}<span class="status-pill neutral">${label}</span></div></div><div class="table-scroll"><table><thead><tr><th>Дата</th><th>Станок</th><th>Категория</th><th>Вид работ</th><th>Исполнитель</th><th>Примечание</th></tr></thead><tbody>${visible.length ? visible.map(item => `<tr><td>${formatDate(item.date)}</td><td>${item.machine}</td><td>${escapeHtml(item.category || type)}</td><td>${escapeHtml(item.work)}</td><td>${escapeHtml(item.performer || "—")}</td><td>${escapeHtml(item.note || "—")}</td></tr>`).join("") : empty}</tbody></table></div></section>`;
}

function renderMaintenanceStatistics(service, repair) {
  const byMachine = new Map();
  const byPerformer = new Map();
  const collect = (records, kind) => records.forEach(record => {
    const machine = String(record.machine || "—");
    const machineItem = byMachine.get(machine) || { service: 0, repair: 0 };
    machineItem[kind] += 1;
    byMachine.set(machine, machineItem);
    if (record.performer) {
      const performerItem = byPerformer.get(record.performer) || { service: 0, repair: 0 };
      performerItem[kind] += 1;
      byPerformer.set(record.performer, performerItem);
    }
  });
  collect(service.records, "service");
  collect(repair.records, "repair");
  const machineRows = [...byMachine.entries()].sort((a, b) => Number(a[0]) - Number(b[0]));
  const performerRows = [...byPerformer.entries()].sort((a, b) => (b[1].service + b[1].repair) - (a[1].service + a[1].repair));
  const makeRows = (items, label) => items.length ? items.map(([name, item]) => `<tr><td>${escapeHtml(name)}</td><td>${item.service}</td><td>${item.repair}</td><td><strong>${item.service + item.repair}</strong></td></tr>`).join("") : `<tr><td colspan="4">${label}</td></tr>`;
  return `<div class="dashboard-grid maintenance-statistics"><section class="card table-card"><div class="section-heading"><div><p class="eyebrow">По оборудованию</p><h2>Записи по станкам</h2></div></div><div class="table-scroll"><table><thead><tr><th>Станок</th><th>ТО</th><th>Ремонт</th><th>Всего</th></tr></thead><tbody>${makeRows(machineRows, "Записей по станкам пока нет.")}</tbody></table></div></section><section class="card table-card"><div class="section-heading"><div><p class="eyebrow">По персоналу</p><h2>Исполнители</h2></div></div><div class="table-scroll"><table><thead><tr><th>Исполнитель</th><th>ТО</th><th>Ремонт</th><th>Всего</th></tr></thead><tbody>${makeRows(performerRows, "Исполнители пока не указаны.")}</tbody></table></div></section></div>`;
}

function renderPlannedModulePage() {
  const module = MODULES.find(item => item.id === state.page);
  const title = moduleLabel(module);
  return `<section class="card placeholder-hero">
    <span class="placeholder-icon">${moduleIcon(module?.icon)}</span>
    <div><p class="eyebrow">Рабочий раздел</p><h2>${escapeHtml(title)}</h2><p>Раздел уже добавлен в программу. Дальше заполним его журналом, полями и статистикой по вашему рабочему порядку.</p></div>
  </section>`;
}

function renderDashboard() {
  const productionRecords = (state.production.records ?? []).filter(record => record.date === today());
  const totalQuantity = productionRecords.reduce((sum, record) => sum + Number(record.quantity || 0), 0);
  const productScrap = productionRecords.reduce((sum, record) => sum + Number(record.scrapKg || 0), 0);
  const boxes = totalQuantity / 240;
  // Keep the same denominator that was saved with each record.  A later
  // specification edit must not change a historical defect percentage.
  const grossProductMassKg = productionRecords.reduce((sum, record) => sum + productionRecordGrossMassKg(record), 0);
  const scrapPercent = grossProductMassKg > 0 ? productScrap / grossProductMassKg * 100 : null;
  const efficiency = calculateShiftEfficiency(productionRecords, state.specifications.specifications ?? []);
  const efficiencyIndicator = shiftEfficiencyIndicator(efficiency.efficiency);
  const shiftPersonnel = presentShiftPersonnel();
  const packers = shiftPersonnel.filter(employee => employee.role === "packer");
  const operators = shiftPersonnel.filter(employee => employee.role === "mechanic-operator");
  const service = state.maintenance.service ?? { records: [], statistics: {} };
  const repair = state.maintenance.repair ?? { records: [], statistics: {} };
  const newest = records => [...records].sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
  const latestRepair = newest(repair.records).slice(0, 10);
  const latestService = newest(service.records).slice(0, 5);
  return `
    ${["manager", "senior"].includes(state.account.role) ? renderBirthdayReminders() : ""}
    ${renderDataTransferStatus()}
    ${renderJournalReadiness()}
    ${state.account.role === "senior" ? renderShiftPanel() : ""}
    ${state.account.role === "senior" ? renderWorkflowPanel() : ""}
    <div class="dashboard-summary-grid">
      <article class="card dashboard-summary-card production-summary">
        <p class="eyebrow">Сегодня · ${formatDate(today())}</p>
        <h2>Готовая продукция</h2>
        <strong>${formatNumber(totalQuantity)} <small>шт.</small> / ${formatBoxes(boxes)} <small>кор.</small></strong>
        <p>${productionRecords.length} ${plural(productionRecords.length, "запись", "записи", "записей")} завершено · 240 шт. в коробке</p>
      </article>
      <article class="card dashboard-summary-card scrap-summary">
        <p class="eyebrow">Сегодня · ${formatDate(today())}</p>
        <h2>Брак продукции</h2>
        <strong>${formatNumber(productScrap)} <small>кг</small> / ${scrapPercent === null ? "—" : scrapPercentLabel(scrapPercent)}</strong>
        <p>${grossProductMassKg ? `Расчёт от ${formatNumber(grossProductMassKg)} кг изготовленной продукции` : "Процент появится после записи готовой продукции"}</p>
      </article>
      <article class="card dashboard-summary-card efficiency-summary efficiency-${attribute(efficiencyIndicator.id)}" style="--efficiency-color: ${attribute(efficiencyIndicator.color)}">
        <p class="eyebrow">Сегодня · ${formatDate(today())}</p>
        <h2>Эффективность смены</h2>
        <strong class="efficiency-value">${efficiency.efficiency === null ? efficiencyIndicator.label : `${new Intl.NumberFormat(localeCode(), { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(efficiency.efficiency * 100)}%`}</strong>
        ${efficiencyIndicator.assessment ? `<span class="efficiency-rating">${escapeHtml(efficiencyIndicator.assessment)}</span>` : ""}
        <p>План выпуска: ${formatBoxes(efficiency.plannedBoxes)} кор. · Факт: ${formatBoxes(efficiency.actualBoxes)} кор.</p>
      </article>
      <article class="card dashboard-summary-card shift-summary">
        <p class="eyebrow">Состав текущей смены</p>
        <h2>Состав смены</h2>
        <div class="shift-summary-counts" aria-label="Упаковщиков: ${packers.length}. Механиков: ${operators.length}.">
          <div><span>Упаковщиков</span><strong>${packers.length}</strong></div>
          <div><span>Механиков</span><strong>${operators.length}</strong></div>
        </div>
        <p>${shiftPersonnel.length ? "Учтены отмеченные в табеле сотрудники" : "Состав появится после отметки табеля"}</p>
      </article>
    </div>
    ${renderMachineStatusPanel({ compact: true })}
    <div class="dashboard-maintenance-grid">
      <section class="card dashboard-maintenance-card">
        <div class="section-heading"><div><p class="eyebrow">Журнал ремонта</p><h2>Последние записи ремонта</h2></div><button class="secondary-button" data-action="navigate" data-page="maintenance">Открыть журнал</button></div>
        ${renderDashboardMaintenanceList(latestRepair, "Ремонт", 10)}
      </section>
      <section class="card dashboard-maintenance-card maintenance-overview-card">
        <div class="section-heading"><div><p class="eyebrow">Таблица ТО · выпуск</p><h2>Остаток до ТО</h2></div><button class="secondary-button" data-action="navigate" data-page="maintenance">Журнал ТО</button></div>
        ${renderMaintenanceDueList(state.maintenanceDue)}
      </section>
    </div>
    <section class="card dashboard-maintenance-card dashboard-service-card">
      <div class="section-heading"><div><p class="eyebrow">Журнал ТО</p><h2>Последние записи ТО</h2></div><span class="status-pill neutral">5 последних</span></div>
      ${renderDashboardMaintenanceList(latestService, "ТО", 5)}
    </section>`;
}

function renderDataTransferStatus() {
  const transfer = state.syncTransfer;
  if (!transfer?.active) return "";
  return `<section class="workforce-connection data-transfer-status" role="status"><span>↥</span><p><strong>Отправляем: ${escapeHtml(transfer.source)}</strong><br><small>Куда: защищённый шлюз → Google Таблицы. Не закрывайте программу до завершения отправки.</small></p></section>`;
}

function renderDashboardMaintenanceList(records, kind, limit) {
  if (!records.length) return `<p class="dashboard-empty">В журнале ${kind} записей пока нет.</p>`;
  return `<div class="dashboard-maintenance-list">${records.slice(0, limit).map(record => `<article><time>${formatDate(record.date)}</time><div><strong>${escapeHtml(record.machine ? `Станок ${record.machine}` : kind)}${record.work ? ` · ${escapeHtml(record.work)}` : ""}</strong><small>${escapeHtml(record.performer || record.category || "Исполнитель не указан")}</small></div>${record.note ? `<span title="${attribute(record.note)}">${escapeHtml(record.note)}</span>` : ""}</article>`).join("")}</div>`;
}

function productionRecordMassKg(record) {
  return productionFinishedMassKg(record, state.specifications.specifications);
}

function renderMaintenanceDueList(snapshot) {
  const records = snapshot?.records ?? [];
  if (!records.length) return `<p class="dashboard-empty">${snapshot?.error ? "Сводка ТО пока недоступна. Показаны данные журнала после следующей проверки." : "Сводка ТО загружается."}</p>`;
  const needsService = records.filter(record => /^(Просрочено|Требуется ТО)$/i.test(record.status));
  const className = record => /^(Просрочено|Требуется ТО)$/i.test(record.status) ? "danger" : record.status === "Скоро ТО" ? "warning" : "";
  return `${needsService.length ? `<p class="maintenance-due-alert"><strong>Требуется ТО:</strong> ${needsService.map(record => `${escapeHtml(record.line)} (${formatNumber(Math.abs(record.remainingBoxes))} кор. ${record.remainingBoxes < 0 ? "сверх интервала" : "осталось"})`).join(", ")}</p>` : ""}<div class="maintenance-due-list">${records.map(record => `<article class="${className(record)}"><strong>${escapeHtml(record.line)}</strong><span>${formatNumber(record.remainingBoxes)} кор.</span><small>${escapeHtml(record.status || "В пределах интервала")}</small></article>`).join("")}</div>`;
}

function renderJournalReadiness() {
  const sync = state.startupSync;
  if (sync.active) return `<section class="workforce-connection"><span>↻</span><p><strong>Подготавливаем журналы: ${sync.completed} из ${sync.total}</strong><br><small>Сейчас: ${escapeHtml(sync.current)}. Программой уже можно пользоваться.</small></p></section>`;
  if (sync.completedAt && !sync.failed.length) return `<section class="workforce-connection"><span>✓</span><p><strong>Все журналы синхронизированы. Программа готова к работе.</strong><br><small>Проверено: ${formatDateTime(sync.completedAt)}.</small></p><button class="small-button" data-action="sync-all-journals">Проверить снова</button></section>`;
  if (sync.completedAt) {
    const failed = sync.failed.map(item => typeof item === "string" ? { label: item, message: "Не удалось получить ответ от Google" } : item);
    return `<section class="workforce-connection warning"><span>!</span><p><strong>Обновлено журналов: ${sync.completed - failed.length} из ${sync.total}</strong><br><small>Не загружены: ${failed.map(item => `${escapeHtml(item.label)} — ${escapeHtml(item.message)}`).join("; ")}. Показаны последние сохранённые данные. Повторная проверка выполнится автоматически.</small></p><button class="small-button" data-action="sync-all-journals">Повторить сейчас</button></section>`;
  }
  return `<section class="workforce-connection"><span>↻</span><p>Журналы будут проверены после подключения к сети.</p><button class="small-button" data-action="sync-all-journals">Проверить</button></section>`;
}

function renderShiftPanel() {
  if (isCurrentSharedShift()) {
    return `
      <section class="shift-strip active">
        <div class="shift-state"><span class="pulse"></span><div><strong>Рабочая смена идёт</strong><small>Старший механик: ${escapeHtml(state.shift.seniorMechanic ?? state.shift.supervisor ?? state.shift.employee)}; механик: ${escapeHtml(state.shift.mechanic || "не выбран")}. ${formatDateTime(state.shift.startedAt)}</small></div></div>
      </section>`;
  }
  return `
    <section class="shift-strip">
      <div class="shift-state"><span class="shift-dot"></span><div><strong>Смена не начата</strong><small>Сначала отметьте присутствующих в табеле.</small></div></div>
      <button class="primary-button" data-action="start-shift">Перейти к табелю</button>
    </section>`;
}

function renderWorkflowPanel() {
  const attendanceReady = isCurrentSharedShift();
  const weightsRequired = state.shift?.requiresScaleControl !== false;
  const weightsReady = attendanceReady && (!weightsRequired || Boolean(state.shift?.weightsCompletedAt));
  return `<section class="workflow-card card">
    <div class="workflow-heading"><div><p class="eyebrow">Порядок начала работы</p><h2>Подготовка смены</h2></div><span class="status-pill ${weightsReady ? "success" : "warning"}">${weightsReady ? "Подготовка завершена" : "Есть напоминание"}</span></div>
    <div class="workflow-steps">
      ${workflowStep(1, "Табель", attendanceReady, "Отметить сотрудников", "attendance")}
      ${workflowStep(2, "Контроль весов", weightsReady, weightsRequired ? "Проверить F1–F13" : "Для второй смены не требуется", "journals")}
      ${workflowStep(3, "Рабочие разделы", true, weightsReady ? "Можно продолжать" : "Доступны без блокировки", "dashboard")}
    </div>
  </section>`;
}

function workflowStep(number, title, done, note, page) {
  return `<button class="workflow-step ${done ? "done" : ""}" data-action="navigate" data-page="${page}"><span>${done ? "✓" : number}</span><strong>${title}</strong><small>${note}</small></button>`;
}

function renderJournalsPage() {
  const todayRecords = state.records.filter(record => record.date === today() && record.status !== "Аннулировано");
  const checkedScales = new Set(todayRecords.map(record => record.scaleName));
  const failedToday = todayRecords.filter(record => record.result === "Вне допуска").length;
  const availableMonths = [...new Set([state.recordMonth, ...state.records.map(record => String(record.date || "").slice(0, 7)).filter(Boolean)])].sort().reverse();
  const visibleRecords = state.records.filter(record => String(record.date || "").startsWith(state.recordMonth));
  return `
    <section class="journal-header card">
      <div class="journal-title-block">
        <span class="journal-symbol large-symbol">13</span>
        <div><p class="eyebrow">Google Sheets · ${journal.sheetName}</p><h2>Быстрый контроль весов</h2><p>Введите показание и нажмите Enter — программа сразу перейдёт к следующим весам.</p></div>
      </div>
      <div class="journal-actions">
        <button class="secondary-button" data-action="refresh">${refreshIcon()} Обновить</button>
        <button class="secondary-button" data-action="new-record">Одна запись</button>
        <button class="primary-button" data-action="start-scale-walk">Начать обход 13 весов</button>
      </div>
    </section>
    <div class="metric-grid three scale-overview">
      ${metricCard("Проверено сегодня", `${checkedScales.size} из ${SCALES.length}`, "Уникальных весов", checkedScales.size === SCALES.length ? "success" : "neutral", true)}
      ${metricCard("В пределах допуска", todayRecords.length - failedToday, "Сегодня", "success")}
      ${metricCard("Вне допуска", failedToday, failedToday ? "Нужен комментарий" : "Отклонений нет", failedToday ? "danger" : "success")}
    </div>
    <section class="card table-card">
      <div class="table-toolbar">
        <div><strong>${visibleRecords.length}</strong> ${plural(visibleRecords.length, "запись", "записи", "записей")} за ${monthTitle(state.recordMonth)}</div>
        <label class="table-filter">Период<select data-record-month aria-label="Период журнала весов">${availableMonths.map(month => `<option value="${month}" ${month === state.recordMonth ? "selected" : ""}>${escapeHtml(monthTitle(month))}</option>`).join("")}</select></label>
        <div class="legend"><span class="legend-item"><i class="dot synced"></i>Отправлено</span><span class="legend-item"><i class="dot pending"></i>В очереди</span></div>
      </div>
      <div class="table-scroll">
        <table>
          <thead><tr><th>Дата</th><th>Весы</th><th>Факт</th><th>Отклонение</th><th>Результат</th><th>Исполнитель</th><th>Состояние записи</th><th></th></tr></thead>
          <tbody>${visibleRecords.length ? visibleRecords.map(renderRecordRow).join("") : renderEmptyRow()}</tbody>
        </table>
      </div>
    </section>`;
}

function renderAttendancePage() {
  const teamCounts = state.workforce.shiftTeams.map(team => ({ code: team.code, count: regularAreaPersonnel().filter(employee => employee.shiftTeamId === team.id).length }));
  return `
    <section class="workforce-hero card">
      <div><p class="eyebrow">Рабочее время и смены</p><h2>Табель участка</h2><p>График 2/2, фактические часы, причины отсутствия и начало смены — в одном разделе.</p></div>
      <div class="workforce-hero-stat"><div><strong>${teamCounts.find(team => team.code === "A")?.count ?? 0}</strong><span>в смене A</span></div><div><strong>${teamCounts.find(team => team.code === "B")?.count ?? 0}</strong><span>в смене B</span></div></div>
    </section>
    ${renderAttendanceTabs()}
    ${state.attendanceView === "schedule" ? renderScheduleView() : state.attendanceView === "timesheet" ? renderTimesheetView() : renderShiftStartView()}`;
}

function renderAttendanceTabs() {
  const tabs = [
    ["start", "Начало смены", "Кто сегодня работает"],
    ["schedule", "График смен", "Цикл 2/2 и часы"],
    ["timesheet", "Табель месяца", "Факт и отсутствие"]
  ];
  return `<nav class="workforce-tabs card" aria-label="Разделы табеля">${tabs.map(([view, label, note]) => `<button class="${state.attendanceView === view ? "active" : ""}" data-action="attendance-view" data-view="${view}"><strong>${label}</strong><small>${note}</small></button>`).join("")}</nav>`;
}

function renderShiftStartView() {
  const activeShift = isCurrentSharedShift() ? state.shift : null;
  const team = teamById(activeShift?.shiftTeamId ?? state.selectedShiftTeamId) ?? state.workforce.shiftTeams[0];
  const members = shiftStartMembers(team?.id);
  const savedAttendance = attendanceForShiftStart(team?.id, activeShift);
  const leadership = shiftLeadershipOptions(members, savedAttendance, activeShift);
  const presentCount = members.filter(employee => attendanceCode(savedAttendance.get(employee.id)) === "11").length;
  const scheduled = team ? getScheduleMonth(team, ...monthParts(today())).some(day => day.date === today() && day.scheduled) : false;
  return `
    ${renderCentralShiftWarning()}
    ${renderLegacyShiftWarning()}
    <section class="shift-day-banner ${scheduled ? "scheduled" : "substitution"}">
      <span>${scheduled ? "Сегодня" : "Вне графика"}</span>
      <div><strong>${escapeHtml(team?.name ?? "Смена")}${scheduled ? " работает по графику" : " может выйти на подмену"}</strong><small>Цикл 2 рабочих / 2 выходных · ${team?.shiftDurationHours ?? 12} ч на производстве · ${team?.accountingHours ?? 11} учётных часов</small></div>
      <b>${escapeHtml(team?.code ?? "—")}</b>
    </section>
    <form class="card shift-attendance-card" data-form="shift-attendance">
      <div class="shift-form-head">
        <div><p class="eyebrow">Шаг 1 · состав смены</p><h2>${activeShift ? "Исправить присутствие" : "Начать рабочую смену"}</h2><p>Выберите смену, отметьте присутствующих, затем назначьте старшего механика и механика.</p></div>
        <div class="attendance-counter"><strong data-attendance-present>${presentCount}</strong><span>из ${members.length}<small>на работе</small></span></div>
      </div>
      <div class="shift-start-controls">
        <label class="field"><span>Рабочая смена</span><select name="shiftTeamId" data-start-team ${activeShift ? "disabled" : ""}>${state.workforce.shiftTeams.map(item => `<option value="${item.id}" ${item.id === team?.id ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select></label>
        <label class="field"><span>Старший механик</span><select name="seniorMechanic" required>${leadership.senior}</select></label>
        <label class="field"><span>Механик (необязательно)</span><select name="mechanic">${leadership.mechanic}</select></label>
      </div>
      <div id="attendance-form-error" class="form-error" hidden></div>
      <div class="shift-attendance-list">
        ${members.map(employee => {
          const status = attendanceCode(savedAttendance.get(employee.id));
          const substitution = employee.isSubstitute ? `<small class="substitute-badge">Подмена · ${escapeHtml(employee.substitutionReason)}</small>` : "";
          const remove = employee.isSubstitute && !state.shift?.active ? `<button type="button" class="remove-shift-guest" data-action="remove-shift-guest" data-id="${attribute(employee.id)}" aria-label="Убрать ${attribute(employee.fullName)}">×</button>` : "";
          return `<label class="shift-person-row ${employee.isSubstitute ? "is-substitute" : ""}"><span class="employee-avatar">${initials(employee.fullName)}</span><span class="shift-person-name"><strong>${escapeHtml(employee.fullName)}</strong><small>${escapeHtml(roleLabel(employee.role))}</small>${substitution}</span><select class="attendance-status-select attendance-status-${attendanceTone(status)}" name="attendance-${employee.id}" data-attendance-status aria-label="Статус: ${attribute(employee.fullName)}">${attendanceStatusOptions(status)}</select>${remove}</label>`;
        }).join("")}
      </div>
      <div class="shift-guest-actions"><button type="button" class="secondary-button" data-action="add-shift-guest">+ Добавить сотрудника другой смены</button><small>Выберите причину: подработка или производственная необходимость.</small></div>
      <div class="shift-form-footer"><p>${activeShift ? "Исправления сохраняются в общей активной смене и не требуют нового запуска." : "После сохранения появится напоминание о весах, но другие разделы останутся доступны."}</p><button class="primary-button" type="submit">${activeShift ? "Сохранить исправления" : "Подтвердить состав и начать"}</button></div>
    </form>
    ${renderPersonnelDistribution(team, members, savedAttendance)}`;
}

function renderPersonnelDistribution(team, members, attendance) {
  const present = members.filter(employee => attendanceCode(attendance.get(employee.id)) === "11");
  const operators = present.filter(employee => employee.role === "mechanic-operator");
  const packers = present.filter(employee => employee.role === "packer");
  const previous = state.personnelDistribution?.teamId === team?.id ? state.personnelDistribution : null;
  const selected = values => new Set(previous?.[values] ?? []);
  const selectedLines = selected("lines");
  const selectedOperators = selected("operatorIds");
  const selectedPackers = selected("packerIds");
  const personById = new Map(present.map(employee => [employee.id, employee]));
  const checkboxList = (name, options, selectedIds) => options.length
    ? `<div class="distribution-options">${options.map(option => `<label><input type="checkbox" name="${name}" value="${attribute(option.id ?? option)}" ${selectedIds.has(option.id ?? option) ? "checked" : ""}><span>${escapeHtml(option.fullName ?? option)}</span></label>`).join("")}</div>`
    : `<p class="distribution-empty">Нет присутствующих сотрудников этой роли.</p>`;
  const name = id => escapeHtml(personById.get(id)?.fullName || "—");
  const result = previous?.result;
  return `<section class="card personnel-distribution-card">
    <header class="section-heading"><div><p class="eyebrow">Необязательный помощник</p><h2>Распределение персонала</h2><p>Выберите работающие линии и присутствующих сотрудников. Результат случайный, сохраняется только на экране и никуда не отправляется.</p></div></header>
    ${present.length ? `<form data-form="personnel-distribution">
      <input type="hidden" name="teamId" value="${attribute(team?.id || "")}">
      <div class="personnel-distribution-selectors">
        <fieldset><legend>Линии в работе</legend>${checkboxList("line", PRODUCTION_LINES, selectedLines)}</fieldset>
        <fieldset><legend>Механики-операторы</legend>${checkboxList("operator", operators, selectedOperators)}</fieldset>
        <fieldset><legend>Упаковщики</legend>${checkboxList("packer", packers, selectedPackers)}</fieldset>
      </div>
      <div class="distribution-actions"><small>Выбор можно менять и распределять заново — запись не создаётся.</small><button class="primary-button" type="submit">Распределить вразброс</button></div>
    </form>` : `<p class="distribution-empty">Сначала отметьте присутствующих в табеле и сохраните состав смены.</p>`}
    ${result ? `<section class="distribution-result" aria-live="polite"><h3>Автоматическая расстановка <span class="distribution-run-counter">№ ${formatNumber(result.runNumber || 1)}</span></h3>${result.lines.length ? `<div class="distribution-result-grid">${result.lines.map(item => `<article><strong>Линия ${escapeHtml(item.line)}</strong><span><small>Механик-оператор</small>${item.operatorId ? name(item.operatorId) : "Не выбран"}</span><span><small>Упаковщик</small>${item.packerId ? name(item.packerId) : "Не выбран"}</span></article>`).join("")}</div>` : `<p class="distribution-empty">Выберите хотя бы одну линию.</p>`}${result.unassignedOperatorIds.length || result.unassignedPackerIds.length ? `<div class="distribution-unassigned"><strong>Без линии</strong>${result.unassignedOperatorIds.length ? `<span><small>Механики-операторы</small>${result.unassignedOperatorIds.map(name).join(", ")}</span>` : ""}${result.unassignedPackerIds.length ? `<span><small>Упаковщики</small>${result.unassignedPackerIds.map(name).join(", ")}</span>` : ""}</div>` : ""}</section>` : ""}
  </section>`;
}

function attendanceForShiftStart(teamId, activeShift = null) {
  if (!teamId) return new Map();
  const source = activeShift?.shiftTeamId === teamId
    ? activeShift.attendance
    : (state.workforce.attendance || []).filter(item => item.date === today() && item.shiftTeamId === teamId);
  const attendance = new Map((source || []).map(item => [item.employeeId, item.status ?? item.value]));
  state.shiftGuests
    .filter(item => !attendance.has(item.employeeId))
    .forEach(item => attendance.set(item.employeeId, "11"));
  return attendance;
}

function renderLegacyShiftWarning() {
  const legacy = state.legacyShift;
  if (!APP_CONFIG.centralAuth || !legacy?.active) return "";
  const legacyDate = String(legacy.startedAt || "").slice(0, 10);
  const currentTeam = scheduledTeam()?.id;
  if (legacyDate === today() && legacy.shiftTeamId === currentTeam) return "";
  return `<section class="workforce-connection warning"><span>!</span><p><strong>Найдена локальная незавершённая смена ${escapeHtml(teamLabel(legacy.shiftTeamId))}</strong><br><small>Она не управляет общей сменой и не блокирует бригаду по графику. Завершите её явно только после проверки; сохранённые отметки табеля не будут изменены.</small></p><button class="small-button" data-action="archive-legacy-shift">Завершить и сохранить ${escapeHtml(teamLabel(legacy.shiftTeamId))}</button></section>`;
}

function renderCentralShiftWarning() {
  const shift = state.shift;
  if (!APP_CONFIG.centralAuth || !shift?.active || isCurrentSharedShift()) return "";
  return `<section class="workforce-connection warning"><span>!</span><p><strong>Общая смена ${escapeHtml(teamLabel(shift.shiftTeamId))} относится к ${escapeHtml(shift.shiftDate || "другой дате")}</strong><br><small>Сервер закрывает смены прошлой даты автоматически. Если предупреждение не исчезло после обновления, завершите смену явно только после проверки.</small></p><button class="small-button" data-action="end-shift">Завершить общую смену</button></section>`;
}

function renderScheduleView() {
  const days = monthDays(state.attendanceMonth);
  const teams = teamsWithCurrentShiftFirst();
  return `${renderWorkforceMonthToolbar("График смен", "Плановый цикл 2/2")}
    <section class="schedule-summary-grid">
      ${teams.map(team => {
        const schedule = getScheduleMonth(team, ...monthParts(state.attendanceMonth));
        const workDays = schedule.filter(day => day.scheduled).length;
        const workHours = schedule.reduce((sum, day) => sum + day.accountingHours, 0);
        return `<article class="schedule-summary-card card"><span class="team-orb">${team.code}</span><div><strong>${escapeHtml(team.name)}</strong><small>2 рабочих / 2 выходных · предпраздничная смена −1 ч</small></div><dl><div><dt>Смен</dt><dd>${workDays}</dd></div><div><dt>Часов</dt><dd>${workHours}</dd></div><div><dt>Состав</dt><dd>${activePersonnel().filter(employee => employee.shiftTeamId === team.id).length}</dd></div></dl></article>`;
      }).join("")}
      <article class="schedule-summary-card office card"><span class="team-orb">5/2</span><div><strong>${OFFICE_SCHEDULE.name}</strong><small>Пн–Пт · праздничные дни нерабочие</small></div><dl><div><dt>День</dt><dd>8 ч</dd></div><div><dt>Состав</dt><dd>${activePersonnel().filter(employee => employee.shiftTeamId === "office").length}</dd></div></dl></article>
    </section>
    <div class="schedule-groups">${teams.map(team => renderScheduleTeam(team, days)).join("")}</div>`;
}

function renderScheduleTeam(team, days) {
  const schedule = new Map(getScheduleMonth(team, ...monthParts(state.attendanceMonth)).map(day => [day.date, day]));
  const members = activePersonnel().filter(employee => employee.shiftTeamId === team.id).sort(comparePersonnel);
  const scheduledDays = [...schedule.values()].filter(day => day.scheduled).length;
  const scheduledHours = [...schedule.values()].reduce((sum, day) => sum + day.accountingHours, 0);
  return `<section class="card schedule-team-card">
    <header><div><span class="team-orb">${team.code}</span><span><strong>${escapeHtml(team.name)}</strong><small>${team.shiftDurationHours} часов · к учёту ${team.accountingHours} · перед праздником −1 ч</small></span></div><div><b>${scheduledDays}</b><small>${scheduledHours} учётных ч</small></div></header>
    <div class="attendance-scroll"><table class="attendance-table schedule-table"><thead><tr><th class="attendance-person">Сотрудник</th>${days.map(day => dayHeader(day)).join("")}<th class="total-column">Итого</th></tr></thead><tbody>${members.map(employee => `<tr><th class="attendance-person"><strong>${escapeHtml(employee.fullName)}</strong><small>${escapeHtml(roleLabel(employee.role))}</small></th>${days.map(day => { const shiftDay = schedule.get(day.date); return `<td class="${dayClasses(day)} ${shiftDay?.scheduled ? "is-scheduled" : "is-rest"}" title="${attribute(calendarTitle(day))}"><span>${shiftDay?.scheduled ? team.code : "·"}</span>${shiftDay?.scheduled && day.isPreholiday ? '<small class="preholiday-shift">−1 ч</small>' : ""}</td>`; }).join("")}<td class="total-column"><strong>${scheduledHours}</strong></td></tr>`).join("")}</tbody></table></div>
  </section>`;
}

function renderTimesheetView() {
  const days = monthDays(state.attendanceMonth);
  const teams = teamsWithCurrentShiftFirst();
  const editHint = state.account?.role === "senior"
    ? "Старший механик может изменять только текущий день; прошлые даты исправляет Администрация"
    : "Нажмите на ячейку, чтобы изменить часы или причину отсутствия";
  return `${renderWorkforceMonthToolbar("Табель рабочего времени", editHint)}
    <section class="attendance-code-strip">${ATTENDANCE_CODES.map(item => `<span class="tone-${item.tone}"><b>${item.value}</b>${item.label}</span>`).join("")}</section>
    <div class="schedule-groups">${teams.map(team => renderTimesheetTeam(team, days)).join("")}</div>`;
}

function renderTimesheetTeam(team, days) {
  const schedule = new Map(getScheduleMonth(team, ...monthParts(state.attendanceMonth)).map(day => [day.date, day]));
  const records = new Map(state.workforce.attendance.filter(item => item.shiftTeamId === team.id).map(item => [`${item.employeeId}:${item.date}`, item]));
  const regularMembers = regularAreaPersonnel().filter(employee => employee.shiftTeamId === team.id);
  const substituteMembers = activePersonnel().filter(employee => (employee.shiftTeamId !== team.id || isSubstituteOnly(employee)) && [...records.values()].some(record => record.employeeId === employee.id && record.substitutionReason));
  const members = [...regularMembers, ...substituteMembers].sort(comparePersonnel);
  return `<section class="card schedule-team-card timesheet-team-card">
    <header><div><span class="team-orb">${team.code}</span><span><strong>${escapeHtml(team.name)}</strong><small>Фактические часы и причины отсутствия</small></span></div>${renderTimesheetSaveState(team.id)}</header>
    <div class="attendance-scroll"><table class="attendance-table timesheet-table"><thead><tr><th class="attendance-person">Сотрудник</th>${days.map(day => dayHeader(day)).join("")}<th class="total-column">Часы</th></tr></thead><tbody>${members.map(employee => renderTimesheetRow(employee, team, days, schedule, records)).join("")}</tbody></table></div>
  </section>`;
}

function renderTimesheetSaveState(teamId) {
  const pending = (state.workforce.pending || []).filter(item => item.kind === "attendance" && item.record?.shiftTeamId === teamId);
  if (pending.some(item => item.status === "conflict" || item.status === "error")) return '<span class="status-pill danger">Требуется проверка</span>';
  if (pending.length || state.syncTransfer?.active) return '<span class="status-pill warning">Отправляется в Google</span>';
  if (state.workforce.syncError) return '<span class="status-pill danger">Ошибка синхронизации</span>';
  return `<span class="status-pill success">Сохранено в Google${state.workforce.lastSync ? ` · ${escapeHtml(formatDateTime(state.workforce.lastSync))}` : ""}</span>`;
}

function renderTimesheetRow(employee, team, days, schedule, records) {
  let total = 0;
  const substituteReasons = [...records.values()]
    .filter(record => record.employeeId === employee.id && record.substitutionReason)
    .map(record => record.substitutionReason);
  const substituteNote = substituteReasons.length ? `<span class="substitute-badge">Подмена · ${escapeHtml([...new Set(substituteReasons)].join(", "))}</span>` : "";
  const cells = days.map(day => {
    const record = records.get(`${employee.id}:${day.date}`);
    const scheduled = schedule.get(day.date)?.scheduled;
    const future = day.date > today();
    if (!record && (!scheduled || future)) return `<td class="${dayClasses(day)} ${future ? "is-future" : "is-rest"}" title="${attribute(calendarTitle(day))}">·</td>`;
    const vacation = vacationForDay(employee.id, day.date);
    // An approved vacation fills the timesheet automatically.  A real
    // attendance record always wins, so an early return to work remains a
    // normal manual correction.
    const value = record?.value ?? (vacation ? "A" : (workforceRepository ? "" : String(schedule.get(day.date)?.accountingHours ?? team.accountingHours)));
    const hours = Number(value);
    if (Number.isFinite(hours)) total += hours;
    const canEdit = canEditTimesheetDate(day.date);
    const editNote = canEdit ? "" : " title=\"Прошлые даты может исправлять только Администрация\"";
    return `<td class="timesheet-cell ${dayClasses(day)} ${canEdit ? "" : "is-readonly"} tone-${attendanceTone(value, team.accountingHours)}" title="${attribute(calendarTitle(day))}"><select data-timesheet-cell data-date="${day.date}" data-shift-team-id="${team.id}" data-employee-id="${employee.id}" aria-label="${attribute(`${employee.fullName}, ${day.date}`)}"${editNote} ${canEdit ? "" : "disabled"}>${value === "" ? '<option value="" selected disabled>—</option>' : ""}${timesheetOptions(value, team.accountingHours)}</select></td>`;
  }).join("");
  return `<tr><th class="attendance-person"><strong>${escapeHtml(employee.fullName)}</strong><small>${escapeHtml(roleLabel(employee.role))}</small>${substituteNote}</th>${cells}<td class="total-column"><strong>${total}</strong></td></tr>`;
}

function renderWorkforceMonthToolbar(title, note) {
  return `<section class="card workforce-month-toolbar"><button class="icon-button" data-action="attendance-month" data-offset="-1" aria-label="Предыдущий месяц">←</button><div><p class="eyebrow">${title}</p><h2>${escapeHtml(monthTitle(state.attendanceMonth))}</h2><small>${note}</small></div><button class="icon-button" data-action="attendance-month" data-offset="1" aria-label="Следующий месяц">→</button></section>`;
}

function renderPersonnelPage() {
  const employees = personnel().sort(comparePersonnel);
  const canEdit = state.account.role === "manager";
  return `
    <section class="workforce-hero card personnel-header">
      <div><p class="eyebrow">Команда фасовочного участка</p><h2>Персонал</h2><p>${canEdit ? "Полный справочник: состав смен, статус и личные данные сотрудников." : "Справочник сотрудников: должность, смена и рабочий статус. Редактирование доступно начальнику участка."}</p></div>
      <div class="personnel-actions"><span class="count-badge"><b data-personnel-count>${employees.length}</b> сотрудников</span>${canEdit ? `<button class="primary-button" data-action="add-employee">+ Добавить сотрудника</button>` : `<span class="status-pill muted">Только просмотр</span>`}</div>
    </section>
    <section class="card personnel-filter-card">
      <label class="personnel-search"><span>Поиск</span><input type="search" data-personnel-filter data-personnel-search placeholder="Имя или фамилия…" autocomplete="off"></label>
      <label class="field"><span>Смена</span><select data-personnel-filter data-personnel-team><option value="all">Все смены</option><option value="office">Администрация 5/2</option>${state.workforce.shiftTeams.map(team => `<option value="${team.id}">${escapeHtml(team.name)}</option>`).join("")}</select></label>
      <label class="field"><span>Должность</span><select data-personnel-filter data-personnel-role><option value="all">Все должности</option>${Object.entries(ROLE_LABELS).map(([role, label]) => `<option value="${role}">${escapeHtml(label)}</option>`).join("")}</select></label>
    </section>
    <section class="personnel-grid">
      ${employees.map(employee => `<article class="personnel-card ${employee.active === false ? "inactive" : ""}" data-personnel-card data-search="${attribute(employee.fullName.toLocaleLowerCase("ru-RU"))}" data-team="${employee.shiftTeamId}" data-role="${employee.role}">
        <div class="personnel-card-top"><span class="employee-avatar">${initials(employee.fullName)}</span><span class="employee-team-badge">${escapeHtml(teamLabel(employee.shiftTeamId))}</span></div>
        <h3>${escapeHtml(employee.fullName)}</h3>
        <p>${escapeHtml(roleLabel(employee.role))}</p>
        <dl><div><dt>График</dt><dd>${employee.shiftTeamId === "office" ? "5/2 · 8 ч" : "2/2 · 12 ч"}</dd></div><div class="personnel-shift"><dt>Смена</dt><dd>${escapeHtml(teamLabel(employee.shiftTeamId))}</dd></div><div><dt>Статус</dt><dd>${employee.active === false ? "В архиве" : "Активен"}</dd></div>${employee.role === "packer" ? `<div class="personnel-pak"><dt>Номер PAK</dt><dd>${escapeHtml(employee.pakNumber || "—")}</dd></div><div class="personnel-pak personnel-code"><dt>Код</dt><dd>${escapeHtml(employee.pakCode || "—")}</dd></div>` : ""}</dl>
        ${canEdit ? renderPersonnelPrivateDetails(employee) : `<p class="directory-note">Справочник · только просмотр</p>`}
        ${canEdit ? `<div class="personnel-card-actions"><button data-action="edit-employee" data-id="${employee.id}">Карточка</button><button data-action="toggle-employee" data-id="${employee.id}">${employee.active === false ? "Вернуть" : "В архив"}</button></div>` : ""}
      </article>`).join("")}
    </section>`;
}

function renderPersonnelPrivateDetails(employee) {
  return `<details class="personnel-private"><summary>Личные сведения</summary><dl>
    <div><dt>Дата рождения</dt><dd>${escapeHtml(formatPersonnelDate(employee.birthday))}</dd></div>
    <div><dt>Возраст</dt><dd>${escapeHtml(formatPersonnelAge(employee.birthday))}</dd></div>
    <div><dt>Дата приёма</dt><dd>${escapeHtml(formatPersonnelDate(employee.hireDate))}</dd></div>
    <div><dt>Стаж работы</dt><dd>${escapeHtml(formatPersonnelExperience(employee.hireDate))}</dd></div>
    <div class="full"><dt>Телефон</dt><dd>${escapeHtml(employee.phone || "Не указан")}</dd></div>
    <div class="full"><dt>Электронная почта</dt><dd>${escapeHtml(employee.email || "Не указана")}</dd></div>
  </dl></details>`;
}

function renderStatisticsPage() {
  const statisticsMonthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
  const years = statisticsYears();
  const year = years.includes(state.statisticsYear) ? state.statisticsYear : years[0];
  const month = state.statisticsMonth;
  const periodLabel = month ? `${statisticsMonthNames[Number(month) - 1]} ${year}` : `весь ${year} год`;
  const production = sortStatisticsProductionRows(statisticsProductionRows(year, month));
  const attendance = statisticsAttendanceRows(year, month);
  const activity = statisticsActivityRows(year, month);
  const table = (headers, rows, empty) => `<div class="table-scroll"><table><thead><tr>${headers.map(header => `<th>${header}</th>`).join("")}</tr></thead><tbody>${rows.length ? rows.join("") : `<tr><td colspan="${headers.length}">${empty}</td></tr>`}</tbody></table></div>`;
  const productionSortHeader = (label, key) => {
    const active = state.statisticsProductionSort.key === key;
    const direction = active ? state.statisticsProductionSort.direction : "desc";
    return `<button class="statistics-sort-button ${active ? "active" : ""}" type="button" data-action="sort-statistics-production" data-sort-key="${key}"><span>${label}</span><b aria-hidden="true">${direction === "desc" ? "↓" : "↑"}</b></button>`;
  };
  const productionRows = statisticsRoleTableRows(production, 5, row => `<tr><td><strong>${escapeHtml(row.fullName)}</strong><small>${escapeHtml(roleLabel(row.role))}</small></td><td>${escapeHtml(row.team)}</td><td><strong>${formatNumber(row.quantity)}</strong><br><small>${formatBoxes(row.quantity / 240)} кор.</small></td><td>${formatNumber(row.scrapKg)}</td><td class="production-scrap-percent">${row.grossMassKg > 0 ? scrapPercentLabel(row.scrapKg / row.grossMassKg * 100) : "—"}</td></tr>`);
  const attendanceRows = statisticsRoleTableRows(attendance, 6, row => `<tr><td><strong>${escapeHtml(row.fullName)}</strong><small>${escapeHtml(roleLabel(row.role))}</small></td><td>${escapeHtml(row.team)}</td><td>${row.workedShifts}</td><td>${formatNumber(row.hours)}</td><td>${row.sickDays}</td><td>${row.vacationDays}</td></tr>`);
  const activityTable = (title, rows) => `<section class="card table-card statistics-activity-table"><div class="section-heading"><div><p class="eyebrow">Активность · ${escapeHtml(periodLabel)}</p><h3>${title}</h3></div></div>${table(["Сотрудник", "Выпуск, шт.", "Смены / у линии", "Ремонт", "ТО", "Весы", "Очистки"], statisticsRoleTableRows(rows, 7, row => `<tr><td><strong>${escapeHtml(row.fullName)}</strong><small>${escapeHtml(roleLabel(row.role))} · смена ${escapeHtml(row.team)}</small></td><td>${formatNumber(row.quantity)}<br><small>${formatBoxes(row.quantity / 240)} кор.</small></td><td>${row.leadershipShifts} / ${row.lineEntries}</td><td>${row.repairs}</td><td>${row.services}</td><td>${row.scales}</td><td>${row.cyclones}</td></tr>`), "За выбранный период подтверждённых действий нет.")}${renderStatisticsLeaders(rows, statisticsActivityCompare, activityHasData, activityLeaderDetail, [...new Set(rows.map(row => row.role))])}</section>`;
  const overallLeaders = statisticsOverallLeaders(production, attendance, activity);
  return `
    <section class="settings-hero card statistics-hero">
      <div><p class="eyebrow">Сводные показатели участка</p><h2>Статистика</h2><p>Выпуск и брак берутся из подготовленного отчёта производства, отработанные смены — из табеля, остальные действия — из соответствующих рабочих журналов. Старший механик может только просматривать показатели.</p></div>
      <span class="status-pill success">Просмотр: Администрация и Старший механик</span>
    </section>
    <section class="card statistics-filters"><div><strong>Период отчёта</strong><small>Фильтр применяется ко всем трём разделам.</small></div><label>Год<select data-statistics-year>${years.map(item => `<option value="${item}" ${item === year ? "selected" : ""}>${item}</option>`).join("")}</select></label><label>Месяц<select data-statistics-month><option value="">Весь год</option>${statisticsMonthNames.map((name, index) => `<option value="${String(index + 1).padStart(2, "0")}" ${month === String(index + 1).padStart(2, "0") ? "selected" : ""}>${name}</option>`).join("")}</select></label></section>
    <section class="card table-card statistics-production"><div class="section-heading"><div><p class="eyebrow">1 · Производство</p><h2>Выпуск и брак по персоналу</h2><p>Данные выпусков и брака берутся из листов «Механики», «Упаковщики» и «Брак» рабочего отчёта. Процент показывается там, где в отчёте есть масса для его расчёта.</p></div><span class="status-pill neutral">${escapeHtml(periodLabel)}</span></div>${table(["Сотрудник", "Смена", productionSortHeader("Произведено, банок / коробок", "quantity"), productionSortHeader("Брак продукции, кг", "scrapKg"), productionSortHeader("Процент брака", "scrapPercent")], productionRows, "За выбранный период выпуск не зарегистрирован.")}${renderStatisticsLeaders(production, statisticsProductionCompare, productionHasData, productionLeaderDetail)}</section>
    <section class="card table-card statistics-attendance"><div class="section-heading"><div><p class="eyebrow">2 · Табель</p><h2>Отработанные смены и отсутствие</h2><p>Смена засчитывается при фактически указанном количестве часов. Отпуск считается только по рабочим сменам 2/2, а для администрации — по рабочим дням 5/2.</p></div><span class="status-pill neutral">${escapeHtml(periodLabel)}</span></div>${table(["Сотрудник", "Смена", "Отработано смен", "Часы", "Болезнь, дней", "Отпуск, смен / раб. дн."], attendanceRows, "За выбранный период табель ещё не заполнен.")}${renderStatisticsLeaders(attendance, statisticsAttendanceCompare, attendanceHasData, attendanceLeaderDetail)}</section>
    <section class="statistics-activity"><section class="card statistics-activity-intro"><div><p class="eyebrow">3 · Активность и продуктивность</p><h2>Подтверждённые действия по журналам</h2><p>Это не общий балл. Выпуск — фактически указанный в записи; «Смены / у линии» — количество смен руководства и записей назначения к линии. Ремонт, ТО, весы и очистки считаются только по журналам, где сотрудник указан исполнителем.</p></div></section><div class="statistics-activity-grid">${activityTable("Старшие механики и механики", activity.filter(row => ["senior-mechanic", "mechanic"].includes(row.role)))}${activityTable("Механики-операторы", activity.filter(row => row.role === "mechanic-operator"))}${activityTable("Упаковщики", activity.filter(row => row.role === "packer"))}</div></section>
    ${renderStatisticsOverallLeader(overallLeaders, periodLabel)}`;
}

const STATISTICS_ROLE_ORDER = Object.freeze(["senior-mechanic", "mechanic", "mechanic-operator", "packer"]);

function statisticsRoleTableRows(rows, columnCount, renderRow) {
  const order = new Map(STATISTICS_ROLE_ORDER.map((role, index) => [role, index]));
  const ordered = rows.map((row, index) => ({ row, index })).sort((left, right) => order.get(left.row.role) - order.get(right.row.role) || left.index - right.index);
  let previousRole = "";
  return ordered.flatMap(({ row }) => {
    const divider = row.role !== previousRole
      ? [`<tr class="statistics-role-divider"><td colspan="${columnCount}">${escapeHtml(roleLabel(row.role))}</td></tr>`]
      : [];
    previousRole = row.role;
    return [...divider, renderRow(row)];
  });
}

function statisticsProductionCompare(left, right) {
  const leftPercent = left.grossMassKg > 0 ? left.scrapKg / left.grossMassKg : Infinity;
  const rightPercent = right.grossMassKg > 0 ? right.scrapKg / right.grossMassKg : Infinity;
  return right.quantity - left.quantity || leftPercent - rightPercent || left.fullName.localeCompare(right.fullName, "ru");
}

function statisticsAttendanceCompare(left, right) {
  return right.workedShifts - left.workedShifts || right.hours - left.hours || (left.sickDays + left.vacationDays) - (right.sickDays + right.vacationDays) || left.fullName.localeCompare(right.fullName, "ru");
}

function activityScore(row) {
  return Number(row.leadershipShifts || 0) + Number(row.lineEntries || 0) + Number(row.repairs || 0) + Number(row.services || 0) + Number(row.scales || 0) + Number(row.cyclones || 0);
}

function statisticsActivityCompare(left, right) {
  return activityScore(right) - activityScore(left) || right.quantity - left.quantity || left.fullName.localeCompare(right.fullName, "ru");
}

function productionHasData(row) { return row.quantity > 0 || row.scrapKg > 0; }
function attendanceHasData(row) { return row.workedShifts > 0 || row.hours > 0 || row.sickDays > 0 || row.vacationDays > 0; }
function activityHasData(row) { return activityScore(row) > 0 || row.quantity > 0; }

function productionLeaderDetail(row) {
  const percent = row.grossMassKg > 0 ? `${formatPercent(row.scrapKg / row.grossMassKg * 100)}%` : "—";
  return `${formatBoxes(row.quantity / 240)} кор. · брак ${percent}`;
}

function attendanceLeaderDetail(row) { return `${row.workedShifts} смен · ${formatNumber(row.hours)} ч`; }
function activityLeaderDetail(row) { return `${activityScore(row)} подтверждённых действий`; }

function renderStatisticsLeaders(rows, comparator, hasData, detail, roles = STATISTICS_ROLE_ORDER) {
  const leaders = roles.map(role => {
    const candidates = rows.filter(row => row.role === role && hasData(row)).sort(comparator);
    return { role, person: candidates[0] || null };
  });
  return `<footer class="statistics-leaders"><div class="statistics-leaders-heading"><div><p class="eyebrow">Лучшие показатели за период</p><h3>Лидеры по должностям</h3></div></div><div class="statistics-leaders-grid">${leaders.map(({ role, person }) => `<article class="statistics-leader-card ${person ? "" : "empty"}"><span>${escapeHtml(roleLabel(role))}</span>${person ? `<strong>${escapeHtml(person.fullName)}</strong><small>${escapeHtml(detail(person))}</small>` : "<small>Нет подтверждённых данных</small>"}</article>`).join("")}</div></footer>`;
}

function rankedStatisticsRows(rows, comparator) {
  const ranks = new Map();
  STATISTICS_ROLE_ORDER.forEach(role => rows.filter(row => row.role === role).sort(comparator).forEach((row, index) => ranks.set(row.id, index + 1)));
  return ranks;
}

function statisticsOverallLeaders(production, attendance, activity) {
  const productionRanks = rankedStatisticsRows(production, statisticsProductionCompare);
  const attendanceRanks = rankedStatisticsRows(attendance, statisticsAttendanceCompare);
  const activityRanks = rankedStatisticsRows(activity, statisticsActivityCompare);
  const people = new Map();
  [[production, "production"], [attendance, "attendance"], [activity, "activity"]].forEach(([rows, source]) => rows.forEach(row => {
    const current = people.get(row.id) || { id: row.id, fullName: row.fullName, role: row.role };
    current[source] = row;
    people.set(row.id, current);
  }));
  return STATISTICS_ROLE_ORDER.map(role => [...people.values()]
    .filter(person => person.role === role && (
      productionHasData(person.production || {})
      || attendanceHasData(person.attendance || {})
      || activityHasData(person.activity || {})
    ))
    .map(person => ({
      ...person,
      totalPlace: (productionRanks.get(person.id) || 0) + (attendanceRanks.get(person.id) || 0) + (activityRanks.get(person.id) || 0)
    }))
    .sort((left, right) => left.totalPlace - right.totalPlace || left.fullName.localeCompare(right.fullName, "ru"))[0] || null);
}

function renderStatisticsOverallLeader(leaders, periodLabel) {
  return `<section class="card statistics-overall-leader"><div><p class="eyebrow">Итог · ${escapeHtml(periodLabel)}</p><h2>Общие лидеры статистики</h2><p>По одному сотруднику для каждой должности: минимальная сумма мест в производстве, табеле и активности.</p></div><div class="statistics-overall-grid">${STATISTICS_ROLE_ORDER.map((role, index) => {
    const leader = leaders[index];
    return `<article class="statistics-overall-winner ${leader ? "" : "empty"}"><span>${escapeHtml(roleLabel(role))}</span>${leader ? `<strong>${escapeHtml(leader.fullName)}</strong><small>Сумма мест: ${leader.totalPlace}</small>` : "<small>Нет подтверждённых данных</small>"}</article>`;
  }).join("")}</div></section>`;
}

function statisticsYears() {
  if (state.statistics.years?.length) return [...new Set([Number(today().slice(0, 4)), ...state.statistics.years.map(Number)])].sort((left, right) => right - left);
  const dates = [
    ...(state.production.records || []).map(record => record.date), ...(state.workforce.attendance || []).map(record => record.date),
    ...((state.maintenance.service?.records || []).map(record => record.date)), ...((state.maintenance.repair?.records || []).map(record => record.date)),
    ...(state.cyclones.records || []).map(record => record.date), ...(state.records || []).map(record => record.date)
  ].map(value => Number(String(value || "").slice(0, 4))).filter(Number.isInteger);
  return [...new Set([Number(today().slice(0, 4)), ...dates])].sort((left, right) => right - left);
}

function statisticsInPeriod(record, year, month = "") {
  const date = String(record?.date || "");
  return date.startsWith(`${year}-${month || ""}`);
}

function statisticsPeople() {
  const roleOrder = { "senior-mechanic": 0, mechanic: 1, "mechanic-operator": 2, packer: 3 };
  const people = state.statistics.personnel?.length ? state.statistics.personnel.filter(person => person.active) : activePersonnel();
  return people.filter(person => Object.hasOwn(roleOrder, person.role)).sort((left, right) => roleOrder[left.role] - roleOrder[right.role] || left.fullName.localeCompare(right.fullName, "ru"));
}

function statisticsTeam(employee) {
  const teams = state.statistics.shiftTeams?.length ? state.statistics.shiftTeams : state.workforce.shiftTeams;
  return teams.find(team => team.id === employee.shiftTeamId)?.code || "—";
}

function statisticsProductionRows(year, month) {
  const people = statisticsPeople();
  if (state.statistics.source === "production-report") {
    const source = new Map(state.statistics.production.map(row => [`${row.fullName}:${row.role || ""}`, row]));
    const order = { "senior-mechanic": 0, mechanic: 1, "mechanic-operator": 2, packer: 3 };
    const byName = new Map(people.map(person => [person.fullName, person]));
    const rows = state.statistics.production.map(sourceRow => {
      const person = byName.get(sourceRow.fullName);
      if (!person) return null;
      return { ...person, role: sourceRow.role || person.role, team: statisticsTeam(person), quantity: Number(sourceRow.boxes || 0) * 240, scrapKg: Number(sourceRow.scrapKg || 0), grossMassKg: Number(sourceRow.grossMassKg || 0) };
    }).filter(Boolean);
    const represented = new Set(rows.map(row => `${row.fullName}:${row.role}`));
    people.forEach(person => {
      if (!represented.has(`${person.fullName}:${person.role}`)) rows.push({ ...person, team: statisticsTeam(person), quantity: 0, scrapKg: 0, grossMassKg: 0 });
    });
    return rows.sort((left, right) => order[left.role] - order[right.role] || right.quantity - left.quantity || left.fullName.localeCompare(right.fullName, "ru"));
  }
  const byName = new Map(people.map(person => [person.fullName, person]));
  const rows = new Map();
  const rowFor = (name, role) => {
    const person = byName.get(String(name || "").trim());
    if (!person) return null;
    const key = `${person.id}:${role || person.role}`;
    if (!rows.has(key)) rows.set(key, { ...person, role: role || person.role, team: statisticsTeam(person), quantity: 0, scrapKg: 0, grossMassKg: 0, shifts: new Map() });
    return rows.get(key);
  };
  const add = (name, record, fraction = 1, role = "") => {
    const row = rowFor(name, role);
    if (!row) return;
    const grossMass = productionRecordMassKg(record) + Number(record.scrapKg || 0);
    row.quantity += Number(record.quantity || 0) * fraction;
    row.scrapKg += Number(record.scrapKg || 0) * fraction;
    row.grossMassKg += grossMass * fraction;
    const shift = String(record.shift || "").trim().toUpperCase();
    if (shift) row.shifts.set(shift, (row.shifts.get(shift) || 0) + 1);
  };
  productionShiftGroups((state.production.records || []).filter(record => statisticsInPeriod(record, year, month))).forEach(group => {
    group.records.forEach(record => {
      add(record.packer, record);
      productionLineCredits(record).forEach(({ name, fraction }) => add(name, record, fraction, "mechanic-operator"));
    });
    const total = group.records.reduce((result, record) => ({
      quantity: result.quantity + Number(record.quantity || 0),
      scrapKg: result.scrapKg + Number(record.scrapKg || 0),
      grossMassKg: result.grossMassKg + productionRecordMassKg(record) + Number(record.scrapKg || 0)
    }), { quantity: 0, scrapKg: 0, grossMassKg: 0 });
    productionShiftRoleCredits(group).forEach(({ name, role, fraction }) => {
      const row = rowFor(name, role);
      if (!row) return;
      row.quantity += total.quantity * fraction; row.scrapKg += total.scrapKg * fraction; row.grossMassKg += total.grossMassKg * fraction;
      const shift = String(group.records[0]?.shift || "").trim().toUpperCase();
      if (shift) row.shifts.set(shift, (row.shifts.get(shift) || 0) + 1);
    });
  });
  people.forEach(person => rowFor(person.fullName, person.role));
  const order = { "senior-mechanic": 0, mechanic: 1, "mechanic-operator": 2, packer: 3 };
  return [...rows.values()].map(row => ({ ...row, team: [...row.shifts.entries()].sort((left, right) => right[1] - left[1])[0]?.[0] || row.team })).sort((left, right) => order[left.role] - order[right.role] || right.quantity - left.quantity || left.fullName.localeCompare(right.fullName, "ru"));
}

function sortStatisticsProductionRows(rows) {
  const roleOrder = { "senior-mechanic": 0, mechanic: 1, "mechanic-operator": 2, packer: 3 };
  const { key, direction } = state.statisticsProductionSort;
  const value = row => key === "scrapPercent"
    ? (row.grossMassKg > 0 ? row.scrapKg / row.grossMassKg : null)
    : Number(row[key] || 0);
  return [...rows].sort((left, right) => {
    const roleDifference = roleOrder[left.role] - roleOrder[right.role];
    if (roleDifference) return roleDifference;
    const leftValue = value(left), rightValue = value(right);
    if (leftValue === null || rightValue === null) {
      if (leftValue === rightValue) return left.fullName.localeCompare(right.fullName, "ru");
      return leftValue === null ? 1 : -1;
    }
    const difference = direction === "asc" ? leftValue - rightValue : rightValue - leftValue;
    return difference || left.fullName.localeCompare(right.fullName, "ru");
  });
}

function statisticsAttendanceRows(year, month) {
  const people = statisticsPeople(), rows = new Map(people.map(person => [person.id, { ...person, team: statisticsTeam(person), workedShifts: 0, hours: 0, sickDays: 0, vacationDays: 0 }]));
  const attendance = state.statistics.source === "production-report" ? state.statistics.attendance : state.workforce.attendance;
  attendance.filter(record => statisticsInPeriod(record, year, month)).forEach(record => {
    const row = rows.get(record.employeeId); if (!row) return;
    const value = String(record.value || "").replace(",", "."), hours = Number(value);
    if (Number.isFinite(hours) && hours > 0) { row.workedShifts += 1; row.hours += hours; }
    if (value === "L") row.sickDays += 1;
    if (value === "A" && isVacationChargeableDay(row, record.date, state.workforce.shiftTeams)) row.vacationDays += 1;
  });
  return [...rows.values()];
}

function statisticsActivityRows(year, month) {
  const people = statisticsPeople(), byName = new Map(people.map(person => [person.fullName, person]));
  const rows = new Map(people.map(person => [person.id, { ...person, team: statisticsTeam(person), quantity: 0, lineEntries: 0, leadership: new Set(), repairs: 0, services: 0, scales: 0, cyclones: 0 }]));
  const add = (name, field, value = 1) => { const person = byName.get(String(name || "").trim()), row = person && rows.get(person.id); if (row) row[field] += value; };
  if (state.statistics.source === "production-report") {
    state.statistics.production.forEach(item => { add(item.fullName, "quantity", Number(item.boxes || 0) * 240); add(item.fullName, "lineEntries", Number(item.days || 0)); });
    productionShiftGroups((state.production.records || []).filter(record => statisticsInPeriod(record, year, month))).forEach(group => group.shiftAssignees.forEach(name => {
      const person = byName.get(name), row = person && rows.get(person.id); if (row) row.leadership.add(group.key);
    }));
  } else {
    productionShiftGroups((state.production.records || []).filter(record => statisticsInPeriod(record, year, month))).forEach(group => {
      group.records.forEach(record => {
        add(record.packer, "lineEntries"); add(record.packer, "quantity", Number(record.quantity || 0));
        productionLineCredits(record, group.shiftAssignees).forEach(({ name, fraction }) => { add(name, "lineEntries"); add(name, "quantity", Number(record.quantity || 0) * fraction); });
      });
      group.shiftAssignees.forEach(name => { const person = byName.get(name), row = person && rows.get(person.id); if (row) row.leadership.add(group.key); });
    });
  }
  const maintenance = (records, field) => records.filter(record => statisticsInPeriod(record, year, month)).forEach(record => add(record.performer, field));
  maintenance(state.maintenance.repair?.records || [], "repairs"); maintenance(state.maintenance.service?.records || [], "services");
  (state.records || []).filter(record => record.status !== "Аннулировано" && statisticsInPeriod(record, year, month)).forEach(record => add(record.performer, "scales"));
  (state.cyclones.records || []).filter(record => record.syncState === "synced" && statisticsInPeriod(record, year, month)).forEach(record => add(record.performer, "cyclones"));
  return [...rows.values()].map(row => ({ ...row, leadershipShifts: row.leadership.size })).sort((left, right) => left.fullName.localeCompare(right.fullName, "ru"));
}

function formatPersonnelDate(value) {
  const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return match ? `${match[3]}.${match[2]}.${match[1]}` : "Не указана";
}

function renderVacationsPage() {
  const year = WORKFORCE_YEARS.includes(state.vacationYear) ? state.vacationYear : WORKFORCE_YEARS[0];
  const allRows = [...(state.workforce.vacations || [])].filter(vacation => Number(vacation.year) === year && isVacationEligible(personnel().find(employee => employee.id === vacation.employeeId)));
  const rows = allRows.filter(vacation => vacation.status !== "Аннулирован");
  const canEdit = state.account.role === "manager";
  const conflictsByVacation = findVacationConflicts(rows, personnel(), { asOfDate: today() });
  const conflictCount = [...conflictsByVacation.values()].reduce((total, conflicts) => total + conflicts.length, 0) / 2;
  const byEmployee = new Map();
  rows.forEach(vacation => byEmployee.set(vacation.employeeId, [...(byEmployee.get(vacation.employeeId) || []), vacation]));
  const teams = [...teamsWithCurrentShiftFirst().filter(team => ["shift-team-a", "shift-team-b"].includes(team.id)), { id: "office", name: "Администрация", code: "5/2" }];
  return `<section class="card module-header vacation-header"><div><h2>График отпусков</h2><p>${canEdit ? "Период задаётся датами. Для смен 2/2 бухгалтерский остаток и списание ведутся в сменах: 15 смен в год; для администрации — в рабочих днях: 20 в год. Государственные праздники не списываются." : "Только просмотр. Изменять график отпусков может начальник участка."}</p></div><div class="vacation-header-actions"><label>Год<select data-vacation-year>${WORKFORCE_YEARS.map(item => `<option value="${item}" ${item === year ? "selected" : ""}>${item}</option>`).join("")}</select></label>${canEdit ? `<button class="primary-button" data-action="add-vacation">+ Добавить период</button>${journalLink("vacations")}` : '<span class="status-pill muted">Только просмотр</span>'}</div></section><section class="card vacation-board">${conflictCount ? `<div class="vacation-conflict-notice"><strong>⚠ Пересечения отпусков: ${conflictCount}</strong><span>Допускаются, но требуют проверки: два упаковщика, два механика-оператора или старший механик с механиком одной смены.</span></div>` : ""}<div class="vacation-grid vacation-grid-head"><div class="vacation-person-heading">Сотрудник</div><div class="vacation-months">${vacationMonths().map(month => `<div class="vacation-month"><strong>${month}</strong><span>с</span><span>по</span></div>`).join("")}</div></div>${teams.map(team => renderVacationTeam(team, byEmployee, year, canEdit, conflictsByVacation)).join("")}</section>${renderVacationPeriodList(allRows, canEdit, conflictsByVacation)}`;
}

function vacationMonths() { return ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]; }
function renderVacationPeriodList(rows, canEdit, conflictsByVacation = new Map()) {
  const listed = [...rows].sort((left, right) => String(left.startDate).localeCompare(String(right.startDate)) || String(left.id).localeCompare(String(right.id)));
  if (!listed.length) return '<section class="card vacation-periods"><div class="section-heading"><div><p class="eyebrow">Периоды выбранного года</p><h3>Пока нет периодов</h3></div></div></section>';
  const currentOrUpcoming = listed.filter(vacation => vacation.status !== "Аннулирован" && vacation.endDate >= today());
  const history = listed.filter(vacation => !currentOrUpcoming.includes(vacation));
  const period = vacation => { const employee = personnel().find(person => person.id === vacation.employeeId); const team = state.workforce.shiftTeams.find(item => item.id === employee?.shiftTeamId); const cancelled = vacation.status === "Аннулирован"; const conflicts = conflictsByVacation.get(vacation.id) || []; const warning = vacationConflictText(conflicts); return `<article class="vacation-period ${cancelled ? "cancelled" : ""} ${conflicts.length ? "vacation-period-conflict" : ""}"><div><strong>${escapeHtml(employee?.fullName || "Сотрудник не найден")}</strong><small>${escapeHtml(employee ? `${roleLabel(employee.role)} · ${team?.name || "Смена не указана"}` : "")}</small></div><div><strong>${escapeHtml(formatPersonnelDate(vacation.startDate))} — ${escapeHtml(formatPersonnelDate(vacation.endDate))}</strong><small>${escapeHtml(String(vacation.days || "—"))} ${escapeHtml(vacationUnitLabel(employee))} отпуска · ${escapeHtml(vacation.status || "Запланирован")}</small>${conflicts.length ? `<small class="vacation-period-warning" title="${attribute(warning)}">⚠ ${escapeHtml(warning)}</small>` : ""}</div>${canEdit ? `<div class="vacation-period-actions"><button class="small-button" data-action="edit-vacation" data-id="${attribute(vacation.id)}">Изменить</button>${cancelled ? "" : `<button class="small-button" data-action="cancel-vacation" data-id="${attribute(vacation.id)}">Отменить</button>`}<button class="small-button danger-button" data-action="delete-vacation" data-id="${attribute(vacation.id)}">Удалить</button></div>` : ""}</article>`; };
  return `<section class="card vacation-periods"><div class="section-heading"><div><p class="eyebrow">Периоды выбранного года</p><h3>Управление отпусками</h3></div><span class="status-pill muted">${currentOrUpcoming.length} актуально</span></div><div class="vacation-period-list">${currentOrUpcoming.length ? currentOrUpcoming.map(period).join("") : '<p class="vacation-period-empty">Нет текущих или запланированных отпусков.</p>'}</div>${history.length ? `<details class="vacation-period-history"><summary>Прошедшие и отменённые периоды <span>${history.length}</span></summary><div class="vacation-period-list">${history.map(period).join("")}</div></details>` : ""}</section>`;
}
function renderVacationTeam(team, byEmployee, year, canEdit, conflictsByVacation) {
  const members = activePersonnel().filter(employee => employee.shiftTeamId === team.id && isVacationEligible(employee)).sort(comparePersonnel);
  const roles = team.id === "office"
    ? [...new Set(members.map(employee => employee.role))].sort((left, right) => roleLabel(left).localeCompare(roleLabel(right), "ru"))
    : ["senior-mechanic", "mechanic", "mechanic-operator", "packer"];
  return `<section class="vacation-team"><header><span>${escapeHtml(team.name)}</span><small>${members.length} сотрудников</small></header>${roles.map(role => { const people = members.filter(employee => employee.role === role); return people.length ? `<div class="vacation-role"><div class="vacation-role-title">${escapeHtml(roleLabel(role))}</div>${people.map(employee => renderVacationPerson(employee, byEmployee.get(employee.id) || [], year, canEdit, conflictsByVacation)).join("")}</div>` : ""; }).join("")}</section>`;
}
function vacationConflictText(conflicts) {
  if (!conflicts.length) return "";
  const names = [...new Map(conflicts.map(conflict => [conflict.employee.id, conflict])).values()]
    .map(conflict => `${conflict.employee.fullName} (${roleLabel(conflict.employee.role)}) · ${formatPersonnelDate(conflict.overlapStart)}–${formatPersonnelDate(conflict.overlapEnd)}`);
  return `Пересечение с ${names.join("; ")}`;
}
function renderVacationPerson(employee, vacations, year, canEdit, conflictsByVacation = new Map()) {
  const balance = vacationBalance(employee, year);
  const ranges = [...vacations].sort((left, right) => String(left.startDate).localeCompare(String(right.startDate)) || String(left.id).localeCompare(String(right.id))).map((vacation, index) => {
    const conflicts = conflictsByVacation.get(vacation.id) || [];
    const warning = vacationConflictText(conflicts);
    const label = `${formatPersonnelDate(vacation.startDate)} — ${formatPersonnelDate(vacation.endDate)} · ${vacation.days} ${vacationUnitLabel(employee)}${warning ? ` · ⚠ ${warning}` : ""}`;
    const startMonth = Number(String(vacation.startDate).slice(5, 7)) - 1;
    const endMonth = Number(String(vacation.endDate).slice(5, 7)) - 1;
    if (startMonth < 0 || startMonth >= 12 || endMonth < 0 || endMonth >= 12) return "";
    const button = (date, edge) => `<button class="vacation-date vacation-date-${edge}" title="${attribute(label)}" aria-label="${attribute(label)}" ${canEdit ? `data-action="edit-vacation" data-id="${attribute(vacation.id)}"` : "disabled"}>${escapeHtml(String(date).slice(8, 10))}</button>`;
    return `<div class="vacation-range ${conflicts.length ? "vacation-range-conflict" : ""}" style="grid-column:${startMonth * 2 + 1} / ${endMonth * 2 + 3};grid-row:${index + 1}" title="${attribute(label)}">${button(vacation.startDate, "start")}<span class="vacation-range-line" aria-hidden="true"></span>${button(vacation.endDate, "end")}${conflicts.length ? `<span class="vacation-conflict-mark" title="${attribute(warning)}" aria-label="${attribute(warning)}">!</span>` : ""}</div>`;
  }).join("");
  const balanceText = `Использовано: ${formatVacationBalance(balance.yearUsed)} · Запланировано: ${formatVacationBalance(balance.planned)} · Осталось: ${formatVacationBalance(balance.remaining)}`;
  const rowWarnings = [...new Map(vacations.flatMap(vacation => conflictsByVacation.get(vacation.id) || []).map(conflict => [conflict.employee.id, conflict])).values()];
  return `<div class="vacation-grid vacation-person-row ${rowWarnings.length ? "vacation-person-row-conflict" : ""}"><div class="vacation-person"><strong>${escapeHtml(employee.fullName)}</strong><small>${escapeHtml(roleLabel(employee.role))}</small><small class="vacation-balance">${escapeHtml(balanceText)}</small>${rowWarnings.length ? `<small class="vacation-conflict-summary" title="${attribute(vacationConflictText(rowWarnings))}">⚠ ${escapeHtml(vacationConflictText(rowWarnings))}</small>` : ""}</div><div class="vacation-track" style="--vacation-rows:${Math.max(vacations.length, 1)}">${ranges}</div></div>`;
}

function vacationBalance(employee, year, cache = new Map()) {
  const cacheKey = `${employee.id}:${year}`;
  if (cache.has(cacheKey)) return cache.get(cacheKey);
  const usedDates = new Set();
  const yearUsedDates = new Set();
  const plannedDates = new Set();
  const currentDate = today();
  const manual = (state.workforce.vacationBalances || []).find(row => row.employeeId === employee.id && Number(row.year) === year);
  const asOfDate = /^\d{4}-\d{2}-\d{2}$/.test(String(manual?.asOfDate || "")) ? manual.asOfDate : "";
  const isFactual = Number.isFinite(Number(manual?.factualRemaining)) && Boolean(asOfDate);
  const vacations = (state.workforce.vacations || []).filter(vacation => vacation.employeeId === employee.id && Number(vacation.year) === year && vacation.status !== "Аннулирован");
  vacations.forEach(vacation => {
    const start = String(vacation.startDate || "");
    const end = String(vacation.endDate || "");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) return;
    for (let cursor = new Date(`${start}T12:00:00Z`), finish = new Date(`${end}T12:00:00Z`); cursor <= finish; cursor.setUTCDate(cursor.getUTCDate() + 1)) {
      const date = cursor.toISOString().slice(0, 10);
      if (Number(date.slice(0, 4)) !== year) continue;
      if (!isVacationDay(employee, date)) continue;
      if (date <= currentDate) yearUsedDates.add(date);
      if (isFactual && date <= asOfDate) continue;
      (date <= currentDate ? usedDates : plannedDates).add(date);
    }
  });
  const allowance = vacationAllowance(employee, year);
  const prior = year > WORKFORCE_YEARS[0] ? vacationBalance(employee, year - 1, cache).remaining : 0;
  const carryover = isFactual ? Number(manual.factualRemaining) : prior;
  const accrued = isFactual && Number.isFinite(Number(manual?.accruedAfterSnapshot)) ? Number(manual.accruedAfterSnapshot) : 0;
  const adjustment = Number(manual?.adjustment || 0);
  const used = usedDates.size;
  const planned = plannedDates.size;
  const balance = { allowance, unit: vacationUnitLabel(employee), carryover, accrued, monthlyRate: vacationMonthlyRate(employee), adjustment, used, yearUsed: yearUsedDates.size, planned, isFactual, asOfDate, remaining: Math.max(0, (isFactual ? carryover + accrued : allowance + carryover) + adjustment - used - planned) };
  cache.set(cacheKey, balance);
  return balance;
}
function isVacationEligible(employee) { return Boolean(employee) && !isSubstituteOnly(employee); }
function isOfficeVacationDay(date) { const weekday = new Date(`${date}T12:00:00Z`).getUTCDay(); return weekday !== 0 && weekday !== 6 && !lithuanianCalendarDay(date).isHoliday; }
function isVacationDay(employee, date) { return isVacationChargeableDay(employee, date, state.workforce.shiftTeams); }
function vacationAllowance(employee, year) {
  const standard = employee.shiftTeamId === "office" ? OFFICE_VACATION_ALLOWANCE : SHIFT_VACATION_ALLOWANCE;
  const hireDate = String(employee.hireDate || "");
  if (!hireDate.startsWith(`${year}-`)) return standard;
  const start = new Date(`${hireDate}T12:00:00Z`), end = new Date(`${year}-12-31T12:00:00Z`);
  if (employee.shiftTeamId !== "office") {
    const team = state.workforce.shiftTeams.find(item => item.id === employee.shiftTeamId);
    let employed = 0, total = 0;
    for (let cursor = new Date(`${year}-01-01T12:00:00Z`); cursor <= end; cursor.setUTCDate(cursor.getUTCDate() + 1)) { const date = cursor.toISOString().slice(0, 10); if (!isVacationChargeableDay(employee, date, [team].filter(Boolean))) continue; total += 1; if (cursor >= start) employed += 1; }
    return total ? Number((standard * employed / total).toFixed(1)) : 0;
  }
  let employed = 0, total = 0;
  for (let cursor = new Date(`${year}-01-01T12:00:00Z`); cursor <= end; cursor.setUTCDate(cursor.getUTCDate() + 1)) { const date = cursor.toISOString().slice(0, 10); if (!isOfficeVacationDay(date)) continue; total += 1; if (cursor >= start) employed += 1; }
  return Math.round(standard * employed / total);
}

function renderPackagingPage() {
  const { records, operations, lastReadAt, error } = state.packaging;
  const status = error ? `Google недоступен: ${error}` : lastReadAt ? `Последнее чтение Google: ${formatDateTime(lastReadAt)}` : "Связь с Google ещё не проверена";
  const current = records.find(record => record.date === today());
  const selected = PACKAGING_FIELDS.find(field => field.key === state.packagingEntryItem) ?? null;
  const canSubmit = Boolean(selected);
  return `<section class="packaging-toolbar"><p>${escapeHtml(status)} · В очереди: <strong>${operations.length}</strong>${!APP_CONFIG.integration.googleWritesEnabled ? " · Отправка в Google выключена" : ""}</p><div class="packaging-toolbar-actions"><button class="secondary-button" data-action="sync-packaging">Обновить</button>${current ? `<button class="secondary-button" data-action="edit-packaging" data-id="${attribute(current.id)}">Исправить итог за сегодня</button>` : ""}</div></section>
    <section class="packaging-workspace"><article class="card packaging-catalog"><div class="section-heading"><div><p class="eyebrow">Сегодня</p><h2>Вид упаковки</h2><p>Нажмите на нужную позицию. Рядом показан уже взятый итог за день.</p></div></div><div class="packaging-item-list">${PACKAGING_DISPLAY_FIELDS.map(field => { const total = Number(current?.values?.[field.key] || 0); const active = selected?.key === field.key; return `<button type="button" class="packaging-item packaging-tone-${attribute(field.tone)} ${active ? "selected" : ""}" data-action="select-packaging-item" data-item="${attribute(field.key)}"><span><strong>${escapeHtml(shortPackagingLabel(field.label))}</strong><small>Уже взято сегодня</small></span><b>${formatNumber(total)} <small>${escapeHtml(packagingUnit(field))}</small></b></button>`; }).join("")}</div></article>
    <form class="card packaging-entry-panel ${selected ? `packaging-entry-colored packaging-tone-${attribute(selected.tone)}` : ""}" data-form="packaging-quick"><p class="eyebrow">Быстрый ввод</p><h2>${selected ? escapeHtml(shortPackagingLabel(selected.label)) : "Выберите упаковку"}</h2><p class="packaging-current-total">${selected ? `Уже взято: <strong>${formatNumber(Number(current?.values?.[selected.key] || 0))} ${escapeHtml(packagingUnit(selected))}</strong>` : "Сначала выберите позицию слева."}</p><input type="hidden" name="item" value="${attribute(selected?.key || "")}">${formField("packaging-quantity", "Количество", `<input id="packaging-quantity" name="quantity" type="number" min="1" step="1" inputmode="numeric" placeholder="0" required ${selected ? "" : "disabled"}>`, "Новое количество будет прибавлено к итогу за сегодня. Только целое положительное число.", "full")}<p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="submit" class="primary-button packaging-submit" ${canSubmit ? "" : "disabled"}>Прибавить к итогу</button></div></form></section>
    `;
}

function renderNonconformitiesPage() {
  const all = state.nonconformities.records ?? [];
  const month = today().slice(0, 7);
  const records = all.filter(record => record.date.startsWith(month)).sort((left, right) => right.date.localeCompare(left.date) || right.id.localeCompare(left.id));
  const categories = new Set(records.map(record => record.category).filter(Boolean));
  const reporters = new Set(records.map(record => record.reportedBy).filter(Boolean));
  const canWrite = canManageNonconformities();
  const canDelete = state.account?.role === "manager";
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · входящие несоответствия</p><h2>Несоответствия</h2><p>Фиксируются несоответствующие смесь, упаковка, материал или жидкость, поступившие на участок.</p></div><div class="header-actions"><button class="secondary-button" data-action="refresh-nonconformities" ${state.nonconformityLoading ? "disabled" : ""}>${state.nonconformityLoading ? "Обновляем…" : "Обновить"}</button>${state.account?.role === "manager" ? '<button class="secondary-button" data-action="manage-nonconformity-dictionary">Справочник</button>' : ""}${canWrite ? `<button class="primary-button" data-action="add-nonconformity">+ Новое несоответствие</button>` : ""}</div></section>
    ${state.nonconformities.error ? `<p class="form-error">${escapeHtml(state.nonconformities.error)}</p>` : ""}
    <div class="dashboard-grid production-metrics nonconformity-metrics"><article class="metric-card"><span>За текущий месяц</span><strong>${records.length}</strong><small>записей</small></article><article class="metric-card"><span>Категории</span><strong>${categories.size}</strong><small>за текущий месяц</small></article><article class="metric-card"><span>Сделали запись</span><strong>${reporters.size}</strong><small>сотрудников</small></article></div>
    <section class="card table-card nonconformity-table-card"><div class="table-toolbar"><div><span class="eyebrow">Текущий период</span><strong>${monthTitle(month)}</strong></div><span class="status-pill neutral">${records.length} ${plural(records.length, "запись", "записи", "записей")}</span></div><div class="table-scroll"><table><thead><tr><th>Дата и время</th><th>Смена</th><th>Категория</th><th>Вид</th><th>Предполагаемая причина</th><th>Корректирующие действия</th><th>Кто сделал запись</th>${canWrite ? "<th></th>" : ""}</tr></thead><tbody>${records.length ? records.map(record => `<tr><td>${formatDate(record.date)}${record.time ? `<br><small>${escapeHtml(record.time)}</small>` : ""}</td><td><strong>${escapeHtml(record.shift)}</strong></td><td>${escapeHtml(record.category)}</td><td>${escapeHtml(record.type)}</td><td>${escapeHtml(record.cause)}</td><td>${escapeHtml(record.correctiveAction)}</td><td>${escapeHtml(record.reportedBy)}</td>${canWrite ? `<td><div class="row-actions"><button class="small-button" data-action="edit-nonconformity" data-id="${attribute(record.id)}">Исправить</button>${canDelete ? `<button class="more-button" data-action="delete-nonconformity" data-id="${attribute(record.id)}" title="Удалить">×</button>` : ""}</div></td>` : ""}</tr>`).join("") : `<tr><td colspan="${canWrite ? 8 : 7}">За текущий месяц записей нет.</td></tr>`}</tbody></table></div><footer class="nonconformity-table-footer"><span>Дата, время и смена фиксируются автоматически.</span><span>Для исправления записи используйте «Исправить».</span></footer></section>`;
}

function shortPackagingLabel(label) {
  return label.replace(", шт", "").replace(", рул", "");
}

function renderPackagingWarehousePage() {
  const { records, summary, error } = state.packagingWarehouse;
  const orderedRecords = [...records].sort((left, right) => `${right.date}-${right.id}`.localeCompare(`${left.date}-${left.id}`));
  const canWrite = ["manager", "senior"].includes(state.account?.role);
  const canEdit = state.account?.role === "manager";
  const actions = canWrite ? `<div class="header-actions"><button class="secondary-button" data-action="refresh-packaging-warehouse">Обновить</button>${journalLink("packagingWarehouse") }<button class="primary-button" data-action="add-packaging-stock">+ Новое движение</button></div>` : journalLink("packagingWarehouse");
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · упаковочные материалы</p><h2>Склад упаковки</h2><p>Приход и расход сохраняются в общем журнале. Расчётный остаток считается автоматически, фактический заполняется при инвентаризации.</p>${error ? `<p class="form-error">${escapeHtml(error)}</p>` : ""}</div>${actions}</section>
    <section class="card table-card"><div class="table-toolbar"><strong>Остатки: расчёт и факт</strong><span>Общий склад</span></div><div class="table-scroll"><table><thead><tr><th>Наименование</th><th>Ед.</th><th>Начальный</th><th>Приход</th><th>Расход</th><th>Расчётный</th><th>Фактический</th><th>Разница</th><th>Комментарий</th></tr></thead><tbody>${summary.length ? summary.map(row => `<tr><td><strong>${escapeHtml(row.item)}</strong></td><td>${escapeHtml(row.unit || "—")}</td><td>${formatNumber(row.opening)}</td><td>${formatNumber(row.received)}</td><td>${formatNumber(row.issued)}</td><td><strong>${formatNumber(row.calculated)}</strong></td><td>${row.actual === null ? "—" : formatNumber(row.actual)}</td><td>${row.difference === null ? "—" : formatNumber(row.difference)}</td><td>${escapeHtml(row.note || "—")}</td></tr>`).join("") : '<tr><td colspan="9">Сводка склада ещё загружается.</td></tr>'}</tbody></table></div></section>
    <section class="card table-card"><div class="table-toolbar"><strong>Журнал движений</strong><span>${orderedRecords.length} ${plural(orderedRecords.length, "запись", "записи", "записей")}</span></div><div class="table-scroll"><table><thead><tr><th>Дата</th><th>Операция</th><th>Наименование</th><th>Количество</th><th>Примечание</th><th>Внёс</th>${canEdit ? "<th></th>" : ""}</tr></thead><tbody>${orderedRecords.length ? orderedRecords.map(record => `<tr><td>${formatDate(record.date)}</td><td><span class="status-pill ${record.type === "Приход" ? "success" : "warning"}">${escapeHtml(record.type)}</span></td><td>${escapeHtml(record.item)}</td><td><strong>${record.type === "Приход" ? "+" : "−"}${formatNumber(record.quantity)}</strong></td><td>${escapeHtml(record.note || "—")}</td><td>${escapeHtml(record.author || "—")}</td>${canEdit ? `<td><div class="row-actions"><button class="small-button" data-action="edit-packaging-stock" data-id="${attribute(record.id)}">Исправить</button><button class="more-button" data-action="delete-packaging-stock" data-id="${attribute(record.id)}" title="Удалить">×</button></div></td>` : ""}</tr>`).join("") : `<tr><td colspan="${canEdit ? 7 : 6}">Движений склада пока нет. Внесите первый приход или расход.</td></tr>`}</tbody></table></div></section>`;
}

function renderPartsWarehousePage() {
  const { items, operations, categories, error } = state.partsWarehouse;
  const canEdit = state.account?.role === "manager";
  const grouped = categories.map(category => [category, items.filter(item => item.category === category).sort((a, b) => a.name.localeCompare(b.name, "ru"))]);
  const orderedOperations = [...operations].sort((a, b) => `${b.date}-${b.id}`.localeCompare(`${a.date}-${a.id}`)).slice(0, 50);
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · остатки и списания</p><h2>Склад запчастей</h2><p>Запчасти сгруппированы по разделам. При сохранении ремонта выбранные позиции автоматически списываются со склада.</p>${error ? `<p class="form-error">${escapeHtml(error)}</p>` : ""}</div><div class="header-actions"><button class="secondary-button" data-action="refresh-parts-warehouse">Обновить</button>${canEdit ? '<button class="primary-button" data-action="add-parts-stock">+ Добавить запчасть</button>' : ""}</div></section>
    <section class="card parts-warehouse-filters"><div class="form-grid">${formField("parts-warehouse-category-filter", "Раздел", `<select id="parts-warehouse-category-filter" data-parts-filter><option value="all">Все разделы</option>${categories.map(category => `<option value="${attribute(category)}">${escapeHtml(category)}</option>`).join("")}</select>`)}${formField("parts-warehouse-search", "Запчасть", '<input id="parts-warehouse-search" type="search" data-parts-filter placeholder="Название или код запчасти" autocomplete="off">')}</div><small data-parts-filter-count>${items.length} ${plural(items.length, "позиция", "позиции", "позиций")}</small></section>
    ${grouped.map(([category, rows]) => `<section class="card table-card" data-parts-category-card data-parts-category="${attribute(category)}"><div class="table-toolbar"><strong>${escapeHtml(category)}</strong><span>${rows.length} ${plural(rows.length, "позиция", "позиции", "позиций")}</span></div><div class="table-scroll"><table><thead><tr><th>Запчасть</th><th>Ед.</th><th>Остаток</th><th>Мин. остаток</th><th>Примечание</th>${canEdit ? "<th></th>" : ""}</tr></thead><tbody>${rows.length ? rows.map(item => `<tr class="${item.quantity <= item.minimum ? "warehouse-low-stock" : ""}" data-parts-row data-parts-category="${attribute(category)}" data-parts-search="${attribute(`${item.id} ${item.name}`.toLocaleLowerCase(localeCode()))}"><td><strong>${escapeHtml(item.name)}</strong><br><small>${escapeHtml(item.id)}</small></td><td>${escapeHtml(item.unit)}</td><td><strong>${formatNumber(item.quantity)}</strong></td><td>${formatNumber(item.minimum)}</td><td>${escapeHtml(item.note || "—")}</td>${canEdit ? `<td><div class="row-actions"><button class="small-button" data-action="receive-parts-stock" data-id="${attribute(item.id)}">Приход</button><button class="small-button" data-action="adjust-parts-stock" data-id="${attribute(item.id)}">Остаток</button></div></td>` : ""}</tr>`).join("") : `<tr><td colspan="${canEdit ? 6 : 5}">В этом разделе запчастей пока нет.</td></tr>`}</tbody></table></div></section>`).join("")}
    <section class="card table-card"><div class="table-toolbar"><strong>Последние операции</strong><span>${operations.length} ${plural(operations.length, "запись", "записи", "записей")}</span></div><div class="table-scroll"><table><thead><tr><th>Дата</th><th>Операция</th><th>Запчасть</th><th>Количество</th><th>Остаток</th><th>Источник</th><th>Исполнитель</th></tr></thead><tbody>${orderedOperations.length ? orderedOperations.map(operation => `<tr><td>${formatDate(operation.date)}</td><td>${escapeHtml(operation.type)}</td><td>${escapeHtml(operation.name)}</td><td>${formatNumber(operation.quantity)}</td><td>${formatNumber(operation.balance)}</td><td>${escapeHtml(operation.source || "—")}</td><td>${escapeHtml(operation.author || "—")}</td></tr>`).join("") : '<tr><td colspan="7">Операций склада пока нет.</td></tr>'}</tbody></table></div></section>`;
}

function renderPpeWarehousePage() {
  const { items, records, error } = state.ppeWarehouse;
  const canWrite = state.account?.role === "manager";
  const orderedRecords = [...records].sort((left, right) => `${right.date}-${right.id}`.localeCompare(`${left.date}-${left.id}`));
  const pending = orderedRecords.filter(record => record.status !== "Отправлено");
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · остатки и выдача</p><h2>Склад СИЗ</h2><p>Остатки читаются из сводной таблицы. Каждая выдача сначала сохраняется в отдельном журнале СИЗ, затем попадает в расход нужного месяца листа «Фасовка».</p>${error ? `<p class="form-error">${escapeHtml(error)}</p>` : ""}</div>${canWrite ? `<div class="header-actions"><button class="secondary-button" data-action="refresh-ppe-warehouse">Обновить</button>${journalLink("ppeWarehouse", "Журнал выдач СИЗ ↗")}<button class="primary-button" data-action="add-ppe-issue">+ Внести выдачу</button></div>` : ""}</section>
    <section class="card table-card"><div class="table-toolbar"><strong>Остатки по сводной таблице</strong><span>${items.length} ${plural(items.length, "позиция", "позиции", "позиций")}</span></div><div class="table-scroll"><table><thead><tr><th>Наименование</th><th>Ед.</th><th>Остаток</th></tr></thead><tbody>${items.length ? items.map(row => `<tr><td><strong>${escapeHtml(row.item)}</strong></td><td>${escapeHtml(row.unit || "—")}</td><td><strong>${formatNumber(row.quantity)}</strong></td></tr>`).join("") : '<tr><td colspan="3">Остатки ещё загружаются.</td></tr>'}</tbody></table></div></section>
    <section class="card table-card"><div class="table-toolbar"><strong>Промежуточный журнал выдач</strong><span>${pending.length ? `${pending.length} требуют отправки` : "Все записи переданы"}</span></div><div class="table-scroll"><table><thead><tr><th>Дата</th><th>Наименование</th><th>Количество</th><th>Месяц</th><th>Взял</th><th>Примечание</th><th>Статус</th><th></th></tr></thead><tbody>${orderedRecords.length ? orderedRecords.map(record => `<tr><td>${formatDate(record.date)}</td><td><strong>${escapeHtml(record.item)}</strong><br><small>${escapeHtml(record.unit || "")}</small></td><td><strong>−${formatNumber(record.quantity)}</strong></td><td>${escapeHtml(record.month || "—")}</td><td>${escapeHtml(record.author || "—")}</td><td>${escapeHtml(record.note || "—")}${record.error ? `<br><small class="form-error">${escapeHtml(record.error)}</small>` : ""}</td><td><span class="status-pill ${record.status === "Отправлено" ? "success" : "warning"}">${escapeHtml(record.status)}</span></td><td>${canWrite && ["Ошибка", "В очереди"].includes(record.status) ? `<button class="small-button" data-action="retry-ppe-issue" data-id="${attribute(record.id)}">Повторить</button>` : ""}</td></tr>`).join("") : '<tr><td colspan="8">Выдач пока нет.</td></tr>'}</tbody></table></div></section>`;
}

function renderShiftTasksPage() {
  const manager = state.account?.role === "manager";
  const senior = state.account?.role === "senior";
  const shiftCode = currentShiftTaskCode();
  const records = (state.shiftTasks.records || []).filter(record => manager || isShiftTaskVisible(record, shiftCode)).sort((left, right) =>
    Number(left.status === "Выполнено") - Number(right.status === "Выполнено")
    || String(right.createdDate).localeCompare(String(left.createdDate))
    || String(right.id).localeCompare(String(left.id))
  );
  const open = records.filter(record => record.status !== "Выполнено");
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · задания между сменами</p><h2>Сменное задание</h2><p>Незавершённые задания остаются в напоминании каждой следующей смены, пока старший механик не отметит выполнение.</p>${state.shiftTasks.error ? `<p class="form-error">${escapeHtml(state.shiftTasks.error)}</p>` : ""}</div>${manager ? `<div class="header-actions"><button class="secondary-button" data-action="refresh-shift-tasks">Обновить</button>${journalLink("shiftTasks", "Открыть журнал ↗")}<button class="primary-button" data-action="add-shift-task">+ Новое задание</button></div>` : ""}</section>
    <div class="dashboard-grid production-metrics"><article class="metric-card"><span>Открыты</span><strong>${open.length}</strong><small>требуют отметки о выполнении</small></article><article class="metric-card"><span>Всего</span><strong>${records.length}</strong><small>заданий в общем журнале</small></article></div>
    <section class="card table-card"><div class="table-toolbar"><strong>Сменные задания${manager ? "" : ` · смена ${shiftCode || "не определена"}`}</strong><span>${open.length ? `Открыто: ${open.length}` : "Незавершённых нет"}</span></div><div class="table-scroll"><table><thead><tr><th>Поставлено</th><th>Задание</th><th>Для смены</th><th>Фото</th><th>Статус</th><th>Отметки</th><th>Примечание</th>${manager || senior ? "<th></th>" : ""}</tr></thead><tbody>${records.length ? records.map(record => `<tr><td>${formatDate(record.createdDate)}</td><td><strong>${escapeHtml(record.task)}</strong><br><small>Поставил: ${escapeHtml(record.createdBy || "—")}</small></td><td><strong>${escapeHtml(record.shiftTarget || "A,B")}</strong></td><td>${record.photoFileId ? `<a class="small-button" href="${attribute(`${APP_CONFIG.integration.gatewayBaseUrl}/api/shift-task-photo/${record.photoFileId}`)}" target="_blank" rel="noopener">Открыть ↗</a>` : "—"}</td><td><span class="status-pill ${record.status === "Выполнено" ? "success" : "warning"}">${escapeHtml(record.status)}</span></td><td>${shiftTaskCompletionLabel(record)}</td><td>${escapeHtml(record.completionNote || "—")}</td>${manager || senior ? `<td><div class="row-actions">${canCompleteShiftTask(record, shiftCode) ? `<button class="small-button" data-action="complete-shift-task" data-id="${attribute(record.id)}">Выполнено</button>` : ""}${manager ? `<button class="small-button" data-action="edit-shift-task" data-id="${attribute(record.id)}">Изменить</button><button class="more-button" data-action="delete-shift-task" data-id="${attribute(record.id)}" title="Удалить">×</button>` : ""}</div></td>` : ""}</tr>`).join("") : `<tr><td colspan="${manager || senior ? 8 : 7}">${manager ? "Сменных заданий пока нет." : `Для смены ${shiftCode || ""} заданий нет.`}</td></tr>`}</tbody></table></div></section>`;
}

function currentShiftTaskCode() {
  const teamId = isCurrentSharedShift() ? state.shift?.shiftTeamId : state.selectedShiftTeamId;
  return String(teamById(teamId)?.code || "").toUpperCase();
}

function isShiftTaskVisible(record, shiftCode) {
  if (!["A", "B"].includes(shiftCode)) return false;
  if (record.shiftTarget === "A и B") return shiftCode === "A" ? !record.completionA : !record.completionB;
  return record.shiftTarget === "A,B" || record.shiftTarget === shiftCode;
}

function openShiftTasksForAccount() {
  const records = state.shiftTasks.records || [];
  if (state.account?.role === "manager") return records.filter(record => record.status !== "Выполнено");
  const shiftCode = currentShiftTaskCode();
  return records.filter(record => record.status !== "Выполнено" && isShiftTaskVisible(record, shiftCode));
}

function sidebarNotificationCount(page) {
  if (page === "shift-tasks") return openShiftTasksForAccount().length;
  if (page === "attendance") return state.account?.role === "senior" && !state.shift?.active ? 1 : 0;
  if (page === "journals") {
    const reminder = getScaleControlReminder({ date: today(), team: scheduledTeam(), records: state.records });
    return ["manager", "senior"].includes(state.account?.role) && reminder ? 1 : 0;
  }
  if (page === "cyclones") return pendingCycloneCleaningDates(state.cyclones.records).length;
  return 0;
}

function canCompleteShiftTask(record, shiftCode) {
  if (record.status === "Выполнено") return false;
  if (record.shiftTarget === "A и B") return state.account?.role === "senior" && isShiftTaskVisible(record, shiftCode);
  return state.account?.role === "manager" || (state.account?.role === "senior" && isShiftTaskVisible(record, shiftCode));
}

function shiftTaskCompletionLabel(record) {
  if (record.shiftTarget !== "A и B") return record.completedBy ? `${escapeHtml(record.completedBy)}${record.completedDate ? `<br><small>${formatDate(record.completedDate)}</small>` : ""}` : "—";
  return `<small>A: ${escapeHtml(record.completionA || "ожидается")}<br>B: ${escapeHtml(record.completionB || "ожидается")}</small>`;
}

function renderIncidentsPage() {
  const records = [...state.incidents.records].sort((left, right) => `${right.date}-${right.id}`.localeCompare(`${left.date}-${left.id}`));
  const open = records.filter(record => record.status !== "Закрыт").length;
  const categories = new Set(records.map(record => record.category).filter(Boolean));
  const canWrite = canManageIncidents();
  return `<section class="section-heading"><div><p class="eyebrow">Google Sheets · единый журнал</p><h2>Журнал регистрации инцидентов</h2><p>Выберите категорию и конкретный случай из справочника — программа подскажет ответственных, адресатов и первые действия. Вручную внесите только фактические обстоятельства и выполненные действия.</p></div><div class="header-actions"><button class="secondary-button" data-action="refresh-incidents" ${state.incidentLoading ? "disabled" : ""}>${state.incidentLoading ? "Обновляем…" : "Обновить"}</button>${canWrite ? '<button class="primary-button" data-action="add-incident">+ Новый инцидент</button>' : ""}</div></section>
    ${state.incidents.error ? `<p class="form-error">${escapeHtml(state.incidents.error)}</p>` : ""}
    <div class="dashboard-grid production-metrics"><article class="metric-card"><span>За всё время</span><strong>${records.length}</strong><small>записей в общем журнале</small></article><article class="metric-card"><span>Требуют завершения</span><strong>${open}</strong><small>статус не «Закрыт»</small></article><article class="metric-card"><span>Категории</span><strong>${categories.size}</strong><small>использованы в журнале</small></article></div>
    <section class="card table-card"><div class="table-toolbar"><strong>Все инциденты</strong><span>${records.length} ${plural(records.length, "запись", "записи", "записей")}</span></div><div class="table-scroll"><table><thead><tr><th>Дата</th><th>Смена</th><th>Линия / оборудование</th><th>Категория</th><th>Что случилось</th><th>Фактическое описание</th><th>Меры сразу</th><th>Корректирующие действия</th><th>Старший механик</th><th>Статус</th>${canWrite ? "<th></th>" : ""}</tr></thead><tbody>${records.length ? records.map(record => `<tr><td>${formatDate(record.date)}</td><td><strong>${escapeHtml(record.shift)}</strong></td><td>${escapeHtml(record.equipment)}</td><td>${escapeHtml(record.category)}</td><td>${escapeHtml(record.type)}</td><td>${escapeHtml(record.description)}</td><td>${escapeHtml(record.immediateAction)}</td><td>${escapeHtml(record.correctiveAction)}</td><td>${escapeHtml(record.seniorMechanic)}</td><td><span class="status-pill ${record.status === "Закрыт" ? "success" : "warning"}">${escapeHtml(record.status)}</span></td>${canWrite ? `<td><div class="row-actions"><button class="small-button" data-action="edit-incident" data-id="${attribute(record.id)}">Исправить</button><button class="more-button" data-action="delete-incident" data-id="${attribute(record.id)}" title="Удалить">×</button></div></td>` : ""}</tr>`).join("") : `<tr><td colspan="${canWrite ? 11 : 10}">Инцидентов пока не зарегистрировано.</td></tr>`}</tbody></table></div></section>`;
}

function packagingUnit(field) {
  return field.label.includes(", рул") ? "рул." : "шт.";
}

function renderCyclonesPage() {
  const { records, operations, lastReadAt, error } = state.cyclones;
  const stats = cycloneStatistics(records, state.cycloneYear);
  const years = [...new Set([Number(today().slice(0, 4)), state.cycloneYear, ...records.map(r => Number(r.date.slice(0, 4)))])].sort((a, b) => b - a);
  const monthNames = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];
  const max = Math.max(1, ...stats.months);
  const status = error ? `Google недоступен: ${error}` : lastReadAt ? `Последнее чтение Google: ${formatDateTime(lastReadAt)}` : "Связь с Google ещё не проверена";
  const journalRecords = [...records].sort((left, right) => `${right.date}-${right.id}`.localeCompare(`${left.date}-${left.id}`));
  const journalSection = `<section class="card settings-table-wrap cyclone-records"><h3>Записи журнала</h3><table class="settings-data-table"><thead><tr><th>Дата</th><th>Исполнитель</th><th>Состояние</th></tr></thead><tbody>${journalRecords.map(r => `<tr><td>${formatDate(r.date)}</td><td>${escapeHtml(r.performer)}</td><td>${r.syncState === "synced" ? "Подтверждено Google" : "Ожидает отправки"}${operations.find(o => o.record.id === r.id)?.error ? `<br><small>${escapeHtml(operations.find(o => o.record.id === r.id).error)}</small>` : ""}</td></tr>`).join("") || '<tr><td colspan="3">Записи ещё не загружены. Можно сохранить новую очистку в локальную очередь.</td></tr>'}</tbody></table></section>`;
  return `<section class="card cyclone-heading"><div><h2>Очистка циклонов</h2><p>${escapeHtml(status)}</p>
    ${!APP_CONFIG.integration.googleWritesEnabled ? '<p class="cyclone-warning">Отправка в Google выключена. Новые записи сохраняются в очередь на этом компьютере.</p>' : ""}
    <p>В очереди: <strong>${operations.length}</strong>. ${operations.length ? "Эти записи ещё не подтверждены Google." : ""}</p></div>
    <div class="dialog-actions"><button class="secondary-button" data-action="sync-cyclones">Обновить и отправить очередь</button><button class="primary-button" data-action="new-cyclone">Записать очистку</button></div></section>
    ${journalSection}
    <section class="card cyclone-statistics"><div><h3>Статистика</h3><label>Год <select data-cyclone-year>${years.map(y => `<option ${y === state.cycloneYear ? "selected" : ""}>${y}</option>`).join("")}</select></label>
    <p>Подтверждено Google: <strong>${stats.total}</strong></p>
    <table class="settings-data-table"><thead><tr><th>Месяц</th><th>Очисток</th></tr></thead><tbody>${stats.months.map((n, i) => `<tr><td>${monthNames[i]}</td><td>${n}</td></tr>`).join("")}</tbody></table>
    <h3>По сотрудникам</h3><table class="settings-data-table"><thead><tr><th>Сотрудник</th><th>Очисток</th></tr></thead><tbody>${stats.people.map(([name, n]) => `<tr><td>${escapeHtml(name)}</td><td>${n}</td></tr>`).join("") || '<tr><td colspan="2">Нет подтверждённых записей за год</td></tr>'}</tbody></table></div>
    <div><h3>Очистки по месяцам — ${state.cycloneYear}</h3><div class="cyclone-chart" role="img" aria-label="${attribute(stats.months.map((n, i) => `${monthNames[i]}: ${n}`).join(", "))}">${stats.months.map((n, i) => `<div class="cyclone-chart-column"><span>${n}</span><div class="cyclone-chart-track"><div style="height:${n / max * 100}%"></div></div><small>${monthNames[i]}</small></div>`).join("")}</div><p>${lastReadAt ? "Статистика рассчитана по последним прочитанным данным Google. Записи в очереди не включены." : "После подключения Google здесь появятся данные рабочего журнала."}</p></div></section>`;
}

function openMaintenanceDialog(journalType) {
  const isRepair = journalType === "repair";
  const journal = isRepair ? state.maintenance.repair : state.maintenance.service;
  const title = isRepair ? "Добавить запись о ремонте" : "Добавить запись о ТО";
  const machines = journal.machines ?? Array.from({ length: 16 }, (_, index) => index + 1);
  const performers = operationalAuthorNames().length ? operationalAuthorNames() : (journal.performers ?? []);
  const categories = journal.categories ?? [];
  const workByCategory = journal.workByCategory ?? {};
  const optionList = (items, placeholder) => `<option value="">${placeholder}</option>${items.map(item => `<option value="${attribute(item)}">${escapeHtml(item)}</option>`).join("")}`;
  const warehouseCategories = state.partsWarehouse.categories ?? [];
  const repairParts = isRepair ? `<section id="repair-parts" class="repair-parts field" hidden><span>Запчасти со склада</span><div id="repair-parts-list"><small>Выберите раздел справа, затем запчасть и количество.</small></div><button type="button" class="small-button" data-add-repair-part>+ Добавить ещё запчасть</button></section>` : "";
  const repairFields = isRepair ? `<div class="form-grid">${formField("maintenance-category", "Категория работ", `<select id="maintenance-category" name="category" required>${optionList(categories, "Выберите категорию")}</select>`)}${formField("maintenance-parts-category", "Раздел", `<select id="maintenance-parts-category" disabled><option value="">Сначала выберите «Ремонт»</option>${warehouseCategories.map(category => `<option value="${attribute(category)}">${escapeHtml(category)}</option>`).join("")}</select>`)}</div>${repairParts}${formField("maintenance-work", "Виды работ", `<div id="maintenance-work-options" class="maintenance-work-options" aria-live="polite"><small>Сначала выберите категорию.</small></div>`, "Отметьте нужные работы маленькими квадратами. Каждая работа показана отдельной строкой; в Google будет одна общая запись.")}` : "";
  const dialog = createDialog(`<form class="dialog-card"><div class="dialog-heading"><div><p class="eyebrow">${isRepair ? "Журнал ремонта" : "Журнал ТО"}</p><h2>${title}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
    <p>Запись будет сразу внесена в соответствующий лист рабочего журнала Google.</p>
    <div class="form-grid">${formField("maintenance-date", "Дата", `<input id="maintenance-date" name="date" type="date" value="${today()}" max="${today()}" required>`)}${formField("maintenance-machine", "Станок", `<select id="maintenance-machine" name="machine" required>${optionList(machines.map(machine => String(machine).padStart(2, "0")), "Выберите станок")}</select>`)}</div>
    ${repairFields}
    ${formField("maintenance-performer", "Исполнитель", `<select id="maintenance-performer" name="performer" required>${optionList(performers, "Выберите исполнителя")}</select>`)}
    ${formField("maintenance-note", "Примечание", `<textarea id="maintenance-note" name="note" rows="3" maxlength="5000" placeholder="При необходимости укажите детали выполненных работ"></textarea>`, "Для ремонта с пометкой «описать в примечании» поле обязательно.")}
    <p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Внести в журнал</button></div></form>`);
  const form = dialog.querySelector("form");
  const categorySelect = form.elements.category;
  const workOptions = form.querySelector("#maintenance-work-options");
  const renderWorkOptions = works => {
    workOptions.innerHTML = works.length ? works.map(work => `<label><input type="checkbox" name="work" value="${attribute(work)}"><span>${escapeHtml(work)}</span></label>`).join("") : "<small>Нет вариантов в справочнике.</small>";
  };
  if (isRepair) {
    const repairPartsSection = form.querySelector("#repair-parts");
    const partList = form.querySelector("#repair-parts-list");
    const partsCategorySelect = form.querySelector("#maintenance-parts-category");
    const updatePartOptions = (row, category) => {
      const select = row.querySelector("[data-part-id]");
      const parts = state.partsWarehouse.items.filter(item => item.category === category);
      select.disabled = !parts.length;
      select.innerHTML = `<option value="">${parts.length ? "Выберите запчасть" : "Нет запчастей в этом разделе"}</option>${parts.map(item => `<option value="${attribute(item.id)}">${escapeHtml(`${item.name} · ${formatNumber(item.quantity)} ${item.unit}`)}</option>`).join("")}`;
    };
    const renderPartRow = ({ category = "", primary = false } = {}) => {
      const row = document.createElement("div");
      row.className = "form-grid repair-part-row";
      if (primary) row.dataset.primaryPart = "true";
      const categoryOptions = optionList(warehouseCategories, "Выберите раздел");
      const categoryField = primary ? "" : formField("", "Раздел", `<select data-part-category>${categoryOptions}</select>`);
      row.innerHTML = `${categoryField}${formField("", "Запчасть", '<select data-part-id disabled><option value="">Сначала выберите раздел</option></select>')}${formField("", "Количество", '<input data-part-quantity type="number" min="0.001" step="0.001" required>')}<button type="button" class="more-button" data-remove-repair-part title="Убрать">×</button>`;
      const categorySelect = row.querySelector("[data-part-category]");
      if (categorySelect) categorySelect.addEventListener("change", event => updatePartOptions(row, event.target.value));
      if (category) updatePartOptions(row, category);
      row.querySelector("[data-remove-repair-part]").addEventListener("click", () => {
        row.remove();
        if (!partList.querySelector(".repair-part-row")) partList.innerHTML = "<small>Выберите раздел справа, затем запчасть и количество.</small>";
      });
      return row;
    };
    const updateRepairPartsVisibility = () => {
      const isRepairCategory = categorySelect.value === "Ремонт";
      repairPartsSection.hidden = !isRepairCategory;
      partsCategorySelect.disabled = !isRepairCategory;
      if (!isRepairCategory) {
        partsCategorySelect.value = "";
        partList.innerHTML = "<small>Выберите раздел справа, затем запчасть и количество.</small>";
      }
    };
    categorySelect.addEventListener("change", () => {
      const works = workByCategory[categorySelect.value] ?? [];
      renderWorkOptions(works);
      updateRepairPartsVisibility();
    });
    partsCategorySelect.addEventListener("change", event => {
      const selectedCategory = event.target.value;
      const existing = partList.querySelector("[data-primary-part]");
      if (!selectedCategory) { existing?.remove(); return; }
      if (partList.querySelector("small")) partList.innerHTML = "";
      if (existing) {
        updatePartOptions(existing, selectedCategory);
      } else {
        partList.prepend(renderPartRow({ category: selectedCategory, primary: true }));
      }
    });
    form.querySelector("[data-add-repair-part]").addEventListener("click", () => {
      if (partList.querySelector("small")) partList.innerHTML = "";
      partList.append(renderPartRow());
    });
  }
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    if (isRepair) { data.work = [...new Set(formData.getAll("work").map(value => String(value).trim()).filter(Boolean))].join("; "); data.parts = [...form.querySelectorAll(".repair-part-row")].map(row => ({ id: row.querySelector("[data-part-id]")?.value || "", quantity: row.querySelector("[data-part-quantity]")?.value || "" })); }
    if (isRepair && !data.work) { showFormError(form, new Error("Выберите хотя бы один вид работ.")); return; }
    if (isRepair && /описать в примечании/i.test(data.work || "") && !String(data.note || "").trim()) {
      showFormError(form, new Error("Для выбранного вида работ заполните примечание.")); return;
    }
    const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try {
      const response = await fetch(`${APP_CONFIG.integration.gatewayBaseUrl}/api/maintenance`, {
        method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ ...data, journal: journalType, requestId: `maintenance-${Date.now()}-${Math.random().toString(36).slice(2, 10)}` })
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload?.ok) throw new Error(payload?.message || "Не удалось внести запись в журнал.");
      dialog.close(); await refreshMaintenance(); render();
      toast(isRepair ? "Запись о ремонте внесена в Google журнал." : "Запись ТО внесена в Google журнал.", "success");
    } catch (error) { showFormError(form, error); submit.disabled = false; }
  });
  dialog.showModal();
}

async function openProductionDialog(record = null) {
  const editing = Boolean(record);
  if (!editing && !state.shift?.active) { toast("Сначала заполните табель и начните смену.", "warning"); return; }
  const draft = editing ? null : await productionService.draft();
  const initial = record || draft?.record || null;
  const present = presentShiftPersonnel();
  const packers = present.filter(person => person.role === "packer");
  const lineMechanics = present.filter(person => ["mechanic-operator", "mechanic", "senior-mechanic"].includes(person.role));
  const existingOperators = splitProductionParticipants(initial?.operator);
  const packerNames = [...new Set([...packers.map(person => person.fullName), ...(initial?.packer ? [initial.packer] : [])])];
  const lineMechanicNames = [...new Set([...lineMechanics.map(person => person.fullName), ...existingOperators])];
  if (!editing && (!packers.length || !lineMechanics.length)) { toast("В табеле должны быть отмечены присутствующий упаковщик и механик у линии.", "warning"); return; }
  const specifications = state.specifications.specifications ?? [];
  const strengths = [...new Set(specifications.map(item => Number(item.variant)).filter(Number.isFinite))].sort((a, b) => b - a);
  const optionList = (items, placeholder) => `<option value="">${placeholder}</option>${items.map(item => `<option value="${attribute(item)}">${escapeHtml(item)}</option>`).join("")}`;
  const lineMechanicOptions = (placeholder, excludedNames = []) => {
    const excluded = new Set(Array.isArray(excludedNames) ? excludedNames : [excludedNames]);
    return `<option value="">${placeholder}</option>${lineMechanicNames.filter(name => !excluded.has(name)).map(name => { const person = lineMechanics.find(item => item.fullName === name); return `<option value="${attribute(name)}">${escapeHtml(person ? `${name} · ${roleLabel(person.role)}` : name)}</option>`; }).join("")}`;
  };
  const dialog = createDialog(`<form class="dialog-card production-dialog"><div class="dialog-heading"><div><p class="eyebrow">Учёт продукции и брака</p><h2>${editing ? "Исправить запись" : "Завершить продукт"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>${draft ? '<p class="dialog-lead">Восстановлен неотправленный черновик. Проверьте данные и повторите сохранение.</p>' : ""}
    <div class="form-grid">${formField("production-date", "Дата", `<input id="production-date" name="date" type="date" value="${attribute(initial?.date || today())}" readonly>`)}${formField("production-shift", "Смена", `<input id="production-shift" name="shift" value="${attribute(initial?.shift || productionShiftCode())}" readonly>`)}${formField("production-strength", "Крепость, mg/g", `<select id="production-strength" name="strength" required>${optionList(strengths, "Выберите крепость")}</select>`)}${formField("production-product", "Продукт", `<select id="production-product" name="product" required disabled><option value="">Сначала выберите крепость</option></select>`)}${formField("production-catalog-line", "Линейка", `<select id="production-catalog-line" name="catalogLine" required disabled><option value="">Сначала выберите продукт</option></select>`)}</div>
    <div class="form-grid production-line-row">${formField("production-quantity", "Готовая продукция, шт", `<input id="production-quantity" name="quantity" type="number" min="0.001" step="0.001" required>`, "240 шт. = 1 кор.")}${formField("production-scrap", "Брак продукции, кг", `<input id="production-scrap" name="scrapKg" type="number" min="0" step="0.001" required>`)}${formField("production-can-scrap", "Брак банок, кг", `<input id="production-can-scrap" name="canScrapKg" type="number" min="0" step="0.001" value="${attribute(initial?.canScrapKg ?? 0)}" required>`, "", "can-scrap-field")}${formField("production-machine-line", "Линия (машина)", `<select id="production-machine-line" name="machineLine" required>${optionList(PRODUCTION_LINES, "Выберите линию")}</select>`, "", "machine-line-field")}</div>
    <div id="production-active-machines" class="field production-active-machines" hidden><span>Работавшие машины</span><div class="machine-check-list"><label><input type="checkbox" name="activeMachines" value="2"> 2</label><label><input type="checkbox" name="activeMachines" value="3"> 3</label><label><input type="checkbox" name="activeMachines" value="4"> 4</label><label><input type="checkbox" name="activeMachines" value="5"> 5</label><label><input type="checkbox" name="activeMachines" value="6"> 6</label><label><input type="checkbox" name="activeMachines" value="7"> 7</label><label><input type="checkbox" name="activeMachines" value="8"> 8</label><label><input type="checkbox" name="activeMachines" value="9"> 9</label><label><input type="checkbox" name="activeMachines" value="11"> 11</label><label><input type="checkbox" name="activeMachines" value="12"> 12</label><label><input type="checkbox" name="activeMachines" value="13"> 13</label><label><input type="checkbox" name="activeMachines" value="14"> 14</label><label><input type="checkbox" name="activeMachines" value="15"> 15</label><label><input type="checkbox" name="activeMachines" value="16"> 16</label></div><div class="machine-start-list" id="production-machine-start-times"><div class="machine-start-field" data-machine-start="11" hidden><label for="production-machine-start-11">Машина 11 включена с</label><input id="production-machine-start-11" type="time" name="machineStart-11"></div><div class="machine-start-field" data-machine-start="12" hidden><label for="production-machine-start-12">Машина 12 включена с</label><input id="production-machine-start-12" type="time" name="machineStart-12"></div><div class="machine-start-field" data-machine-start="13" hidden><label for="production-machine-start-13">Машина 13 включена с</label><input id="production-machine-start-13" type="time" name="machineStart-13"></div><div class="machine-start-field" data-machine-start="14" hidden><label for="production-machine-start-14">Машина 14 включена с</label><input id="production-machine-start-14" type="time" name="machineStart-14"></div><div class="machine-start-field" data-machine-start="15" hidden><label for="production-machine-start-15">Машина 15 включена с</label><input id="production-machine-start-15" type="time" name="machineStart-15"></div><div class="machine-start-field" data-machine-start="16" hidden><label for="production-machine-start-16">Машина 16 включена с</label><input id="production-machine-start-16" type="time" name="machineStart-16"></div></div><small id="production-active-machines-help"></small></div>
    <div class="form-grid">${formField("production-packer", "Упаковщик (мой выпуск)", `<select id="production-packer" name="packer" required>${optionList(packerNames, "Выберите себя")}</select>`)}${formField("production-operator", "Механик-оператор", `<select id="production-operator" name="operator" required>${lineMechanicOptions("Выберите механика-оператора")}</select>`)}</div>
    <div class="form-grid">${formField("production-start-time", "Время начала", `<input id="production-start-time" name="startTime" type="time" value="${attribute(initial?.startTime || "")}" required><small id="production-start-time-help"></small>`)}${formField("production-time", "Время окончания", `<input id="production-time" name="time" type="time" value="${attribute(initial?.time || currentVilniusTime())}" required>`)}</div>
    <div class="form-grid">${formField("production-operator-second", "Второй механик-оператор", `<select id="production-operator-second" name="operatorSecond">${lineMechanicOptions("Нет второго механика-оператора")}</select>`)}</div>
    <div id="production-second-operator-time" class="field production-second-time" hidden><span>Время работы второго механика-оператора</span><div class="production-second-time-inputs"><label><b>С</b><input id="production-operator-second-start" name="operatorSecondStartTime" type="time" aria-label="Время работы второго механика-оператора: с"></label><label><b>По</b><input id="production-operator-second-end" name="operatorSecondEndTime" type="time" aria-label="Время работы второго механика-оператора: по"></label></div></div>
    <div class="field production-operator-change"><label><input id="production-operator-change" name="operatorChanged" type="checkbox"> Смена механика-оператора</label></div>
    <div id="production-operator-change-fields" class="form-grid" hidden>${formField("production-operator-replacement", "Новый механик-оператор", `<select id="production-operator-replacement" name="operatorReplacement">${lineMechanicOptions("Выберите механика-оператора")}</select>`)}${formField("production-operator-first-time", "Время первого механика-оператора", `<div class="production-second-time-inputs"><label><b>С</b><input id="production-operator-start" name="operatorStartTime" type="time" aria-label="Время первого механика-оператора: с"></label><label><b>По</b><input id="production-operator-end" name="operatorEndTime" type="time" aria-label="Время первого механика-оператора: по"></label></div>`)}${formField("production-operator-replacement-time", "Время нового механика-оператора", `<div class="production-second-time-inputs"><label><b>С</b><input id="production-operator-replacement-start" name="operatorReplacementStartTime" type="time" aria-label="Время нового механика-оператора: с"></label><label><b>По</b><input id="production-operator-replacement-end" name="operatorReplacementEndTime" type="time" aria-label="Время нового механика-оператора: по"></label></div>`)}</div>
    ${formField("production-note", "Примечание", `<textarea id="production-note" name="note" rows="2" maxlength="5000" placeholder="При необходимости добавьте комментарий">${escapeHtml(initial?.note || "")}</textarea>`) }
    <p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">${editing ? "Сохранить исправления" : "Сохранить"}</button></div></form>`);
  const form = dialog.querySelector("form");
  const strength = form.elements.strength, product = form.elements.product, catalogLine = form.elements.catalogLine;
  const firstOperator = form.elements.operator, secondOperator = form.elements.operatorSecond, replacementOperator = form.elements.operatorReplacement;
  const operatorChange = form.elements.operatorChanged;
  const operatorChangeFields = form.querySelector("#production-operator-change-fields");
  const secondOperatorTime = form.querySelector("#production-second-operator-time");
  const machineLine = form.elements.machineLine;
  const activeMachines = form.querySelector("#production-active-machines");
  const activeMachinesHelp = form.querySelector("#production-active-machines-help");
  const machineStartTimes = form.querySelector("#production-machine-start-times");
  machineStartTimes.querySelectorAll("[data-machine-start]").forEach(field => {
    const machine = field.dataset.machineStart;
    const title = field.querySelector("label");
    const start = field.querySelector("input");
    title.textContent = `Машина ${machine}`;
    const inputs = document.createElement("div");
    inputs.className = "machine-interval-inputs";
    const startLabel = document.createElement("label");
    startLabel.innerHTML = "<b>С</b>";
    startLabel.append(start);
    const endLabel = document.createElement("label");
    endLabel.innerHTML = "<b>До</b>";
    const end = document.createElement("input");
    end.id = `production-machine-end-${machine}`;
    end.name = `machineEnd-${machine}`;
    end.type = "time";
    end.setAttribute("aria-label", `Время выключения машины ${machine}`);
    endLabel.append(end);
    inputs.append(startLabel, endLabel);
    field.append(inputs);
  });
  const startTime = form.elements.startTime;
  const endTime = form.elements.time;
  const startTimeHelp = form.querySelector("#production-start-time-help");
  const secondOperatorStart = form.elements.operatorSecondStartTime, secondOperatorEnd = form.elements.operatorSecondEndTime;
  const operatorStart = form.elements.operatorStartTime, operatorEnd = form.elements.operatorEndTime;
  const replacementStart = form.elements.operatorReplacementStartTime, replacementEnd = form.elements.operatorReplacementEndTime;
  const updateActiveMachines = () => {
    const line = machineLine.value;
    const allowed = { B: ["2", "3"], D: ["4", "5"], F: ["6", "7"], H: ["8", "9"], L: ["11", "12", "13"], M: ["14", "15", "16"] }[line] || [];
    activeMachines.hidden = !allowed.length;
    activeMachines.querySelectorAll('input[name="activeMachines"]').forEach(input => {
      input.hidden = !allowed.includes(input.value);
      input.closest("label").hidden = !allowed.includes(input.value);
      if (!allowed.includes(input.value)) input.checked = false;
    });
    const selectedMachines = [...activeMachines.querySelectorAll('input[name="activeMachines"]:checked')]
      .filter(input => allowed.includes(input.value));
    const useIndividualStartTimes = ["L", "M"].includes(line) && selectedMachines.length === allowed.length && allowed.length === 3;
    activeMachinesHelp.textContent = allowed.length
      ? useIndividualStartTimes
        ? `Отмечены все машины линии ${line}: укажите время включения каждой.`
        : `Отметьте работавшие машины линии ${line}. Время начала записи будет использовано для всех отмеченных машин.`
      : "";
    machineStartTimes.querySelectorAll("[data-machine-start]").forEach(field => {
      const machine = field.dataset.machineStart;
      const checkbox = activeMachines.querySelector(`input[value="${machine}"]`);
      const start = field.querySelector(`input[name="machineStart-${machine}"]`);
      const end = field.querySelector(`input[name="machineEnd-${machine}"]`);
      const show = Boolean(useIndividualStartTimes && checkbox?.checked && allowed.includes(machine));
      field.hidden = !show;
      start.disabled = !show;
      end.disabled = !show;
      if (show && !start.value) start.value = form.elements.startTime.value || "";
      if (show && !end.value) end.value = form.elements.time.value || "";
    });
  };
  const updateProductionStartTime = () => {
    if (editing) return;
    const operatorNames = [firstOperator.value, secondOperator.value].filter(Boolean).join(" + ");
    const ready = Boolean(machineLine.value && form.elements.packer.value && firstOperator.value && product.value && catalogLine.value);
    if (!ready) {
      startTimeHelp.textContent = "Сначала выберите линию, упаковщика, механика и продукт.";
      return;
    }
    const minimum = minimumProductionStartTime(state.production.records ?? [], {
      date: form.elements.date.value,
      shift: form.elements.shift.value,
      machineLine: machineLine.value,
      packer: form.elements.packer.value,
      operator: operatorNames,
      catalogLine: catalogLine.value,
      product: product.value,
      strength: strength.value,
      startTime: startTime.value
    });
    startTime.min = minimum || "19:30";
    if (!startTime.value || startTime.value < startTime.min) startTime.value = startTime.min;
    endTime.min = startTime.value;
    startTimeHelp.textContent = minimum
      ? `Раньше ${minimum} начать нельзя: учтены подготовка и переход.`
      : "В этой смене уже недостаточно рабочего времени для нового продукта.";
    updateActiveMachines();
  };
  const updateSecondOperatorOptions = () => {
    const selected = secondOperator.value;
    secondOperator.innerHTML = lineMechanicOptions("Нет второго механика-оператора", [firstOperator.value, replacementOperator.value]);
    if (selected && selected !== firstOperator.value && [...secondOperator.options].some(option => option.value === selected)) secondOperator.value = selected;
  };
  const updateReplacementOptions = () => {
    const selected = replacementOperator.value;
    replacementOperator.innerHTML = lineMechanicOptions("Выберите механика-оператора", [firstOperator.value, secondOperator.value]);
    if (selected && ![firstOperator.value, secondOperator.value].includes(selected) && [...replacementOperator.options].some(option => option.value === selected)) replacementOperator.value = selected;
  };
  const updateSecondOperatorTime = () => {
    const enabled = Boolean(secondOperator.value);
    secondOperatorTime.hidden = !enabled;
    [secondOperatorStart, secondOperatorEnd].forEach(input => { input.disabled = !enabled; });
    if (!enabled) {
      secondOperatorStart.value = "";
      secondOperatorEnd.value = "";
    }
  };
  const updateOperatorChange = () => {
    const enabled = operatorChange.checked;
    operatorChangeFields.hidden = !enabled;
    [replacementOperator, operatorStart, operatorEnd, replacementStart, replacementEnd].forEach(input => {
      input.disabled = !enabled;
      input.required = enabled;
    });
    if (!enabled) {
      replacementOperator.value = "";
      operatorStart.value = "";
      operatorEnd.value = "";
      replacementStart.value = "";
      replacementEnd.value = "";
    }
  };
  const matching = () => specifications.filter(item => String(item.variant) === String(strength.value));
  const fillProducts = () => {
    const names = [...new Set(matching().map(item => item.product))].sort((a, b) => a.localeCompare(b, "ru"));
    product.innerHTML = optionList(names, names.length ? "Выберите продукт" : "Нет подходящих продуктов"); product.disabled = !names.length; catalogLine.innerHTML = '<option value="">Сначала выберите продукт</option>'; catalogLine.disabled = true;
  };
  strength.addEventListener("change", fillProducts);
  product.addEventListener("change", () => {
    const lines = [...new Set(matching().filter(item => item.product === product.value).map(item => item.line))].sort((a, b) => a.localeCompare(b, "ru"));
    catalogLine.innerHTML = optionList(lines, lines.length ? "Выберите линейку" : "Нет вариантов"); catalogLine.disabled = !lines.length;
    updateProductionStartTime();
  });
  catalogLine.addEventListener("change", updateProductionStartTime);
  if (initial) {
    strength.value = String(initial.strength);
    fillProducts();
    product.value = initial.product;
    product.dispatchEvent(new Event("change"));
    catalogLine.value = initial.catalogLine || (catalogLine.options.length > 1 ? catalogLine.options[1].value : "");
    form.elements.quantity.value = initial.quantity;
    form.elements.scrapKg.value = initial.scrapKg;
    form.elements.canScrapKg.value = initial.canScrapKg;
    const initialLine = initial.line || initial.machineLine || "";
    form.elements.machineLine.value = initialLine;
    const selectedMachines = new Set((initial.activeMachines || []).map(String));
    // Older records do not contain a machine list. Preserve their former
    // full-line norm when the user opens and saves such a record.
    if (!selectedMachines.size) {
      const defaultMachines = { B: ["2", "3"], D: ["4", "5"], F: ["6", "7"], H: ["8", "9"], L: ["11", "12"], M: ["14", "15"] }[initialLine] || [];
      defaultMachines.forEach(machine => selectedMachines.add(machine));
    }
    activeMachines.querySelectorAll('input[name="activeMachines"]').forEach(input => { input.checked = selectedMachines.has(input.value); });
    activeMachines.querySelectorAll('input[name="activeMachines"]').forEach(input => {
      const start = form.elements[`machineStart-${input.value}`];
      const end = form.elements[`machineEnd-${input.value}`];
      if (start) start.value = initial.machineStartTimes?.[input.value] || initial.startTime || "";
      if (end) end.value = initial.machineEndTimes?.[input.value] || initial.time || "";
    });
    form.elements.packer.value = initial.packer;
    const replacement = initial.operatorReplacement || existingOperators[2] || "";
    firstOperator.value = initial.operator || existingOperators[0] || "";
    secondOperator.value = initial.operatorSecond || (existingOperators[1] === replacement ? "" : existingOperators[1] || "");
    secondOperatorStart.value = initial.operatorSecondStartTime || initial.startTime || "";
    secondOperatorEnd.value = initial.operatorSecondEndTime || initial.time || "";
    operatorChange.checked = Boolean(replacement);
    replacementOperator.value = replacement;
    operatorStart.value = initial.operatorStartTime || "";
    operatorEnd.value = initial.operatorEndTime || "";
    replacementStart.value = initial.operatorReplacementStartTime || "";
    replacementEnd.value = initial.operatorReplacementEndTime || "";
  }
  updateActiveMachines();
  updateSecondOperatorOptions();
  updateReplacementOptions();
  updateSecondOperatorTime();
  updateOperatorChange();
  updateProductionStartTime();
  firstOperator.addEventListener("change", () => { updateSecondOperatorOptions(); updateReplacementOptions(); updateProductionStartTime(); });
  secondOperator.addEventListener("change", () => { updateSecondOperatorTime(); updateReplacementOptions(); updateProductionStartTime(); });
  operatorChange.addEventListener("change", updateOperatorChange);
  machineLine.addEventListener("change", () => { updateActiveMachines(); updateProductionStartTime(); });
  activeMachines.addEventListener("change", updateActiveMachines);
  form.elements.packer.addEventListener("change", updateProductionStartTime);
  startTime.addEventListener("change", () => { endTime.min = startTime.value; updateActiveMachines(); });
  endTime.addEventListener("change", updateActiveMachines);
  // A failed HTTP response does not mean that Google rejected the write. Keep
  // one request id for the whole production dialog so a retry is idempotent.
  const createRequestId = editing ? "" : String(draft?.record?.requestId || `production-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`);
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const formData = new FormData(form);
    const selectedMachines = formData.getAll("activeMachines");
    const machineStartTimes = Object.fromEntries(selectedMachines.map(machine => [machine, form.elements[`machineStart-${machine}`]?.value || form.elements.startTime.value]));
    const machineEndTimes = Object.fromEntries(selectedMachines.map(machine => [machine, form.elements[`machineEnd-${machine}`]?.value || form.elements.time.value]));
    const data = { ...Object.fromEntries(formData), activeMachines: selectedMachines, machineStartTimes, machineEndTimes };
    delete data.operatorChanged;
    if (!catalogLine.value) { showFormError(form, new Error("Выберите линейку продукта")); return; }
    if (!editing && data.startTime < FIRST_PRODUCTION_START_TIME) { showFormError(form, new Error(`Первый продукт можно начать не раньше ${FIRST_PRODUCTION_START_TIME}.`)); return; }
    if (["B", "D", "F", "H", "L", "M"].includes(machineLine.value) && !data.activeMachines.length) { showFormError(form, new Error(`Отметьте работавшие машины линии ${machineLine.value}`)); return; }
    const submit = form.querySelector('[type="submit"]');
    const closeControls = [...dialog.querySelectorAll('[data-action="close-dialog"]')];
    submit.disabled = true;
    closeControls.forEach(control => { control.disabled = true; });
    submit.textContent = "Сохраняем…";
    let draftInput = null;
    try {
      const people = { packers: packerNames, operators: lineMechanicNames };
      const leadership = activeShiftLeadership();
      const finishedMassKg = productionFinishedMassKg(data, state.specifications.specifications);
      const scrapKg = Number(String(data.scrapKg ?? "").replace(",", "."));
      const scrapPercent = finishedMassKg > 0 && Number.isFinite(scrapKg)
        ? scrapKg / (finishedMassKg + scrapKg)
        : null;
      const productionInput = { ...data, leadership, scrapPercent };
      draftInput = { ...productionInput, requestId: createRequestId };
      // Save before the network request. If the application or gateway stops
      // while waiting for Google, the operator can reopen this exact entry.
      if (!editing) await productionService.saveDraft(draftInput);
      const saved = editing
        ? await productionService.update(record.id, productionInput, people)
        : await productionService.create(draftInput, people);
      if (!editing) await productionService.clearDraft();
      state.production = {
        ...state.production,
        records: [saved, ...(state.production.records ?? []).filter(item => item.id !== saved.id && item.id !== record?.id)],
        cachedAt: new Date().toISOString(),
        error: null
      };
      dialog.close();
      render();
      toast(editing ? "Исправления сохранены в журнале." : "Запись сохранена в журнал.", "success");
      void refreshProduction().then(() => render());
    } catch (error) {
      const savedDraftNote = !editing && draftInput ? " Введённые данные сохранены на этом компьютере — исправьте ошибку и повторите попытку." : "";
      showFormError(form, new Error(`${error.message || "Не удалось сохранить запись"}.${savedDraftNote}`));
      submit.disabled = false;
      submit.textContent = "Сохранить";
      closeControls.forEach(control => { control.disabled = false; });
    }
  });
  dialog.showModal();
}

function openNonconformityDialog(record = null) {
  if (!canManageNonconformities()) {
    toast("Вносить несоответствия могут старший механик и механик текущей смены.", "warning");
    return;
  }
  const dictionary = state.nonconformities.dictionary?.categories ?? [];
  const categories = [...new Set([...dictionary.map(item => item.category), ...(record?.category ? [record.category] : [])])];
  const reporters = [...new Set([...operationalAuthorNames(), ...(record?.reportedBy ? [record.reportedBy] : [])])];
  const optionList = (items, placeholder) => `<option value="">${placeholder}</option>${items.map(item => `<option value="${attribute(item)}">${escapeHtml(item)}</option>`).join("")}`;
  const dialog = createDialog(`<form class="dialog-card production-dialog"><div class="dialog-heading"><div><p class="eyebrow">Журнал несоответствий</p><h2>${record ? "Исправить запись" : "Новое несоответствие"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
    <p class="dialog-lead">Дата, время и смена фиксируются автоматически.</p>
    <input name="date" type="hidden" value="${attribute(record?.date || today())}"><input name="time" type="hidden" value="${attribute(record?.time || currentVilniusTime())}"><input name="shift" type="hidden" value="${attribute(record?.shift || productionShiftCode())}">
    <div class="form-grid">${formField("nonconf-category", "Категория несоответствия", `<select id="nonconf-category" name="category" required>${optionList(categories, "Выберите категорию")}</select>`)}${formField("nonconf-type", "Вид несоответствия", `<select id="nonconf-type" name="type" required disabled><option value="">Сначала выберите категорию</option></select>`)}</div>
    ${formField("nonconf-cause", "Предполагаемая причина появления", `<textarea id="nonconf-cause" name="cause" rows="3" maxlength="5000" required></textarea>`)}
    ${formField("nonconf-action", "Корректирующие действия", `<textarea id="nonconf-action" name="correctiveAction" rows="3" maxlength="5000" required></textarea>`)}
    ${formField("nonconf-reporter", "Кто сделал запись", `<select id="nonconf-reporter" name="reportedBy" required>${optionList(reporters, "Выберите сотрудника")}</select>`, "Старший механик или механик текущей смены.")}
    <p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">${record ? "Сохранить исправления" : "Внести в журнал"}</button></div></form>`);
  const form = dialog.querySelector("form");
  const updateTypes = (selected = "") => {
    const configuredTypes = dictionary.find(item => item.category === form.elements.category.value)?.types ?? [];
    const types = selected && !configuredTypes.includes(selected) ? [selected, ...configuredTypes] : configuredTypes;
    form.elements.type.disabled = !types.length;
    form.elements.type.innerHTML = optionList(types, types.length ? "Выберите вид" : "Сначала выберите категорию");
    form.elements.type.value = types.includes(selected) ? selected : "";
  };
  form.elements.category.addEventListener("change", () => updateTypes());
   if (record) { form.elements.category.value = record.category; updateTypes(record.type); form.elements.cause.value = record.cause; form.elements.correctiveAction.value = record.correctiveAction; form.elements.reportedBy.value = record.reportedBy; }
  form.addEventListener("submit", async event => {
    event.preventDefault(); const data = Object.fromEntries(new FormData(form)); const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
     try { if (record) await nonconformityService.update(record.id, data, reporters); else await nonconformityService.create({ ...data, requestId: `nonconformity-${Date.now()}-${Math.random().toString(36).slice(2, 10)}` }, reporters); dialog.close(); await refreshNonconformities(); render(); toast(record ? "Исправления сохранены в журнале." : "Несоответствие внесено в журнал.", "success"); }
    catch (error) { showFormError(form, error); submit.disabled = false; }
  });
  dialog.showModal();
}

function openNonconformityDictionaryDialog() {
  if (state.account?.role !== "manager") return;
  const entries = state.nonconformities.dictionary?.entries ?? [];
  const categories = [...new Set(entries.map(entry => entry.category))].sort((left, right) => left.localeCompare(right, "ru"));
  const dialog = createDialog(`<form class="dialog-card production-dialog" data-nonconformity-dictionary-form><div class="dialog-heading"><div><p class="eyebrow">Журнал несоответствий</p><h2>Справочник</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div><p class="dialog-lead">Добавьте вид в существующую или новую категорию. Удалённый вид остаётся в уже внесённых записях.</p><div class="form-grid">${formField("dictionary-category", "Категория", `<input id="dictionary-category" name="category" list="nonconformity-categories" maxlength="180" required><datalist id="nonconformity-categories">${categories.map(category => `<option value="${attribute(category)}">`).join("")}</datalist>`)}${formField("dictionary-type", "Вид несоответствия", '<input id="dictionary-type" name="type" maxlength="500" required>')}</div><p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Закрыть</button><button type="submit" class="primary-button">Добавить</button></div><section class="card table-card"><div class="table-scroll"><table><thead><tr><th>Категория</th><th>Вид</th><th></th></tr></thead><tbody>${entries.length ? entries.sort((left, right) => `${left.category}|${left.type}`.localeCompare(`${right.category}|${right.type}`, "ru")).map(entry => `<tr><td>${escapeHtml(entry.category)}</td><td>${escapeHtml(entry.type)}</td><td><button class="more-button" type="button" data-remove-nonconformity-dictionary-entry="${attribute(entry.id)}" title="Удалить">×</button></td></tr>`).join("") : '<tr><td colspan="3">Справочник пуст.</td></tr>'}</tbody></table></div></section></form>`);
  const form = dialog.querySelector("form");
  form.addEventListener("submit", async event => { event.preventDefault(); const submit = form.querySelector('[type="submit"]'); submit.disabled = true; try { await nonconformityService.createDictionaryEntry(Object.fromEntries(new FormData(form))); dialog.close(); await refreshNonconformities(); render(); toast("Вид добавлен в справочник.", "success"); } catch (error) { showFormError(form, error); submit.disabled = false; } });
  form.addEventListener("click", async event => { const button = event.target.closest("[data-remove-nonconformity-dictionary-entry]"); if (!button) return; if (!window.confirm("Удалить этот вид из справочника?")) return; button.disabled = true; try { await nonconformityService.removeDictionaryEntry(button.dataset.removeNonconformityDictionaryEntry); dialog.close(); await refreshNonconformities(); render(); toast("Вид удалён из справочника.", "success"); } catch (error) { showFormError(form, error); button.disabled = false; } });
  dialog.showModal();
}

async function refreshCyclonePersonnel() {
  if (navigator.onLine && workforceRepository) {
    try { state.workforce = await workforceRepository.refresh(); }
    catch { /* Keep the last verified list while offline or during a short Google outage. */ }
  }
  await reconcileCycloneQueuePerformers();
}

async function reconcileCycloneQueuePerformers() {
  return cycloneService.reconcilePerformers(activePersonnel().map(person => person.fullName));
}

async function openCycloneDialog() {
  await refreshCyclonePersonnel();
  const names = operationalAuthorNames();
  const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><h2>Записать очистку циклонов</h2><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
    ${formField("cyclone-date", "Дата очистки", `<input id="cyclone-date" name="date" type="date" value="${today()}" max="${today()}" required>`)}
    ${formField("cyclone-performer", "Кто выполнил очистку", `<select id="cyclone-performer" name="performer" required><option value="">Выберите сотрудника</option>${names.map(name => `<option>${escapeHtml(name)}</option>`).join("")}</select>`)}
    <p>Запись сначала сохранится на этом компьютере. Подтверждение Google появится после успешной отправки.</p>
    <p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Сохранить очистку</button></div></form>`);
  let saving = false;
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault();
    if (saving) return;
    saving = true;
    const form = event.currentTarget;
    form.querySelector('[type="submit"]').disabled = true;
    try {
      await cycloneService.create(Object.fromEntries(new FormData(form)), state.account, names);
      dialog.close();
      state.cyclones = await cycloneService.snapshot();
      render();
      toast("Очистка сохранена на этом компьютере. Ожидает подтверждения Google.", "success");
      if (navigator.onLine) { await refreshCyclones(true); render(); }
    } catch (error) {
      showFormError(form, error);
      saving = false;
      form.querySelector('[type="submit"]').disabled = false;
    }
  });
  dialog.showModal();
}

function filterSpecifications(specifications, selection, ignoredField = "") {
  return specifications.filter(item => ["line", "product", "variant"].every(field => {
    if (field === ignoredField || !selection[field]) return true;
    return String(item[field]) === String(selection[field]);
  }));
}

function uniqueSpecificationValues(specifications, field) {
  const values = [...new Set(specifications.map(item => String(item[field] ?? "")).filter(Boolean))];
  return field === "variant"
    ? values.sort((a, b) => Number(b) - Number(a))
    : values.sort((a, b) => a.localeCompare(b, "ru"));
}

function normalizeSpecificationSelection(specifications, selection, lockedField) {
  const next = { line: selection.line || "", product: selection.product || "", variant: selection.variant || "" };
  for (const field of ["line", "product", "variant"]) {
    if (field === lockedField || !next[field]) continue;
    if (!filterSpecifications(specifications, next).length) next[field] = "";
  }
  return next;
}

function specificationUsageKey(item) {
  return `${String(item.product ?? "").trim().toLocaleLowerCase("ru")}::${String(item.variant ?? item.strength ?? "").trim()}`;
}

function specificationUsageFrequency(records) {
  return records.reduce((frequency, record) => {
    const key = specificationUsageKey(record);
    if (key !== "::") frequency.set(key, (frequency.get(key) || 0) + 1);
    return frequency;
  }, new Map());
}

function renderSpecificationsPage() {
  const all = state.specifications?.specifications ?? [];
  const selection = state.specificationSelection;
  const query = state.specificationSearch.trim().toLocaleLowerCase("ru");
  const optionsFor = field => uniqueSpecificationValues(filterSpecifications(all, selection, field), field);
  const lines = optionsFor("line");
  const products = optionsFor("product");
  const variants = optionsFor("variant");
  const selectedCandidates = filterSpecifications(all, selection);
  const selected = selectedCandidates.length === 1 ? selectedCandidates[0] : null;
  const matching = filterSpecifications(all.filter(item => !query || [item.line, item.product, item.variant, item.processType, item.canType, item.lidColor].some(value => String(value ?? "").toLocaleLowerCase("ru").includes(query))), selection);
  const hasSelection = Object.values(selection).some(Boolean);
  const frequency = specificationUsageFrequency(state.production?.records ?? []);
  const catalog = [...matching].sort((a, b) => (frequency.get(specificationUsageKey(b)) || 0) - (frequency.get(specificationUsageKey(a)) || 0) || String(a.product).localeCompare(String(b.product), "ru") || String(a.line).localeCompare(String(b.line), "ru") || Number(b.variant) - Number(a.variant));
  const sourceLabel = state.specifications?.source === "google" ? "Google Sheets" : state.specifications?.source === "cache" ? "Офлайн-копия" : state.specifications?.source === "demo" ? "Демонстрационные данные" : "Источник недоступен";
  const error = state.specifications?.error ? `<p class="module-note">${escapeHtml(state.specifications.error)}. Можно открыть последнюю сохранённую копию при следующем запуске.</p>` : "";
  const canEdit = state.account?.role === "manager" && APP_CONFIG.integration.googleWritesEnabled;
  return `<section class="module-header card"><div><p class="eyebrow">${escapeHtml(sourceLabel)} · утверждённые нормы</p><h2>Спецификация продуктов</h2><p>${canEdit ? "Добавляйте и исправляйте продукты прямо в программе. Каталог обновляется из Google Sheets без ручного переноса." : "Рабочий каталог продуктов и технологических норм. Только просмотр."}</p></div><div class="header-actions"><button class="secondary-button" data-action="refresh-specifications">↻ Обновить каталог</button>${canEdit ? `<button class="primary-button" data-action="add-specification">+ Добавить продукт</button>` : ""}<a class="quiet-link" href="https://docs.google.com/spreadsheets/d/${PRODUCT_SPECIFICATION_SOURCE.spreadsheetId}/edit" target="_blank" rel="noreferrer">Источник Google ↗</a></div></section>
    ${error}
    <section class="card specification-picker"><div class="catalog-search-row"><label class="personnel-search"><span>Поиск по каталогу</span><input type="search" value="${attribute(state.specificationSearch)}" data-specification-search placeholder="Название продукта, линейка, mg/g, банка или крышка" autocomplete="off"></label><span class="status-pill neutral">${matching.length} из ${all.length} позиций</span></div><div class="form-grid">
      ${formField("spec-line", "Линейка", `<select id="spec-line" data-specification-select="line"><option value="">Все линейки</option>${lines.map(line => `<option value="${attribute(line)}" ${selection.line === line ? "selected" : ""}>${escapeHtml(line)}</option>`).join("")}</select>`)}
      ${formField("spec-product", "Продукт", `<select id="spec-product" data-specification-select="product"><option value="">Все продукты</option>${products.map(product => `<option value="${attribute(product)}" ${selection.product === product ? "selected" : ""}>${escapeHtml(product)}</option>`).join("")}</select>`)}
      ${formField("spec-variant", "mg/g", `<select id="spec-variant" data-specification-select="variant"><option value="">Все варианты</option>${variants.map(variant => `<option value="${attribute(variant)}" ${selection.variant === variant ? "selected" : ""}>${escapeHtml(variant)}</option>`).join("")}</select>`)}
    </div></section>
    <section class="specification-workspace"><section class="card specification-catalog"><div class="section-heading"><div><p class="eyebrow">Каталог</p><h2>${query || hasSelection ? "Результаты выбора" : "Быстрый выбор"}</h2>${query || hasSelection ? "" : "<p>Сначала — позиции, которые чаще всего встречаются в журнале продукции.</p>"}</div><span class="status-pill neutral">${Math.min(catalog.length, 12)} показано</span></div><div class="specification-result-list">${catalog.slice(0, 12).map(item => `<button class="specification-result ${selected?.id === item.id ? "selected" : ""}" data-action="select-specification" data-id="${attribute(item.id)}"><span><strong>${escapeHtml(item.product)}</strong><small>${escapeHtml(item.line)}</small></span><span><b>${escapeHtml(String(item.variant))}</b><small>mg/g · ${escapeHtml(item.processType || "—")}</small></span></button>`).join("") || '<div class="empty-state compact"><span>⌕</span><p>По этому запросу продуктов нет</p></div>'}</div>${catalog.length > 12 ? `<p class="module-note">Уточните поиск или выберите любой фильтр: найдено ещё ${catalog.length - 12} позиций.</p>` : ""}</section>
      <div>${selected ? renderSpecificationCard(selected, canEdit) : `<section class="card empty-state specification-empty"><span>⌁</span><h3>${all.length ? "Выберите позицию" : "Спецификации пока не загружены"}</h3><p>${all.length ? "Найдите продукт или выберите его из каталога — здесь сразу появятся технологические нормы и упаковка." : "Проверьте подключение к Google и обновите каталог."}</p></section>`}</div>
    </section>
    <p class="module-note">Источник — Google Sheets. Новые продукты и изменения появляются после обновления каталога; исходные названия и пустые нормы сухих продуктов сохраняются без изменений.</p>`;
}

function renderSpecificationCard(specification, canEdit = false) {
  const value = number => number === null || number === undefined ? "—" : formatNumber(number);
  return `<section class="specification-detail card"><div class="section-heading"><div><p class="eyebrow">${escapeHtml(specification.line)}</p><h2>${escapeHtml(specification.product)}</h2><p class="specification-variant">${escapeHtml(String(specification.variant))} mg/g</p></div><div class="header-actions"><span class="status-pill success">${escapeHtml(specification.processType || "Тип не указан")}</span>${canEdit ? `<button class="small-button" data-action="edit-specification" data-id="${attribute(specification.id)}">Изменить</button><button class="small-button danger-outline" data-action="delete-specification" data-id="${attribute(specification.id)}">Удалить</button>` : ""}</div></div><dl class="specification-values">
    <div><dt>Вес сухого продукта</dt><dd>${value(specification.dryMass)} г</dd></div><div><dt>Вес мокрого продукта</dt><dd>${value(specification.wetMass)} г</dd></div><div><dt>Жидкость</dt><dd>${value(specification.liquidVolume)} мл</dd></div><div><dt>Подушек в банке</dt><dd>${value(specification.pouchCount)}</dd></div><div><dt>Цвет крышки</dt><dd>${escapeHtml(specification.lidColor || "—")}</dd></div><div><dt>Вид банки</dt><dd>${escapeHtml(specification.canType || "—")}</dd>
  </dl></section>`;
}

function journalLink(key, label = "Открыть в Google Sheets") {
  const journal = WORKSPACE_JOURNALS[key];
  if (!journal) return "";
  return `<a class="secondary-button journal-link" href="https://docs.google.com/spreadsheets/d/${journal.id}/edit" target="_blank" rel="noreferrer">${escapeHtml(label)} ↗</a>`;
}

function renderRecordRow(record) {
  const isAnnulled = record.status === "Аннулировано";
  const resultClass = record.result === "Вне допуска" ? "danger" : "success";
  return `
    <tr class="${isAnnulled ? "annulled-row" : ""}">
      <td><strong>${formatDate(record.date)}</strong><small>${record.source === "demo" ? "Демонстрационная запись" : ""}</small></td>
      <td>${escapeHtml(record.scaleName)}</td>
      <td><strong>${formatNumber(record.actual)} г</strong><small>Номинал ${formatNumber(record.nominal)} г</small></td>
      <td class="mono">${signedNumber(record.deviation)} г</td>
      <td><span class="status-pill ${resultClass}">${escapeHtml(record.result)}</span></td>
      <td>${escapeHtml(record.performer)}</td>
      <td>${recordStatus(record)}</td>
      <td>
        <div class="row-actions">
          ${!isAnnulled ? `<button class="small-button" data-action="edit-record" data-id="${record.id}">Исправить</button><button class="more-button" data-action="annul-record" data-id="${record.id}" title="Аннулировать">×</button>` : ""}
        </div>
      </td>
    </tr>`;
}

function renderCompactRecords(records) {
  if (!records.length) return `<div class="empty-state compact"><span>◎</span><p>Записей пока нет</p></div>`;
  return `<div class="compact-list">${records.map(record => `
    <div class="compact-record">
      <span class="result-mark ${record.result === "Вне допуска" ? "danger" : "success"}">${record.result === "Вне допуска" ? "!" : "✓"}</span>
      <span><strong>${escapeHtml(record.scaleName)} · ${formatNumber(record.actual)} г</strong><small>${formatDate(record.date)} · ${escapeHtml(record.performer)}</small></span>
      ${recordStatus(record)}
    </div>`).join("")}</div>`;
}

function renderSyncPage() {
  const entries = queueEntries();
  const conflicts = entries.filter(item => item.conflict);
  const diagnostics = state.googleDiagnostics;
  return `
    <div class="sync-summary card">
      <div class="sync-illustration ${navigator.onLine ? "online" : "offline"}">${syncLargeIcon()}</div>
      <div class="sync-copy">
        <p class="eyebrow">Передача данных</p>
        <h2>${navigator.onLine ? "Подключение есть" : "Работа без интернета"}</h2>
        <p>${!APP_CONFIG.integration.googleWritesEnabled ? "Отправка в Google выключена. Локальная очередь ожидает разрешения на запись." : navigator.onLine ? "Программа готова автоматически отправлять новые записи." : "Можно продолжать работу. Всё сохранится на этом компьютере и отправится позже."}</p>
      </div>
      <div class="sync-actions"><button class="secondary-button" data-action="google-diagnostics" ${diagnostics?.busy ? "disabled" : ""}>${diagnostics?.busy ? "Проверяем…" : "Проверить Google"}</button><button class="primary-button" data-action="sync" ${state.syncing ? "disabled" : ""}>${state.syncing ? "Отправляем…" : "Синхронизировать"}</button></div>
    </div>
    ${diagnostics ? `<div class="sync-diagnostics ${diagnostics.tone}"><strong>${escapeHtml(diagnostics.message)}</strong>${diagnostics.detail ? `<small>${escapeHtml(diagnostics.detail)}</small>` : ""}</div>` : ""}
    <div class="metric-grid three">
       ${metricCard("В очереди", entries.length, "Ожидает отправки", entries.length ? "warning" : "neutral")}
       ${metricCard("Конфликты", conflicts.length, conflicts.length ? "Нужно выбрать версию" : "Конфликтов нет", conflicts.length ? "danger" : "success")}
      ${metricCard("Последнее обновление", state.lastRefresh ? formatDateTime(state.lastRefresh) : "—", "Автоматически каждые 60 секунд", "neutral", true)}
    </div>
    <section class="card queue-card">
      <div class="section-heading"><div><p class="eyebrow">Локальная очередь</p><h2>Неотправленные изменения</h2></div></div>
       ${entries.length ? `<div class="queue-list">${entries.map(renderQueueEntry).join("")}</div>` : `<div class="empty-state"><span>✓</span><h3>Всё отправлено</h3><p>На этом компьютере нет ожидающих изменений.</p></div>`}
    </section>`;
}

function queueEntries() {
  const checks = (state.operations ?? []).map(operation => ({
    source: "checks", id: operation.id, title: `${operation.record?.scaleName || "Контроль весов"} · ${formatNumber(operation.record?.actual)} г`,
    detail: `${operationLabel(operation.type)} · ${formatDateTime(operation.createdAt)}`,
    conflict: operation.state === "conflict", error: operation.error, operation
  }));
  const labels = { personnel: "Персонал", shiftTeams: "Смены", attendance: "Табель", vacations: "График отпусков" };
  const workforce = (state.workforce?.pending ?? []).map(operation => ({
    source: "workforce", id: operation.requestId, title: labels[operation.kind] || "Журнал персонала",
    detail: `${operation.actor?.performer || "Автор не указан"} · ${formatDateTime(operation.record?.updatedAt || new Date().toISOString())}`,
    conflict: operation.status === "conflict" || operation.status === "error", error: operation.error, operation
  }));
  const packaging = (state.packaging?.operations ?? []).map(operation => ({
    source: "packaging", id: operation.id, title: "Расход упаковки",
    detail: `${operation.record?.date || "Дата не указана"} · ${operation.type === "delete" ? "удаление записи" : "сохранение записи"}`,
    conflict: Boolean(operation.error), error: operation.error, operation
  }));
  const cyclones = (state.cyclones?.operations ?? []).map(operation => ({
    source: "cyclones", id: operation.id, title: "Очистка циклонов",
    detail: `${operation.record?.date || "Дата не указана"} · ${operation.record?.performer || "исполнитель не указан"}`,
    conflict: Boolean(operation.error), error: operation.error, operation
  }));
  return [...checks, ...workforce, ...packaging, ...cyclones];
}

function renderQueueEntry(entry) {
  const status = entry.conflict ? "Конфликт" : "В очереди";
  const sourceButton = `<button class="small-button" data-action="sync-queue-source" data-source="${entry.source}">Повторить отправку</button>`;
  const discardButton = entry.source === "checks" || entry.source === "cyclones"
    ? `<button class="small-button danger-outline-button" data-action="queue-discard" data-source="${entry.source}" data-id="${attribute(entry.id)}">Удалить из очереди</button>`
    : "";
  let actions = `${sourceButton}${discardButton}`;
  if (entry.source === "checks" && entry.conflict) actions = `<button class="small-button" data-action="queue-accept-remote" data-id="${attribute(entry.id)}">Оставить версию Google</button>`;
  if (entry.source === "workforce" && entry.conflict) {
    const retry = entry.operation.kind === "attendance" ? `<button class="small-button" data-action="workforce-retry-missing-attendance" data-id="${attribute(entry.id)}">Отправить, если в Google пусто</button>` : "";
    const overwrite = entry.operation.kind === "vacations" ? `<button class="small-button" data-action="workforce-overwrite-vacation" data-id="${attribute(entry.id)}">Отправить мою версию</button>` : entry.operation.kind === "personnel" ? `<button class="small-button" data-action="workforce-overwrite-personnel" data-id="${attribute(entry.id)}">Отправить мою версию</button>` : "";
    actions = `${retry}${overwrite}<button class="small-button" data-action="workforce-accept-remote" data-id="${attribute(entry.id)}">Оставить версию Google</button>`;
  }
  return `<div class="queue-item"><span class="queue-icon ${entry.conflict ? "conflict" : "pending"}">${entry.conflict ? "!" : "↥"}</span><span><strong>${escapeHtml(entry.title)}</strong><small>${escapeHtml(entry.detail)}${entry.error ? ` · ${escapeHtml(entry.error)}` : ""}</small></span><span class="status-pill ${entry.conflict ? "danger" : "warning"}">${status}</span><span class="queue-actions">${actions}</span></div>`;
}

function renderOperation(operation) {
  const record = operation.record;
  return `<div class="queue-item">
    <span class="queue-icon ${operation.state}">${operation.state === "conflict" ? "!" : "↥"}</span>
    <span><strong>${escapeHtml(record.scaleName)} · ${formatNumber(record.actual)} г</strong><small>${operationLabel(operation.type)} · ${formatDateTime(operation.createdAt)}</small></span>
    <span class="status-pill ${operation.state === "conflict" ? "danger" : "warning"}">${operation.state === "conflict" ? "Конфликт" : "В очереди"}</span>
  </div>`;
}

function renderSettingsPage() {
  const language = LANGUAGES.find(item => item.code === state.language) ?? LANGUAGES[0];
  return `
    <section class="settings-hero card">
      <div><p class="eyebrow">Центр управления</p><h2>Настройки участка</h2><p>Здесь действительно настраиваются сотрудники, смены и правила табеля. Изменения сохраняются локально и будут подключены к рабочему источнику.</p></div>
      <span class="status-pill success">Только начальник</span>
    </section>
    <nav class="settings-tabs card" aria-label="Разделы настроек">
      ${settingsTabButton("overview", "Общие", settingsIcon())}
      ${settingsTabButton("personnel", "Персонал", personnelIcon(), personnel().length)}
      ${settingsTabButton("shifts", "Смены", attendanceIcon(), state.workforce.shiftTeams.length)}
      ${settingsTabButton("timesheet", "Табель", moduleIcon("documents"))}
    </nav>
    ${state.settingsTab === "personnel" ? renderPersonnelSettings() : state.settingsTab === "shifts" ? renderShiftSettings() : state.settingsTab === "timesheet" ? renderTimesheetSettings() : `
      <div class="settings-grid">
        <section class="card settings-section">
          <div class="section-heading"><div><p class="eyebrow">Интеграция</p><h2>Google Workspace</h2></div><span class="status-pill ${APP_CONFIG.integration.mode === "demo" ? "warning" : "success"}">${APP_CONFIG.integration.mode === "demo" ? "Тестовый режим" : "Рабочий шлюз"}</span></div>
          ${settingRow("Рабочая таблица", journal.sheetName, "Подключение подготовлено")}
          ${settingRow("Автообновление", "Каждую минуту", "Доступная проверенная версия устанавливается автоматически")}
          ${settingRow("Запись в Google", APP_CONFIG.integration.googleWritesEnabled ? "Включена" : "Выключена", APP_CONFIG.integration.googleWritesEnabled ? "Через защищённый шлюз" : "До контролируемой проверки")}
          ${settingRow("Часовой пояс", APP_CONFIG.timeZone, "Дата и время заполняются автоматически")}
        </section>
        <section class="card settings-section">
          <div class="section-heading"><div><p class="eyebrow">Программа</p><h2>Обновление</h2></div><span class="status-pill ${state.update.available ? "warning" : "success"}">${state.update.available ? "Доступно" : "Актуально"}</span></div>
          ${settingRow("Установлено", `Версия ${APP_CONFIG.version}`, state.update.checked ? (state.update.message || "Проверено при запуске") : "Проверяем наличие новой версии")}
          ${state.update.available ? `<p class="settings-copy">Доступна версия <b>${escapeHtml(state.update.version)}</b>. Она будет установлена автоматически не позднее чем через минуту. Настройки Google и локальная очередь сохранятся.</p>` : `<button class="secondary-button" data-action="check-update">Проверить сейчас</button>`}
        </section>
        <section class="card settings-section">
          <div class="section-heading"><div><p class="eyebrow">Интерфейс</p><h2>Язык и оформление</h2></div></div>
          ${settingRow("Язык", language.name, "RU · EN · LT")}
          ${settingRow("Тема", state.theme === "dark" ? "Тёмная" : "Светлая", "Переключается также в верхней панели")}
          ${settingRow("Дата и время", APP_CONFIG.timeZone, "Часы отображаются постоянно")}
        </section>
        <section class="card settings-section">
          <div class="section-heading"><div><p class="eyebrow">Доступ к программе</p><h2>Пароли учётных записей</h2></div><span class="status-pill warning">${APP_CONFIG.centralAuth ? "Центральный сервер" : "Только этот компьютер"}</span></div>
          <p class="settings-copy">${APP_CONFIG.centralAuth ? "Пароли едины для рабочих компьютеров. Чтобы изменить пароль, укажите текущий пароль выбранной учётной записи." : "Первоначальный пароль — <b>0000</b>. Чтобы изменить пароль, укажите текущий пароль выбранной учётной записи."}</p>
          <form class="settings-password-form" data-form="password-change">
            <label class="field"><span>Учётная запись</span><select name="accountId">${authService.availableAccounts().map(account => `<option value="${account.id}">${escapeHtml(account.title)}</option>`).join("")}</select></label>
            <label class="field"><span>Текущий пароль</span><input name="currentPassword" type="password" minlength="4" required autocomplete="current-password"></label>
            <label class="field"><span>Новый пароль</span><input name="nextPassword" type="password" minlength="4" required autocomplete="new-password"></label>
            <label class="field"><span>Повторите новый пароль</span><input name="repeatPassword" type="password" minlength="4" required autocomplete="new-password"></label>
            <button class="primary-button" type="submit">Сменить пароль</button>
          </form>
        </section>
        <section class="card settings-section wide">
          <div class="section-heading"><div><p class="eyebrow">Рабочая модель</p><h2>Персонал и графики перенесены</h2></div></div>
          <div class="settings-links">
            ${settingsLink("personnel", "Персонал", `${personnel().length} сотрудников`, personnelIcon())}
            ${settingsLink("attendance", "Табель", "График 2/2 и фактические часы", attendanceIcon())}
            ${settingsLink("vacations", "График отпусков", "Годовой календарь", moduleIcon("vacation"))}
          </div>
        </section>
      </div>`}`;
}

function settingsTabButton(tab, label, icon, count = "") {
  return `<button class="${state.settingsTab === tab ? "active" : ""}" data-action="settings-tab" data-tab="${tab}"><span>${icon}</span><strong>${label}</strong>${count !== "" ? `<b>${count}</b>` : ""}</button>`;
}

function renderPersonnelSettings() {
  const employees = personnel().sort(comparePersonnel);
  return `<section class="card settings-workforce-panel">
    <header><div><p class="eyebrow">Справочник</p><h2>Сотрудники участка</h2><p>Имя, должность, смена и активность используются во всех формах программы.</p></div><button class="primary-button" data-action="add-employee">+ Добавить сотрудника</button></header>
    <div class="settings-table-wrap"><table class="settings-data-table"><thead><tr><th>Сотрудник</th><th>Должность</th><th>Смена</th><th>Статус</th><th></th></tr></thead><tbody>${employees.map(employee => `<tr class="${employee.active === false ? "inactive" : ""}"><td><strong>${escapeHtml(employee.fullName)}</strong></td><td>${escapeHtml(roleLabel(employee.role))}</td><td><span class="table-team">${escapeHtml(teamLabel(employee.shiftTeamId))}</span></td><td>${employee.active === false ? "В архиве" : "Активен"}</td><td><div class="row-actions"><button class="small-button" data-action="edit-employee" data-id="${employee.id}">Изменить</button><button class="small-button" data-action="toggle-employee" data-id="${employee.id}">${employee.active === false ? "Вернуть" : "В архив"}</button></div></td></tr>`).join("")}</tbody></table></div>
  </section>`;
}

function renderShiftSettings() {
  return `<div class="shift-settings-grid">${state.workforce.shiftTeams.map(team => `<form class="card shift-settings-card" data-form="shift-settings">
    <input type="hidden" name="id" value="${team.id}">
    <header><span class="team-orb">${team.code}</span><div><p class="eyebrow">Рабочая смена</p><h2>${escapeHtml(team.name)}</h2></div></header>
    <div class="form-grid">
      ${formField(`team-name-${team.id}`, "Название", `<input id="team-name-${team.id}" name="name" value="${attribute(team.name)}" required>`, "Отображается в табеле", "full")}
      ${formField(`team-anchor-${team.id}`, "Первый рабочий день цикла", `<input id="team-anchor-${team.id}" name="anchorDate" type="date" value="${team.anchorDate}" required>`)}
      ${formField(`team-duration-${team.id}`, "Длительность смены", `<input id="team-duration-${team.id}" name="shiftDurationHours" type="number" min="1" max="24" value="${team.shiftDurationHours}" required>`, "часов на производстве")}
      ${formField(`team-accounting-${team.id}`, "К учёту", `<input id="team-accounting-${team.id}" name="accountingHours" type="number" min="1" max="24" value="${team.accountingHours}" required>`, "часов в табеле")}
    </div>
    <div class="shift-settings-summary"><span><b>2</b> рабочих дня</span><span><b>2</b> выходных дня</span><span><b>${activePersonnel().filter(employee => employee.shiftTeamId === team.id).length}</b> сотрудников</span></div>
    <footer><button class="primary-button" type="submit">Сохранить смену</button></footer>
  </form>`).join("")}</div>`;
}

function renderTimesheetSettings() {
  return `<div class="settings-grid">
    <section class="card settings-section wide"><div class="section-heading"><div><p class="eyebrow">Коды табеля</p><h2>Виды работы и причины отсутствия</h2></div><button class="secondary-button" data-action="navigate" data-page="attendance">Открыть табель</button></div><div class="attendance-code-settings">${ATTENDANCE_CODES.map(item => `<div class="tone-${item.tone}"><b>${item.value}</b><span><strong>${item.label}</strong><small>${item.value === "11" ? "Часы полной смены; можно указать другое фактически отработанное время" : "Выбирается в ячейке табеля"}</small></span></div>`).join("")}</div></section>
    <section class="card settings-section"><div class="section-heading"><div><p class="eyebrow">Администрация</p><h2>График 5/2</h2></div></div>${settingRow("Рабочий день", "8 часов", "Понедельник — пятница")}${settingRow("Праздники", "Литва", "По производственному календарю")}</section>
    <section class="card settings-section"><div class="section-heading"><div><p class="eyebrow">Производство</p><h2>График 2/2</h2></div></div>${settingRow("Смена", "12 часов", "Фактическая длительность")}${settingRow("К учёту", "11 часов", "Норма табеля")}</section>
  </div>`;
}

function openScaleWalkDialog() {
  const walk = {
    date: today(),
    performer: "",
    index: 0,
    readings: new Map(),
    skipped: new Set()
  };
  const dialog = createDialog(`<section class="dialog-card scale-walk-dialog"><div class="scale-walk-shell"></div></section>`);
  const shell = dialog.querySelector(".scale-walk-shell");

  function renderSetup() {
    shell.innerHTML = `
      <form class="scale-walk-setup">
        <div class="dialog-heading"><div><p class="eyebrow">Быстрый ввод</p><h2>Обход 13 весов</h2></div><button type="button" class="dialog-close" data-action="close-dialog" aria-label="Закрыть">×</button></div>
        <div class="walk-intro"><span>13</span><div><strong>Одно показание — один шаг</strong><p>Имя и дату указываем один раз. После каждого значения нажимайте Enter.</p></div></div>
        <div id="walk-error" class="form-error" hidden></div>
        <div class="form-grid">
          ${formField("walk-date", "Дата проверки", `<input id="walk-date" name="date" type="date" value="${attribute(walk.date)}" required>`)}
          ${formField("walk-performer", "Кто проводит проверку", `<select id="walk-performer" name="performer" required><option value="">Выберите имя и фамилию</option>${operationalAuthorNames().map(employee => `<option>${escapeHtml(employee)}</option>`).join("")}</select>`, "Только ответственный за текущую смену")}
        </div>
        <div class="walk-route">${SCALES.map(scale => `<span>${scale.code}</span>`).join("")}</div>
        <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button class="primary-button" type="submit">Начать с F1</button></div>
      </form>`;
    shell.querySelector("form").addEventListener("submit", event => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget));
      if (!data.date || !data.performer) {
        showWalkError("Укажите дату и выберите исполнителя");
        return;
      }
      walk.date = data.date;
      walk.performer = data.performer;
      renderStep();
    });
  }

  function renderStep() {
    const scale = SCALES[walk.index];
    const saved = walk.readings.get(scale.name);
    const percent = Math.round(((walk.index + 1) / SCALES.length) * 100);
    shell.innerHTML = `
      <div class="walk-step">
        <div class="walk-progress-row"><span>Весы ${walk.index + 1} из ${SCALES.length}</span><span><strong>${percent}%</strong><button type="button" class="dialog-close compact" data-action="close-dialog" aria-label="Закрыть обход">×</button></span></div>
        <div class="walk-progress-track"><i style="width:${percent}%"></i></div>
        <div class="walk-scale-heading"><span class="walk-scale-code">${scale.code}</span><div><p>${scale.manufacturer}</p><h2>${scale.model}</h2></div></div>
        <div class="walk-reference"><span>Контрольная гиря</span><strong>${formatNumber(journal.nominal)} г</strong><small>Допуск ±${formatNumber(journal.tolerance)} г</small></div>
        <label class="walk-reading"><span>Показание весов</span><div><input id="walk-reading" type="text" inputmode="decimal" autocomplete="off" value="${attribute(saved?.actual ?? "")}" placeholder="50,00"><b>г</b></div></label>
        <div id="walk-result" class="walk-live-result">Введите показание</div>
        <div id="walk-failure-fields" class="walk-failure-fields" hidden>
          <label class="field"><span>Состояние весов</span><select id="walk-condition"><option value="">Выберите состояние</option><option ${saved?.condition === "Рабочие" ? "selected" : ""}>Рабочие</option><option ${saved?.condition === "Нерабочие" ? "selected" : ""}>Нерабочие</option></select></label>
          <label class="field"><span>Комментарий обязателен</span><textarea id="walk-note" rows="2" placeholder="Что обнаружено и что сделано">${escapeHtml(saved?.note ?? "")}</textarea></label>
        </div>
        <div id="walk-error" class="form-error" hidden></div>
        <div class="walk-step-actions">
          <button type="button" class="secondary-button" data-walk-previous ${walk.index === 0 ? "disabled" : ""}>← Назад</button>
          <button type="button" class="text-button" data-walk-skip>Пропустить</button>
          <button type="button" class="primary-button" data-walk-next>${walk.index === SCALES.length - 1 ? "К проверке" : "Далее →"}</button>
        </div>
      </div>`;
    const input = shell.querySelector("#walk-reading");
    input.addEventListener("input", updatePreview);
    input.addEventListener("keydown", event => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      saveStep();
    });
    shell.querySelector("[data-walk-next]").addEventListener("click", saveStep);
    shell.querySelector("[data-walk-skip]").addEventListener("click", skipStep);
    shell.querySelector("[data-walk-previous]").addEventListener("click", () => {
      captureDraft();
      walk.index -= 1;
      renderStep();
    });
    updatePreview();
    setTimeout(() => { input.focus(); input.select(); }, 0);
  }

  function currentReading() {
    const raw = shell.querySelector("#walk-reading")?.value.trim().replace(",", ".") ?? "";
    if (!raw) return null;
    const actual = Number(raw);
    if (!Number.isFinite(actual) || actual < 0) return null;
    const result = calculateResult(actual, journal.nominal, journal.tolerance);
    return {
      actual,
      deviation: Number((journal.nominal - actual).toFixed(3)),
      result,
      condition: result === "В пределах допуска" ? "Рабочие" : shell.querySelector("#walk-condition")?.value,
      note: shell.querySelector("#walk-note")?.value.trim() ?? ""
    };
  }

  function updatePreview() {
    const reading = currentReading();
    const result = shell.querySelector("#walk-result");
    const failureFields = shell.querySelector("#walk-failure-fields");
    result.className = "walk-live-result";
    if (!reading) {
      result.textContent = "Введите показание";
      failureFields.hidden = true;
      return;
    }
    const passed = reading.result === "В пределах допуска";
    result.classList.add(passed ? "passed" : "failed");
    result.innerHTML = `<strong>${passed ? "✓ В пределах допуска" : "! Вне допуска"}</strong><span>Отклонение ${signedNumber(reading.deviation)} г</span>`;
    failureFields.hidden = passed;
  }

  function captureDraft() {
    const reading = currentReading();
    if (!reading) return;
    walk.readings.set(SCALES[walk.index].name, reading);
    walk.skipped.delete(SCALES[walk.index].name);
  }

  function saveStep() {
    const reading = currentReading();
    if (!reading) {
      showWalkError("Введите корректное показание весов");
      shell.querySelector("#walk-reading")?.focus();
      return;
    }
    if (reading.result === "Вне допуска" && !reading.condition) {
      showWalkError("Для отклонения выберите состояние весов");
      shell.querySelector("#walk-condition")?.focus();
      return;
    }
    if (reading.result === "Вне допуска" && !reading.note) {
      showWalkError("Для отклонения укажите комментарий");
      shell.querySelector("#walk-note")?.focus();
      return;
    }
    const scale = SCALES[walk.index];
    walk.readings.set(scale.name, reading);
    walk.skipped.delete(scale.name);
    if (walk.index === SCALES.length - 1) renderReview();
    else { walk.index += 1; renderStep(); }
  }

  function skipStep() {
    const scale = SCALES[walk.index];
    walk.readings.delete(scale.name);
    walk.skipped.add(scale.name);
    if (walk.index === SCALES.length - 1) renderReview();
    else { walk.index += 1; renderStep(); }
  }

  function renderReview() {
    const readings = [...walk.readings.entries()];
    const failed = readings.filter(([, reading]) => reading.result === "Вне допуска").length;
    shell.innerHTML = `
      <div class="walk-review">
        <div class="dialog-heading"><div><p class="eyebrow">Проверка перед сохранением</p><h2>Обход завершён</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
        <div class="walk-review-summary"><div><span>Проверено</span><strong>${readings.length}</strong></div><div><span>Пропущено</span><strong>${walk.skipped.size}</strong></div><div class="${failed ? "danger" : "success"}"><span>Вне допуска</span><strong>${failed}</strong></div></div>
        <div class="walk-review-list">${SCALES.map(scale => {
          const reading = walk.readings.get(scale.name);
          if (!reading) return `<button type="button" data-review-scale="${scale.name}" class="skipped"><b>${scale.code}</b><span>Пропущено</span><strong>Изменить</strong></button>`;
          const passed = reading.result === "В пределах допуска";
          return `<button type="button" data-review-scale="${scale.name}" class="${passed ? "passed" : "failed"}"><b>${scale.code}</b><span>${formatNumber(reading.actual)} г · ${passed ? "В допуске" : "Вне допуска"}</span><strong>Изменить</strong></button>`;
        }).join("")}</div>
        <div id="walk-error" class="form-error" hidden></div>
        <div class="dialog-actions"><button type="button" class="secondary-button" data-review-back>← Вернуться</button><button type="button" class="primary-button" data-save-walk ${readings.length ? "" : "disabled"}>Сохранить ${readings.length} ${plural(readings.length, "запись", "записи", "записей")}</button></div>
      </div>`;
    shell.querySelectorAll("[data-review-scale]").forEach(button => button.addEventListener("click", () => {
      walk.index = SCALES.findIndex(scale => scale.name === button.dataset.reviewScale);
      renderStep();
    }));
    shell.querySelector("[data-review-back]").addEventListener("click", () => { walk.index = SCALES.length - 1; renderStep(); });
    shell.querySelector("[data-save-walk]")?.addEventListener("click", saveWalk);
  }

  async function saveWalk() {
    const button = shell.querySelector("[data-save-walk]");
    button.disabled = true;
    try {
      const entries = [...walk.readings.entries()].map(([scaleName, reading]) => ({
        date: walk.date,
        scaleName,
        actual: reading.actual,
        condition: reading.condition,
        performer: walk.performer,
        note: reading.note
      }));
      await journalService.createBatch(entries, state.account);
      if (state.shift?.active && state.shift.requiresScaleControl) {
        state.shift = await shiftService.completeScaleControl(entries.length);
      }
      dialog.close();
      await reloadLocalState();
      render();
      toast(entries.length === SCALES.length
        ? (state.shift?.requiresScaleControl ? "Все 13 весов проверены. Рабочие разделы открыты." : "Все 13 весов проверены и сохранены.")
        : `Сохранено показаний: ${entries.length}. Для завершения контроля нужны все 13 весов.`, entries.length === SCALES.length ? "success" : "warning");
      syncInBackground();
    } catch (error) {
      showWalkError(error.message || "Не удалось сохранить обход");
      button.disabled = false;
    }
  }

  function showWalkError(message) {
    const error = shell.querySelector("#walk-error");
    if (!error) return;
    error.hidden = false;
    error.textContent = message;
  }

  renderSetup();
  dialog.showModal();
}

function openRecordDialog(id = null) {
  const existing = id ? state.records.find(item => item.id === id) : null;
  const values = existing ?? journalService.emptyForm();
  const dialog = createDialog(`
    <form id="record-form" class="dialog-card">
      <div class="dialog-heading">
        <div><p class="eyebrow">${existing ? "Исправление записи" : "Новая запись"}</p><h2>${journal.title}</h2></div>
        <button type="button" class="dialog-close" data-action="close-dialog" aria-label="Закрыть">×</button>
      </div>
      <div class="form-notice"><span>i</span><p>Исполнителя необходимо выбрать перед каждым сохранением. Дата заполняется автоматически, но её можно исправить.</p></div>
      <div id="form-error" class="form-error" hidden></div>
      <div class="form-grid">
        ${formField("date", "Дата проверки", `<input id="date" name="date" type="date" value="${attribute(values.date)}" required />`)}
        ${formField("scaleName", "Весы", `<select id="scaleName" name="scaleName" required>${journal.scaleOptions.map(option => `<option ${option === values.scaleName ? "selected" : ""}>${escapeHtml(option)}</option>`).join("")}</select>`)}
        ${formField("actual", "Фактический вес, г", `<input id="actual" name="actual" type="number" inputmode="decimal" step="0.001" min="0" value="${attribute(values.actual)}" placeholder="Например, 50,000" required />`, "Номинал: 50 г")}
        ${formField("condition", "Состояние весов", `<select id="condition" name="condition"><option ${values.condition === "Рабочие" ? "selected" : ""}>Рабочие</option><option ${values.condition === "Нерабочие" ? "selected" : ""}>Нерабочие</option></select>`)}
        ${formField("performer", "Кто внёс данные", `<select id="performer" name="performer" required><option value="">Выберите имя и фамилию</option>${operationalAuthorNames().map(employee => `<option ${employee === values.performer && !existing ? "selected" : ""}>${escapeHtml(employee)}</option>`).join("")}</select>`, "Только ответственный за текущую смену", "full")}
        ${formField("note", "Примечание", `<textarea id="note" name="note" rows="3" placeholder="Необязательно">${escapeHtml(values.note)}</textarea>`, "", "full")}
      </div>
      <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">${existing ? "Сохранить исправление" : "Добавить запись"}</button></div>
    </form>`);

  const form = dialog.querySelector("#record-form");
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const submitButton = form.querySelector("[type=submit]");
    submitButton.disabled = true;
    const data = Object.fromEntries(new FormData(form));
    try {
      if (existing) await journalService.update(existing.id, data, state.account);
      else await journalService.create(data, state.account);
      dialog.close();
      await reloadLocalState();
      render();
      toast(existing ? "Исправление сохранено." : "Запись сохранена.", "success");
      syncInBackground();
    } catch (error) {
      showFormError(form, error);
      submitButton.disabled = false;
    }
  });
  dialog.showModal();
}

function openAnnulDialog(id) {
  const record = state.records.find(item => item.id === id);
  if (!record) return;
  const dialog = createDialog(`
    <form id="annul-form" class="dialog-card small-dialog">
      <div class="dialog-heading"><div><p class="eyebrow">Без удаления данных</p><h2>Аннулировать запись?</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
      <p class="dialog-lead">Запись ${formatDate(record.date)} · ${escapeHtml(record.scaleName)} останется в журнале и получит статус «Аннулировано».</p>
      <div id="form-error" class="form-error" hidden></div>
       ${formField("performer", "Кто аннулирует", `<select id="performer" name="performer" required><option value="">Выберите имя и фамилию</option>${operationalAuthorNames().map(employee => `<option>${escapeHtml(employee)}</option>`).join("")}</select>`)}
      ${formField("reason", "Причина", `<textarea id="reason" name="reason" rows="3" placeholder="Причина обязательна" required></textarea>`)}
      <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="danger-button">Аннулировать</button></div>
    </form>`);
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      await journalService.annul(id, data.reason, data.performer, state.account);
      dialog.close();
      await reloadLocalState();
      render();
      toast("Запись аннулирована.", "success");
      syncInBackground();
    } catch (error) {
      showFormError(event.currentTarget, error);
    }
  });
  dialog.showModal();
}

function openEmployeeDialog(id = null) {
  if (state.account.role !== "manager") throw new Error("Редактировать справочник персонала может только Администрация.");
  const employee = id ? personnel().find(item => item.id === id) : null;
  const dialog = createDialog(`
    <form class="dialog-card employee-dialog" data-employee-form>
      <div class="dialog-heading"><div><p class="eyebrow">Справочник персонала</p><h2>${employee ? "Изменить сотрудника" : "Новый сотрудник"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
      <p class="dialog-lead">Основные данные используются в графике смен, табеле и списке исполнителей. Личные сведения доступны только Администрации.</p>
      <div id="form-error" class="form-error" hidden></div>
      <div class="form-grid">
        ${formField("employee-full-name", "Имя и фамилия", `<input id="employee-full-name" name="fullName" value="${attribute(employee?.fullName ?? "")}" autocomplete="off" required>`, "Как в рабочих документах", "full")}
        ${formField("employee-role", "Должность", `<select id="employee-role" name="role" required>${Object.entries(ROLE_LABELS).map(([role, label]) => `<option value="${role}" ${employee?.role === role ? "selected" : ""}>${escapeHtml(label)}</option>`).join("")}</select>`)}
        ${formField("employee-team", "Смена", `<select id="employee-team" name="shiftTeamId" required><option value="office" ${employee?.shiftTeamId === "office" ? "selected" : ""}>Администрация · 5/2</option>${state.workforce.shiftTeams.map(team => `<option value="${team.id}" ${employee?.shiftTeamId === team.id ? "selected" : ""}>${escapeHtml(team.name)} · 2/2</option>`).join("")}</select>`)}
        <div class="pak-form-fields" data-pak-fields ${employee?.role === "packer" ? "" : "hidden"}>${formField("employee-pak-number", "Номер PAK", `<input id="employee-pak-number" name="pakNumber" value="${attribute(employee?.pakNumber ?? "")}" autocomplete="off">`)}${formField("employee-pak-code", "Код", `<input id="employee-pak-code" name="pakCode" value="${attribute(employee?.pakCode ?? "")}" autocomplete="off">`)}</div>
        ${formField("employee-birthday", "Дата рождения", `<input id="employee-birthday" name="birthday" type="date" value="${attribute(employee?.birthday ?? "")}">`)}
        ${formField("employee-hire-date", "Дата приёма", `<input id="employee-hire-date" name="hireDate" type="date" value="${attribute(employee?.hireDate ?? "")}" ${employee ? "" : "required"}>`, employee ? "Для нового сотрудника дата нужна для пропорционального расчёта отпуска." : "Обязательна: по ней рассчитывается отпуск в год приёма.")}
        ${formField("employee-phone", "Телефон", `<input id="employee-phone" name="phone" type="tel" value="${attribute(employee?.phone ?? "")}" autocomplete="tel">`)}
        ${formField("employee-email", "Электронная почта", `<input id="employee-email" name="email" type="email" value="${attribute(employee?.email ?? "")}" autocomplete="email">`)}
      </div>
      <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button class="primary-button" type="submit">Сохранить</button></div>
    </form>`);
  const roleControl = dialog.querySelector("[name=role]");
  const pakFields = dialog.querySelector("[data-pak-fields]");
  const syncPakFields = () => {
    const isPacker = roleControl.value === "packer";
    pakFields.hidden = !isPacker;
    pakFields.querySelectorAll("input").forEach(input => { input.disabled = !isPacker; if (!isPacker) input.value = ""; });
  };
  roleControl.addEventListener("change", syncPakFields);
  syncPakFields();
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(form));
      await withWorkforceActor(() => workforceService.saveEmployee({ ...data, id: employee?.id, active: employee?.active !== false }));
      state.workforce = await workforceService.snapshot();
      dialog.close();
      render();
      toast("Сотрудник сохранён.", "success");
      sendWorkforceInBackground();
    } catch (error) {
      showFormError(form, error);
      button.disabled = false;
    }
  });
  dialog.showModal();
}

function openSpecificationDialog(id = null) {
  if (state.account?.role !== "manager") throw new Error("Редактировать спецификации может только Администрация.");
  const specification = id ? state.specifications.specifications.find(item => item.id === id) : null;
  const value = (field) => specification?.[field] ?? "";
  const dialog = createDialog(`
    <form class="dialog-card employee-dialog" data-specification-form>
      <div class="dialog-heading"><div><p class="eyebrow">Спецификация продуктов</p><h2>${specification ? "Изменить продукт" : "Новый продукт"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
      <p class="dialog-lead">Пустые поля норм сохраняются пустыми. Все изменения сразу попадут в рабочую Google-таблицу.</p>
      <div id="form-error" class="form-error" hidden></div>
      <div class="form-grid">
        ${formField("specification-line", "Линейка", `<input id="specification-line" name="line" value="${attribute(value("line"))}" required>`)}
        ${formField("specification-product", "Продукт", `<input id="specification-product" name="product" value="${attribute(value("product"))}" required>`)}
        ${formField("specification-variant", "mg/g", `<input id="specification-variant" name="variant" type="number" step="any" min="0" value="${attribute(value("variant"))}" required>`)}
        ${formField("specification-process", "Сухой / мокрый", `<input id="specification-process" name="processType" value="${attribute(value("processType"))}">`)}
        ${formField("specification-dry", "Вес сухого продукта, г", `<input id="specification-dry" name="dryMass" type="number" step="0.01" min="0" value="${attribute(value("dryMass"))}">`)}
        ${formField("specification-wet", "Вес мокрого продукта, г", `<input id="specification-wet" name="wetMass" type="number" step="0.01" min="0" value="${attribute(value("wetMass"))}">`)}
        ${formField("specification-liquid", "Жидкость, мл", `<input id="specification-liquid" name="liquidVolume" type="number" step="0.01" min="0" value="${attribute(value("liquidVolume"))}">`)}
        ${formField("specification-pouches", "Подушек в банке", `<input id="specification-pouches" name="pouchCount" type="number" step="1" min="0" value="${attribute(value("pouchCount"))}">`)}
        ${formField("specification-lid", "Цвет крышки", `<input id="specification-lid" name="lidColor" value="${attribute(value("lidColor"))}">`)}
        ${formField("specification-can", "Вид банки", `<input id="specification-can" name="canType" value="${attribute(value("canType"))}">`)}
      </div>
      <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button class="primary-button" type="submit">Сохранить</button></div>
    </form>`);
  dialog.querySelector("form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    try {
      const saved = await productSpecificationService.save({ ...Object.fromEntries(new FormData(form)), id: specification?.id });
      state.specifications = await productSpecificationService.initialize();
      state.specificationSelection = { line: saved.line, product: saved.product, variant: String(saved.variant) };
      dialog.close(); render(); toast("Спецификация сохранена в Google Sheets.", "success");
    } catch (error) { showFormError(form, error); button.disabled = false; }
  });
  dialog.showModal();
}

async function deleteSpecification(id) {
  if (state.account?.role !== "manager") throw new Error("Удалять спецификации может только начальник участка.");
  const item = state.specifications.specifications.find(specification => specification.id === id);
  if (!item || !window.confirm(`Удалить спецификацию «${item.product} · ${item.variant} mg/g»?`)) return;
  try {
    await productSpecificationService.remove(id);
    state.specifications = await productSpecificationService.initialize();
    state.specificationSelection = { line: "", product: "", variant: "" };
    render(); toast("Спецификация удалена из Google Sheets.", "success");
  } catch (error) { toast(error.message || "Не удалось удалить спецификацию.", "error"); }
}

function openShiftGuestDialog() {
  const teamId = state.shift?.shiftTeamId ?? state.selectedShiftTeamId;
  const guests = activePersonnel()
    .filter(employee => (employee.shiftTeamId !== teamId || isSubstituteOnly(employee)) && !state.shiftGuests.some(item => item.employeeId === employee.id))
    .sort(comparePersonnel);
  const dialog = createDialog(`
    <form class="dialog-card small-dialog" data-shift-guest-form>
      <div class="dialog-heading"><div><p class="eyebrow">Подменный выход</p><h2>Добавить сотрудника другой смены или отдела</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
      <p class="dialog-lead">Сотрудник будет учтён в текущей смене. В табеле сохранятся часы и причина выхода.</p>
      <div class="form-grid">
        ${formField("shift-guest", "Сотрудник", `<select id="shift-guest" name="employeeId" required><option value="">Выберите сотрудника</option>${guests.map(employee => `<option value="${attribute(employee.id)}">${escapeHtml(employee.fullName)} · ${escapeHtml(teamById(employee.shiftTeamId)?.name ?? (employee.shiftTeamId === "office" ? "Другой отдел" : "Другая смена"))}</option>`).join("")}</select>`, "Только действующий персонал другой смены или отдела", "full")}
        ${formField("shift-guest-reason", "Причина выхода", `<select id="shift-guest-reason" name="substitutionReason" required><option value="">Выберите причину</option><option>Подработка</option><option>Производственная необходимость</option></select>`, "Будет указана в журнале табеля", "full")}
      </div>
      <div id="shift-guest-error" class="form-error" hidden></div>
      <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button class="primary-button" type="submit">Добавить в смену</button></div>
    </form>`);
  const form = dialog.querySelector("[data-shift-guest-form]");
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const submit = form.querySelector('[type="submit"]');
    const data = new FormData(form);
    const employee = activePersonnel().find(item => item.id === String(data.get("employeeId") || ""));
    const substitutionReason = String(data.get("substitutionReason") || "");
    if (!employee || (employee.shiftTeamId === teamId && !isSubstituteOnly(employee)) || !substitutionReason) {
      showFormError(form, new Error("Выберите сотрудника другой смены или отдела и причину выхода"));
      return;
    }
    state.shiftGuests = [...state.shiftGuests.filter(item => item.employeeId !== employee.id), { employeeId: employee.id, substitutionReason, homeShiftTeamId: employee.shiftTeamId }];
    if (state.shift?.active) {
      submit.disabled = true;
      const guestAttendance = { employeeId: employee.id, status: "11", isSubstitute: true, substitutionReason, homeShiftTeamId: employee.shiftTeamId };
      const attendance = [...state.shift.attendance.filter(item => item.employeeId !== employee.id), guestAttendance];
      try {
        const save = () => workforceService.saveAttendance({ date: today(), shiftTeamId: teamId, employeeId: employee.id, value: "11", substitutionReason, homeShiftTeamId: employee.shiftTeamId });
        if (state.shift.supervisor) {
          workforceActor = { performer: state.shift.supervisor };
          await save();
        } else await withWorkforceActor(save, attendanceAuthorNames(teamId));
        state.shift = await shiftService.updateAttendance(attendance);
        state.shiftGuests = state.shiftGuests.filter(item => item.employeeId !== employee.id);
        sendWorkforceInBackground();
      } catch (error) {
        submit.disabled = false;
        showFormError(form, error);
        return;
      }
    }
    dialog.close();
    render();
    toast(`${employee.fullName} добавлен${state.shift?.active ? " в табель и" : " в состав"} текущей смены.`, "success");
  });
  dialog.showModal();
}

function renderBirthdayReminders() {
  const notices = getBirthdayReminders(personnel(), { asOfDate: today() });
  if (!notices.length) return "";
  return `<section class="card birthday-reminders"><div class="birthday-reminders-heading"><p class="eyebrow">Напоминание</p><h2>Дни рождения</h2></div><div class="birthday-reminders-list">${notices.map(({ employee, days }) => `<div><strong>${escapeHtml(employee.fullName)}</strong><span>${days === 0 ? "Сегодня день рождения" : days === 3 ? "Через 3 дня" : "Через неделю"}</span></div>`).join("")}</div></section>`;
}

function renderWorkforceOperation(operation) {
  const conflict = operation.status === "conflict" || operation.status === "error";
  const labels = { personnel: "Персонал", shiftTeams: "Смены", attendance: "Табель", vacations: "График отпусков" };
  const retry = operation.kind === "attendance" && conflict
    ? `<button class="small-button" data-action="workforce-retry-missing-attendance" data-id="${attribute(operation.requestId)}">Отправить, если в Google пусто</button>` : "";
  const overwrite = operation.kind === "vacations" && conflict
    ? `<button class="small-button" data-action="workforce-overwrite-vacation" data-id="${attribute(operation.requestId)}">Отправить мою версию</button>`
    : operation.kind === "personnel" && conflict ? `<button class="small-button" data-action="workforce-overwrite-personnel" data-id="${attribute(operation.requestId)}">Отправить мою версию</button>` : "";
  return `<div class="queue-item"><span class="queue-icon ${conflict ? "conflict" : "pending"}">${conflict ? "!" : "↥"}</span><span><strong>${escapeHtml(labels[operation.kind] || "Журнал")}</strong><small>${escapeHtml(operation.actor?.performer || "Автор не указан")} · ${formatDateTime(operation.record?.updatedAt || new Date().toISOString())}</small></span><span class="status-pill ${conflict ? "danger" : "warning"}">${conflict ? "Конфликт" : "В очереди"}</span>${conflict ? `<span class="queue-actions">${retry}${overwrite}<button class="small-button" data-action="workforce-accept-remote" data-id="${attribute(operation.requestId)}">Оставить версию Google</button></span>` : ""}</div>`;
}

function openVacationDialog(id = null) {
  if (state.account.role !== "manager") throw new Error("График отпусков доступен для редактирования только начальнику участка.");
  const vacation = id ? (state.workforce.vacations || []).find(item => item.id === id) : null;
  const dialog = createDialog(`
    <form class="dialog-card employee-dialog" data-vacation-form>
      <div class="dialog-heading"><div><p class="eyebrow">График отпусков</p><h2>${vacation ? "Изменить период" : "Новый период"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
      <p class="dialog-lead">Один период — одна строка в рабочем журнале. Дни считаются автоматически.</p>
      <div id="form-error" class="form-error" hidden></div>
      <div class="form-grid">
        ${formField("vacation-year", "Год", `<select id="vacation-year" name="year" required>${WORKFORCE_YEARS.map(year => `<option value="${year}" ${Number(vacation?.year || WORKFORCE_YEARS[0]) === year ? "selected" : ""}>${year}</option>`).join("")}</select>`)}
        ${formField("vacation-person", "Сотрудник", `<select id="vacation-person" name="employeeId" required><option value="">Выберите сотрудника</option>${personnel().filter(isVacationEligible).sort(comparePersonnel).map(employee => `<option value="${attribute(employee.id)}" ${vacation?.employeeId === employee.id ? "selected" : ""}>${escapeHtml(employee.fullName)}</option>`).join("")}</select>`, "Можно выбрать сотрудника из архива для старой записи", "full")}
        ${formField("vacation-start", "Начало", `<input id="vacation-start" name="startDate" type="date" value="${attribute(vacation?.startDate || "")}" required>`)}
        ${formField("vacation-end", "Окончание", `<input id="vacation-end" name="endDate" type="date" value="${attribute(vacation?.endDate || "")}" required>`)}
        ${formField("vacation-note", "Примечание", `<textarea id="vacation-note" name="note" rows="2">${escapeHtml(vacation?.note || "")}</textarea>`, "Необязательно", "full")}
      </div>
      <div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button class="primary-button" type="submit">Сохранить</button></div>
    </form>`);
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    try {
      await withWorkforceActor(() => workforceService.saveVacation({ ...Object.fromEntries(new FormData(form)), id: vacation?.id, status: "Запланирован" }));
      state.workforce = await workforceService.snapshot();
      dialog.close();
      render();
      toast("Период отпуска сохранён.", "success");
      sendWorkforceInBackground();
    } catch (error) {
      showFormError(form, error);
      button.disabled = false;
    }
  });
  dialog.showModal();
}

function withWorkforceActor(action) {
  if (!workforceRepository) return action();
  workforceActor = { performer: workforceActorName() };
  return action();
}

function workforceActorName() {
  // The manager account represents the area manager. A senior account has no
  // personal name of its own, so audit attendance with the senior mechanic of
  // the selected/current team instead of the manager's name.
  if (state.account?.role === "manager") return "Anatolii Brazhko";
  const teamId = state.shift?.shiftTeamId ?? state.selectedShiftTeamId ?? scheduledTeam()?.id;
  return activePersonnel().find(person => person.shiftTeamId === teamId && person.role === "senior-mechanic")?.fullName
    || state.shift?.seniorMechanic
    || state.shift?.supervisor
    || state.account?.title
    || "";
}

function createDialog(content) {
  const dialog = document.createElement("dialog");
  dialog.className = "modal";
  dialog.innerHTML = content;
  localizeElement(dialog, state.language);
  dialog.addEventListener("close", () => dialog.remove());
  dialog.addEventListener("cancel", event => event.preventDefault());
  dialog.addEventListener("click", event => {
    if (event.target.closest('[data-action="close-dialog"]')) {
      dialog.close();
      return;
    }
    const navigation = event.target.closest('[data-action="mobile-navigate"]');
    if (navigation) {
      dialog.close();
      void navigateToPage(navigation.dataset.page);
      return;
    }
  });
  document.body.append(dialog);
  return dialog;
}

function showFormError(form, error) {
  const panel = form.querySelector("#form-error");
  if (panel) {
    panel.hidden = false;
  panel.textContent = translateUiText(error.message || "Проверьте заполнение формы", state.language);
  }
  for (const name of Object.keys(error.fields ?? {})) {
    const field = form.elements[name];
    if (field) field.setAttribute("aria-invalid", "true");
  }
}


function renderPreparationReminder() {
  const reminders = [];
  if (state.account?.role === "senior" && !state.shift?.active) reminders.push(`<button class="preparation-reminder" data-action="navigate" data-page="attendance"><span>1</span><div><strong>Смена ещё не начата</strong><small>Заполните табель. Разделы доступны — это напоминание, а не блокировка.</small></div><b>Перейти →</b></button>`);
  const team = scheduledTeam();
  const scaleReminder = getScaleControlReminder({ date: today(), team, records: state.records });
  if (["manager", "senior"].includes(state.account?.role) && scaleReminder) {
    const teamCode = team?.code || "";
    const message = scaleReminder.day === 1
      ? `Сегодня проверено ${scaleReminder.recordCount} из ${scaleReminder.minimum} разных весов. Напоминание исчезнет после четвёртой записи по разным весам.`
      : "В первый день смены проверок весов не было. Выполните проверку сегодня.";
    reminders.push(`<button class="preparation-reminder scales" data-action="navigate" data-page="journals"><span>${scaleReminder.minimum}</span><div><strong>${scaleReminder.day === 1 ? `Контроль весов — первый день смены ${teamCode}` : `Контроль весов — второй день смены ${teamCode}`}</strong><small>${message}</small></div><b>Проверить →</b></button>`);
  }
  const overdueCyclones = pendingCycloneCleaningDates(state.cyclones.records);
  if (overdueCyclones.length) {
    const days = overdueCyclones.map(date => Number(date.slice(-2))).join(" и ");
    reminders.push(`<button class="preparation-reminder cyclone-reminder" data-action="navigate" data-page="cyclones"><span>◌</span><div><strong>Требуется очистка циклонов</strong><small>Нет записи за ${days}-е ${overdueCyclones.length === 1 ? "число" : "числа"} этого месяца. Напоминание исчезнет после внесения записи в журнал.</small></div><b>Открыть →</b></button>`);
  }
  const openTasks = openShiftTasksForAccount();
  if (state.account?.role === "senior" && openTasks.length) {
    const first = openTasks[0];
    reminders.push(`<button class="preparation-reminder" data-action="navigate" data-page="shift-tasks"><span>${openTasks.length}</span><div><strong>Есть незавершённые сменные задания</strong><small>${escapeHtml(first.task)}${openTasks.length > 1 ? ` · ещё ${openTasks.length - 1}` : ""}. Напоминание останется, пока задания не отметят выполненными.</small></div><b>Открыть →</b></button>`);
  }
  return reminders.join("");
}

function connectionBadge() {
  const pending = queueEntries().length;
  const network = `<span class="connection-badge ${navigator.onLine ? "online" : "offline"}" title="${navigator.onLine ? "Подключение к сети доступно" : "Нет подключения к сети"}"><i></i>${navigator.onLine ? ui("online") : ui("offline")}</span>`;
  const queue = pending ? `<button class="queue-badge" data-action="navigate" data-page="sync" title="${pending} записей ожидают отправки в Google"><i>↥</i>Очередь: <b>${pending}</b></button>` : "";
  return `${network}${queue}`;
}

function recordStatus(record) {
  if (record.status === "Аннулировано") return `<span class="status-pill muted" title="${attribute(record.annulReason)}">Аннулировано</span>`;
  if (record.syncState === "conflict") return `<span class="status-pill danger">Конфликт</span>`;
  if (record.syncState === "pending") return `<span class="status-pill warning">В очереди</span>`;
  if (record.source === "demo") return `<span class="status-pill demo">Демо</span>`;
  return `<span class="status-pill success">Отправлено</span>`;
}

function navItem(page, label, icon, count = 0) {
  return `<button class="nav-item ${state.page === page ? "active" : ""}" data-action="navigate" data-page="${page}">${icon}<span>${label}</span>${count ? `<b>${count}</b>` : ""}</button>`;
}

function renderMobileNav() {
  return `<nav class="mobile-nav" aria-label="Мобильное меню">
    ${navItem("dashboard", moduleLabelById("dashboard"), dashboardIcon())}
    ${navItem("attendance", moduleLabelById("attendance"), attendanceIcon(), sidebarNotificationCount("attendance"))}
    ${navItem("journals", moduleLabelById("journals"), journalIcon(), sidebarNotificationCount("journals"))}
    ${navItem("cyclones", moduleLabelById("cyclones"), moduleIcon("cyclone"), sidebarNotificationCount("cyclones"))}
    <button class="nav-item" data-action="open-mobile-menu" aria-haspopup="dialog">${settingsIcon()}<span>Меню</span></button>
  </nav>`;
}

function openMobileMenu() {
  const dialog = createDialog(`<section class="dialog-card mobile-menu-dialog">
    <header class="dialog-heading">
      <div><p class="eyebrow">Основное меню</p><h2>Все разделы</h2></div>
      <button class="icon-button" data-action="close-dialog" aria-label="Закрыть">×</button>
    </header>
    <nav class="mobile-menu-grid" aria-label="Все разделы">
      ${modulesForAccount().map(module => {
        const count = sidebarNotificationCount(module.id);
        return `<button class="mobile-menu-item ${state.page === module.id ? "active" : ""}" data-action="mobile-navigate" data-page="${module.id}">${moduleIcon(module.icon)}<span>${moduleLabel(module)}</span>${count ? `<b>${count}</b>` : ""}</button>`;
      }).join("")}
    </nav>
  </section>`);
  dialog.showModal();
}

function metricCard(label, value, note, tone, compactValue = false) {
  return `<article class="metric-card card ${tone}"><p>${label}</p><strong class="${compactValue ? "compact-value" : ""}">${value}</strong><small>${note}</small></article>`;
}

function settingRow(label, value, note) {
  return `<div class="setting-row"><span><strong>${label}</strong><small>${note}</small></span><b>${value}</b></div>`;
}

function settingsLink(page, title, note, icon) {
  return `<button class="settings-link" data-action="navigate" data-page="${page}"><span>${icon}</span><span><strong>${title}</strong><small>${note}</small></span><b>→</b></button>`;
}

function formField(id, label, control, hint = "", width = "") {
  return `<label class="field ${width}"><span>${label}</span>${control}${hint ? `<small>${hint}</small>` : ""}</label>`;
}

function renderEmptyRow() {
  return `<tr><td colspan="8"><div class="empty-state"><span>◎</span><h3>Записей пока нет</h3><p>Нажмите «Новая запись», чтобы начать.</p></div></td></tr>`;
}

function operationLabel(type) {
  return ({ create: "Новая запись", update: "Исправление", annul: "Аннулирование" })[type] ?? "Изменение";
}

function pageTitle() {
  if (state.page === "sync") return "Синхронизация";
  return moduleLabelById(state.page) || ui("home");
}

function accountWorkstationLabel(account) {
  if (account?.role === "manager") return "Рабочий компьютер начальника";
  if (account?.role === "senior") return "Рабочий компьютер старшего механика";
  return ui("account");
}

function modulesForAccount() {
  return MODULES.filter(module => !module.managerOnly || state.account?.role === "manager");
}

function moduleLabel(module) {
  return module?.labels?.[state.language] ?? module?.labels?.ru ?? "";
}

function moduleLabelById(id) {
  return moduleLabel(MODULES.find(module => module.id === id));
}

function personnel() {
  return [...(state.workforce?.personnel ?? [])];
}

function activePersonnel() {
  return personnel().filter(employee => employee.active !== false);
}

function presentShiftPersonnel() {
  const teamId = isCurrentSharedShift()
    ? state.shift.shiftTeamId
    : state.selectedShiftTeamId ?? scheduledTeam()?.id;
  if (!teamId) return [];
  const activeShift = isCurrentSharedShift() && state.shift.shiftTeamId === teamId ? state.shift : null;
  const attendance = attendanceForShiftStart(teamId, activeShift);
  return shiftStartMembers(teamId).filter(employee => hasWorkedAttendance(attendance.get(employee.id)));
}

function isSubstituteOnly(employee) {
  return Boolean(employee?.substituteOnly) || SUBSTITUTE_ONLY_EMPLOYEE_IDS.includes(employee?.id);
}

function isRegularAreaEmployee(employee) {
  return Boolean(employee) && employee.shiftTeamId !== "office" && !isSubstituteOnly(employee);
}

function regularAreaPersonnel() {
  return activePersonnel().filter(isRegularAreaEmployee);
}

function employeeNames() {
  return activePersonnel().map(employee => employee.fullName).sort((left, right) => left.localeCompare(right, "ru"));
}

function roleLabel(role) {
  return ROLE_LABELS[role] ?? "Должность не указана";
}

function teamById(id) {
  return state.workforce?.shiftTeams?.find(team => team.id === id) ?? null;
}

function teamLabel(id) {
  if (id === "office") return "5/2";
  return teamById(id)?.code ?? "—";
}

function productionShiftCode() {
  const teamId = isCurrentSharedShift()
    ? state.shift?.shiftTeamId
    : state.selectedShiftTeamId ?? scheduledTeam()?.id;
  return teamById(teamId)?.code ?? "";
}

function normalizeMachineStatuses(value) {
  const source = value && typeof value === "object" ? value : {};
  return Object.fromEntries(Array.from({ length: 16 }, (_, index) => {
    const machine = index + 1;
    return [machine, ["work", "attention", "maintenance", "repair", "inactive"].includes(source[machine]) ? source[machine] : "work"];
  }));
}

function renderMachineStatusPanel({ compact = false, interactive = false } = {}) {
  const statuses = normalizeMachineStatuses(state.machineStatuses);
  const repairCount = Object.values(statuses).filter(status => status === "repair").length;
  const attentionCount = Object.values(statuses).filter(status => status === "attention").length;
  const maintenanceCount = Object.values(statuses).filter(status => status === "maintenance").length;
  const inactiveCount = Object.values(statuses).filter(status => status === "inactive").length;
  const canEdit = interactive && ["manager", "senior"].includes(state.account?.role);
  const tiles = Array.from({ length: 16 }, (_, index) => {
    const machine = index + 1;
    const status = statuses[machine];
    const label = { work: "Рабочая", attention: "Требует внимания", maintenance: "ТО", repair: "В ремонте", inactive: "Не в работе" }[status];
    const tag = interactive ? "button" : "div";
    const attributes = interactive
      ? ` type="button" data-action="toggle-machine-status" data-machine="${machine}" ${canEdit ? "" : "disabled"} aria-label="Станок ${machine}: ${label}. ${canEdit ? "Нажмите, чтобы изменить состояние." : ""}" title="Станок ${machine}: ${label}"`
      : ` aria-label="Станок ${machine}: ${label}" title="Станок ${machine}: ${label}"`;
    return `<${tag} class="machine-status-tile ${status}"${attributes}><strong>${machine}</strong><span>${label}</span></${tag}>`;
  }).join("");
  return `<section class="card machine-status-panel ${compact ? "compact" : ""}">
    <div class="machine-status-heading"><div><p class="eyebrow">Состояние станков</p><h2>${repairCount ? `В ремонте: ${repairCount}` : maintenanceCount ? `На ТО: ${maintenanceCount}` : inactiveCount ? `Не в работе: ${inactiveCount}` : attentionCount ? `Требуют внимания: ${attentionCount}` : "Все станки работают"}</h2></div>${interactive ? `<small>${canEdit ? "Клик: рабочая → требует внимания → ТО → в ремонте → не в работе" : "Только просмотр"}</small>` : `<button class="secondary-button" data-action="navigate" data-page="maintenance">Открыть</button>`}</div>
    <div class="machine-status-legend" aria-label="Обозначения"><span class="work">Рабочая</span><span class="attention">Требует внимания</span><span class="maintenance">ТО</span><span class="repair">В ремонте</span><span class="inactive">Не в работе</span></div>
    <div class="machine-status-grid">${tiles}</div>
  </section>`;
}

function activeShiftLeadership() {
  if (!isCurrentSharedShift()) throw new Error("Сначала в табеле начните сегодняшнюю смену.");
  const seniorMechanic = String(state.shift?.seniorMechanic || state.shift?.supervisor || "").trim();
  const mechanic = String(state.shift?.mechanic || "").trim();
  if (!seniorMechanic) throw new Error("Сначала в табеле выберите старшего механика.");
  return { seniorMechanic, mechanic };
}

function currentShiftSeniorMechanic() {
  if (!isCurrentSharedShift()) return "";
  return String(state.shift?.seniorMechanic || state.shift?.supervisor || "").trim();
}

function canManageNonconformities() {
  // A nonconformity can be recorded by either leader assigned to the active
  // shift: the senior mechanic or the mechanic.
  return state.account?.role === "manager" || (["senior", "mechanic"].includes(state.account?.role) && operationalAuthorNames().length > 0);
}

function canManageIncidents() {
  return state.account?.role === "manager" || canManageNonconformities();
}

function scheduledTeam(date = today()) {
  const [year, monthIndex] = monthParts(date);
  return state.workforce?.shiftTeams?.find(team => getScheduleMonth(team, year, monthIndex).some(day => day.date === date && day.scheduled)) ?? null;
}

function isCurrentSharedShift(shift = state.shift) {
  if (!shift?.active) return false;
  const shiftDate = String(shift.shiftDate || (shift.startedAt ? new Intl.DateTimeFormat("en-CA", { timeZone: APP_CONFIG.timeZone }).format(new Date(shift.startedAt)) : ""));
  return shiftDate === today();
}

function shiftLeadershipOptions(members, attendance = new Map(), activeShift = null, preferred = {}) {
  const present = members.filter(employee => attendanceCode(attendance.get(employee.id)) === "11");
  const seniorCandidates = present.filter(employee => employee.role === "senior-mechanic");
  const directMechanics = present.filter(employee => employee.role === "mechanic");
  const seniorPool = seniorCandidates.length ? seniorCandidates : directMechanics;
  const seniorValue = String(preferred.seniorMechanic || activeShift?.seniorMechanic || activeShift?.supervisor || "");
  const mechanicValue = String(preferred.mechanic || activeShift?.mechanic || "");
  const optionMarkup = (items, value, empty, autoSelect, optional = false) => {
    if (!items.length) return `<option value="" selected>${empty}</option>`;
    const selected = items.some(employee => employee.fullName === value) ? value : (autoSelect ? items[0].fullName : "");
    const emptyOption = optional ? '<option value="">Не назначен</option>' : autoSelect ? "" : '<option value="">Выберите сотрудника</option>';
    return `${emptyOption}${items.map(employee => `<option value="${attribute(employee.fullName)}" ${employee.fullName === selected ? "selected" : ""}>${escapeHtml(employee.fullName)}</option>`).join("")}`;
  };
  const selectedSenior = seniorPool.some(employee => employee.fullName === seniorValue) ? seniorValue : seniorPool[0]?.fullName || "";
  // A regular mechanic is the default choice. Mechanic-operators are used
  // only when no regular mechanic is present or that mechanic leads the shift.
  const mechanicPool = directMechanics.filter(employee => employee.fullName !== selectedSenior);
  const fallbackMechanicPool = mechanicPool.length ? mechanicPool : present.filter(employee => employee.role === "mechanic-operator");
  return {
    senior: optionMarkup(seniorPool, seniorValue, "Сначала отметьте присутствующих", true),
    // If a regular mechanic is present, select them automatically. A
    // mechanic-operator remains an optional fallback, never a forced choice.
    mechanic: optionMarkup(fallbackMechanicPool, mechanicValue, "Не назначен", mechanicPool.length > 0, true)
  };
}

function updateShiftLeadershipOptions(form) {
  if (!form?.matches("[data-form=shift-attendance]")) return;
  const teamId = String(form.elements.shiftTeamId?.value || state.selectedShiftTeamId || "");
  const members = shiftStartMembers(teamId);
  const attendance = new Map(members.map(employee => [employee.id, form.elements[`attendance-${employee.id}`]?.value || ""]));
  const senior = form.elements.seniorMechanic;
  const mechanic = form.elements.mechanic;
  if (!senior || !mechanic) return;
  const options = shiftLeadershipOptions(members, attendance, null, { seniorMechanic: senior.value, mechanic: mechanic.value });
  senior.innerHTML = options.senior;
  mechanic.innerHTML = options.mechanic;
}

function shiftLeadershipFromForm(form, teamId) {
  const members = shiftStartMembers(teamId);
  const attendance = new Map(members.map(employee => [employee.id, form.elements[`attendance-${employee.id}`]?.value || ""]));
  const present = members.filter(employee => attendanceCode(attendance.get(employee.id)) === "11");
  const seniorCandidates = present.filter(employee => employee.role === "senior-mechanic");
  const directMechanics = present.filter(employee => employee.role === "mechanic");
  const seniorPool = seniorCandidates.length ? seniorCandidates : directMechanics;
  const seniorMechanic = String(form.elements.seniorMechanic?.value || "").trim();
  const mechanic = String(form.elements.mechanic?.value || "").trim();
  const mechanicPool = directMechanics.filter(employee => employee.fullName !== seniorMechanic);
  const fallbackMechanicPool = mechanicPool.length ? mechanicPool : present.filter(employee => employee.role === "mechanic-operator");
  if (!seniorPool.some(employee => employee.fullName === seniorMechanic)) throw new Error("Выберите старшего механика из присутствующих в табеле.");
  if (mechanic && !fallbackMechanicPool.some(employee => employee.fullName === mechanic)) throw new Error("Выберите механика из присутствующих в табеле.");
  return { seniorMechanic, mechanic };
}

function responsibilityCandidates(teamId, roles) {
  return activePersonnel()
    .filter(employee => employee.shiftTeamId === teamId && roles.includes(employee.role))
    .sort(comparePersonnel);
}

function shiftGuestEntries(teamId) {
  const saved = isCurrentSharedShift() && state.shift.shiftTeamId === teamId
    ? (state.shift.attendance || []).filter(item => item.isSubstitute)
    : [];
  return [...saved, ...state.shiftGuests]
    .filter(item => {
      const employee = activePersonnel().find(person => person.id === item.employeeId);
      return item.homeShiftTeamId && (item.homeShiftTeamId !== teamId || isSubstituteOnly(employee));
    })
    .filter((item, index, list) => list.findIndex(other => other.employeeId === item.employeeId) === index);
}

function shiftStartMembers(teamId) {
  const regular = regularAreaPersonnel().filter(employee => employee.shiftTeamId === teamId);
  const guests = shiftGuestEntries(teamId)
    .map(item => {
      const employee = activePersonnel().find(person => person.id === item.employeeId);
      return employee ? { ...employee, isSubstitute: true, substitutionReason: item.substitutionReason, homeShiftTeamId: item.homeShiftTeamId } : null;
    })
    .filter(Boolean);
  return [...regular, ...guests].sort(comparePersonnel);
}

function loginShiftResponsibility(data) {
  const teamId = String(data.get("responsibleTeamId") || "");
  const selectedId = String(data.get("shiftResponsible") || "");
  const employeeId = selectedId === "other"
    ? String(data.get("otherShiftResponsible") || "")
    : selectedId;
  const allowedRoles = selectedId === "other"
    ? ["mechanic-operator"]
    : ["senior-mechanic", "mechanic"];
  const employee = responsibilityCandidates(teamId, allowedRoles).find(item => item.id === employeeId);
  return employee ? { employeeId: employee.id, fullName: employee.fullName, teamId } : null;
}

function teamsWithCurrentShiftFirst() {
  const currentTeamId = isCurrentSharedShift() ? state.shift.shiftTeamId : scheduledTeam()?.id;
  return [...(state.workforce?.shiftTeams || [])].sort((left, right) => {
    if (left.id === currentTeamId) return -1;
    if (right.id === currentTeamId) return 1;
    return left.code.localeCompare(right.code, "ru");
  });
}

function comparePersonnel(left, right) {
  const teamOrder = { "shift-team-a": 0, "shift-team-b": 1, office: 2 };
  const roleOrder = { "senior-mechanic": 0, mechanic: 1, "mechanic-operator": 2, packer: 3, "head-of-area": 4, "production-manager": 5, administrator: 6, "warehouse-manager": 7 };
  return (teamOrder[left.shiftTeamId] ?? 9) - (teamOrder[right.shiftTeamId] ?? 9) || (roleOrder[left.role] ?? 9) - (roleOrder[right.role] ?? 9) || left.fullName.localeCompare(right.fullName, "ru");
}

function monthParts(value) {
  const [year, month] = String(value).split("-").map(Number);
  return [year, month - 1];
}

function dayHeader(day) {
  const marker = day.isHoliday ? "Праздник" : day.isPreholiday ? "−1 ч" : "";
  return `<th class="${dayClasses(day)}" title="${attribute(calendarTitle(day))}"${day.isToday ? ' aria-label="Сегодня"' : ""}><strong>${day.day}</strong><small>${escapeHtml(day.weekday)}</small>${marker ? `<em>${marker}</em>` : ""}</th>`;
}

function dayClasses(day) { return [day.isToday ? "today" : "", day.isHoliday ? "holiday" : "", day.isPreholiday ? "preholiday" : ""].filter(Boolean).join(" "); }
function calendarTitle(day) {
  const names = day.holidays?.map(item => item.name) ?? [];
  const preholidayNames = day.preholidayFor?.map(item => item.name) ?? [];
  if (names.length && preholidayNames.length) return `Праздник: ${names.join(", ")}. Канун: ${preholidayNames.join(", ")} · −1 ч по графику.`;
  if (names.length) return `Праздник: ${names.join(", ")}`;
  if (preholidayNames.length) return `Предпраздничный день перед: ${preholidayNames.join(", ")} · −1 ч по графику.`;
  return "";
}

function attendanceTone(value) {
  const code = String(value ?? "").trim();
  if (!code) return "empty";
  if (Number.isFinite(Number(code.replace(",", ".")))) return "worked";
  if (code === "A") return "vacation";
  return "other";
}

function timesheetOptions(selected, expectedHours = 11) {
  const current = normalizeAttendanceDisplayValue(selected, expectedHours);
  const hours = Array.from({ length: 48 }, (_, index) => (index + 1) / 2).map(value => `<option value="${value}" ${current === String(value) ? "selected" : ""}>${String(value).replace(".", ",")}</option>`).join("");
  const codes = ATTENDANCE_CODES.filter(item => item.value !== "11").map(item => `<option value="${item.value}" ${current === item.value ? "selected" : ""}>${item.value}</option>`).join("");
  return `<optgroup label="Часы">${hours}</optgroup><optgroup label="Коды">${codes}</optgroup>`;
}

function normalizeAttendanceDisplayValue(value, fallback = 11) {
  const source = String(value ?? "").trim();
  const hours = Number(source.replace(",", "."));
  return Number.isFinite(hours) && hours >= .5 && hours <= 24 && Math.round(hours * 2) === hours * 2
    ? String(hours)
    : (source || String(fallback));
}

function vacationForDay(employeeId, date) {
  return (state.workforce.vacations || []).some(vacation => vacation.employeeId === employeeId
    && vacation.status !== "Аннулирован" && vacation.startDate <= date && vacation.endDate >= date);
}

function filterPersonnelCards() {
  const query = (root.querySelector("[data-personnel-search]")?.value ?? "").trim().toLocaleLowerCase(localeCode());
  const team = root.querySelector("[data-personnel-team]")?.value ?? "all";
  const role = root.querySelector("[data-personnel-role]")?.value ?? "all";
  let visible = 0;
  root.querySelectorAll("[data-personnel-card]").forEach(card => {
    const matches = (!query || card.dataset.search.includes(query)) && (team === "all" || card.dataset.team === team) && (role === "all" || card.dataset.role === role);
    card.hidden = !matches;
    if (matches) visible += 1;
  });
  const counter = root.querySelector("[data-personnel-count]");
  if (counter) counter.textContent = String(visible);
}

function filterPartsWarehouseRows() {
  const query = (root.querySelector("[data-parts-filter][type='search']")?.value ?? "").trim().toLocaleLowerCase(localeCode());
  const category = root.querySelector("select[data-parts-filter]")?.value ?? "all";
  let visible = 0;
  root.querySelectorAll("[data-parts-row]").forEach(row => {
    const matches = (category === "all" || row.dataset.partsCategory === category)
      && (!query || row.dataset.partsSearch.includes(query));
    row.hidden = !matches;
    if (matches) visible += 1;
  });
  root.querySelectorAll("[data-parts-category-card]").forEach(card => {
    card.hidden = ![...card.querySelectorAll("[data-parts-row]")].some(row => !row.hidden);
  });
  const counter = root.querySelector("[data-parts-filter-count]");
  if (counter) counter.textContent = `${visible} ${plural(visible, "позиция", "позиции", "позиций")}`;
}

function ui(key) {
  return SHELL_TEXT[state.language]?.[key] ?? SHELL_TEXT.ru[key] ?? key;
}

function normalizeLanguage(value) {
  return LANGUAGES.some(language => language.code === value) ? value : "ru";
}

function localeCode() {
  return LANGUAGES.find(language => language.code === state.language)?.locale ?? APP_CONFIG.locale;
}

function formatDate(value) {
  return formatJournalDate(value, localeCode());
}

function formatDateTime(value) {
  return formatJournalDateTime(value, localeCode());
}

function startClock() {
  clearInterval(clockTimer);
  updateClock();
  clockTimer = setInterval(updateClock, 1000);
}

function updateClock() {
  const clock = root.querySelector("[data-clock]");
  if (!clock) return;
  const now = new Date();
  const date = clock.querySelector("[data-clock-date]");
  const time = clock.querySelector("[data-clock-time]");
  if (date) date.textContent = headerDate(now);
  if (time) time.textContent = headerTime(now);
  clock.dateTime = now.toISOString();
}

function headerDate(value = new Date()) {
  return new Intl.DateTimeFormat(localeCode(), { timeZone: APP_CONFIG.timeZone, weekday: "short", day: "2-digit", month: "short", year: "numeric" }).format(value).replace(",", "");
}

function headerTime(value = new Date()) {
  return new Intl.DateTimeFormat(localeCode(), { timeZone: APP_CONFIG.timeZone, hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).format(value);
}

function attendanceStatusOptions(selected) {
  const current = attendanceCode(selected);
  return ATTENDANCE_CODES.map(item => `<option value="${item.value}" ${current === item.value ? "selected" : ""}>${item.value} · ${escapeHtml(item.label)}</option>`).join("");
}

function updateAttendanceCounter(form) {
  if (!form) return;
  const counter = form.querySelector("[data-attendance-present]");
  if (!counter) return;
  counter.textContent = String([...form.querySelectorAll("[data-attendance-status]")].filter(select => select.value === "11").length);
}

function updateAttendanceStatusTone(select) {
  select.classList.remove("attendance-status-worked", "attendance-status-vacation", "attendance-status-other", "attendance-status-empty");
  select.classList.add(`attendance-status-${attendanceTone(select.value)}`);
}

function attendanceCode(value) {
  return ({ present: "11", vacation: "A", sick: "L", absent: "P", "day-off": "M" })[String(value || "")] ?? String(value || "11");
}

async function saveShiftAttendanceToTimesheet(teamId, attendance, changes = attendance) {
  const date = today();
  // Starting a shift must stay responsive.  The attendance is first written
  // to the local queue, so that a slow Google Sheets request never blocks the
  // responsible-person dialog or the transition to scale control.
  await withWorkforceActor(async () => {
    for (const item of changes) {
      await workforceService.saveAttendance({
        date,
        shiftTeamId: teamId,
        employeeId: item.employeeId,
        value: attendanceCode(item.status),
        substitutionReason: item.isSubstitute ? item.substitutionReason : "",
        homeShiftTeamId: item.isSubstitute ? item.homeShiftTeamId : ""
      });
    }
  }, attendanceAuthorNames(teamId));
  sendWorkforceInBackground();
}

function attendanceChanges(teamId, attendance) {
  const existing = new Map((state.workforce.attendance || [])
    .filter(item => item.date === today() && item.shiftTeamId === teamId)
    .map(item => [item.employeeId, item]));
  return attendance.filter(item => {
    const prior = existing.get(item.employeeId);
    return !prior
      || attendanceCode(prior.value) !== attendanceCode(item.status)
      || String(prior.substitutionReason || "") !== String(item.substitutionReason || "")
      || String(prior.homeShiftTeamId || "") !== String(item.homeShiftTeamId || "");
  });
}

function attendanceChangeMessage(changes) {
  const existingIds = new Set((state.workforce.attendance || [])
    .filter(item => item.date === today())
    .map(item => item.employeeId));
  const changed = changes.filter(item => existingIds.has(item.employeeId));
  if (!changed.length) return "Подтвердить состав смены и сохранить новые отметки табеля?";
  const names = changed.map(item => activePersonnel().find(person => person.id === item.employeeId)?.fullName || item.employeeId).join(", ");
  return `Будут изменены уже сохранённые отметки: ${names}. Продолжить?`;
}

async function archiveLegacyShift() {
  const legacy = state.legacyShift;
  if (!legacy?.active) return;
  if (!window.confirm("Завершить только старую локальную смену? Табель и общая смена на сервере не изменятся.")) return;
  const history = await store.preference("legacyShiftArchive", []);
  await store.setPreference("legacyShiftArchive", [...history, { ...legacy, archivedAt: new Date().toISOString(), archiveReason: "central-shift-migration" }]);
  await store.setPreference("activeShift", { ...legacy, active: false, endedAt: new Date().toISOString(), endedReason: "migrated-to-central-shift" });
  state.legacyShift = await legacyShiftService.current();
}

function sendWorkforceInBackground() {
  if (!workforceRepository || !navigator.onLine) return;
  if (!state.syncing) {
    state.syncTransfer = { active: true, source: "Табель и персонал" };
    render();
  }
  void syncWorkforce().catch(error => {
    toast(`Табель сохранён на этом компьютере. Отправка в Google будет повторена автоматически: ${error.message}`, "warning");
  }).finally(() => {
    if (!state.syncing) {
      state.syncTransfer = { active: false, source: "" };
      render();
    }
  });
}

function attendanceAuthorNames(teamId) {
  if (isCurrentSharedShift() && state.shift?.shiftTeamId === teamId) {
    const selected = [state.shift.seniorMechanic || state.shift.supervisor, state.shift.mechanic].map(value => String(value || "").trim()).filter(Boolean);
    if (selected.length) return [...new Set(selected)];
  }
  const responsible = state.shiftResponsible;
  const responsibleEmployee = responsible?.teamId === teamId
    ? activePersonnel().find(employee => employee.id === responsible.employeeId)
    : null;
  if (responsibleEmployee?.role === "mechanic-operator") return [responsibleEmployee.fullName];
  return activePersonnel()
    .filter(employee => employee.shiftTeamId === teamId && ["senior-mechanic", "mechanic"].includes(employee.role))
    .map(employee => employee.fullName);
}

function operationalAuthorNames() {
  const teamId = isCurrentSharedShift()
    ? state.shift.shiftTeamId
    : state.selectedShiftTeamId ?? scheduledTeam()?.id;
  return attendanceAuthorNames(teamId);
}

function showInlineFormError(form, message) {
  const panel = form.querySelector("#attendance-form-error");
  if (!panel) return;
  panel.hidden = false;
  panel.textContent = message;
}

function today() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: APP_CONFIG.timeZone }).format(new Date());
}

function currentVilniusTime() {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: APP_CONFIG.timeZone, hour: "2-digit", minute: "2-digit", hourCycle: "h23"
  }).formatToParts(new Date());
  const value = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${value.hour}:${value.minute}`;
}

function canEditTimesheetDate(date) {
  return state.account?.role === "manager" || String(date || "") === today();
}

function personnelDistributionCounterKey(teamId, date = today()) {
  return `pfh-personnel-distribution-runs:${date}:${String(teamId || "")}`;
}

function nextPersonnelDistributionRun(teamId) {
  const key = personnelDistributionCounterKey(teamId);
  try {
    const current = Number.parseInt(window.localStorage.getItem(key) || "0", 10);
    const next = Number.isFinite(current) && current > 0 ? current + 1 : 1;
    window.localStorage.setItem(key, String(next));
    return next;
  } catch {
    return 1;
  }
}

function shiftMonth(value, offset) {
  const [year, month] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1 + offset, 1, 12));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

function monthTitle(value) {
  const [year, month] = value.split("-").map(Number);
  return new Intl.DateTimeFormat(localeCode(), { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(year, month - 1, 1, 12)));
}

function monthDays(value) {
  const [year, month] = value.split("-").map(Number);
  const count = new Date(Date.UTC(year, month, 0, 12)).getUTCDate();
  return Array.from({ length: count }, (_, index) => {
    const day = index + 1;
    const date = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    return {
      day,
      date,
      weekday: new Intl.DateTimeFormat(localeCode(), { weekday: "short", timeZone: "UTC" }).format(new Date(Date.UTC(year, month - 1, day, 12))).replace(".", ""),
      isToday: date === today(),
      ...lithuanianCalendarDay(date)
    };
  });
}

function formatNumber(value) {
  return new Intl.NumberFormat(localeCode(), { maximumFractionDigits: 3, minimumFractionDigits: 0 }).format(Number(value));
}

function formatVacationBalance(value) {
  return new Intl.NumberFormat(localeCode(), { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(Number(value));
}

function formatBoxes(value) {
  return new Intl.NumberFormat(localeCode(), { maximumFractionDigits: 1, minimumFractionDigits: 1 }).format(Number(value));
}

function openPartsWarehouseDialog() {
  const categories = state.partsWarehouse.categories ?? [];
  const options = categories.map(category => `<option value="${attribute(category)}">${escapeHtml(category)}</option>`).join("");
  const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><div><p class="eyebrow">Склад запчастей · Google Sheets</p><h2>Добавить запчасть</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div><div class="form-grid">${formField("parts-category", "Раздел", `<select id="parts-category" name="category" required><option value="">Выберите раздел</option>${options}</select>`)}${formField("parts-name", "Запчасть", '<input id="parts-name" name="name" maxlength="180" required>')}${formField("parts-unit", "Ед. изм.", '<input id="parts-unit" name="unit" value="шт." maxlength="60" required>')}${formField("parts-quantity", "Начальный остаток", '<input id="parts-quantity" name="quantity" type="number" min="0.001" step="0.001" required>')}${formField("parts-minimum", "Мин. остаток", '<input id="parts-minimum" name="minimum" type="number" min="0" step="0.001" value="0" required>')}</div>${formField("parts-note", "Примечание", '<textarea id="parts-note" name="note" rows="3" maxlength="500"></textarea>')}<p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Добавить</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => { event.preventDefault(); const form = event.currentTarget, submit = form.querySelector('[type="submit"]'); submit.disabled = true; try { state.partsWarehouse = await partsWarehouseService.save({ action: "add", ...Object.fromEntries(new FormData(form)) }, state.account); dialog.close(); render(); toast("Запчасть добавлена на склад.", "success"); } catch (error) { showFormError(form, error); submit.disabled = false; } }); dialog.showModal();
}
function openPartsWarehouseMovementDialog(item, action) {
  const adjustment = action === "adjust"; const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><div><p class="eyebrow">Склад запчастей</p><h2>${adjustment ? "Уточнить остаток" : "Приход"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div><p><strong>${escapeHtml(item.name)}</strong><br><small>Текущий остаток: ${formatNumber(item.quantity)} ${escapeHtml(item.unit)}</small></p>${formField("parts-movement-quantity", adjustment ? "Фактический остаток" : "Количество прихода", `<input id="parts-movement-quantity" name="quantity" type="number" min="${adjustment ? "0" : "0.001"}" step="0.001" ${adjustment ? `value="${attribute(item.quantity)}"` : ""} required>`)}${formField("parts-movement-note", "Примечание", '<textarea id="parts-movement-note" name="note" rows="3" maxlength="500"></textarea>')}<p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Сохранить</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => { event.preventDefault(); const form = event.currentTarget, submit = form.querySelector('[type="submit"]'); submit.disabled = true; try { state.partsWarehouse = await partsWarehouseService.save({ action, id: item.id, ...Object.fromEntries(new FormData(form)) }, state.account); dialog.close(); render(); toast("Остаток запчасти обновлён.", "success"); } catch (error) { showFormError(form, error); submit.disabled = false; } }); dialog.showModal();
}

function openPackagingWarehouseDialog(record = null) {
  const items = state.packagingWarehouse.summary.map(row => row.item).filter(Boolean);
  const optionList = [`<option value="">Выберите наименование</option>`, ...items.map(item => `<option value="${attribute(item)}" ${record?.item === item ? "selected" : ""}>${escapeHtml(item)}</option>`)].join("");
  const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><div><p class="eyebrow">Склад упаковки · Google Sheets</p><h2>${record ? "Исправить движение" : "Новое движение"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
    <p>Запись сразу попадёт в общий журнал. Расчётный остаток обновится автоматически.</p>
    <div class="form-grid">${formField("warehouse-date", "Дата", `<input id="warehouse-date" name="date" type="date" value="${attribute(record?.date || today())}" max="${today()}" required>`)}${formField("warehouse-type", "Операция", `<select id="warehouse-type" name="type" required><option value="Приход" ${record?.type === "Приход" ? "selected" : ""}>Приход</option><option value="Расход" ${record?.type === "Расход" ? "selected" : ""}>Расход</option></select>`)}</div>
    ${formField("warehouse-item", "Наименование", `<select id="warehouse-item" name="item" required>${optionList}</select>`)}
    ${formField("warehouse-quantity", "Количество", `<input id="warehouse-quantity" name="quantity" type="number" min="1" step="1" inputmode="numeric" value="${attribute(record?.quantity || "")}" required>`)}
    ${formField("warehouse-note", "Примечание", `<textarea id="warehouse-note" name="note" rows="3" maxlength="500" placeholder="Накладная, место хранения или причина расхода">${escapeHtml(record?.note || "")}</textarea>`)}
    <p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">${record ? "Сохранить изменения" : "Внести в журнал"}</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault(); const form = event.currentTarget; const data = Object.fromEntries(new FormData(form)); const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try { state.packagingWarehouse = await packagingWarehouseService.save({ ...data, ...(record ? { id: record.id } : {}) }, state.account); dialog.close(); render(); toast(record ? "Движение склада исправлено." : "Движение склада внесено в Google журнал.", "success"); }
    catch (error) { showFormError(form, error); submit.disabled = false; }
  });
  dialog.showModal();
}

function openPpeIssueDialog() {
  const items = state.ppeWarehouse.items;
  const optionList = [`<option value="">Выберите наименование</option>`, ...items.map(row => `<option value="${attribute(row.item)}">${escapeHtml(row.item)} · ${formatNumber(row.quantity)} ${escapeHtml(row.unit)}</option>`)].join("");
  const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><div><p class="eyebrow">Склад СИЗ · защищённый журнал</p><h2>Выдача со склада</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>
    <p>Сначала запись попадёт в отдельный журнал СИЗ. Затем программа передаст её в расход соответствующего месяца на листе «Фасовка».</p>
    <div class="form-grid">${formField("ppe-date", "Дата", `<input id="ppe-date" name="date" type="date" value="${today()}" max="${today()}" required>`)}${formField("ppe-quantity", "Количество", '<input id="ppe-quantity" name="quantity" type="number" min="1" step="1" inputmode="numeric" required>')}</div>
    ${formField("ppe-item", "Наименование", `<select id="ppe-item" name="item" required>${optionList}</select>`)}
    ${formField("ppe-note", "Примечание", '<textarea id="ppe-note" name="note" rows="3" maxlength="500" placeholder="Кому или для чего выдано"></textarea>')}
    <p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Внести выдачу</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault(); const form = event.currentTarget; const data = Object.fromEntries(new FormData(form)); const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try { const result = await ppeWarehouseService.issue({ ...data, id: createRuntimeId() }, state.account); state.ppeWarehouse = ppeWarehouseService.snapshot(); dialog.close(); render(); toast(result.status === "Отправлено" ? "Выдача сохранена и передана в «Фасовка»." : "Выдача сохранена в журнале СИЗ. Передачу нужно проверить.", result.status === "Отправлено" ? "success" : "warning"); }
    catch (error) { showFormError(form, error); submit.disabled = false; }
  });
  dialog.showModal();
}

function openIncidentDialog(record = null) {
  if (!canManageIncidents()) { toast("Вносить инциденты может администрация или старший механик, выбранный для текущей смены в табеле.", "warning"); return; }
  const dictionary = state.incidents.dictionary ?? { categories: [], statuses: [], templates: [] };
  const categories = dictionary.categories ?? [];
  const statuses = dictionary.statuses?.length ? dictionary.statuses : ["Открыт", "В работе", "Закрыт"];
  const templates = dictionary.templates ?? [];
  const isManager = state.account?.role === "manager";
  const seniorMechanic = record?.seniorMechanic || currentShiftSeniorMechanic();
  const selectedShift = record?.shift || productionShiftCode();
  const optionList = (items, placeholder, selected = "") => `<option value="">${placeholder}</option>${items.map(item => `<option value="${attribute(item)}" ${item === selected ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}`;
  const typesForCategory = category => templates.filter(item => item.category === category).map(item => item.type);
  const typeOptions = (category, selected = "") => optionList(typesForCategory(category), category ? "Выберите случай" : "Сначала выберите категорию", selected);
  const dateField = isManager ? `<input id="incident-date" name="date" type="date" value="${attribute(record?.date || today())}" max="${today()}" required>` : `<input id="incident-date" name="date" type="date" value="${attribute(record?.date || today())}" readonly>`;
  const shiftField = isManager ? `<select id="incident-shift" name="shift" required><option value="A" ${selectedShift === "A" ? "selected" : ""}>A</option><option value="B" ${selectedShift === "B" ? "selected" : ""}>B</option></select>` : `<input id="incident-shift" name="shift" value="${attribute(selectedShift)}" readonly>`;
  const seniorField = isManager ? `<input id="incident-senior" name="seniorMechanic" value="${attribute(seniorMechanic)}" maxlength="180" required placeholder="Укажите старшего механика">` : `<input id="incident-senior" name="seniorMechanic" value="${attribute(seniorMechanic)}" readonly required>`;
  const seniorHint = isManager ? "Администрация может внести или исправить запись за любую смену." : "Берётся из назначения старшего механика в текущем табеле.";
  const dialog = createDialog(`<form class="dialog-card production-dialog"><div class="dialog-heading"><div><p class="eyebrow">Журнал регистрации инцидентов</p><h2>${record ? "Исправить инцидент" : "Новый инцидент"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div><p>Выберите категорию и случай. Справочник подскажет, кто отвечает, кому сообщить и что сделать сначала.</p><div class="form-grid">${formField("incident-date", "Дата", dateField)}${formField("incident-shift", "Смена", shiftField)}${formField("incident-equipment", "Линия / оборудование", `<input id="incident-equipment" name="equipment" maxlength="180" required>`)}${formField("incident-category", "Категория", `<select id="incident-category" name="category" required>${optionList(categories, "Выберите категорию", record?.category || "")}</select>`)}</div>${formField("incident-type", "Что случилось", `<select id="incident-type" name="type" required ${record?.category ? "" : "disabled"}>${typeOptions(record?.category || "", record?.type || "")}</select>`)}<section class="incident-template-card" data-incident-template hidden></section>${formField("incident-description", "Фактические обстоятельства", '<textarea id="incident-description" name="description" rows="4" maxlength="5000" required placeholder="Что произошло: линия, партия, время, объём и границы"></textarea>')}${formField("incident-immediate", "Меры сразу", '<textarea id="incident-immediate" name="immediateAction" rows="3" maxlength="5000" required placeholder="Меры из справочника появятся после выбора случая"></textarea>')}${formField("incident-corrective", "Выполненные корректирующие действия", '<textarea id="incident-corrective" name="correctiveAction" rows="3" maxlength="5000" required placeholder="Что фактически исправили или запланировали"></textarea>')}<div class="form-grid">${formField("incident-senior", "Старший механик", seniorField, seniorHint)}${formField("incident-status", "Статус", `<select id="incident-status" name="status" required>${optionList(statuses, "Выберите статус", record?.status || "Открыт")}</select>`)}</div><p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">${record ? "Сохранить исправления" : "Внести в журнал"}</button></div></form>`);
  const form = dialog.querySelector("form");
  const templateCard = form.querySelector("[data-incident-template]");
  const showTemplate = (prefill = false) => {
    const template = templates.find(item => item.category === form.elements.category.value && item.type === form.elements.type.value);
    if (!template) { templateCard.hidden = true; return; }
    templateCard.hidden = false;
    const explanation = { "Да": "Объяснительная требуется.", "Нет": "Объяснительная не требуется.", "После проверки": "Решение об объяснительной принимается после проверки обстоятельств.", "По ситуации": "Решение об объяснительной принимает Старший механик после проверки обстоятельств." }[template.explanation] || template.explanation || "—";
    templateCard.innerHTML = `<p class="eyebrow">Подсказка из справочника</p><h3>${escapeHtml(template.severity || "Рабочий случай")}</h3><dl><div><dt>Кто отвечает</dt><dd>${escapeHtml(template.responsible || "—")}</dd></div><div><dt>Кто замечает и что делает</dt><dd>${escapeHtml(template.detectionAndFix || "—")}</dd></div><div><dt>Объяснительная</dt><dd>${escapeHtml(explanation)}</dd></div><div><dt>Кто вносит запись</dt><dd>${escapeHtml(template.reporter || "—")}</dd></div><div><dt>Кому сообщить</dt><dd>${escapeHtml(template.notify || "—")}</dd></div><div><dt>Что важно зафиксировать</dt><dd>${escapeHtml(template.note || "—")}</dd></div><div><dt>Меры сразу</dt><dd>${escapeHtml(template.immediateAction || "—")}</dd></div></dl>`;
    if (prefill && template.immediateAction && (!form.elements.immediateAction.value || form.elements.immediateAction.dataset.template === "true")) { form.elements.immediateAction.value = template.immediateAction; form.elements.immediateAction.dataset.template = "true"; }
  };
  form.elements.category.addEventListener("change", () => { form.elements.type.innerHTML = typeOptions(form.elements.category.value); form.elements.type.disabled = !form.elements.category.value; showTemplate(true); });
  form.elements.type.addEventListener("change", () => showTemplate(true));
  if (record) { form.elements.equipment.value = record.equipment; form.elements.description.value = record.description; form.elements.immediateAction.value = record.immediateAction; form.elements.correctiveAction.value = record.correctiveAction; showTemplate(false); } else form.elements.status.value = "Открыт";
  form.addEventListener("submit", async event => { event.preventDefault(); const data = Object.fromEntries(new FormData(form)); const submit = form.querySelector('[type="submit"]'); submit.disabled = true; try { const allowedSeniorMechanics = isManager ? [] : [seniorMechanic]; if (record) await incidentService.update(record.id, data, allowedSeniorMechanics); else await incidentService.create({ ...data, requestId: `incident-${Date.now()}-${Math.random().toString(36).slice(2, 10)}` }, allowedSeniorMechanics); dialog.close(); await refreshIncidents(); render(); toast(record ? "Исправления сохранены в журнале." : "Инцидент внесён в журнал.", "success"); } catch (error) { showFormError(form, error); submit.disabled = false; } });
  dialog.showModal();
}

function openShiftTaskDialog(record = null) {
  if (state.account?.role !== "manager") return;
  const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><div><p class="eyebrow">Сменное задание</p><h2>${record ? "Изменить задание" : "Новое задание"}</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>${formField("shift-task", "Что нужно сделать", `<textarea id="shift-task" name="task" rows="5" maxlength="5000" required placeholder="Например: прикрутить розетку">${escapeHtml(record?.task || "")}</textarea>`)}${record ? formField("shift-task-status", "Статус", `<select id="shift-task-status" name="status"><option value="Открыто" ${record.status !== "Выполнено" ? "selected" : ""}>Открыто</option><option value="Выполнено" ${record.status === "Выполнено" ? "selected" : ""}>Выполнено</option></select>`) : formField("shift-task-target", "Для какой смены", '<select id="shift-task-target" name="shiftTarget" required><option value="A">A — только смена A</option><option value="B">B — только смена B</option><option value="A,B" selected>A,B — отметка от любой смены</option><option value="A и B">A и B — отметка от каждой смены</option></select>', "Смена увидит только предназначенное ей задание.")}${record ? formField("shift-task-note", "Примечание выполнения", `<textarea id="shift-task-note" name="completionNote" rows="3" maxlength="5000">${escapeHtml(record.completionNote || "")}</textarea>`) : formField("shift-task-photo", "Фото (необязательно)", '<input id="shift-task-photo" name="photo" type="file" accept="image/jpeg,image/png,image/webp">', "JPG, PNG или WebP · до 8 МБ")}<p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">${record ? "Сохранить" : "Поставить задание"}</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault(); const form = event.currentTarget; const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try { if (record) await requestShiftTask("PUT", { id: record.id, expectedRevision: record.revision, ...Object.fromEntries(new FormData(form)) }); else { const values = Object.fromEntries(new FormData(form)); delete values.photo; const photo = await readShiftTaskPhoto(form.elements.photo?.files?.[0]); await requestShiftTask("POST", { ...values, ...(photo ? { photo } : {}) }); } dialog.close(); await refreshShiftTasks(); render(); toast(record ? "Задание изменено." : "Сменное задание поставлено.", "success"); } catch (error) { showFormError(form, error); submit.disabled = false; }
  });
  dialog.showModal();
}

function readShiftTaskPhoto(file) {
  if (!file) return Promise.resolve(null);
  if (!/^(image\/jpeg|image\/png|image\/webp)$/.test(file.type)) return Promise.reject(new Error("Выберите изображение JPG, PNG или WebP."));
  if (file.size > 8 * 1024 * 1024) return Promise.reject(new Error("Размер фотографии не должен превышать 8 МБ."));
  return new Promise((resolvePhoto, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Не удалось прочитать фотографию."));
    reader.onload = () => resolvePhoto({ dataUrl: reader.result });
    reader.readAsDataURL(file);
  });
}

function openShiftTaskCompletionDialog(record) {
  const dialog = createDialog(`<form class="dialog-card small-dialog"><div class="dialog-heading"><div><p class="eyebrow">Сменное задание</p><h2>Отметить выполнение</h2></div><button type="button" class="dialog-close" data-action="close-dialog">×</button></div><p><strong>${escapeHtml(record.task)}</strong></p>${formField("shift-task-completion-note", "Примечание", '<textarea id="shift-task-completion-note" name="completionNote" rows="4" maxlength="5000" placeholder="Что сделано, если нужно — детали"></textarea>')}<p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Отметить выполненным</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => {
    event.preventDefault(); const form = event.currentTarget; const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try { await requestShiftTask("PUT", { id: record.id, expectedRevision: record.revision, status: "Выполнено", shiftCode: currentShiftTaskCode(), ...Object.fromEntries(new FormData(form)) }); dialog.close(); await refreshShiftTasks(); render(); toast(record.shiftTarget === "A и B" ? "Отметка смены сохранена." : "Задание отмечено выполненным.", "success"); } catch (error) { showFormError(form, error); submit.disabled = false; }
  });
  dialog.showModal();
}
function openPackagingDialog() {
  state.packagingEntryItem = state.packagingEntryItem || PACKAGING_DISPLAY_FIELDS[0]?.key || "";
  render();
  focusPackagingQuantity();
}

function focusPackagingQuantity() {
  window.setTimeout(() => root.querySelector("#packaging-quantity:not(:disabled)")?.focus(), 0);
}

function openPackagingEditDialog(record) {
  const fields = PACKAGING_DISPLAY_FIELDS.map(field => formField(`packaging-edit-${field.key}`, field.label, `<input id="packaging-edit-${field.key}" name="${field.key}" type="number" min="0" step="0.001" value="${attribute(record.values?.[field.key] || 0)}" inputmode="decimal">`)).join("");
  const dialog = createDialog(`<form class="dialog-card packaging-dialog"><div class="dialog-heading"><h2>Изменить итог за день</h2><button type="button" class="dialog-close" data-action="close-dialog">×</button></div>${formField("packaging-edit-date", "Дата", `<input id="packaging-edit-date" name="date" type="date" value="${attribute(record.date)}" readonly required>`)}<div class="form-grid packaging-fields">${fields}</div><p id="form-error" class="form-error" hidden></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="close-dialog">Отмена</button><button type="submit" class="primary-button">Сохранить итог</button></div></form>`);
  dialog.querySelector("form").addEventListener("submit", async event => { event.preventDefault(); const form = event.currentTarget; const submit = form.querySelector('[type="submit"]'); submit.disabled = true; try { await packagingService.update(record, Object.fromEntries(new FormData(form)), state.account); dialog.close(); state.packaging = await packagingService.snapshot(); render(); if (navigator.onLine) void packagingService.sync().then(snapshot => { state.packaging = snapshot; render(); }); } catch (error) { showFormError(form, error); submit.disabled = false; } }); dialog.showModal();
}

function formatPercent(value) {
  return new Intl.NumberFormat(localeCode(), { maximumFractionDigits: 1, minimumFractionDigits: 0 }).format(Number(value));
}

function scrapPercentTone(value) {
  const percent = Number(value);
  if (!Number.isFinite(percent)) return "neutral";
  if (percent < 3) return "good";
  if (percent < 5) return "warning";
  return "danger";
}

function scrapPercentLabel(value) {
  return `<span class="scrap-percent scrap-percent--${scrapPercentTone(value)}">${formatPercent(value)}%</span>`;
}

function signedNumber(value) {
  const number = Number(value);
  return `${number > 0 ? "+" : ""}${formatNumber(number)}`;
}

function initials(name) {
  return name.split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function plural(value, one, few, many) {
  const mod10 = value % 10;
  const mod100 = value % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
  return many;
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[character]);
}

function attribute(value = "") {
  return escapeHtml(value);
}

function toast(message, tone = "neutral") {
  const region = document.querySelector("#toast-region");
  if (!region) return;
  const element = document.createElement("div");
  element.className = `toast ${tone}`;
  element.innerHTML = `<span>${tone === "success" ? "✓" : tone === "error" ? "!" : "i"}</span><p>${escapeHtml(translateUiText(message, state.language))}</p>`;
  region.append(element);
  setTimeout(() => element.classList.add("visible"), 10);
  setTimeout(() => {
    element.classList.remove("visible");
    setTimeout(() => element.remove(), 250);
  }, 3800);
}

function renderFatalError(error) {
  root.innerHTML = `<main class="fatal-error"><div class="brand-mark large">!</div><h1>Программа не запустилась</h1><p>${escapeHtml(error.message)}</p><button class="primary-button" onclick="location.reload()">Попробовать снова</button></main>`;
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    navigator.serviceWorker.register("./service-worker.js", { updateViaCache: "none" }).then(registration => registration.update()).catch(() => {});
  }
}

function dashboardIcon() { return `<svg viewBox="0 0 24 24"><path d="M4 13h6V4H4zm0 7h6v-4H4zm10 0h6v-9h-6zm0-16v4h6V4z"/></svg>`; }
function journalIcon() { return `<svg viewBox="0 0 24 24"><path d="M5 4h14v16H5zM8 8h8M8 12h8M8 16h5"/></svg>`; }
function attendanceIcon() { return `<svg viewBox="0 0 24 24"><path d="M5 3v3M19 3v3M4 8h16M5 5h14a1 1 0 0 1 1 1v14H4V6a1 1 0 0 1 1-1zM8 12h2M12 12h2M16 12h1M8 16h2M12 16h2"/></svg>`; }
function personnelIcon() { return `<svg viewBox="0 0 24 24"><path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM3 21v-2a6 6 0 0 1 12 0v2M17 8a3 3 0 0 1 0 6M18 16a5 5 0 0 1 3 5"/></svg>`; }
function syncIcon() { return `<svg viewBox="0 0 24 24"><path d="M20 7h-7V4l-4 4 4 4V9h5a6 6 0 0 1-9 5M4 17h7v3l4-4-4-4v3H6a6 6 0 0 1 9-5"/></svg>`; }
function settingsIcon() { return `<svg viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM19 13.5v-3l-2-.6-.5-1.1 1-1.9-2.1-2.1-1.9 1L12.4 5 12 3h-3l-.6 2-1.1.5-1.9-1-2.1 2.1 1 1.9-.5 1.1-2 .6v3l2 .6.5 1.1-1 1.9 2.1 2.1 1.9-1 1.1.5.6 2h3l.6-2 1.1-.5 1.9 1 2.1-2.1-1-1.9.5-1.1z"/></svg>`; }
function refreshIcon() { return `<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/></svg>`; }
function syncLargeIcon() { return `<svg viewBox="0 0 64 64"><path d="M51 22H35v-8L23 26l12 12v-8h12a14 14 0 0 1-23 11M13 42h16v8l12-12-12-12v8H17a14 14 0 0 1 23-11"/></svg>`; }

function brandIcon() { return `<svg viewBox="0 0 32 32"><path d="M5 10.5 16 4l11 6.5v11L16 28 5 21.5zM5 10.5 16 17l11-6.5M16 17v11M10.5 7.3 21.5 14v6"/></svg>`; }
function sunIcon() { return `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>`; }
function moonIcon() { return `<svg viewBox="0 0 24 24"><path d="M20 15.2A8.5 8.5 0 0 1 8.8 4a8.5 8.5 0 1 0 11.2 11.2z"/></svg>`; }

function moduleIcon(type) {
  if (type === "home") return dashboardIcon();
  if (type === "attendance") return attendanceIcon();
  if (type === "scales") return journalIcon();
  if (type === "personnel") return personnelIcon();
  if (type === "settings") return settingsIcon();
  if (type === "statistics") return statisticsIcon();
  const paths = {
    package: `<path d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5zM4 7.5l8 4.5 8-4.5M12 12v9"/>`,
    tools: `<path d="m14 6 4-4 4 4-4 4M16 8 7 17M4 14l6 6-3 2-5-5z"/>`,
    alert: `<path d="M12 3 2.5 20h19zM12 9v5M12 17h.01"/>`,
    specification: `<path d="M6 3h9l4 4v14H6zM15 3v5h4M9 12h6M9 16h6"/>`,
    production: `<path d="M3 21V9l6 4V9l6 4V5h6v16zM7 17h2M12 17h2M17 17h2"/>`,
    warehouse: `<path d="m3 9 9-6 9 6v12H3zM7 21v-8h10v8M7 16h10"/>`,
    ppe: `<path d="M7 4h10v5l3 3v8H4v-8l3-3zM9 4v5M15 4v5M8 14h8M8 17h8"/>`,
    cyclone: `<path d="M5 4h14l-5 7v7l-4 2v-9zM8 7h8"/>`,
    documents: `<path d="M6 3h9l4 4v14H6zM15 3v5h4M9 12h6M9 16h6"/>`,
    vacation: `<path d="M5 3v3M19 3v3M4 8h16M5 5h14v15H5zM8 12h3M13 12h3M8 16h3"/>`
  };
  return `<svg viewBox="0 0 24 24">${paths[type] ?? paths.documents}</svg>`;
}

function statisticsIcon() { return `<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>`; }
