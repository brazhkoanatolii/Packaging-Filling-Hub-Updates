const SHIFT_START = 7 * 60 + 30;
const FIRST_PRODUCTION_START = 7 * 60 + 45;
const SHIFT_END = 19 * 60 + 30;
const NON_PRODUCTION_INTERVALS = Object.freeze([
  [7 * 60 + 30, 7 * 60 + 45],
  [9 * 60 + 30, 9 * 60 + 35],
  [12 * 60, 12 * 60 + 30],
  [14 * 60, 14 * 60 + 5],
  [16 * 60, 16 * 60 + 30],
  [18 * 60, 18 * 60 + 5],
  [19 * 60, 19 * 60 + 30]
]);

function toMinutes(value) {
  const match = String(value || "").match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const minutes = Number(match[1]) * 60 + Number(match[2]);
  return Number.isFinite(minutes) ? minutes : null;
}

function toTime(value) {
  const hours = Math.floor(value / 60);
  const minutes = value % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function operatorNames(record) {
  return String(record?.operator || "").split(/\s*(?:;|\||\+)\s*/).map(value => value.trim()).filter(Boolean).sort((left, right) => left.localeCompare(right, "ru"));
}

function workingGroup(record) {
  return [String(record?.packer || "").trim(), ...operatorNames(record)].join("|");
}

function productKey(record) {
  return [record?.catalogLine, record?.product, record?.strength].map(value => String(value || "").trim()).join("\u0001");
}

export function productiveMinutesBetween(startTime, endTime) {
  const start = toMinutes(startTime);
  const end = toMinutes(endTime);
  if (start === null || end === null || end <= start) return 0;
  const boundedStart = Math.max(start, SHIFT_START);
  const boundedEnd = Math.min(end, SHIFT_END);
  if (boundedEnd <= boundedStart) return 0;
  return NON_PRODUCTION_INTERVALS.reduce((total, [pauseStart, pauseEnd]) => total - Math.max(0, Math.min(boundedEnd, pauseEnd) - Math.max(boundedStart, pauseStart)), boundedEnd - boundedStart);
}

export function addProductiveMinutes(startTime, requestedMinutes) {
  let cursor = toMinutes(startTime);
  let remaining = Number(requestedMinutes);
  if (cursor === null || !Number.isFinite(remaining) || remaining < 0) return null;
  cursor = Math.max(cursor, SHIFT_START);
  for (const [pauseStart, pauseEnd] of NON_PRODUCTION_INTERVALS) {
    if (remaining <= 0) break;
    if (cursor < pauseStart) {
      const usable = Math.min(remaining, pauseStart - cursor);
      cursor += usable;
      remaining -= usable;
    }
    if (remaining > 0 && cursor >= pauseStart && cursor < pauseEnd) cursor = pauseEnd;
  }
  if (remaining > 0) {
    const usable = Math.min(remaining, Math.max(0, SHIFT_END - cursor));
    cursor += usable;
    remaining -= usable;
  }
  return remaining > 0 || cursor > SHIFT_END ? null : toTime(cursor);
}

export function transitionWorkingMinutes(previous, next) {
  if (!previous || !next || workingGroup(previous) !== workingGroup(next)) return 0;
  const previousLine = String(previous.line || previous.machineLine || "").trim().toUpperCase();
  const nextLine = String(next.line || next.machineLine || "").trim().toUpperCase();
  if (previousLine && nextLine && previousLine !== nextLine) return 20;
  if (previousLine && previousLine === nextLine && productKey(previous) !== productKey(next)) return 15;
  return 0;
}

export function minimumProductionStartTime(records, next, { excludeId = "" } = {}) {
  const base = toTime(FIRST_PRODUCTION_START);
  const nextDate = String(next?.date || "");
  const nextShift = String(next?.shift || "").trim().toUpperCase();
  const group = workingGroup(next);
  const candidates = (records || []).filter(record => (!excludeId || String(record?.id || "") !== String(excludeId))
    && String(record?.date || "") === nextDate
    && String(record?.shift || "").trim().toUpperCase() === nextShift
    && group && workingGroup(record) === group
    && toMinutes(record?.time) !== null);
  if (!candidates.length) return base;
  const start = toMinutes(next?.startTime);
  const previous = [...candidates]
    .filter(record => start === null || toMinutes(record.startTime) === null || toMinutes(record.startTime) <= start)
    .sort((left, right) => toMinutes(right.time) - toMinutes(left.time))[0];
  if (!previous) return base;
  const delay = transitionWorkingMinutes(previous, next);
  if (!delay) return base;
  return addProductiveMinutes(previous.time, delay);
}

export const FIRST_PRODUCTION_START_TIME = toTime(FIRST_PRODUCTION_START);
