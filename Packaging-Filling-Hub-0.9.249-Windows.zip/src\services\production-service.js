import { getVilniusDate, makeId } from "../domain/scale-check.js";
import { FIRST_PRODUCTION_START_TIME, minimumProductionStartTime } from "../domain/production-timing.js";

const LINES = Object.freeze(["A", "B", "D", "F", "H", "K", "L", "M"]);
const CACHE_KEY = "productionJournalCache";
const DRAFT_KEY = "productionJournalDraft";
const PARTICIPANT_SEPARATOR = " + ";

export class ProductionService {
  constructor(store, repository) {
    this.store = store;
    this.repository = repository;
    this.pendingCreates = new Map();
    this.completedCreates = new Map();
  }

  async snapshot() {
    const cached = await this.store.preference(CACHE_KEY, null);
    return { records: cached?.records ?? [], source: cached ? "cache" : "loading", cachedAt: cached?.cachedAt ?? null, error: null };
  }

  async refresh() {
    try {
      const records = normalizeRecords(await this.repository.list());
      const cachedAt = new Date().toISOString();
      await this.store.setPreference(CACHE_KEY, { records, cachedAt });
      return { records, source: "google", cachedAt, error: null };
    } catch (error) {
      const cached = await this.snapshot();
      return { ...cached, error: error.message };
    }
  }

  async draft() {
    return await this.store.preference(DRAFT_KEY, null);
  }

  async saveDraft(record) {
    await this.store.setPreference(DRAFT_KEY, {
      record: structuredClone(record),
      savedAt: new Date().toISOString()
    });
  }

  async clearDraft() {
    await this.store.setPreference(DRAFT_KEY, null);
  }

  async create(input, { packers = [], operators = [] } = {}) {
    const current = await this.snapshot();
    const record = validateProductionRecord(input, { packers, operators }, current.records);
    const requestId = record.requestId;
    if (this.completedCreates.has(requestId)) return this.completedCreates.get(requestId);
    if (this.pendingCreates.has(requestId)) return this.pendingCreates.get(requestId);
    const task = this.createOnce(record);
    this.pendingCreates.set(requestId, task);
    try {
      const saved = await task;
      this.completedCreates.set(requestId, saved);
      while (this.completedCreates.size > 100) this.completedCreates.delete(this.completedCreates.keys().next().value);
      return saved;
    } finally {
      this.pendingCreates.delete(requestId);
    }
  }

  async createOnce(record) {
    const saved = normalizeRecord(await this.repository.create(record));
    const current = await this.snapshot();
    const records = [saved, ...current.records.filter(item => item.id !== saved.id)];
    await this.store.setPreference(CACHE_KEY, { records, cachedAt: new Date().toISOString() });
    return saved;
  }

  async update(id, input, people = {}) {
    const record = validateProductionRecord({ ...input, requestId: productionUpdateRequestId(id) }, people);
    const saved = normalizeRecord(await this.repository.update(id, record));
    const current = await this.snapshot();
    await this.store.setPreference(CACHE_KEY, { records: [saved, ...current.records.filter(item => item.id !== id)], cachedAt: new Date().toISOString() });
    return saved;
  }

  async remove(id) {
    if (!String(id || "").trim()) throw new Error("Не найдена запись для удаления");
    await this.repository.remove(String(id));
    const current = await this.snapshot();
    await this.store.setPreference(CACHE_KEY, { records: current.records.filter(item => item.id !== id), cachedAt: new Date().toISOString() });
  }
}

export { LINES };

export function productionFinishedMassKg(record, specifications = []) {
  const normalize = value => String(value || "").trim().toLocaleLowerCase();
  const product = normalize(record?.product);
  const catalogLine = normalize(record?.catalogLine);
  const strength = Number(record?.strength);
  const matchesProduct = item => normalize(item?.product) === product && Number(item?.variant) === strength;
  const specification = catalogLine
    ? specifications.find(item => matchesProduct(item) && normalize(item?.line) === catalogLine)
    : specifications.find(matchesProduct);
  if (!specification) return 0;
  const gramsPerCan = Number(specification.wetMass) > 0 ? Number(specification.wetMass) : Number(specification.dryMass);
  const canCount = Number(record?.quantity || 0);
  if (!Number.isFinite(gramsPerCan) || !Number.isFinite(canCount) || gramsPerCan <= 0 || canCount <= 0) return 0;
  return canCount * gramsPerCan / 1000;
}

/**
 * The defect percentage is fixed when a production record is entered.  Keep
 * its original denominator for later personnel and shift summaries: product
 * specifications may be edited after the record was saved.  Older records
 * without a stored percentage continue to use their available specification.
 */
export function productionGrossMassKg(record, specifications = []) {
  const scrapKg = Number(record?.scrapKg || 0);
  const scrapPercent = Number(record?.scrapPercent);
  if (scrapKg > 0 && Number.isFinite(scrapPercent) && scrapPercent > 0 && scrapPercent < 1) {
    return scrapKg / scrapPercent;
  }
  return productionFinishedMassKg(record, specifications) + Math.max(0, scrapKg);
}

function productionUpdateRequestId(id) {
  const safeId = String(id || "").trim().replace(/[^a-zA-Z0-9_-]/g, "-");
  return `production-update-${safeId || makeId("request")}`.slice(0, 160);
}

function validateProductionRecord(input, { packers, operators }, existingRecords = []) {
  const date = String(input.date || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > getVilniusDate()) throw new Error("Дата должна быть сегодняшней или более ранней");
  const time = validTime(input.time, "окончания");
  const startTime = validTime(input.startTime, "начала");
  const text = (key, label, limit = 180) => {
    const value = String(input[key] || "").trim();
    if (!value) throw new Error(`Заполните поле «${label}»`);
    if (value.length > limit) throw new Error(`Поле «${label}» слишком длинное`);
    return value;
  };
  const numeric = (key, label, positive = false) => {
    const value = Number(String(input[key] ?? "").replace(",", "."));
    if (!Number.isFinite(value) || value < 0 || (positive && value <= 0)) throw new Error(`Поле «${label}» должно быть ${positive ? "положительным" : "неотрицательным"} числом`);
    return value;
  };
  const packer = text("packer", "Упаковщик");
  const operator = text("operator", "Механик у линии");
  const operatorSecond = String(input.operatorSecond || "").trim();
  const operatorReplacement = String(input.operatorReplacement || "").trim();
  if (operatorSecond.length > 180) throw new Error("Поле «Второй механик-оператор» слишком длинное");
  if (operatorReplacement.length > 180) throw new Error("Поле «Новый механик-оператор» слишком длинное");
  if (!packers.includes(packer)) throw new Error("Выберите присутствующего упаковщика");
  if (!operators.includes(operator)) throw new Error("Выберите присутствующего механика у линии");
  if (operatorSecond && !operators.includes(operatorSecond)) throw new Error("Выберите присутствующего второго механика-оператора");
  if (operatorReplacement && !operators.includes(operatorReplacement)) throw new Error("Выберите присутствующего нового механика-оператора");
  if (operatorSecond && operatorSecond === operator) throw new Error("Второй механик-оператор должен отличаться от первого");
  if (operatorReplacement && [operator, operatorSecond].includes(operatorReplacement)) throw new Error("Новый механик-оператор должен отличаться от уже выбранных");
  const operatorStartTime = String(input.operatorStartTime || "").trim();
  const operatorEndTime = String(input.operatorEndTime || "").trim();
  if ((operatorStartTime || operatorEndTime) && (!operatorStartTime || !operatorEndTime)) throw new Error("Укажите время начала и окончания работы механика");
  if (operatorStartTime || operatorEndTime) {
    validTime(operatorStartTime, "начала работы механика");
    validTime(operatorEndTime, "окончания работы механика");
    if (operatorStartTime < startTime || operatorEndTime > time || operatorStartTime >= operatorEndTime) throw new Error("Время механика должно входить в интервал этой записи");
  }
  const enteredSecondStartTime = String(input.operatorSecondStartTime || "").trim();
  const enteredSecondEndTime = String(input.operatorSecondEndTime || "").trim();
  let operatorSecondStartTime = "";
  let operatorSecondEndTime = "";
  if (operatorSecond) {
    if (enteredSecondStartTime || enteredSecondEndTime) {
      if (!enteredSecondStartTime || !enteredSecondEndTime) throw new Error("Укажите время начала и окончания работы второго механика-оператора");
      validTime(enteredSecondStartTime, "начала работы второго механика-оператора");
      validTime(enteredSecondEndTime, "окончания работы второго механика-оператора");
      if (enteredSecondStartTime < startTime || enteredSecondEndTime > time || enteredSecondStartTime >= enteredSecondEndTime) {
        throw new Error("Время второго механика-оператора должно входить в интервал этой записи");
      }
      operatorSecondStartTime = enteredSecondStartTime;
      operatorSecondEndTime = enteredSecondEndTime;
    } else {
      operatorSecondStartTime = startTime;
      operatorSecondEndTime = time;
    }
  }
  const replacementStartTime = String(input.operatorReplacementStartTime || "").trim();
  const replacementEndTime = String(input.operatorReplacementEndTime || "").trim();
  if (operatorReplacement) {
    if (!operatorStartTime || !operatorEndTime || !replacementStartTime || !replacementEndTime) throw new Error("При смене первого механика-оператора укажите время работы обоих сотрудников");
    validTime(replacementStartTime, "начала работы нового механика-оператора");
    validTime(replacementEndTime, "окончания работы нового механика-оператора");
    if (replacementStartTime < startTime || replacementEndTime > time || replacementStartTime >= replacementEndTime) throw new Error("Время нового механика-оператора должно входить в интервал этой записи");
    if (operatorEndTime > replacementStartTime) throw new Error("Время первого и нового механика-оператора не должно пересекаться");
  }
  const line = text("machineLine", "Линия (машина)", 4).toUpperCase();
  if (!LINES.includes(line)) throw new Error("Выберите линию из рабочего списка");
  const activeMachines = [...new Set((Array.isArray(input.activeMachines) ? input.activeMachines : String(input.activeMachines || "").split(","))
    .map(value => String(value).trim()).filter(Boolean).map(Number).filter(Number.isInteger))];
  const allowedMachines = { B: [2, 3], D: [4, 5], F: [6, 7], H: [8, 9], L: [11, 12, 13], M: [14, 15, 16] }[line] || [];
  if (allowedMachines.length && (!activeMachines.length || activeMachines.some(machine => !allowedMachines.includes(machine)))) {
    throw new Error(`Отметьте работавшие машины линии ${line}`);
  }
  const rawMachineStartTimes = input.machineStartTimes && typeof input.machineStartTimes === "object" ? input.machineStartTimes : {};
  const rawMachineEndTimes = input.machineEndTimes && typeof input.machineEndTimes === "object" ? input.machineEndTimes : {};
  const machineStartTimes = {};
  const machineEndTimes = {};
  activeMachines.forEach(machine => {
    const machineStart = String(rawMachineStartTimes[machine] ?? rawMachineStartTimes[String(machine)] ?? startTime).trim() || startTime;
    const machineEnd = String(rawMachineEndTimes[machine] ?? rawMachineEndTimes[String(machine)] ?? time).trim() || time;
    validTime(machineStart, `включения машины ${machine}`);
    validTime(machineEnd, `выключения машины ${machine}`);
    if (machineStart < startTime || machineEnd > time || machineStart >= machineEnd) throw new Error(`Время работы машины ${machine} должно входить в интервал этой записи`);
    machineStartTimes[machine] = machineStart;
    machineEndTimes[machine] = machineEnd;
  });
  const shift = text("shift", "Смена", 2).toUpperCase();
  if (!["A", "B"].includes(shift)) throw new Error("Смена должна быть определена из табеля");
  const note = String(input.note || "").trim();
  if (note.length > 5000) throw new Error("Примечание не должно превышать 5000 символов");
  const seniorMechanic = String(input.leadership?.seniorMechanic || "").trim();
  const mechanic = String(input.leadership?.mechanic || "").trim();
  if (!seniorMechanic) throw new Error("Выберите старшего механика из текущей смены");
  const quantity = numeric("quantity", "Количество готовой продукции", true);
  const scrapKg = numeric("scrapKg", "Брак продукции");
  const rawScrapPercent = input.scrapPercent;
  const scrapPercent = rawScrapPercent === null || rawScrapPercent === undefined || rawScrapPercent === ""
    ? null
    : numeric("scrapPercent", "Процент брака");
  if (scrapPercent !== null && scrapPercent >= 1) throw new Error("Процент брака должен быть меньше 100%");
  if (startTime < FIRST_PRODUCTION_START_TIME) throw new Error(`Первый продукт можно начать не раньше ${FIRST_PRODUCTION_START_TIME}`);
  const timingRecord = {
    date, shift, machineLine: line, packer,
    operator: [operator, operatorSecond, operatorReplacement].filter(Boolean).join(PARTICIPANT_SEPARATOR),
    catalogLine: text("catalogLine", "Линейка продукта"), product: text("product", "Продукт"), strength: numeric("strength", "Крепость", true), startTime
  };
  const minimumStart = minimumProductionStartTime(existingRecords, timingRecord);
  if (!minimumStart) throw new Error("В этой смене уже недостаточно рабочего времени для нового продукта");
  if (startTime < minimumStart) throw new Error(`Начало выпуска возможно не раньше ${minimumStart}: учтены подготовка и переход`);
  return {
    requestId: String(input.requestId || makeId("production-request")), date, startTime, time,
    product: timingRecord.product, strength: timingRecord.strength,
    catalogLine: timingRecord.catalogLine,
    quantity, scrapKg, scrapPercent,
    canScrapKg: numeric("canScrapKg", "Вес бракованных банок"), packer,
    operator: [operator, operatorSecond, operatorReplacement].filter(Boolean).join(PARTICIPANT_SEPARATOR),
    operatorStartTime: operatorStartTime || startTime,
    operatorEndTime: operatorEndTime || time,
    operatorSecondStartTime: operatorSecond ? operatorSecondStartTime : "",
    operatorSecondEndTime: operatorSecond ? operatorSecondEndTime : "",
    operatorReplacement,
    operatorReplacementStartTime: operatorReplacement ? replacementStartTime : "",
    operatorReplacementEndTime: operatorReplacement ? replacementEndTime : "",
    machineLine: line, activeMachines, machineStartTimes, machineEndTimes, shift,
    seniorMechanic, mechanic, note
  };
}

function validTime(value, label) {
  const time = String(value || "");
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error(`Укажите время ${label} в формате ЧЧ:ММ`);
  return time;
}

function normalizeRecords(records) { return records.map(normalizeRecord).filter(Boolean); }
function normalizeRecord(value) {
  if (!value?.id || !/^\d{4}-\d{2}-\d{2}$/.test(String(value.date || ""))) return null;
  const operator = String(value.operator || "");
  const rawScrapPercent = value.scrapPercent;
  const scrapPercent = rawScrapPercent === null || rawScrapPercent === undefined || rawScrapPercent === "" ? null : Number(rawScrapPercent);
  const activeMachines = Array.isArray(value.activeMachines) ? value.activeMachines : String(value.activeMachines || "").split(",");
  const normalizedMachines = [...new Set(activeMachines.map(value => String(value).trim()).filter(Boolean).map(Number).filter(Number.isInteger))];
  const rawMachineStartTimes = value.machineStartTimes && typeof value.machineStartTimes === "object" ? value.machineStartTimes : {};
  const rawMachineEndTimes = value.machineEndTimes && typeof value.machineEndTimes === "object" ? value.machineEndTimes : {};
  const machineStartTimes = Object.fromEntries(normalizedMachines.map(machine => [machine, String((rawMachineStartTimes[machine] ?? rawMachineStartTimes[String(machine)] ?? value.startTime) || "")]));
  const machineEndTimes = Object.fromEntries(normalizedMachines.map(machine => [machine, String((rawMachineEndTimes[machine] ?? rawMachineEndTimes[String(machine)] ?? value.time) || "")]));
  return { ...value, id: String(value.id), date: String(value.date), startTime: String(value.startTime || ""), time: String(value.time || ""), operatorStartTime: String(value.operatorStartTime || value.startTime || ""), operatorEndTime: String(value.operatorEndTime || value.time || ""), operatorSecondStartTime: String(value.operatorSecondStartTime || ""), operatorSecondEndTime: String(value.operatorSecondEndTime || ""), operatorReplacement: String(value.operatorReplacement || ""), operatorReplacementStartTime: String(value.operatorReplacementStartTime || ""), operatorReplacementEndTime: String(value.operatorReplacementEndTime || ""), activeMachines: normalizedMachines, machineStartTimes, machineEndTimes, catalogLine: String(value.catalogLine || ""), product: String(value.product || ""), line: String(value.line || value.machineLine || ""), shift: String(value.shift || "").toUpperCase(), strength: Number(value.strength), quantity: Number(value.quantity), scrapKg: Number(value.scrapKg), scrapPercent: Number.isFinite(scrapPercent) ? scrapPercent : null, canScrapKg: Number(value.canScrapKg), packer: String(value.packer || ""), operator, operators: splitParticipants(operator), seniorMechanic: String(value.seniorMechanic || ""), mechanic: String(value.mechanic || ""), note: String(value.note || "") };
}

function splitParticipants(value) {
  return [...new Set(String(value || "").split(/\s+\+\s+/).map(item => item.trim()).filter(Boolean))].slice(0, 3);
}
