/**
 * Splits the people selected at a production line.  The same rule is used by
 * the application statistics and by the Google-report exporter, so a number
 * is not interpreted differently in the two places.
 */
export function splitProductionParticipants(value) {
  return [...new Set(String(value || "").split(/\s*(?:;|\||\+)\s*/).map(item => item.trim()).filter(Boolean))].slice(0, 3);
}

/**
 * A second-mechanic interval is meaningful only when two people are assigned
 * to the line and the stored interval has a real duration. Older Google rows
 * can contain the display default 00:00–00:00 even though no one was selected.
 */
export function hasProductionSecondMechanicInterval(record) {
  const people = splitProductionParticipants(record?.operator);
  const replacement = String(record?.operatorReplacement || "").trim();
  if (people.length < 2 || (replacement && people[1] === replacement)) return false;
  const start = timeMinutes(record?.operatorSecondStartTime);
  const end = timeMinutes(record?.operatorSecondEndTime);
  return Number.isFinite(start) && Number.isFinite(end) && end > start;
}

export function productionShiftKey(record) {
  return `${String(record?.date || "").trim()}:${String(record?.shift || "").trim().toUpperCase()}`;
}

export function productionLineCode(record) {
  const value = String(record?.machineLine || record?.line || "").trim().toUpperCase();
  const match = value.match(/(?:^|[-\s])([A-Z])(?:$|[-\s])/);
  return match?.[1] || value;
}

const LINE_MACHINE_NUMBERS = Object.freeze({ L: [11, 12, 13], M: [14, 15, 16] });

function activeMachineIntervals(record) {
  const allowed = LINE_MACHINE_NUMBERS[productionLineCode(record)];
  if (!allowed) return [];
  const selected = Array.isArray(record?.activeMachines) ? record.activeMachines : String(record?.activeMachines || "").split(",");
  const starts = record?.machineStartTimes && typeof record.machineStartTimes === "object" ? record.machineStartTimes : {};
  const ends = record?.machineEndTimes && typeof record.machineEndTimes === "object" ? record.machineEndTimes : {};
  const recordStart = timeMinutes(record?.startTime);
  const recordEnd = timeMinutes(record?.time);
  if (!Number.isFinite(recordStart) || !Number.isFinite(recordEnd) || recordEnd <= recordStart) return [];
  return [...new Set(selected.map(Number).filter(machine => allowed.includes(machine)))]
    .map(machine => ({ machine,
      start: Math.max(recordStart, timeMinutes(starts[machine]) ?? recordStart),
      end: Math.min(recordEnd, timeMinutes(ends[machine]) ?? recordEnd)
    }))
    .filter(({ start, end }) => end > start);
}

function machinesWorkingAt(record, time) {
  const machines = activeMachineIntervals(record);
  // In older records a list of machines means they worked through the full record.
  return machines.length ? machines.filter(({ start, end }) => start <= time && time < end).length : 1;
}

const SHIFT_NON_PRODUCTION_INTERVALS = Object.freeze([
  ["07:30", "07:45"], // preparation before launch
  ["09:30", "09:35"],
  ["12:00", "12:30"],
  ["14:00", "14:05"],
  ["16:00", "16:30"],
  ["18:00", "18:05"],
  ["19:00", "19:30"] // cleanup after production
]);

const SHIFT_PRODUCTION_START = "07:30";
const SHIFT_PRODUCTION_END = "19:00";

function timeMinutes(value) {
  const match = String(value || "").trim().match(/^(?:[01]\d|2[0-3]):[0-5]\d$/);
  return match ? Number(match[0].slice(0, 2)) * 60 + Number(match[0].slice(3, 5)) : null;
}

function productiveMinutes(start, end) {
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return 0;
  return SHIFT_NON_PRODUCTION_INTERVALS.reduce((minutes, [pauseStart, pauseEnd]) => {
    const overlap = Math.max(0, Math.min(end, timeMinutes(pauseEnd)) - Math.max(start, timeMinutes(pauseStart)));
    return minutes - overlap;
  }, end - start);
}

function explicitInterval(record, startField, endField) {
  const start = timeMinutes(record?.[startField]);
  const end = timeMinutes(record?.[endField]);
  return Number.isFinite(start) && Number.isFinite(end) && end > start ? { start, end } : null;
}

function operatorIntervals(record) {
  const people = splitProductionParticipants(record?.operator);
  const recordStart = timeMinutes(record?.startTime);
  const recordEnd = timeMinutes(record?.time);
  if (!people.length || !Number.isFinite(recordStart) || !Number.isFinite(recordEnd) || recordEnd <= recordStart) return [];

  const replacementName = String(record?.operatorReplacement || "").trim();
  const replacementIndex = replacementName ? people.indexOf(replacementName) : -1;
  const secondName = people[1] && replacementIndex !== 1 ? people[1] : "";
  const replacement = replacementName || (people.length > 2 ? people[2] : "");
  const bounded = ({ name, kind, interval }) => interval && ({
    name, kind, start: Math.max(recordStart, interval.start), end: Math.min(recordEnd, interval.end)
  });

  const firstInterval = replacement
    ? explicitInterval(record, "operatorStartTime", "operatorEndTime")
    : { start: recordStart, end: recordEnd };
  const intervals = [bounded({ name: people[0], kind: "first", interval: firstInterval })];
  if (secondName) intervals.push(bounded({ name: secondName, kind: "second", interval: explicitInterval(record, "operatorSecondStartTime", "operatorSecondEndTime") || { start: recordStart, end: recordEnd } }));
  if (replacement) intervals.push(bounded({ name: replacement, kind: "replacement", interval: explicitInterval(record, "operatorReplacementStartTime", "operatorReplacementEndTime") }));
  return intervals.filter(item => item?.name && item.end > item.start);
}

function mergeIntervals(intervals) {
  const ordered = intervals
    .filter(({ start, end }) => Number.isFinite(start) && Number.isFinite(end) && end > start)
    .sort((left, right) => left.start - right.start);
  const merged = [];
  ordered.forEach(interval => {
    const previous = merged.at(-1);
    if (previous && interval.start <= previous.end) previous.end = Math.max(previous.end, interval.end);
    else merged.push({ ...interval });
  });
  return merged;
}

function lineWorkIntervals(record) {
  return operatorIntervals(record).map(({ name, start, end }) => ({ name, start, end }));
}

function shiftProductiveMinutes() {
  return productiveMinutes(timeMinutes(SHIFT_PRODUCTION_START), timeMinutes(SHIFT_PRODUCTION_END));
}

/**
 * Returns actual productive minutes spent at a line for every selected person
 * in a shift. Intervals are merged per person, so two records that overlap do
 * not turn one real minute into two minutes of personal work.
 */
export function productionShiftLineWorkMinutes(group) {
  const intervalsByPerson = new Map();
  (group?.records || []).forEach(record => lineWorkIntervals(record).forEach(({ name, start, end }) => {
    const intervals = intervalsByPerson.get(name) || [];
    intervals.push({ start, end });
    intervalsByPerson.set(name, intervals);
  }));
  return new Map([...intervalsByPerson].map(([name, intervals]) => [
    name,
    mergeIntervals(intervals).reduce((sum, interval) => sum + productiveMinutes(interval.start, interval.end), 0)
  ]));
}

/**
 * Gives a senior mechanic or mechanic only the part of a shift during which
 * they were not selected as working at a line. The line contribution is
 * accounted for separately through productionLineCredits.
 *
 * This is deliberately separate from productionShiftRoleCredits: the latter
 * preserves the historical layout of the external production report, while
 * this helper is used by the personal statistics calculation.
 */
export function productionShiftRemainingRoleCredits(group) {
  const roles = new Map();
  (group?.records || []).forEach(record => {
    [[record?.seniorMechanic, "senior-mechanic"], [record?.mechanic, "mechanic"]].forEach(([value, role]) => {
      const name = String(value || "").trim();
      if (name && !roles.has(name)) roles.set(name, role);
    });
  });
  const lineMinutes = productionShiftLineWorkMinutes(group);
  const shiftMinutes = shiftProductiveMinutes();
  return [...roles].map(([name, role]) => {
    const atLineMinutes = Math.min(shiftMinutes, Number(lineMinutes.get(name) || 0));
    const roleMinutes = Math.max(0, shiftMinutes - atLineMinutes);
    return { name, role, lineMinutes: atLineMinutes, roleMinutes, fraction: shiftMinutes ? roleMinutes / shiftMinutes : 0 };
  });
}

/**
 * Groups records by a shift and returns the people assigned to a whole-shift
 * role. A person can simultaneously be a shift mechanic and temporarily work
 * at a line; their two credits are deliberately kept separate.
 */
export function productionShiftGroups(records = []) {
  const groups = new Map();
  records.forEach(record => {
    const key = productionShiftKey(record);
    const group = groups.get(key) || { key, records: [], shiftAssignees: new Set() };
    group.records.push(record);
    [record?.seniorMechanic, record?.mechanic]
      .map(value => String(value || "").trim())
      .filter(Boolean)
      .forEach(name => group.shiftAssignees.add(name));
    groups.set(key, group);
  });
  return [...groups.values()];
}

/**
 * Returns the people who receive a particular line record and their shares.
 * This does not use the person's official role: a mechanic-operator,
 * mechanic, or senior mechanic standing at a line follows the same rule.
 */
export function productionLineCredits(record, shiftAssignees = new Set()) {
  const people = splitProductionParticipants(record?.operator);
  if (people.length === 1) return [{ name: people[0], fraction: 1 }];
  const recordStart = timeMinutes(record?.startTime);
  const recordEnd = timeMinutes(record?.time);
  const totalMinutes = productiveMinutes(recordStart, recordEnd);
  const intervals = operatorIntervals(record);

  // Entries made before time fields existed retain the original full-record
  // split. New entries always contain a real record interval.
  if (!intervals.length || !totalMinutes) {
    if (people.length !== 2) return people.map(name => ({ name, fraction: 1 / people.length }));
    const [firstDuringOverlap, secondDuringOverlap] = ["L", "M"].includes(productionLineCode(record)) ? [2 / 3, 1 / 3] : [1 / 2, 1 / 2];
    return [{ name: people[0], fraction: firstDuringOverlap }, { name: people[1], fraction: secondDuringOverlap }];
  }

  const result = new Map(people.map(name => [name, 0]));
  const points = [...new Set([
    recordStart, recordEnd,
    ...intervals.flatMap(({ start, end }) => [start, end]),
    ...activeMachineIntervals(record).flatMap(({ start, end }) => [start, end])
  ])].sort((left, right) => left - right);
  let totalWork = 0;
  for (let index = 0; index < points.length - 1; index += 1) {
    const start = points[index], end = points[index + 1];
    const active = intervals.filter(item => item.start < end && item.end > start);
    const minutes = productiveMinutes(start, end);
    if (!minutes || !active.length) continue;
    const work = minutes * machinesWorkingAt(record, start);
    if (!work) continue;
    totalWork += work;
    if (active.length === 1) result.set(active[0].name, result.get(active[0].name) + work);
    else {
      const second = active.find(item => item.kind === "second");
      const secondShare = second && ["L", "M"].includes(productionLineCode(record)) ? 1 / 3 : 1 / active.length;
      active.forEach(item => {
        const share = item === second ? secondShare : second ? (1 - secondShare) / (active.length - 1) : 1 / active.length;
        result.set(item.name, result.get(item.name) + work * share);
      });
    }
  }
  return people.map(name => ({ name, fraction: (result.get(name) || 0) / totalWork })).filter(({ fraction }) => fraction > 0);
}

/**
 * A selected senior mechanic or mechanic receives the complete shift result.
 * Work at a line is accounted for separately under the mechanic-operator
 * role and must not reduce the shift-role result in the daily report.
 */
export function productionShiftRoleCredits(group) {
  const roles = new Map();
  group.records.forEach(record => {
    [[record?.seniorMechanic, "senior-mechanic"], [record?.mechanic, "mechanic"]].forEach(([value, role]) => {
      const name = String(value || "").trim();
      if (name && !roles.has(name)) roles.set(name, role);
    });
  });
  return [...roles].map(([name, role]) => ({ name, role, fraction: 1 }));
}
