[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$UpdatesRepositoryPath,

  [ValidateRange(3, 20)]
  [int]$KeepVersions = 3
)

$ErrorActionPreference = "Stop"

function Invoke-Git {
  param([string[]]$Arguments)

  $errorPath = Join-Path ([System.IO.Path]::GetTempPath()) "pfh-git-$([guid]::NewGuid().ToString('N')).log"
  try {
    $previousErrorAction = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"
    try {
      $output = & git @Arguments 2> $errorPath
      $exitCode = $LASTEXITCODE
      $errorOutput = if (Test-Path -LiteralPath $errorPath) { Get-Content -LiteralPath $errorPath -Raw -Encoding UTF8 } else { "" }
    } finally {
      $ErrorActionPreference = $previousErrorAction
    }
    if ($exitCode -ne 0) {
      throw "Git-команда завершилась с ошибкой: git $($Arguments -join ' ')`n$errorOutput"
    }
    return @($output)
  } finally {
    if (Test-Path -LiteralPath $errorPath) {
      Remove-Item -LiteralPath $errorPath -Force
    }
  }
}

function Get-Sha256 {
  param([string]$Path)

  $sha256 = [System.Security.Cryptography.SHA256]::Create()
  $stream = [System.IO.File]::OpenRead($Path)
  try {
    return ([System.BitConverter]::ToString($sha256.ComputeHash($stream))).Replace("-", "")
  } finally {
    $stream.Dispose()
    $sha256.Dispose()
  }
}

$projectRoot = [System.IO.Path]::GetFullPath((Resolve-Path (Join-Path $PSScriptRoot "..\..")))
$updatesRoot = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $UpdatesRepositoryPath))
$package = Get-Content -LiteralPath (Join-Path $projectRoot "package.json") -Raw -Encoding UTF8 | ConvertFrom-Json
$version = [string]$package.version
$archiveName = "Packaging-Filling-Hub-$version-Windows.zip"
$archivePath = Join-Path $projectRoot "dist\$archiveName"
$manifestPath = Join-Path $updatesRoot "update-manifest.json"

if (-not (Test-Path -LiteralPath (Join-Path $updatesRoot ".git"))) {
  throw "Указанная папка не является копией репозитория обновлений: $updatesRoot"
}
if (-not (Test-Path -LiteralPath $archivePath -PathType Leaf)) {
  throw "Не найден архив текущей версии: $archivePath. Сначала выполните npm run build:windows."
}

Invoke-Git @("-C", $updatesRoot, "fetch", "origin", "main") | Out-Null
$branch = (Invoke-Git @("-C", $updatesRoot, "branch", "--show-current") | Select-Object -First 1).Trim()
if ($branch -ne "main") {
  throw "Репозиторий обновлений должен быть на ветке main, сейчас: $branch"
}
$status = (Invoke-Git @("-C", $updatesRoot, "status", "--porcelain")) -join "`n"
if ($status.Trim()) {
  throw "В репозитории обновлений есть незакоммиченные изменения. Выпуск остановлен, чтобы ничего не перезаписать."
}
$divergence = (Invoke-Git @("-C", $updatesRoot, "rev-list", "--left-right", "--count", "HEAD...origin/main") | Select-Object -First 1).Trim()
if ($divergence -ne "0`t0" -and $divergence -ne "0 0") {
  throw "Репозиторий обновлений расходится с origin/main ($divergence). Сначала безопасно синхронизируйте его."
}

$targetArchive = Join-Path $updatesRoot $archiveName
Copy-Item -LiteralPath $archivePath -Destination $targetArchive -Force
$sha256 = Get-Sha256 $targetArchive
$manifest = [ordered]@{
  packageUrl = "https://raw.githubusercontent.com/brazhkoanatolii/Packaging-Filling-Hub-Updates/main/$archiveName"
  version = $version
  sha256 = $sha256
}
# Windows PowerShell 5 adds a BOM with Set-Content -Encoding UTF8. Keep the
# public JSON readable by existing JSON.parse and ConvertFrom-Json clients.
[System.IO.File]::WriteAllText($manifestPath, (($manifest | ConvertTo-Json) + [Environment]::NewLine), [System.Text.UTF8Encoding]::new($false))

$archives = @(Get-ChildItem -LiteralPath $updatesRoot -File | ForEach-Object {
  if ($_.Name -match '^Packaging-Filling-Hub-(?<version>\d+\.\d+\.\d+)-Windows\.zip$') {
    [pscustomobject]@{ File = $_; Version = [version]$matches.version }
  }
} | Sort-Object Version -Descending)

$oldArchives = @($archives | Select-Object -Skip $KeepVersions | ForEach-Object { $_.File })
$hashFiles = @(Get-ChildItem -LiteralPath $updatesRoot -File | Where-Object {
  $_.Name -match '^Packaging-Filling-Hub-\d+\.\d+\.\d+-Windows\.zip\.sha256$'
})
foreach ($file in @($oldArchives) + @($hashFiles)) {
  Remove-Item -LiteralPath $file.FullName -Force
}

Invoke-Git @("-C", $updatesRoot, "add", "--all") | Out-Null
$changed = (Invoke-Git @("-C", $updatesRoot, "status", "--porcelain")) -join "`n"
if (-not $changed.Trim()) {
  throw "Нет изменений для публикации обновления."
}
Invoke-Git @("-C", $updatesRoot, "commit", "-m", "Publish Packaging-Filling-Hub $version (keep latest $KeepVersions packages)") | Out-Null
Invoke-Git @("-C", $updatesRoot, "push", "origin", "main") | Out-Null

Write-Host "Опубликовано обновление $version" -ForegroundColor Green
Write-Host "SHA256: $sha256"
Write-Host "Оставлено ZIP-версий: $([Math]::Min($archives.Count, $KeepVersions))"
