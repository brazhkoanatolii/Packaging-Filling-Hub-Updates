const MONTH_NAMES = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const OWNED_COLUMNS = [0, 5, 7, 8, 9, 10, 11, 12, 17, 20, 21];
const numberText = value => new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(value);
const close = (a, b) => typeof a === 'number' && typeof b === 'number' ? Math.abs(a - b) < 1e-8 : (a ?? '') === (b ?? '');

export function productionMonthlyRows(rawRows = [], firstRow = 2) {
  return rawRows.flatMap((row, index) => {
    // Deliberately not "Итог..." in A: legacy gateways and SUMIF("Итог*")
    // must not mistake a month for another shift. The visible title is in F.
    const match = String(row?.[0] || '').match(/^Месяц: (\d{4}-(?:0[1-9]|1[0-2]))$/);
    return match && row[5] === 'Итог месяца' ? [{ month: match[1], rowNumber: firstRow + index }] : [];
  });
}

export function productionMonthlyPlans(snapshot, today) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(today)) throw new Error('Не определена текущая дата Вильнюса для итога месяца');
  const raw = snapshot.rawSecondRows || [];
  const existing = productionMonthlyRows(raw);
  const closed = [...new Set([...snapshot.second.map(r => r.date.slice(0, 7)), ...existing.map(r => r.month)])]
    .filter(month => /^\d{4}-\d{2}$/.test(month) && month < today.slice(0, 7)).sort();
  return closed.map(month => {
    const records = snapshot.second.filter(r => r.date.startsWith(month + '-'));
    const owned = existing.filter(r => r.month === month);
    if (owned.length > 1) throw new Error(`Найдены повторные итоги месяца ${month}; запись остановлена`);
    const recordRows = records.map(r => r.rowNumber);
    const firstRecord = Math.min(Infinity, ...recordRows);
    const lastRecord = Math.max(0, ...recordRows);
    const lastShift = Math.max(lastRecord, ...(snapshot.secondSummaries || []).filter(r => r.date.startsWith(month + '-')).map(r => r.rowNumber));
    const nextRecord = Math.min(Infinity, ...snapshot.second.filter(r => r.rowNumber > lastRecord && !r.date.startsWith(month + '-')).map(r => r.rowNumber));
    if (snapshot.second.some(other => !other.date.startsWith(month + '-') && other.rowNumber > firstRecord && other.rowNumber < lastRecord)) {
      throw new Error(`Записи месяца ${month} перемешаны с другим месяцем; строка итога не перемещалась`);
    }
    let rowNumber = owned[0]?.rowNumber;
    if (rowNumber && records.length && (rowNumber <= lastShift || rowNumber >= nextRecord)) throw new Error(`Итог месяца ${month} находится вне своего блока`);
    if (!rowNumber) {
      // Reuse an existing empty separator. Never move source rows or row IDs.
      for (let row = lastShift + 1; row < nextRecord && row <= lastShift + 3; row++) {
        if (!(raw[row - 2] || []).some(value => value !== '' && value !== null && value !== undefined)) { rowNumber = row; break; }
      }
      if (!rowNumber) throw new Error(`Нет пустой строки после месяца ${month}; существующие данные не изменены`);
    }
    const quantity = records.reduce((sum, r) => sum + Number(r.quantity || 0), 0);
    const boxes = quantity / 240;
    const scrapKg = records.reduce((sum, r) => sum + Number(r.scrapKg || 0), 0);
    const canScrapKg = records.reduce((sum, r) => sum + Number(r.canScrapKg || 0), 0);
    const equivalent = records.reduce((sum, r) => {
      const p = Number(r.scrapPercent);
      return Number.isFinite(p) && p >= 0 && p < 1 ? sum + Number(r.quantity || 0) * p / (1 - p) : sum;
    }, 0);
    const percent = quantity + equivalent > 0 ? equivalent / (quantity + equivalent) : null;
    // U on source records is the current plan; old shift totals and V are not
    // inputs. Missing row plans must remain visibly unknown, not become zero.
    const hasPlan = records.length > 0 && records.every(r => typeof r.plannedBoxes === 'number' && Number.isFinite(r.plannedBoxes) && r.plannedBoxes >= 0);
    const plannedBoxes = hasPlan ? records.reduce((sum, r) => sum + r.plannedBoxes, 0) : null;
    const efficiency = plannedBoxes > 0 ? boxes / plannedBoxes : null;
    const efficiencyText = efficiency === null ? 'Нет данных' : `${numberText(efficiency * 100)}%`;
    const dates = records.map(r => r.date).sort();
    const shortDate = value => value.slice(8) + '.' + value.slice(5, 7);
    const period = dates.length ? ` · Записи: ${shortDate(dates[0])}–${shortDate(dates.at(-1))}` : ' · Нет записей';
    const values = Array(35).fill('');
    values[0] = `Месяц: ${month}`;
    values[5] = 'Итог месяца';
    values.splice(7, 6, quantity, boxes, scrapKg, percent ?? '', canScrapKg, `Эфф.: ${efficiencyText}`);
    values[17] = `${MONTH_NAMES[Number(month.slice(5)) - 1]} ${month.slice(0, 4)} · План: ${plannedBoxes === null ? 'Нет данных' : numberText(plannedBoxes) + ' кор.'} · Эффективность: ${efficiencyText}${period}`;
    values[20] = plannedBoxes ?? '';
    values[21] = efficiency ?? '';
    const stored = raw[rowNumber - 2] || [];
    return { month, rowNumber, values, quantity, boxes, percent, efficiency, plannedBoxes, recordCount: records.length,
      changed: OWNED_COLUMNS.some(column => !close(stored[column], values[column])) };
  });
}

export function productionMonthlyRequests(plans, sheetId) {
  const rgb = (red, green, blue) => ({ red: red / 255, green: green / 255, blue: blue / 255 });
  const color = (value, scrap = false) => {
    if (value === null) return [rgb(217, 234, 247), rgb(23, 74, 115)];
    if (scrap ? value >= 0.05 : value < 0.7) return [rgb(220, 53, 69), rgb(255, 255, 255)];
    if (scrap ? value >= 0.03 : value < 0.9) return [rgb(255, 193, 6), rgb(25, 40, 68)];
    if (!scrap && value > 1) return [rgb(139, 92, 246), rgb(255, 255, 255)];
    return [rgb(40, 167, 71), rgb(255, 255, 255)];
  };
  return plans.flatMap(plan => {
    const range = (start, end) => ({ sheetId, startRowIndex: plan.rowNumber - 1, endRowIndex: plan.rowNumber, startColumnIndex: start, endColumnIndex: end });
    const requests = [[0, 1], [5, 6], [7, 13], [17, 18], [20, 22]].map(([start, end]) => ({ updateCells: {
      range: range(start, end), fields: 'userEnteredValue', rows: [{ values: plan.values.slice(start, end).map((value, offset) => ({ userEnteredValue:
        start + offset === 8 ? { formulaValue: `=IF(H${plan.rowNumber}="";"";H${plan.rowNumber}/240)` } :
          typeof value === 'number' ? { numberValue: value } : { stringValue: value }
      })) }]
    } }));
    for (const [start, end, value, scrap] of [[0, 12, plan.percent, true], [12, 35, plan.efficiency, false]]) {
      const [background, foreground] = color(value, scrap);
      requests.push({ repeatCell: { range: range(start, end), cell: { userEnteredFormat: {
        backgroundColorStyle: { rgbColor: background }, textFormat: { bold: true, foregroundColorStyle: { rgbColor: foreground } },
        horizontalAlignment: 'CENTER', verticalAlignment: 'MIDDLE', wrapStrategy: 'WRAP'
      } }, fields: 'userEnteredFormat.backgroundColorStyle,userEnteredFormat.textFormat.bold,userEnteredFormat.textFormat.foregroundColorStyle,userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment,userEnteredFormat.wrapStrategy' } });
    }
    for (const [start, end, type, pattern] of [[7, 8, 'NUMBER', '0'], [8, 10, 'NUMBER', '0.0'], [10, 11, 'PERCENT', '0.0%'], [11, 12, 'NUMBER', '0.0'], [20, 21, 'NUMBER', '0.0'], [21, 22, 'PERCENT', '0.0%']]) {
      requests.push({ repeatCell: { range: range(start, end), cell: { userEnteredFormat: { numberFormat: { type, pattern } } }, fields: 'userEnteredFormat.numberFormat' } });
    }
    requests.push({ updateBorders: { range: range(0, 35), top: { style: 'SOLID_MEDIUM', colorStyle: { rgbColor: rgb(23, 74, 115) } } } });
    requests.push({ updateDimensionProperties: { range: { sheetId, dimension: 'ROWS', startIndex: plan.rowNumber - 1, endIndex: plan.rowNumber }, properties: { pixelSize: 56 }, fields: 'pixelSize' } });
    return requests;
  });
}

export function createProductionMonthlySynchronizer({ read, write, sheetId, today, withLock, enabled = () => true, sleep = ms => new Promise(resolve => setTimeout(resolve, ms)) }) {
  let pending;
  return function sync() {
    if (!enabled()) return Promise.resolve({ updated: 0, skipped: true });
    if (pending) return pending;
    pending = withLock(async () => {
      const initial = await read();
      const plans = productionMonthlyPlans(initial, today()).filter(plan => plan.changed);
      if (!plans.length) return { updated: 0 };
      const fresh = await read();
      if (JSON.stringify(fresh.rawSecondRows) !== JSON.stringify(initial.rawSecondRows)) throw new Error('Журнал изменился во время расчёта месяца; запись отложена');
      await write(productionMonthlyRequests(plans, await sheetId()));
      for (let attempt = 0; attempt < 4; attempt++) {
        const verified = productionMonthlyPlans(await read(), today());
        if (plans.every(plan => verified.some(item => item.month === plan.month && !item.changed))) return { updated: plans.length };
        if (attempt < 3) await sleep(350);
      }
      throw new Error('Google ещё не подтвердил месячные итоги; следующая проверка выполнится автоматически');
    }).finally(() => { pending = null; });
    return pending;
  };
}
