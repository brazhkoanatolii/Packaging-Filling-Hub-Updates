export const EXAM_BANK_SHEET_NAME = "Банк экзаменов";
export const EXAM_BANK_HEADERS = Object.freeze([
  "Должность ID", "Должность", "Тип", "Порядок", "Вопрос",
  "Вариант А", "Вариант Б", "Вариант В", "Вариант Г", "Правильный ответ", "Критический"
]);
export const EXAM_OPTION_IDS = Object.freeze(["А", "Б", "В", "Г"]);

export function normalizeExamBankRoles(roles, defaults = []) {
  const defaultsById = new Map((defaults || []).map(role => [String(role.id), role]));
  const grouped = new Map((defaults || []).map(role => [String(role.id), {
    id: String(role.id), label: String(role.label), theory: [], scenarios: []
  }]));
  (Array.isArray(roles) ? roles : []).forEach(source => {
    const id = String(source?.id || "").trim();
    if (!id || !defaultsById.has(id)) return;
    const target = grouped.get(id);
    target.label = String(source.label || target.label).trim() || target.label;
    const sourceAnswers = Array.isArray(source.answers) ? source.answers : [];
    const sourceCritical = Array.isArray(source.criticalQuestions) ? source.criticalQuestions.map(Number) : [];
    target.theory = (Array.isArray(source.theory) ? source.theory : []).map((question, index) => normalizeTheoryQuestion({
      ...question,
      correctAnswer: Object.prototype.hasOwnProperty.call(question ?? {}, "correctAnswer")
        ? question.correctAnswer
        : (question?.answer ?? sourceAnswers[index]),
      critical: question?.critical ?? sourceCritical.includes(Number(question?.id || index + 1))
    }, index + 1)).filter(Boolean);
    target.scenarios = (Array.isArray(source.scenarios) ? source.scenarios : []).map((scenario, index) => normalizeScenario(scenario, index + 1)).filter(Boolean);
  });
  return [...grouped.values()].map(role => ({
    ...role,
    theory: role.theory.sort((left, right) => left.id - right.id).map((question, index) => ({ ...question, id: index + 1 })),
    scenarios: role.scenarios.sort((left, right) => left.id - right.id).map((scenario, index) => ({ ...scenario, id: index + 1 })),
    answers: role.theory.map(question => question.correctAnswer),
    criticalQuestions: role.theory.filter(question => question.critical).map(question => question.id)
  }));
}

export function examBankRowsFromRoles(roles, defaults = []) {
  return normalizeExamBankRoles(roles, defaults).flatMap(role => [
    ...role.theory.map(question => [
      role.id, role.label, "theory", question.id, question.text,
      ...EXAM_OPTION_IDS.map(optionId => question.options.find(option => option.id === optionId)?.text || ""),
      question.correctAnswer, question.critical ? "Да" : "Нет"
    ]),
    ...role.scenarios.map(scenario => [role.id, role.label, "scenario", scenario.id, scenario.text, "", "", "", "", "", scenario.critical ? "Да" : "Нет"])
  ]);
}

export function examBankRolesFromRows(rows, defaults = []) {
  const grouped = new Map((defaults || []).map(role => [String(role.id), { id: String(role.id), label: String(role.label), theory: [], scenarios: [] }]));
  const defaultIds = new Set(grouped.keys());
  (Array.isArray(rows) ? rows : []).slice(1).forEach(row => {
    const roleId = String(row?.[0] || "").trim();
    const type = String(row?.[2] || "").trim().toLowerCase();
    const text = String(row?.[4] || "").trim();
    if (!defaultIds.has(roleId) || !text || !["theory", "scenario"].includes(type)) return;
    const role = grouped.get(roleId);
    const order = positiveInteger(row?.[3], type === "theory" ? role.theory.length + 1 : role.scenarios.length + 1);
    role.label = String(row?.[1] || role.label).trim() || role.label;
    const critical = ["да", "true", "1", "yes"].includes(String(row?.[10] || "").trim().toLowerCase());
    if (type === "scenario") role.scenarios.push({ id: order, text, critical });
    else {
      const options = EXAM_OPTION_IDS.map((id, index) => ({ id, text: String(row?.[5 + index] || "").trim() })).filter(option => option.text);
      const correctAnswer = String(row?.[9] || "").trim().toUpperCase();
      if (options.length >= 2 && options.some(option => option.id === correctAnswer)) role.theory.push({ id: order, text, options, correctAnswer, critical });
    }
  });
  return normalizeExamBankRoles([...grouped.values()], defaults);
}

export function assertEditableExamBank(roles, defaults = []) {
  const normalized = normalizeExamBankRoles(roles, defaults);
  normalized.forEach(role => {
    if (!role.theory.length) throw new Error(`Для должности «${role.label}» нужен хотя бы один теоретический вопрос`);
    role.theory.forEach((question, index) => {
      if (!question.text) throw new Error(`Проверьте текст вопроса ${index + 1} для «${role.label}»`);
      if (question.options.length < 2) throw new Error(`В вопросе ${index + 1} для «${role.label}» нужны минимум два варианта`);
      if (!question.options.some(option => option.id === question.correctAnswer)) throw new Error(`Выберите правильный ответ в вопросе ${index + 1} для «${role.label}»`);
    });
  });
  return normalized;
}

function normalizeTheoryQuestion(question, fallbackId) {
  const text = String(question?.text || "").trim();
  if (!text) return null;
  const options = (Array.isArray(question?.options) ? question.options : []).map((option, index) => ({
    id: EXAM_OPTION_IDS[index] || String(option?.id || "").trim().toUpperCase(), text: String(option?.text || "").trim()
  })).filter(option => EXAM_OPTION_IDS.includes(option.id) && option.text);
  return { id: positiveInteger(question?.id, fallbackId), text, options, correctAnswer: String(question?.correctAnswer || question?.answer || "").trim().toUpperCase(), critical: Boolean(question?.critical) };
}

function normalizeScenario(scenario, fallbackId) {
  const text = String(scenario?.text || "").trim();
  return text ? { id: positiveInteger(scenario?.id, fallbackId), text, critical: Boolean(scenario?.critical) } : null;
}

function positiveInteger(value, fallback) { const number = Number(value); return Number.isInteger(number) && number > 0 ? number : fallback; }
