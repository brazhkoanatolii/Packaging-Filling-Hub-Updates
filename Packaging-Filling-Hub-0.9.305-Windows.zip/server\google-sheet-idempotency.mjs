import { createHash } from "node:crypto";

export function operationFingerprint(payload) {
  return createHash("sha256").update(JSON.stringify(payload)).digest("hex");
}

export function operationReceiptNote(requestId, payload) {
  return `PFH_OPERATION_V1:${JSON.stringify({ requestId, fingerprint: operationFingerprint(payload) })}`;
}

export function stockVersionGuard(item, now = Date.now()) {
  const version = JSON.stringify({ id: item.id, quantity: item.quantity ?? null, updatedAt: item.updatedAt || "" });
  const metadataId = (createHash("sha256").update(`PFH_STOCK_V1:${version}`).digest().readUInt32BE(0) & 0x7fffffff) || 1;
  return { createDeveloperMetadata: { developerMetadata: { metadataId, metadataKey: "PFH_STOCK_V1", metadataValue: JSON.stringify({ createdAt: now }), location: { spreadsheet: true }, visibility: "DOCUMENT" } } };
}

export async function collectSheetOperationGuards({ spreadsheetId, listMetadata, batchUpdate, now = Date.now }) {
  const expired = (await listMetadata(spreadsheetId)).filter(item => {
    if (!["PFH_OPERATION_V1", "PFH_STOCK_V1"].includes(item.metadataKey)) return false;
    try {
      const value = JSON.parse(item.metadataValue);
      return (item.metadataKey === "PFH_STOCK_V1" || value.durable === true) && Number.isFinite(value.createdAt) && value.createdAt < now() - 3_600_000;
    } catch { return false; }
  });
  if (expired.length) await batchUpdate(spreadsheetId, expired.map(item => ({ deleteDeveloperMetadata: { dataFilter: { developerMetadataLookup: { metadataId: item.metadataId } } } })));
}

// Sheets applies a batch atomically and metadata IDs are unique per book.
// Creating the receipt in the SAME batch as the data makes even concurrent
// retries safe after a lost response or a gateway restart. No local receipt
// is trusted as proof of a remote write. Hash collisions probe another slot
// only after a read proves that the slot belongs to a different operation.
export function createSheetOperationExecutor({ readMetadata, batchUpdate, listMetadata, now = Date.now }) {
  return async function execute({ spreadsheetId, requestId, payload, buildRequests, readReceipt }) {
    const fingerprint = operationFingerprint(payload);
    const metadataValue = JSON.stringify({ requestId, fingerprint, createdAt: now() });
    // Durable cell notes retain receipts without consuming the Sheets 30k
    // metadata budget. Unique metadata guards cover concurrent/in-flight
    // batches; keep them for an hour (Sheets processing limit is 180 seconds).
    // Never collect a marker from a writer without this durable-note contract.
    if (readReceipt && listMetadata) {
      await collectSheetOperationGuards({ spreadsheetId, listMetadata, batchUpdate, now });
    }
    const matches = metadata => {
      if (!metadata) return false;
      let receipt;
      try { receipt = JSON.parse(metadata.metadataValue); } catch { return false; }
      if (metadata.metadataKey !== "PFH_OPERATION_V1" || receipt.requestId !== requestId) return false;
      if (receipt.fingerprint !== fingerprint) {
        const error = new Error("Повторный идентификатор относится к другой записи");
        error.statusCode = 409;
        throw error;
      }
      return true;
    };
    for (let slot = 0; slot < 8; slot++) {
      const metadataId = (createHash("sha256").update(`${requestId}:${slot}`).digest().readUInt32BE(0) & 0x7fffffff) || 1;
      const existing = await readMetadata(spreadsheetId, metadataId);
      if (matches(existing)) return { replayed: true };
      if (existing) continue;
      const durable = readReceipt ? await readReceipt() : null;
      if (durable && matches({ metadataKey: "PFH_OPERATION_V1", metadataValue: JSON.stringify(durable) })) return { replayed: true };
      const requests = await buildRequests();
      const receipt = { createDeveloperMetadata: { developerMetadata: {
        metadataId, metadataKey: "PFH_OPERATION_V1", metadataValue: readReceipt ? JSON.stringify({ ...JSON.parse(metadataValue), durable: true }) : metadataValue,
        location: { spreadsheet: true }, visibility: "DOCUMENT"
      } } };
      try {
        await batchUpdate(spreadsheetId, [receipt, ...requests]);
        return { replayed: false };
      } catch (error) {
        // Never infer that a timed-out write failed. A repeated batch uses
        // the same unique marker, so a late first commit cannot duplicate it.
        const committed = await readMetadata(spreadsheetId, metadataId);
        if (matches(committed)) return { replayed: true };
        if (committed) continue;
        throw error;
      }
    }
    const error = new Error("Не удалось назначить идентификатор операции. Повторите позже.");
    error.statusCode = 503;
    error.publicMessage = error.message;
    throw error;
  };
}
