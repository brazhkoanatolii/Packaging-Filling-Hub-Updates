export class ExamGatewayProvider {
  constructor({ baseUrl = "", fetchImpl = globalThis.fetch } = {}) { this.baseUrl = String(baseUrl).replace(/\/$/, ""); this.fetch = fetchImpl.bind(globalThis); }
  async save(record) { return this.#request("/api/exam-results", "POST", record).then(payload => payload.record); }
  async getBank() { return this.#request("/api/exam-bank", "GET").then(payload => payload.bank); }
  async saveBank(roles) { return this.#request("/api/exam-bank", "PUT", { roles }).then(payload => payload.bank); }
  async #request(path, method, body) {
    let response;
    try { response = await this.fetch(`${this.baseUrl}${path}`, { method, headers: { Accept: "application/json", "Content-Type": "application/json" }, signal: AbortSignal.timeout(30_000), ...(body === undefined ? {} : { body: JSON.stringify(body) }) }); }
    catch (cause) { const error = new Error(cause?.name === "TimeoutError" ? "Google не ответил за 30 секунд. Повторите позже." : "Нет связи с журналом экзаменов в Google"); error.name = globalThis.navigator?.onLine ? "GatewayUnavailableError" : "OfflineError"; throw error; }
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok !== true) throw new Error(payload?.message || "Журнал экзаменов недоступен");
    return payload;
  }
}
