export function createRepairRequestId(crypto = globalThis.crypto) {
  if (typeof crypto?.randomUUID === "function") return `repair-${crypto.randomUUID()}`;
  // The central server can be opened over HTTP on the factory LAN, where
  // randomUUID is unavailable but getRandomValues remains available.
  const bytes = crypto?.getRandomValues?.(new Uint32Array(4));
  return `repair-${Date.now().toString(36)}-${bytes ? Array.from(bytes, value => value.toString(16).padStart(8, "0")).join("") : Math.random().toString(36).slice(2)}`;
}

export class RepairSubmissionService {
  constructor(store, baseUrl, { fetch = globalThis.fetch, makeId = createRepairRequestId } = {}) {
    this.store = store;
    this.baseUrl = baseUrl;
    // Native browser fetch requires Window as its receiver, not this service.
    this.fetch = fetch.bind(globalThis);
    this.makeId = makeId;
    this.inFlight = null;
  }

  pending() { return this.store.preference("pendingRepairSubmission", null); }

  submit(record = null) {
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.submitOnce(record).finally(() => { this.inFlight = null; });
    return this.inFlight;
  }

  async submitOnce(record) {
    let payload = await this.pending();
    const firstAttempt = !payload;
    if (payload && record) throw new Error("Сначала завершите сохранение предыдущего ремонта.");
    if (!payload) {
      if (!record) throw new Error("Нет незавершённого сохранения ремонта.");
      payload = { ...structuredClone(record), journal: "repair", requestId: this.makeId() };
      // Persist before sending so a reload repeats the same operation.
      if (!await this.store.compareAndSetPreference("pendingRepairSubmission", null, payload)) throw new Error("Сначала завершите сохранение предыдущего ремонта.");
    }
    const response = await this.fetch(`${this.baseUrl}/api/maintenance`, {
      method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || !result?.ok) {
      // Initial validation can be edited; an earlier lost reply stays pending.
      if (firstAttempt && response.status === 400) await this.store.compareAndSetPreference("pendingRepairSubmission", payload, null);
      throw new Error(result?.message || "Не удалось подтвердить сохранение ремонта. Повторите проверку этой записи.");
    }
    if (result.partsWriteOffStatus !== "needs_review") {
      try { await this.store.compareAndSetPreference("pendingRepairSubmission", payload, null); }
      catch { return { ...result, warning: "Ремонт сохранён. Не удалось очистить локальное ожидание; повторная проверка безопасна." }; }
    }
    return result;
  }
}
