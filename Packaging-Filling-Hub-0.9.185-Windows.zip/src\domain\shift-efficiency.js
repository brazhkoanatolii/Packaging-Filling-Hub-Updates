const SHIFT_START_MINUTES = 7 * 60 + 30;
const SHIFT_END_MINUTES = 19 * 60;
const NET_SHIFT_MINUTES = 600;
const SHIFT_SPAN_MINUTES = SHIFT_END_MINUTES - SHIFT_START_MINUTES;

const LINE_TARGETS = Object.freeze({ A: 15, B: 30, D: 30, F: 30, H: 30, K: 15, L: 30, M: 30 });

function minutes(value) {
  const match = String(value || "").match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const result = Number(match[1]) * 60 + Number(match[2]);
  return Number.isFinite(result) ? result : null;
}

function interval(record) {
  const start = minutes(record.startTime);
  const end = minutes(record.time);
  if (start === null || end === null || end <= start) return null;
  return { start: Math.max(start, SHIFT_START_MINUTES), end: Math.min(end, SHIFT_END_MINUTES) };
}

function participants(record) {
  return String(record.operator || "").split(/\s*(?:;|\||\+)\s*/).map(value => value.trim()).filter(Boolean);
}

function activeParticipants(record, start, end) {
  const names = participants(record);
  if (names.length < 2) return names;
  const secondStart = minutes(record.operatorSecondStartTime) ?? minutes(record.startTime);
  const secondEnd = minutes(record.operatorSecondEndTime) ?? minutes(record.time);
  return secondStart !== null && secondEnd !== null && secondStart < end && secondEnd > start ? names : names.slice(0, 1);
}

function lineTarget(line, activeRecords, start, end) {
  const code = String(line || "").toUpperCase();
  if (!["L", "M"].includes(code)) return LINE_TARGETS[code] || 0;
  const operators = new Set(activeRecords.flatMap(record => activeParticipants(record, start, end)));
  return operators.size >= 2 ? 45 : 30;
}

function workingGroup(record) {
  return [String(record.packer || "").trim(), ...participants(record).sort((a, b) => a.localeCompare(b, "ru"))].join("|");
}

export function calculateShiftEfficiency(records) {
  const relevant = records.map(record => ({ record, slot: interval(record) })).filter(item => item.slot && item.slot.end > item.slot.start);
  const actualBoxes = relevant.reduce((sum, { record }) => sum + Number(record.quantity || 0) / 240, 0);
  let plannedBoxes = 0;
  let productChangeCount = 0;
  let lineChangeCount = 0;
  let lostMinutes = 0;

  const byLine = new Map();
  relevant.forEach(item => {
    const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
    if (!LINE_TARGETS[line]) return;
    byLine.set(line, [...(byLine.get(line) || []), item]);
  });
  for (const [line, entries] of byLine) {
    const points = [...new Set(entries.flatMap(({ slot }) => [slot.start, slot.end]))].sort((a, b) => a - b);
    let stableProduct = "";
    for (let index = 0; index < points.length - 1; index += 1) {
      const start = points[index], end = points[index + 1];
      const active = entries.filter(({ slot }) => slot.start < end && slot.end > start).map(({ record }) => record);
      if (!active.length) continue;
      const target = lineTarget(line, active, start, end);
      plannedBoxes += target * (end - start) / SHIFT_SPAN_MINUTES;
      const products = [...new Set(active.map(record => String(record.product || "").trim()).filter(Boolean))];
      if (products.length === 1) {
        if (stableProduct && stableProduct !== products[0]) {
          productChangeCount += 1;
          lostMinutes += 15;
          plannedBoxes -= target * 15 / NET_SHIFT_MINUTES;
        }
        stableProduct = products[0];
      }
    }
  }

  const byGroup = new Map();
  relevant.forEach(item => {
    const key = workingGroup(item.record);
    if (!key || key === "|") return;
    byGroup.set(key, [...(byGroup.get(key) || []), item]);
  });
  for (const entries of byGroup.values()) {
    const ordered = [...entries].sort((left, right) => left.slot.start - right.slot.start || left.slot.end - right.slot.end);
    let previous = null;
    ordered.forEach(item => {
      const line = String(item.record.line || item.record.machineLine || "").toUpperCase();
      if (previous && previous.line !== line && item.slot.start >= previous.slot.end) {
        const target = lineTarget(line, [item.record], item.slot.start, item.slot.end);
        lineChangeCount += 1;
        lostMinutes += 20;
        plannedBoxes -= target * 20 / NET_SHIFT_MINUTES;
      }
      if (!previous || item.slot.end > previous.slot.end) previous = { line, slot: item.slot };
    });
  }

  plannedBoxes = Math.max(0, plannedBoxes);
  return {
    actualBoxes,
    plannedBoxes,
    efficiency: plannedBoxes ? actualBoxes / plannedBoxes : null,
    productChangeCount,
    lineChangeCount,
    lostMinutes
  };
}
