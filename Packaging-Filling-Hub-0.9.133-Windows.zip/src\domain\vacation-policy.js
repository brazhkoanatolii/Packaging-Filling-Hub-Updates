import { lithuanianCalendarDay } from "./lithuanian-calendar.js";

export const SHIFT_VACATION_ALLOWANCE = 15;
export const OFFICE_VACATION_ALLOWANCE = 20;

export function vacationUnitLabel(employee) {
  return employee?.shiftTeamId === "office" ? "раб. дн." : "смен";
}

export function vacationUnitLongLabel(employee) {
  return employee?.shiftTeamId === "office" ? "рабочих дней" : "смен";
}

export function isVacationChargeableDay(employee, date, teams = []) {
  if (lithuanianCalendarDay(date).isHoliday) return false;
  if (employee?.shiftTeamId === "office") {
    const weekday = new Date(`${date}T12:00:00Z`).getUTCDay();
    return weekday !== 0 && weekday !== 6;
  }
  const team = teams.find(item => item.id === employee?.shiftTeamId);
  if (!team?.anchorDate) return false;
  const anchor = Date.parse(`${team.anchorDate}T12:00:00Z`);
  const current = Date.parse(`${date}T12:00:00Z`);
  if (!Number.isFinite(anchor) || !Number.isFinite(current)) return false;
  const cycleLength = Math.max(1, Number(team.cycleLengthDays) || 4);
  const offset = ((Math.round((current - anchor) / 86_400_000) % cycleLength) + cycleLength) % cycleLength;
  return (team.workDayOffsets ?? [0, 1]).map(Number).includes(offset);
}

export function vacationUnitCount(employee, startDate, endDate, teams = []) {
  let units = 0;
  for (let cursor = new Date(`${startDate}T12:00:00Z`), finish = new Date(`${endDate}T12:00:00Z`); cursor <= finish; cursor.setUTCDate(cursor.getUTCDate() + 1)) {
    if (isVacationChargeableDay(employee, cursor.toISOString().slice(0, 10), teams)) units += 1;
  }
  return units;
}
