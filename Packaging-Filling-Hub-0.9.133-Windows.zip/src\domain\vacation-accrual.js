import { OFFICE_VACATION_ALLOWANCE, SHIFT_VACATION_ALLOWANCE } from "./vacation-policy.js";

const MONTHS_IN_YEAR = 12;

function validIsoDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));
}

function monthNumber(value) {
  const [year, month] = String(value).split("-").map(Number);
  return year * MONTHS_IN_YEAR + month - 1;
}

function firstMonthAfter(value) {
  const [year, month] = String(value).split("-").map(Number);
  const next = new Date(Date.UTC(year, month, 1));
  return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}`;
}

function monthlyRate(employee) {
  return (employee?.shiftTeamId === "office" ? OFFICE_VACATION_ALLOWANCE : SHIFT_VACATION_ALLOWANCE) / MONTHS_IN_YEAR;
}

/**
 * Amount earned after a confirmed balance snapshot.  The current month is
 * credited as soon as the application synchronizes during that month; this
 * makes the balance stable for the rest of the month and auditable in Sheets.
 */
export function vacationAccruedAfterSnapshot(employee, asOfDate, throughDate) {
  if (!validIsoDate(asOfDate) || !validIsoDate(throughDate) || throughDate < asOfDate) return 0;
  const firstAccrualMonth = firstMonthAfter(asOfDate);
  const hireDate = validIsoDate(employee?.hireDate) ? employee.hireDate : "";
  const hireMonth = hireDate ? hireDate.slice(0, 7) : "";
  const startMonth = hireMonth && hireMonth > firstAccrualMonth ? hireMonth : firstAccrualMonth;
  const endMonth = String(throughDate).slice(0, 7);
  const months = monthNumber(endMonth) - monthNumber(startMonth) + 1;
  return months > 0 ? Number((months * monthlyRate(employee)).toFixed(2)) : 0;
}

export function vacationMonthlyRate(employee) {
  return Number(monthlyRate(employee).toFixed(4));
}
