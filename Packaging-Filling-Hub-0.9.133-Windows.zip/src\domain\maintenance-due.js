export const MAINTENANCE_LINES = Object.freeze([
  { line: "A", label: "1-A", machines: [1] },
  { line: "B", label: "2-3-B", machines: [2, 3] },
  { line: "D", label: "4-5-D", machines: [4, 5] },
  { line: "F", label: "6-7-F", machines: [6, 7] },
  { line: "H", label: "8-9-H", machines: [8, 9] },
  { line: "K", label: "10-K", machines: [10] },
  { line: "L", label: "11-12-13-L", machines: [11, 12, 13] },
  { line: "M", label: "14-15-16-M", machines: [14, 15, 16] }
]);

export const MAINTENANCE_MACHINE_INTERVAL_BOXES = 500;

function date(value) {
  const result = String(value || "").trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(result) ? result : "";
}

function number(value) {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
}

function statusFor(remainingBoxes, intervalBoxes) {
  if (remainingBoxes < 0) return "Просрочено";
  if (remainingBoxes === 0) return "Требуется ТО";
  if (remainingBoxes <= intervalBoxes * 0.2) return "Скоро ТО";
  return "В пределах интервала";
}

/**
 * Every machine holds a 500-box service allowance. Production is shared by
 * the machines on its line, so one line box uses 1/N of each machine's
 * allowance. A service on one machine resets only that machine to 500.
 */
export function calculateMaintenanceDue({ serviceRecords = [], productionRows = [], asOfDate }) {
  const asOf = date(asOfDate);
  const latestServiceByMachine = new Map();
  for (const record of serviceRecords) {
    const machine = Number(record?.machine);
    const serviceDate = date(record?.date);
    if (!Number.isInteger(machine) || !serviceDate || (asOf && serviceDate > asOf)) continue;
    if (serviceDate > (latestServiceByMachine.get(machine) || "")) latestServiceByMachine.set(machine, serviceDate);
  }

  return MAINTENANCE_LINES.map(config => {
    const machineCount = config.machines.length;
    const intervalBoxes = machineCount * MAINTENANCE_MACHINE_INTERVAL_BOXES;
    const machines = config.machines.map(machine => {
      const lastService = latestServiceByMachine.get(machine) || "";
      const producedBoxes = lastService
        ? productionRows.reduce((total, row) => {
          const productionDate = date(row?.date);
          return String(row?.line || "").trim().toUpperCase() === config.line
            && productionDate > lastService
            && (!asOf || productionDate <= asOf)
            ? total + number(row.boxes)
            : total;
        }, 0)
        : null;
      return {
        machine,
        lastService,
        producedBoxes,
        remainingBoxes: producedBoxes === null
          ? null
          : MAINTENANCE_MACHINE_INTERVAL_BOXES - producedBoxes / machineCount
      };
    });
    const ready = machines.every(machine => machine.remainingBoxes !== null);
    const remainingBoxes = ready ? machines.reduce((total, machine) => total + machine.remainingBoxes, 0) : null;
    const producedBoxes = ready ? intervalBoxes - remainingBoxes : null;
    return {
      line: config.label,
      machines,
      intervalBoxes,
      producedBoxes,
      remainingBoxes,
      usedPercent: ready ? producedBoxes / intervalBoxes : null,
      status: ready ? statusFor(remainingBoxes, intervalBoxes) : "Нет даты ТО"
    };
  });
}
