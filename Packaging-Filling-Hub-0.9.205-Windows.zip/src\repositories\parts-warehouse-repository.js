export class PartsWarehouseRepository { constructor(remote) { this.remote = remote; } list() { return this.remote.list(); } save(record) { return this.remote.save(record); } }
