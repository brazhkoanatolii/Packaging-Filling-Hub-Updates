export class PartsWarehouseService {
  constructor(repository) { this.repository = repository; this.snapshotValue = { items: [], operations: [], categories: [], error: null }; }
  async refresh() { try { const data = await this.repository.list(); this.snapshotValue = { items: Array.isArray(data.items) ? data.items : [], operations: Array.isArray(data.operations) ? data.operations : [], categories: Array.isArray(data.categories) ? data.categories : [], error: null }; } catch (error) { this.snapshotValue = { ...this.snapshotValue, error: error.message }; } return this.snapshot(); }
  snapshot() { return { ...this.snapshotValue, items: [...this.snapshotValue.items], operations: [...this.snapshotValue.operations], categories: [...this.snapshotValue.categories] }; }
  async save(record, account) { const payload = { ...record, author: String(account?.title || account?.id || "Администрация") }; await this.repository.save(payload); return this.refresh(); }
}
