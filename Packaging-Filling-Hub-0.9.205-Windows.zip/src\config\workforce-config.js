export const ROLE_LABELS = Object.freeze({
  "head-of-area": "Администрация",
  "production-manager": "Начальник производства",
  administrator: "Администратор",
  "warehouse-manager": "Начальник склада",
  "senior-mechanic": "Старший механик",
  mechanic: "Механик",
  "mechanic-operator": "Механик-оператор",
  packer: "Упаковщик"
});

// These people remain in the common personnel directory and can be added to a
// shift manually for substitution, but are not permanent members of the area.
export const SUBSTITUTE_ONLY_EMPLOYEE_IDS = Object.freeze([
  "employee-0015", // Danuta Jankovskaja
  "employee-0016", // Tatjana Vasilevska
  "employee-0030", // Malgožata Blinstrubaitė
  "employee-0031", // Jolanta Blinstrubaitė
  "employee-0032"  // Viktoriia Hryhorenko
]);

export const ATTENDANCE_CODES = Object.freeze([
  { value: "11", label: "На работе · полная смена", tone: "worked", isWork: true },
  { value: "A", label: "Ежегодный оплачиваемый отпуск", tone: "vacation" },
  { value: "NA", label: "Отпуск за свой счёт", tone: "unpaid" },
  { value: "MA", label: "Учебный отпуск", tone: "vacation" },
  { value: "G", label: "Отпуск по беременности и родам", tone: "parental" },
  { value: "PV", label: "Отпуск по уходу за ребёнком до 3 лет", tone: "parental" },
  { value: "M", label: "Дополнительный выходной день для родителей", tone: "mother-day" },
  { value: "K", label: "Служебная командировка", tone: "worked", isWork: true },
  { value: "L", label: "Больничный", tone: "sick" },
  { value: "NS", label: "Больничный по уходу за больным членом семьи", tone: "sick" },
  { value: "KV", label: "Повышение квалификации", tone: "mother-day" },
  { value: "P", label: "Прогул", tone: "unauthorized" },
  { value: "VV", label: "Исполнение государственных или общественных обязанностей", tone: "mother-day" }
]);

export const WORKFORCE_PERSONNEL = Object.freeze([
  ["employee-0001", "Albert Krevski", "mechanic", "shift-team-a"],
  ["employee-0002", "Vladislav Balašov", "senior-mechanic", "shift-team-a"],
  ["employee-0003", "Valdemar Stacino", "mechanic-operator", "shift-team-a"],
  ["employee-0004", "Bohdan Nevmerzhytskyi", "mechanic-operator", "shift-team-a"],
  ["employee-0005", "Jaroslav Jankovski", "mechanic-operator", "shift-team-a"],
  ["employee-0006", "Serhii Rybalka", "mechanic-operator", "shift-team-a"],
  ["employee-0007", "Volodymyr Nazarenko", "mechanic-operator", "shift-team-a"],
  ["employee-0008", "Ievhenii Bevz", "mechanic-operator", "shift-team-a"],
  ["employee-0009", "Hanna Khalypenko", "packer", "shift-team-a", true, "PAK 3", "1-A"],
  ["employee-0010", "Gražina Stankevič", "packer", "shift-team-a", true, "PAK 6", "1-C"],
  ["employee-0011", "Alina Macutkevič", "packer", "shift-team-a", true, "PAK 7", "1-D"],
  ["employee-0012", "Alicija Girčienė", "packer", "shift-team-a", true, "PAK 9", "1-F"],
  ["employee-0013", "Ilona Curikova", "packer", "shift-team-a", true, "PAK 1", "1-G"],
  ["employee-0014", "Karina Ivaškevičiūtė", "packer", "shift-team-a", true, "PAK 12", "1-O"],
  ["employee-0015", "Danuta Jankovskaja", "packer", "shift-team-a", true, "PAK 2", "1-H"],
  ["employee-0016", "Tatjana Vasilevska", "packer", "shift-team-a", true, "PAK 5", "1-I"],
  ["employee-0017", "Viktor Minin", "senior-mechanic", "shift-team-b"],
  ["employee-0019", "Maksim Tsikhenia", "mechanic-operator", "shift-team-b"],
  ["employee-0020", "Vitalii Paliienko", "mechanic", "shift-team-b"],
  ["employee-0021", "Rolandas Asanovas", "mechanic-operator", "shift-team-b"],
  ["employee-0022", "Serhii Serikov", "mechanic-operator", "shift-team-b"],
  ["employee-0023", "Roman Vasylets", "mechanic-operator", "shift-team-b"],
  ["employee-0024", "Oleksandr Varchenko", "mechanic-operator", "shift-team-b"],
  ["employee-0025", "Renata Kazlauskienė", "packer", "shift-team-b", true, "PAK 4", "1-J"],
  ["employee-0026", "Kamila Babič", "packer", "shift-team-b", true, "PAK 14", "1-P"],
  ["employee-0027", "Irena Jurevič", "packer", "shift-team-b", true, "PAK 15", "1-Q"],
  ["employee-0028", "Anžela Butėnienė", "packer", "shift-team-b", true, "PAK 16", "1-R"],
  ["employee-0029", "Alina Andriushchenko", "packer", "shift-team-b", true, "PAK 19", "1-S"],
  ["employee-0030", "Malgožata Blinstrubaitė", "packer", "shift-team-b", true, "PAK 13", "1-T"],
  ["employee-0031", "Jolanta Blinstrubaitė", "packer", "shift-team-b", true, "PAK 18", "1-U"],
  ["employee-0032", "Viktoriia Hryhorenko", "packer", "shift-team-b", true, "PAK 17", "1-V"]
].map(([id, fullName, role, shiftTeamId, active = true, pakNumber = "", pakCode = ""]) => Object.freeze({ id, fullName, role, shiftTeamId, active, pakNumber, pakCode })));

export const SHIFT_TEAMS = Object.freeze([
  Object.freeze({ id: "shift-team-a", code: "A", name: "Смена A", anchorDate: "2026-07-01", cycleLengthDays: 4, workDayOffsets: [0, 1], shiftDurationHours: 12, accountingHours: 11, active: true }),
  Object.freeze({ id: "shift-team-b", code: "B", name: "Смена B", anchorDate: "2026-07-03", cycleLengthDays: 4, workDayOffsets: [0, 1], shiftDurationHours: 12, accountingHours: 11, active: true })
]);

export const OFFICE_SCHEDULE = Object.freeze({
  id: "office",
  code: "5/2",
  name: "Администрация",
  shiftDurationHours: 8,
  accountingHours: 8
});

export const LITHUANIAN_HOLIDAYS = Object.freeze([
  [1, 1, "Новый год"], [2, 16, "День восстановления государства"], [3, 11, "День восстановления независимости"],
  [5, 1, "День труда"], [6, 24, "Йонинес"], [7, 6, "День государственности"], [8, 15, "Успение"],
  [11, 1, "День всех святых"], [11, 2, "День поминовения"], [12, 24, "Сочельник"], [12, 25, "Рождество"], [12, 26, "Второй день Рождества"]
].map(([month, day, name]) => Object.freeze({ month, day, name })));
