export class PartsWarehouseGatewayProvider {
  constructor({ baseUrl = "", fetchImpl = globalThis.fetch } = {}) { this.baseUrl = String(baseUrl).replace(/\/$/, ""); this.fetch = fetchImpl.bind(globalThis); }
  async list() { return this.#request("GET"); }
  async save(record) { return this.#request("POST", record); }
  async #request(method, body) {
    let response; try { response = await this.fetch(`${this.baseUrl}/api/parts-warehouse`, { method, headers: { Accept: "application/json", ...(body ? { "Content-Type": "application/json" } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(30_000) }); } catch (error) { throw new Error(error?.name === "TimeoutError" ? "Google не ответил за 30 секунд" : "Нет связи со складом запчастей в Google"); }
    const payload = await response.json().catch(() => null); if (!response.ok || payload?.ok !== true) throw new Error(payload?.message || "Склад запчастей недоступен"); return payload;
  }
}
