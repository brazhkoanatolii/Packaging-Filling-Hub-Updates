const pairedRoles = new Set(["mechanic", "senior-mechanic"]);
const sameRoleCoverage = new Set(["mechanic-operator", "packer"]);

function hasCoverageConflict(left, right) {
  if (left.role === right.role && sameRoleCoverage.has(left.role)) return true;
  return pairedRoles.has(left.role) && pairedRoles.has(right.role) && left.role !== right.role;
}

function datesOverlap(left, right) {
  return left.startDate <= right.endDate && right.startDate <= left.endDate;
}

/**
 * Returns the non-blocking coverage warnings for vacation periods.
 * Only production staff in the same shift are compared: two packers, two
 * mechanic-operators, or the senior mechanic together with a mechanic.
 */
export function findVacationConflicts(vacations, personnel) {
  const employees = new Map((personnel || []).map(employee => [employee.id, employee]));
  const active = (vacations || []).filter(vacation => {
    const employee = employees.get(vacation.employeeId);
    return vacation?.status !== "Аннулирован"
      && employee?.shiftTeamId
      && employee.shiftTeamId !== "office"
      && /^\d{4}-\d{2}-\d{2}$/.test(String(vacation.startDate || ""))
      && /^\d{4}-\d{2}-\d{2}$/.test(String(vacation.endDate || ""));
  });
  const warnings = new Map();

  for (let index = 0; index < active.length; index += 1) {
    const vacation = active[index];
    const employee = employees.get(vacation.employeeId);
    for (let next = index + 1; next < active.length; next += 1) {
      const otherVacation = active[next];
      const otherEmployee = employees.get(otherVacation.employeeId);
      if (vacation.employeeId === otherVacation.employeeId
        || employee.shiftTeamId !== otherEmployee?.shiftTeamId
        || !hasCoverageConflict(employee, otherEmployee)
        || !datesOverlap(vacation, otherVacation)) continue;

      const left = { vacation, employee: otherEmployee, overlapStart: vacation.startDate > otherVacation.startDate ? vacation.startDate : otherVacation.startDate, overlapEnd: vacation.endDate < otherVacation.endDate ? vacation.endDate : otherVacation.endDate };
      const right = { vacation: otherVacation, employee, overlapStart: left.overlapStart, overlapEnd: left.overlapEnd };
      warnings.set(vacation.id, [...(warnings.get(vacation.id) || []), left]);
      warnings.set(otherVacation.id, [...(warnings.get(otherVacation.id) || []), right]);
    }
  }
  return warnings;
}
