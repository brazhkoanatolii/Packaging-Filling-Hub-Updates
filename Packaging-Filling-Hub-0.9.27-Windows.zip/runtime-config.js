globalThis.__PACKAGING_FILLING_CONFIG__ = Object.freeze({
  mode: "gateway",
  googleWritesEnabled: false,
  gatewayBaseUrl: "",
  workstationRole: null,
  workstationId: null,
  workstationLabel: null,
  version: "0.9.27"
});
