const ILONA_CURIKOVA_ID = "employee-0013";
const ILONA_PREFERRED_LINES = ["L", "M"];
const ROTATION_LINES = new Set(["B", "H"]);

function unique(values) {
  return [...new Set((values ?? []).map(value => String(value || "").trim()).filter(Boolean))];
}

export function shuffle(values, random = Math.random) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(random() * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}

function normalizedName(value) {
  return String(value || "").trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

function latestPackerLineRecord(records, line, packerName) {
  const targetName = normalizedName(packerName);
  return (records || []).reduce((latest, record) => {
    if (String(record?.line || "").trim() !== line || normalizedName(record?.packer) !== targetName) return latest;
    const key = `${String(record?.date || "").padEnd(10, "0")}T${String(record?.time || record?.startTime || "").padEnd(5, "0")}`;
    return !latest || key > latest ? key : latest;
  }, "");
}

function rotationOrder(ids, line, packerNamesById, historyRecords) {
  return [...ids].sort((left, right) => {
    const leftName = String(packerNamesById[left] || left);
    const rightName = String(packerNamesById[right] || right);
    const leftLast = latestPackerLineRecord(historyRecords, line, leftName);
    const rightLast = latestPackerLineRecord(historyRecords, line, rightName);
    // A person who has never worked this line goes first. Otherwise the person
    // with the oldest real journal entry goes first, including after absence.
    if (!leftLast && rightLast) return -1;
    if (leftLast && !rightLast) return 1;
    if (leftLast !== rightLast) return leftLast.localeCompare(rightLast);
    return leftName.localeCompare(rightName, "ru");
  });
}

export function distributePersonnel({ teamId = "", lines = [], operatorIds = [], packerIds = [], packerNamesById = {}, historyRecords = [] }, random = Math.random) {
  const selectedLines = unique(lines);
  const operators = shuffle(unique(operatorIds), random);
  const packers = shuffle(unique(packerIds), random);
  const rotationLinesSelected = selectedLines.filter(line => ROTATION_LINES.has(line));
  const preferredLine = teamId === "shift-team-a" && packers.includes(ILONA_CURIKOVA_ID)
    ? ILONA_PREFERRED_LINES.find(line => selectedLines.includes(line))
    : "";
  // Ilona keeps the L/M priority in shift A. B/H can take priority only when
  // the journal queue has actually reached her; merely selecting B/H does not
  // make her lose the preferred line.
  const ilonaIsNextOnRotationLine = rotationLinesSelected.some(line =>
    rotationOrder(packers, line, packerNamesById, historyRecords)[0] === ILONA_CURIKOVA_ID
  );
  const reserveIlonaForPreferredLine = preferredLine && !ilonaIsNextOnRotationLine;
  const remainingPackers = reserveIlonaForPreferredLine ? packers.filter(id => id !== ILONA_CURIKOVA_ID) : packers;
  const assignedPackerIds = new Set();
  const assignedLines = selectedLines.map((line, index) => {
    const availablePackers = remainingPackers.filter(id => !assignedPackerIds.has(id));
    const packerId = line === preferredLine && reserveIlonaForPreferredLine
      ? ILONA_CURIKOVA_ID
      : (ROTATION_LINES.has(line)
        ? rotationOrder(availablePackers, line, packerNamesById, historyRecords)[0]
        : availablePackers[0]) || "";
    if (packerId) assignedPackerIds.add(packerId);
    return { line, operatorId: operators[index] || "", packerId };
  });
  return {
    lines: assignedLines,
    unassignedOperatorIds: operators.slice(selectedLines.length),
    unassignedPackerIds: packers.filter(id => !assignedPackerIds.has(id))
  };
}
