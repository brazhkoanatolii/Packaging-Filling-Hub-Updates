// Coalesce concurrent identical reads without caching snapshots across writes.
export function createGoogleSheetReader({ fetchImpl = fetch, sleep = ms => new Promise(resolve => setTimeout(resolve, ms)) } = {}) {
  const pending = new Map();
  return function read(endpoint, accessToken) {
    const key = `${accessToken}\n${endpoint}`;
    if (pending.has(key)) return pending.get(key);
    const task = (async () => {
      for (let attempt = 0; ; attempt++) {
        let response;
        try {
          response = await fetchImpl(endpoint, {
            headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
            signal: AbortSignal.timeout(12_000)
          });
        } catch (error) {
          if (attempt >= 2 || !["TypeError", "TimeoutError"].includes(error.name)) throw error;
          await sleep(1000 * 2 ** attempt);
          continue;
        }
        const payload = await response.json().catch(() => ({}));
        if (attempt >= 2 || ![429, 500, 502, 503, 504].includes(response.status)) return { response, payload };
        const retryAfter = Number(response.headers.get("retry-after"));
        // Long quota waits belong to a later user retry, not an unbounded save.
        if (retryAfter > 10) return { response, payload };
        await sleep(retryAfter > 0 ? retryAfter * 1000 : (response.status === 429 ? 5000 : 1000) * 2 ** attempt);
      }
    })().finally(() => pending.delete(key));
    pending.set(key, task);
    return task;
  };
}
