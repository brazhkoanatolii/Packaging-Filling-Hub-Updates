export const PACKAGING_TARGET_RANGES = Object.freeze({
  // Columns B:D are entered manually in the daily packaging journal.  Columns
  // E:N are calculated from the completed production records and product
  // specification, so both sources always meet in one daily row.
  rawMaterials: "'Расход сырья'!A3:N500",
  cans: "'Банки'!A4:K500"
});

export function packagingTargetValues(values = {}) {
  const amount = key => {
    const value = Number(values[key] ?? 0);
    if (!Number.isFinite(value) || value < 0) throw new Error(`Некорректный итог расхода упаковки: ${key}`);
    return value;
  };
  return {
    rawMaterials: [amount("garantBox430"), amount("garantBox570"), amount("dochemsPaper")],
    cansPrimary: [amount("killaCanClear"), amount("killaCanGreen")],
    cansSecondary: [amount("killaLidGreen"), amount("dzCanClear"), amount("dzCanGreen"), amount("dzLidBlack"), amount("dzLidWhite"), amount("dzLidGreen")]
  };
}
