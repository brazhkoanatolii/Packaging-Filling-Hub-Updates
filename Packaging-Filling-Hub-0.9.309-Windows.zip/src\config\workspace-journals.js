// Native Google Sheets. IDs are document addresses, not credentials.
export const WORKSPACE_JOURNALS = Object.freeze({
  personnel: { title: "Персонал", id: "1r1opRywv4upVl4oMrUlOqmRsjAuETUu3-JFMUqjRu04" },
  timesheet: { title: "Табель 2025–2029", id: "1eJphWAgaxNb5N--tDrwv4uTzmiAs19NOLSAQlSn3dk0" },
  vacations: { title: "График отпусков 2025–2029", id: "1zenc0sBGtD8KHQdrBxULsoA9jSaUcZeW83XIiz5YxSo" },
  repairs: { title: "Журнал ремонта", id: "1pg2Y9Hnc-5BCU3QaF3k9VwOJjqNwdkXbE3qFAnY6Qw8" },
  maintenance: { title: "Журнал ТО", id: "1SRirurDOMqyGEXj2oo_V81CQ5jKnnvg9nN8G21QAFAY" },
  packaging: { title: "Журнал расхода упаковки", id: "1n7OfVi8__XWRJhj5jtlRUbrU6O9wGLmlDDf0e9-UKoI" },
  packagingWarehouse: { title: "Склад упаковки", id: "1mv7W6IcetxpSNMlTvQclPMIs15ZWZw7Q3ZE_g_NXVok" },
  ppeWarehouse: { title: "Журнал выдач СИЗ", id: "13QGPCIlgp5GAbVfBc1Q6AaHuvxQNWEdYLP8KEHZ3Bc4" },
  shiftTasks: { title: "Сменное задание", id: "1wZ4YdTdjm4dFq3mgdCCKocugPMpG9fJ7ReQCWxJp50A" },
  cyclones: { title: "Очистка циклонов", id: "1jEpmScclwvmIhhiHnBi0EE5kRBGNLtfmP4zepkAMQDU" }
});
export const WORKFORCE_YEARS = Object.freeze([2026, 2027, 2028, 2029]);
