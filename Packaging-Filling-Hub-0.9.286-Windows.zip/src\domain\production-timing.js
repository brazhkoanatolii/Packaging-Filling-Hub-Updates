const SHIFT_START = 7 * 60 + 30;
const FIRST_PRODUCTION_START = 7 * 60 + 45;
const SHIFT_END = 19 * 60 + 30;
const NON_PRODUCTION_INTERVALS = Object.freeze([
  [7 * 60 + 30, 7 * 60 + 45],
  [9 * 60 + 30, 9 * 60 + 35],
  [12 * 60, 12 * 60 + 30],
  [14 * 60, 14 * 60 + 5],
  [16 * 60, 16 * 60 + 30],
  [18 * 60, 18 * 60 + 5],
  [19 * 60, 19 * 60 + 30]
]);

// The end of the shift limits production planning, but it is not a break for
// preparation between two records. For example, 18:55 + 15 minutes is 19:10.
const TRANSITION_PAUSE_INTERVALS = Object.freeze(
  NON_PRODUCTION_INTERVALS.filter(([, pauseEnd]) => pauseEnd < SHIFT_END)
);

function toMinutes(value) {
  const match = String(value || "").match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const minutes = Number(match[1]) * 60 + Number(match[2]);
  return Number.isFinite(minutes) ? minutes : null;
}

function toTime(value) {
  const hours = Math.floor(value / 60);
  const minutes = value % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function operatorNames(record) {
  return String(record?.operator || "").split(/\s*(?:;|\||\+)\s*/).map(value => value.trim()).filter(Boolean).sort((left, right) => left.localeCompare(right, "ru"));
}

function workingGroup(record) {
  return [String(record?.packer || "").trim(), ...operatorNames(record)].join("|");
}

function productKey(record) {
  return [record?.catalogLine, record?.product, record?.strength].map(value => String(value || "").trim()).join("\u0001");
}

function productionLine(record) {
  return String(record?.machineLine || record?.line || "").trim().toUpperCase();
}

function latestRecord(records) {
  return [...records].sort((left, right) => toMinutes(right.time) - toMinutes(left.time))[0] || null;
}

export function productiveMinutesBetween(startTime, endTime) {
  const start = toMinutes(startTime);
  const end = toMinutes(endTime);
  if (start === null || end === null || end <= start) return 0;
  const boundedStart = Math.max(start, SHIFT_START);
  const boundedEnd = Math.min(end, SHIFT_END);
  if (boundedEnd <= boundedStart) return 0;
  return NON_PRODUCTION_INTERVALS.reduce((total, [pauseStart, pauseEnd]) => total - Math.max(0, Math.min(boundedEnd, pauseEnd) - Math.max(boundedStart, pauseStart)), boundedEnd - boundedStart);
}

export function addProductiveMinutes(startTime, requestedMinutes) {
  let cursor = toMinutes(startTime);
  let remaining = Number(requestedMinutes);
  if (cursor === null || !Number.isFinite(remaining) || remaining < 0) return null;
  cursor = Math.max(cursor, SHIFT_START);
  for (const [pauseStart, pauseEnd] of NON_PRODUCTION_INTERVALS) {
    if (remaining <= 0) break;
    if (cursor < pauseStart) {
      const usable = Math.min(remaining, pauseStart - cursor);
      cursor += usable;
      remaining -= usable;
    }
    if (remaining > 0 && cursor >= pauseStart && cursor < pauseEnd) cursor = pauseEnd;
  }
  if (remaining > 0) {
    const usable = Math.min(remaining, Math.max(0, SHIFT_END - cursor));
    cursor += usable;
    remaining -= usable;
  }
  return remaining > 0 || cursor > SHIFT_END ? null : toTime(cursor);
}

function addTransitionMinutes(startTime, requestedMinutes) {
  let cursor = toMinutes(startTime);
  let remaining = Number(requestedMinutes);
  if (cursor === null || !Number.isFinite(remaining) || remaining < 0) return null;
  cursor = Math.max(cursor, SHIFT_START);
  for (const [pauseStart, pauseEnd] of TRANSITION_PAUSE_INTERVALS) {
    if (remaining <= 0) break;
    if (cursor < pauseStart) {
      const usable = Math.min(remaining, pauseStart - cursor);
      cursor += usable;
      remaining -= usable;
    }
    if (remaining > 0 && cursor >= pauseStart && cursor < pauseEnd) cursor = pauseEnd;
  }
  return toTime(cursor + remaining);
}

// The shift-efficiency calculation counts transition losses for the people
// who actually moved. Autocomplete below has separate line/packer rules.
export function transitionWorkingMinutes(previous, next) {
  if (!previous || !next || workingGroup(previous) !== workingGroup(next)) return 0;
  const previousLine = productionLine(previous);
  const nextLine = productionLine(next);
  if (previousLine && nextLine && previousLine !== nextLine) return 20;
  if (previousLine && previousLine === nextLine && productKey(previous) !== productKey(next)) return 15;
  return 0;
}

export function minimumProductionStartTime(records, next, { excludeId = "", ignoreEnteredStart = false } = {}) {
  const base = toTime(FIRST_PRODUCTION_START);
  const nextDate = String(next?.date || "");
  const nextShift = String(next?.shift || "").trim().toUpperCase();
  const nextLine = productionLine(next);
  const nextPacker = String(next?.packer || "").trim();
  const enteredStart = toMinutes(next?.startTime);
  const candidates = (records || []).filter(record => (!excludeId || String(record?.id || "") !== String(excludeId))
    && String(record?.date || "") === nextDate
    && String(record?.shift || "").trim().toUpperCase() === nextShift
    && toMinutes(record?.time) !== null
    && (ignoreEnteredStart || enteredStart === null || toMinutes(record?.startTime) === null || toMinutes(record.startTime) <= enteredStart));
  if (!candidates.length) return base;

  // Cleaning is tied to the production line: a different product after the
  // latest entry on the same line needs 15 productive minutes.
  const previousOnLine = nextLine ? latestRecord(candidates.filter(record => productionLine(record) === nextLine)) : null;
  const lineMinimum = previousOnLine && productKey(previousOnLine) !== productKey(next)
    ? addTransitionMinutes(previousOnLine.time, 15)
    : null;

  // Moving the same packer to another line takes 20 productive minutes.
  const previousForPacker = nextPacker
    ? latestRecord(candidates.filter(record => String(record?.packer || "").trim() === nextPacker))
    : null;
  const packerMinimum = previousForPacker && productionLine(previousForPacker) !== nextLine
    ? addTransitionMinutes(previousForPacker.time, 20)
    : null;

  return [base, lineMinimum, packerMinimum]
    .filter(Boolean)
    .sort((left, right) => toMinutes(right) - toMinutes(left))[0] || base;
}

export const FIRST_PRODUCTION_START_TIME = toTime(FIRST_PRODUCTION_START);
