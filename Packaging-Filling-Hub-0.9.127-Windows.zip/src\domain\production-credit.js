/**
 * Splits the people selected at a production line.  The same rule is used by
 * the application statistics and by the Google-report exporter, so a number
 * is not interpreted differently in the two places.
 */
export function splitProductionParticipants(value) {
  return [...new Set(String(value || "").split(/\s*(?:;|\||\+)\s*/).map(item => item.trim()).filter(Boolean))].slice(0, 2);
}

export function productionShiftKey(record) {
  return `${String(record?.date || "").trim()}:${String(record?.shift || "").trim().toUpperCase()}`;
}

export function productionLineCode(record) {
  const value = String(record?.machineLine || record?.line || "").trim().toUpperCase();
  const match = value.match(/(?:^|[-\s])([A-Z])(?:$|[-\s])/);
  return match?.[1] || value;
}

/**
 * Groups records by a shift and returns the people assigned to the whole
 * shift.  Anyone assigned to the whole shift is deliberately excluded from
 * the line split for that shift: the full shift total is their credit.
 */
export function productionShiftGroups(records = []) {
  const groups = new Map();
  records.forEach(record => {
    const key = productionShiftKey(record);
    const group = groups.get(key) || { key, records: [], shiftAssignees: new Set() };
    group.records.push(record);
    [record?.seniorMechanic, record?.mechanic]
      .map(value => String(value || "").trim())
      .filter(Boolean)
      .forEach(name => group.shiftAssignees.add(name));
    groups.set(key, group);
  });
  return [...groups.values()];
}

/**
 * Returns the people who receive a particular line record and their shares.
 * This does not use the person's official role: a mechanic-operator,
 * mechanic, or senior mechanic standing at a line follows the same rule.
 */
export function productionLineCredits(record, shiftAssignees = new Set()) {
  const people = splitProductionParticipants(record?.operator).filter(name => !shiftAssignees.has(name));
  if (people.length === 1) return [{ name: people[0], fraction: 1 }];
  if (people.length === 2 && ["L", "M"].includes(productionLineCode(record))) {
    return [{ name: people[0], fraction: 2 / 3 }, { name: people[1], fraction: 1 / 3 }];
  }
  return people.map(name => ({ name, fraction: 1 / people.length }));
}
