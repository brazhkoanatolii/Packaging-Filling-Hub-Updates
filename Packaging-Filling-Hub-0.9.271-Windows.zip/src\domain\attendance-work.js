const WORKED_ATTENDANCE_CODES = new Set(["BI", "DN", "DP", "DS", "FD", "K", "KS", "VD"]);

// A positive number is the factual number of hours worked. The approved
// attendance codes below also represent working time rather than absence.
export function hasWorkedAttendance(value) {
  const code = String(value ?? "").trim();
  return (Number.isFinite(Number(code)) && Number(code) > 0) || WORKED_ATTENDANCE_CODES.has(code);
}
