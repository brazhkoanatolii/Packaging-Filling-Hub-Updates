export const CENTRAL_SHIFT_AUTOMATIC_CLOSE_MINUTES = 23 * 60 + 55;

/**
 * An open shift from a previous calendar day cannot remain operational.
 * Today's shift closes at 23:55 in the configured local time zone.
 */
export function shouldAutomaticallyCloseCentralShift(shift, { date, hour, minute }) {
  if (!shift?.active) return false;
  const shiftDate = String(shift.shiftDate || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(shiftDate) || !/^\d{4}-\d{2}-\d{2}$/.test(String(date || ""))) return false;
  if (shiftDate < date) return true;
  if (shiftDate > date) return false;
  return Number(hour) * 60 + Number(minute) >= CENTRAL_SHIFT_AUTOMATIC_CLOSE_MINUTES;
}
