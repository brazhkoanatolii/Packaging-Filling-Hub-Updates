import { splitProductionParticipants } from "./production-credit.js";

const ILONA_CURIKOVA_ID = "employee-0013";
const ILONA_PREFERRED_LINES = ["L", "M"];
const ROTATION_LINES = new Set(["B", "H"]);
const MAX_CANDIDATES = 20000;

function unique(values) {
  return [...new Set((values ?? []).map(value => String(value || "").trim()).filter(Boolean))];
}

export function shuffle(values, random = Math.random) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(random() * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}

function normalizedName(value) {
  return String(value || "").trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

function historyIndex(records, currentDate, currentShift) {
  const packerShifts = new Map(), operatorShifts = new Map(), latestLine = new Map();
  const addShift = (map, name, key, time, value) => {
    if (!name) return;
    const current = map.get(name);
    if (current && key === current.key) { current.values.add(value); if (time > current.time) current.time = time; }
    else if (!current || time > current.time) map.set(name, { key, time, values: new Set([value]) });
  };
  for (const record of records || []) {
    const date = String(record?.date || "").trim();
    const shift = String(record?.shift || "").trim().toUpperCase();
    const line = String(record?.line || record?.machineLine || "").trim().toUpperCase();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !line || (currentDate && date > currentDate)) continue;
    if (currentDate && currentShift && date === currentDate && shift === currentShift) continue;
    const time = `${date}T${String(record.time || record.startTime || "00:00").padStart(5, "0")}`;
    const key = `${date}:${shift}`;
    const packer = normalizedName(record.packer);
    const operators = splitProductionParticipants(record.operator).map(normalizedName);
    const updateLine = name => {
      if (!name) return;
      const k = `${line}\u0000${name}`;
      if (!latestLine.has(k) || latestLine.get(k) < time) latestLine.set(k, time);
    };
    updateLine(packer);
    for (const operator of operators) {
      updateLine(operator);
      addShift(operatorShifts, operator, key, time, packer);
    }
    addShift(packerShifts, packer, key, time, line);
  }
  return { packerShifts, operatorShifts, latestLine };
}

function rotationOrder(ids, line, namesById, latestLine) {
  return [...ids].sort((left, right) => {
    const l = namesById[left] || left, r = namesById[right] || right;
    const leftLast = latestLine.get(`${line}\u0000${normalizedName(l)}`) || "";
    const rightLast = latestLine.get(`${line}\u0000${normalizedName(r)}`) || "";
    return leftLast.localeCompare(rightLast) || String(l).localeCompare(String(r), "ru");
  });
}

export function distributePersonnel({ teamId = "", lines = [], operatorIds = [], packerIds = [], operatorNamesById = {}, packerNamesById = {}, historyRecords = [], currentDate = "", currentShift = "" }, random = Math.random) {
  const selectedLines = unique(lines).map(line => line.toUpperCase());
  const operators = shuffle(unique(operatorIds), random);
  const packers = shuffle(unique(packerIds), random);
  const { packerShifts, operatorShifts, latestLine } = historyIndex(historyRecords, currentDate, String(currentShift || "").trim().toUpperCase());
  const rotationLines = selectedLines.filter(line => ROTATION_LINES.has(line));
  const preferredLine = packers.includes(ILONA_CURIKOVA_ID) ? ILONA_PREFERRED_LINES.find(line => selectedLines.includes(line)) : "";
  const ilonaRotationLine = rotationLines.find(line => rotationOrder(packers, line, packerNamesById, latestLine)[0] === ILONA_CURIKOVA_ID);
  const ilonaTargetLine = ilonaRotationLine || preferredLine;
  const ranks = (ids, names, line) => new Map(rotationOrder(ids, line, names, latestLine).map((id, index) => [id, index]));
  const packerRanks = new Map(rotationLines.map(line => [line, ranks(packers, packerNamesById, line)]));
  const operatorRanks = new Map(rotationLines.map(line => [line, ranks(operators, operatorNamesById, line)]));
  let candidates = [{ lines: [], usedPackers: new Set(), usedOperators: new Set(), violations: 0, rank: 0 }];
  let searchLimited = false;
  for (const [index, line] of selectedLines.entries()) {
    const remainingLines = selectedLines.length - index;
    const next = new Map();
    for (const candidate of candidates) {
      const pAvailable = packers.filter(id => !candidate.usedPackers.has(id) && (!ilonaTargetLine || id !== ILONA_CURIKOVA_ID || line === ilonaTargetLine));
      const oAvailable = operators.filter(id => !candidate.usedOperators.has(id));
      const pChoices = line === ilonaTargetLine
        ? (packers.includes(ILONA_CURIKOVA_ID) && !candidate.usedPackers.has(ILONA_CURIKOVA_ID) ? [ILONA_CURIKOVA_ID] : [""])
        : [...pAvailable, ...(packers.length - candidate.usedPackers.size < remainingLines ? [""] : [])];
      const oChoices = [...oAvailable, ...(oAvailable.length < remainingLines ? [""] : [])];
      for (const packerId of pChoices) for (const operatorId of oChoices) {
        const packerName = normalizedName(packerNamesById[packerId] || packerId);
        const operatorName = normalizedName(operatorNamesById[operatorId] || operatorId);
        const repeatedLine = Boolean(packerId && packerId !== ILONA_CURIKOVA_ID && packerShifts.get(packerName)?.values.has(line));
        const repeatedPair = Boolean(packerId && operatorId && operatorShifts.get(operatorName)?.values.has(packerName));
        const updated = {
          lines: [...candidate.lines, { line, operatorId, packerId, repeatedLine, repeatedPair }],
          usedPackers: new Set([...candidate.usedPackers, ...(packerId ? [packerId] : [])]),
          usedOperators: new Set([...candidate.usedOperators, ...(operatorId ? [operatorId] : [])]),
          violations: candidate.violations + Number(repeatedLine) + Number(repeatedPair),
          rank: candidate.rank + (packerId ? (packerRanks.get(line)?.get(packerId) || 0) : 0) + (operatorId ? (operatorRanks.get(line)?.get(operatorId) || 0) : 0)
        };
        const stateKey = packers.map(id => updated.usedPackers.has(id) ? "1" : "0").join("") + ":" + operators.map(id => updated.usedOperators.has(id) ? "1" : "0").join("");
        const previous = next.get(stateKey);
        if (!previous || updated.violations < previous.violations || (updated.violations === previous.violations && updated.rank < previous.rank)) next.set(stateKey, updated);
      }
    }
    const ordered = [...next.values()].sort((a, b) => a.violations - b.violations || a.rank - b.rank);
    if (ordered.length > MAX_CANDIDATES) searchLimited = true;
    candidates = ordered.slice(0, MAX_CANDIDATES);
  }
  const best = candidates[0] || { lines: [], usedPackers: new Set(), usedOperators: new Set() };
  return {
    lines: best.lines.map(({ line, operatorId, packerId }) => ({ line, operatorId, packerId })),
    warnings: best.lines.flatMap(item => [
      ...(item.repeatedLine ? [{ type: "repeated-line", line: item.line, packerId: item.packerId }] : []),
      ...(item.repeatedPair ? [{ type: "repeated-pair", line: item.line, packerId: item.packerId, operatorId: item.operatorId }] : [])
    ]),
    searchLimited,
    unassignedOperatorIds: operators.filter(id => !best.usedOperators.has(id)),
    unassignedPackerIds: packers.filter(id => !best.usedPackers.has(id))
  };
}
