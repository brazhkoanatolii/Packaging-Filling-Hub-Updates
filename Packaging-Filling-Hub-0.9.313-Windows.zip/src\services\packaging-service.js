import { getVilniusDate } from "../domain/scale-check.js";
export const PACKAGING_FIELDS = Object.freeze([
  { key: "garantBox430", tone: "cardboard", label: "Коробки с логотипом GARANT (широкая) 430×285×255, шт" }, { key: "garantBox570", tone: "cardboard", label: "Коробки с логотипом Garant (узкая) 570×210×249, шт" }, { key: "dochemsPaper", tone: "paper", label: "Бумага Dochems 37 GSM, рул" }, { key: "killaCanClear", tone: "clear", label: "Банка прозрачная, шт" }, { key: "killaCanGreen", tone: "green", label: "Банка зеленая, шт" }, { key: "killaLidGreen", tone: "green", label: "Крышка зеленая, шт" }, { key: "dzCanClear", tone: "clear", label: "Банка прозрачная Garant+, шт" }, { key: "dzCanGreen", tone: "green", label: "Банка зеленая Garant+, шт" }, { key: "dzLidBlack", tone: "black", label: "Крышка черная Garant+, шт" }, { key: "dzLidWhite", tone: "white", label: "Крышка белая Garant+, шт" }, { key: "dzLidGreen", tone: "green", label: "Крышка зеленая Garant+, шт" }
]);
const packagingFieldByKey = Object.freeze(Object.fromEntries(PACKAGING_FIELDS.map(field => [field.key, field])));
export const PACKAGING_DISPLAY_FIELDS = Object.freeze([
  "garantBox430", "garantBox570", "dochemsPaper", "killaCanClear",
  "dzCanClear", "dzLidBlack", "dzLidWhite", "dzCanGreen", "dzLidGreen",
  "killaCanGreen", "killaLidGreen"
].map(key => packagingFieldByKey[key]));
const emptyValues = () => Object.fromEntries(PACKAGING_FIELDS.map(field => [field.key, 0]));
export class PackagingService {
  constructor(repository) { this.repository = repository; this.error = null; }
  async snapshot() { return { records: await this.repository.list(), operations: await this.repository.pending(), lastReadAt: await this.repository.lastReadAt(), error: this.error }; }
  async refresh() { try { await this.repository.refresh(); this.error = null; } catch (error) { this.error = error.message; } return this.snapshot(); }
  async sync() { try { await this.repository.sync(); this.error = null; } catch (error) { this.error = error.message; } const writeError = this.error; await this.refresh(); if (writeError) this.error = writeError; return this.snapshot(); }
  async add(input) { const date = validDate(input.date); const item = PACKAGING_FIELDS.find(field => field.key === input.item); if (!item) throw new Error("Выберите вид упаковки"); const quantity = positiveInteger(input.quantity); const current = (await this.repository.list()).find(record => record.date === date); return this.repository.save({ ...(current || {}), id: current?.id || `packaging-day-${date}`, date, values: { ...emptyValues(), ...(current?.values || {}), [item.key]: Number(current?.values?.[item.key] || 0) + quantity } }); }
  async update(record, input) { return this.repository.save({ ...record, date: validDate(input.date), values: values(input) }); }
  async remove(record) { if (!record?.id) throw new Error("Не найдена дневная запись"); return this.repository.remove(record); }
}
function validDate(value) { const date = String(value || ""); if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > getVilniusDate()) throw new Error("Дата должна быть сегодняшней или более ранней"); return date; }
function positiveInteger(value) { const text = String(value ?? "").trim(); if (!/^\d+$/.test(text) || Number(text) <= 0) throw new Error("Количество указывается целым положительным числом"); return Number(text); }
function values(input) { const result = Object.fromEntries(PACKAGING_FIELDS.map(field => { const n = Number(String(input[field.key] ?? "").replace(",", ".")); if (!Number.isFinite(n) || n < 0) throw new Error(`Поле «${field.label}» должно быть неотрицательным числом`); return [field.key, n]; })); if (!Object.values(result).some(n => n > 0)) throw new Error("Укажите расход хотя бы по одному виду упаковки"); return result; }
