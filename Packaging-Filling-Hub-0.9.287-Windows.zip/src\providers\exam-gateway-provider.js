export class ExamGatewayProvider {
  constructor({ baseUrl = "", fetchImpl = globalThis.fetch } = {}) { this.baseUrl = String(baseUrl).replace(/\/$/, ""); this.fetch = fetchImpl.bind(globalThis); }
  async save(record) { return this.#request("POST", record).then(payload => payload.record); }
  async #request(method, body) {
    let response;
    try { response = await this.fetch(`${this.baseUrl}/api/exam-results`, { method, headers: { Accept: "application/json", "Content-Type": "application/json" }, signal: AbortSignal.timeout(30_000), body: JSON.stringify(body) }); }
    catch (cause) { const error = new Error(cause?.name === "TimeoutError" ? "Google не ответил за 30 секунд. Повторите позже." : "Нет связи с журналом экзаменов в Google"); error.name = globalThis.navigator?.onLine ? "GatewayUnavailableError" : "OfflineError"; throw error; }
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok !== true) throw new Error(payload?.message || "Журнал экзаменов недоступен");
    return payload;
  }
}
