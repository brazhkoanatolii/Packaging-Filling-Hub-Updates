import { EXAM_PASSING, EXAM_ROLES } from "../config/exam-bank.js";

export function scoreExam(roleId, submittedAnswers, submittedScenarioScore, criticalScenario = false) {
  const role = EXAM_ROLES.find(item => item.id === roleId);
  if (!role) throw new Error("Выберите должность для экзамена");
  const answers = Array.isArray(submittedAnswers) ? submittedAnswers : [];
  const theoryScore = role.answers.reduce((score, answer, index) => score + (String(answers[index] || "").trim().toUpperCase() === answer ? 1 : 0), 0);
  const criticalQuestionErrors = role.criticalQuestions.filter(number => String(answers[number - 1] || "").trim().toUpperCase() !== role.answers[number - 1]);
  const scenarioScore = Number(submittedScenarioScore);
  if (!Number.isInteger(scenarioScore) || scenarioScore < 0 || scenarioScore > 6) throw new Error("Оценка ситуаций должна быть целым числом от 0 до 6");
  const criticalError = Boolean(criticalScenario) || criticalQuestionErrors.length > 0;
  const passed = !criticalError && theoryScore >= EXAM_PASSING.theory && scenarioScore >= EXAM_PASSING.scenarios;
  return Object.freeze({ role, theoryScore, scenarioScore, criticalError, criticalQuestionErrors, passed, result: criticalError ? "Повторная подготовка" : passed ? "Сдан" : "Не сдан" });
}
