export const EXAM_PASSING = Object.freeze({ theory: 16, scenarios: 5 });

// The approved questions remain in Google Docs.  This stores only the scoring
// key, so the source tests are never copied or changed by the application.
export const EXAM_ROLES = Object.freeze([
  Object.freeze({ id: "packer", label: "Упаковщик", testUrl: "https://docs.google.com/document/d/1Y-6On4B-2ecI1fXm2TLJ8Fjgdd97HsChUzFbjZLs4M/edit", answers: Object.freeze(["Г", "Б", "В", "Б", "Г", "Б", "А", "А", "В", "Б", "В", "Г", "А", "В", "А", "В", "Г", "А", "Г", "Б"]), criticalQuestions: Object.freeze([2, 16, 19, 20]) }),
  Object.freeze({ id: "mechanic-operator", label: "Механик-оператор", testUrl: "https://docs.google.com/document/d/1ABBQyt0d3WLMLlMSm4SN23G5xo-YWzIXQqBp8WyJC50/edit", answers: Object.freeze(["Б", "А", "В", "В", "Г", "Г", "Б", "Г", "А", "В", "В", "А", "Б", "А", "Б", "Г", "Б", "А", "Г", "В"]), criticalQuestions: Object.freeze([6, 7, 12, 15]) }),
  Object.freeze({ id: "mechanic", label: "Механик", testUrl: "https://docs.google.com/document/d/1UWM2cpH3tnrzjjFtT2_HxbH5QmOM8UswKsAAepraVOY/edit", answers: Object.freeze(["В", "Б", "В", "А", "Б", "В", "Г", "Г", "В", "Г", "Г", "Б", "А", "Г", "А", "А", "Б", "А", "В", "Б"]), criticalQuestions: Object.freeze([3, 5, 6, 9, 10, 12, 16, 18, 20]) }),
  Object.freeze({ id: "senior-mechanic", label: "Старший механик", testUrl: "https://docs.google.com/document/d/11lQVbEr5m9qtYgzHTrjN_aL4AT8B0iNOsy_ihOpZR9I/edit", answers: Object.freeze(["Г", "А", "А", "В", "В", "Г", "Б", "А", "Б", "В", "В", "А", "А", "Б", "Г", "В", "Г", "Г", "Б", "Б"]), criticalQuestions: Object.freeze([1, 2, 3, 10]) })
]);
