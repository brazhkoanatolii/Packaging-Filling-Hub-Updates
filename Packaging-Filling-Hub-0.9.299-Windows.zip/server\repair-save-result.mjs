export async function finalizeRepairSave({ record, repairId, rowNumber, parts, writeOffParts }) {
  const result = { ok: true, record: { ...record, id: repairId, rowNumber } };
  try {
    if (parts.length) await writeOffParts(parts, { repairId, record });
    return { ...result, partsWrittenOff: parts.length, partsWriteOffStatus: "confirmed" };
  } catch {
    return {
      ...result,
      partsWrittenOff: null,
      partsWriteOffStatus: "needs_review",
      warning: "Ремонт сохранён. Не удалось подтвердить списание всех запчастей. Проверьте склад; повторно отправлять ремонт не нужно."
    };
  }
}
