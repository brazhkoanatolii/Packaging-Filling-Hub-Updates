import { getVilniusDate } from "../domain/scale-check.js";

export class PpeWarehouseService {
  constructor(repository) { this.repository = repository; this.items = []; this.records = []; this.error = null; }
  snapshot() { return { items: [...this.items], records: [...this.records], error: this.error }; }
  async refresh() { try { const data = await this.repository.list(); this.items = data.items; this.records = data.records; this.error = data.warning || null; } catch (error) { this.error = error.message; } return this.snapshot(); }
  async issue(input, account) {
    const record = validate(input, account);
    const balance = this.items.find(row => row.item === record.item);
    if (!balance) throw new Error("Выберите позицию из текущего списка склада СИЗ");
    if (record.quantity > balance.quantity) throw new Error(`На складе доступно только ${balance.quantity} ${balance.unit || "шт."}`);
    const result = await this.repository.issue(record);
    await this.refresh();
    return result;
  }
  async retry(id) { await this.repository.retry(id); return this.refresh(); }
}

function validate(input, account) {
  const date = String(input?.date || "");
  const item = String(input?.item || "").trim();
  const quantity = Number(input?.quantity);
  const note = String(input?.note || "").trim();
  const id = String(input?.id || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > getVilniusDate()) throw new Error("Дата должна быть сегодняшней или более ранней");
  if (!item || !Number.isInteger(quantity) || quantity <= 0) throw new Error("Укажите наименование и целое положительное количество");
  if (!/^[a-zA-Z0-9_-]{8,160}$/.test(id)) throw new Error("Не удалось подготовить идентификатор выдачи");
  if (note.length > 500) throw new Error("Примечание не должно превышать 500 символов");
  return { id, date, item, quantity, note, author: String(account?.title || account?.id || "Рабочая учётная запись") };
}
