export class PpeWarehouseGatewayProvider {
  constructor({ baseUrl = "", fetchImpl = globalThis.fetch } = {}) {
    this.baseUrl = String(baseUrl).replace(/\/$/, "");
    this.fetch = fetchImpl.bind(globalThis);
  }

  async list() {
    const payload = await this.#request("GET");
    if (!Array.isArray(payload.items) || !Array.isArray(payload.records)) throw new Error("Google не вернул остатки склада СИЗ");
    return { items: payload.items.map(normalizeItem), records: payload.records.map(normalizeRecord), warning: String(payload.warning || "") };
  }

  async issue(record) { return this.#request("POST", record); }
  async retry(id) { return this.#request("POST", { id }, "/retry"); }

  async #request(method, body, suffix = "") {
    let response;
    try {
      response = await this.fetch(`${this.baseUrl}/api/ppe-warehouse-records${suffix}`, {
        method,
        headers: { Accept: "application/json", ...(body ? { "Content-Type": "application/json" } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {}),
        signal: AbortSignal.timeout(30_000)
      });
    } catch (cause) {
      throw new Error(cause?.name === "TimeoutError" ? "Google не ответил за 30 секунд" : "Нет связи со складом СИЗ в Google");
    }
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok !== true) throw new Error(payload?.message || "Журнал склада СИЗ недоступен");
    return payload;
  }
}

function normalizeItem(item) {
  const quantity = Number(item?.quantity);
  if (!String(item?.item || "").trim() || !Number.isFinite(quantity)) throw new Error("Google вернул некорректный остаток СИЗ");
  return { item: String(item.item), unit: String(item.unit || "шт."), quantity };
}

function normalizeRecord(record) {
  if (!record?.id || !/^\d{4}-\d{2}-\d{2}$/.test(String(record.date || ""))) throw new Error("Google вернул некорректную запись СИЗ");
  return {
    id: String(record.id), date: String(record.date), item: String(record.item || ""), unit: String(record.unit || ""),
    quantity: Number(record.quantity), author: String(record.author || ""), note: String(record.note || ""),
    month: String(record.month || ""), status: String(record.status || "В очереди"), error: String(record.error || "")
  };
}
