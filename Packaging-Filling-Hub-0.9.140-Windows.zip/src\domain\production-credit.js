/**
 * Splits the people selected at a production line.  The same rule is used by
 * the application statistics and by the Google-report exporter, so a number
 * is not interpreted differently in the two places.
 */
export function splitProductionParticipants(value) {
  return [...new Set(String(value || "").split(/\s*(?:;|\||\+)\s*/).map(item => item.trim()).filter(Boolean))].slice(0, 2);
}

export function productionShiftKey(record) {
  return `${String(record?.date || "").trim()}:${String(record?.shift || "").trim().toUpperCase()}`;
}

export function productionLineCode(record) {
  const value = String(record?.machineLine || record?.line || "").trim().toUpperCase();
  const match = value.match(/(?:^|[-\s])([A-Z])(?:$|[-\s])/);
  return match?.[1] || value;
}

const SHIFT_NON_PRODUCTION_INTERVALS = Object.freeze([
  ["07:30", "07:45"], // preparation before launch
  ["09:30", "09:35"],
  ["12:00", "12:30"],
  ["14:00", "14:05"],
  ["16:00", "16:30"],
  ["18:00", "18:05"],
  ["19:00", "19:30"] // cleanup after production
]);

function timeMinutes(value) {
  const match = String(value || "").trim().match(/^(?:[01]\d|2[0-3]):[0-5]\d$/);
  return match ? Number(match[0].slice(0, 2)) * 60 + Number(match[0].slice(3, 5)) : null;
}

function productiveMinutes(start, end) {
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return 0;
  return SHIFT_NON_PRODUCTION_INTERVALS.reduce((minutes, [pauseStart, pauseEnd]) => {
    const overlap = Math.max(0, Math.min(end, timeMinutes(pauseEnd)) - Math.max(start, timeMinutes(pauseStart)));
    return minutes - overlap;
  }, end - start);
}

function explicitSecondOperatorInterval(record) {
  const start = timeMinutes(record?.operatorSecondStartTime);
  const end = timeMinutes(record?.operatorSecondEndTime);
  return Number.isFinite(start) && Number.isFinite(end) && end > start ? { start, end } : null;
}

/**
 * Groups records by a shift and returns the people assigned to the whole
 * shift.  Anyone assigned to the whole shift is deliberately excluded from
 * the line split for that shift: the full shift total is their credit.
 */
export function productionShiftGroups(records = []) {
  const groups = new Map();
  records.forEach(record => {
    const key = productionShiftKey(record);
    const group = groups.get(key) || { key, records: [], shiftAssignees: new Set() };
    group.records.push(record);
    [record?.seniorMechanic, record?.mechanic]
      .map(value => String(value || "").trim())
      .filter(Boolean)
      .forEach(name => group.shiftAssignees.add(name));
    groups.set(key, group);
  });
  return [...groups.values()];
}

/**
 * Returns the people who receive a particular line record and their shares.
 * This does not use the person's official role: a mechanic-operator,
 * mechanic, or senior mechanic standing at a line follows the same rule.
 */
export function productionLineCredits(record, shiftAssignees = new Set()) {
  const people = splitProductionParticipants(record?.operator).filter(name => !shiftAssignees.has(name));
  if (people.length === 1) return [{ name: people[0], fraction: 1 }];
  if (people.length !== 2) return people.map(name => ({ name, fraction: 1 / people.length }));

  const [first, second] = people;
  const [firstDuringOverlap, secondDuringOverlap] = ["L", "M"].includes(productionLineCode(record))
    ? [2 / 3, 1 / 3]
    : [1 / 2, 1 / 2];
  const recordStart = timeMinutes(record?.startTime);
  const recordEnd = timeMinutes(record?.time);
  const secondInterval = explicitSecondOperatorInterval(record);
  const totalMinutes = productiveMinutes(recordStart, recordEnd);

  // Entries made before this field existed deliberately retain their previous
  // full-record split. They are recalculated by time only after correction.
  if (!secondInterval || !totalMinutes) {
    return [{ name: first, fraction: firstDuringOverlap }, { name: second, fraction: secondDuringOverlap }];
  }

  const overlapStart = Math.max(recordStart, secondInterval.start);
  const overlapEnd = Math.min(recordEnd, secondInterval.end);
  const sharedMinutes = productiveMinutes(overlapStart, overlapEnd);
  const firstFraction = (totalMinutes - sharedMinutes + sharedMinutes * firstDuringOverlap) / totalMinutes;
  const secondFraction = sharedMinutes * secondDuringOverlap / totalMinutes;
  return [{ name: first, fraction: firstFraction }, { name: second, fraction: secondFraction }];
}
