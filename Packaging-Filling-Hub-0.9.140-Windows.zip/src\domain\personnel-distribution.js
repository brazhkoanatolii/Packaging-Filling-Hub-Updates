const ILONA_CURIKOVA_ID = "employee-0013";
const ILONA_PREFERRED_LINES = ["L", "M"];

function unique(values) {
  return [...new Set((values ?? []).map(value => String(value || "").trim()).filter(Boolean))];
}

export function shuffle(values, random = Math.random) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(random() * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}

export function distributePersonnel({ teamId = "", lines = [], operatorIds = [], packerIds = [] }, random = Math.random) {
  const selectedLines = unique(lines);
  const operators = shuffle(unique(operatorIds), random);
  const packers = shuffle(unique(packerIds), random);
  const preferredLine = teamId === "shift-team-a" && packers.includes(ILONA_CURIKOVA_ID)
    ? ILONA_PREFERRED_LINES.find(line => selectedLines.includes(line))
    : "";
  const remainingPackers = preferredLine ? packers.filter(id => id !== ILONA_CURIKOVA_ID) : packers;
  let nextPacker = 0;
  const assignedPackerIds = new Set();
  const assignedLines = selectedLines.map((line, index) => {
    const packerId = line === preferredLine ? ILONA_CURIKOVA_ID : (remainingPackers[nextPacker++] || "");
    if (packerId) assignedPackerIds.add(packerId);
    return { line, operatorId: operators[index] || "", packerId };
  });
  return {
    lines: assignedLines,
    unassignedOperatorIds: operators.slice(selectedLines.length),
    unassignedPackerIds: packers.filter(id => !assignedPackerIds.has(id))
  };
}
