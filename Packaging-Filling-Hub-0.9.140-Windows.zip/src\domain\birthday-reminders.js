const DEFAULT_NOTICE_DAYS = Object.freeze([0, 3, 7]);

export function getBirthdayReminders(personnel, { asOfDate, noticeDays = DEFAULT_NOTICE_DAYS } = {}) {
  const start = parseIsoDate(asOfDate);
  if (!start) return [];
  const acceptedDays = new Set(noticeDays.filter(days => Number.isInteger(days) && days >= 0));
  return (personnel || []).filter(employee => employee?.active !== false).map(employee => {
    const birthday = parseIsoDate(employee?.birthday);
    if (!birthday) return null;
    const next = anniversaryOnOrAfter(birthday, start.year, start);
    const days = Math.round((Date.UTC(next.year, next.month - 1, next.day) - Date.UTC(start.year, start.month - 1, start.day)) / 86400000);
    return acceptedDays.has(days) ? { employee, days, date: toIsoDate(next) } : null;
  }).filter(Boolean).sort((left, right) => left.days - right.days || String(left.employee.fullName).localeCompare(String(right.employee.fullName), "ru"));
}

function anniversaryOnOrAfter(birthday, year, start) {
  let anniversary = { year, month: birthday.month, day: Math.min(birthday.day, daysInMonth(year, birthday.month)) };
  if (compareDates(anniversary, start) < 0) anniversary = { year: year + 1, month: birthday.month, day: Math.min(birthday.day, daysInMonth(year + 1, birthday.month)) };
  return anniversary;
}

function parseIsoDate(value) {
  const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  const [year, month, day] = match.slice(1).map(Number);
  return month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth(year, month) ? { year, month, day } : null;
}

function daysInMonth(year, month) { return new Date(Date.UTC(year, month, 0)).getUTCDate(); }
function compareDates(left, right) { return toIsoDate(left).localeCompare(toIsoDate(right)); }
function toIsoDate(date) { return `${date.year}-${String(date.month).padStart(2, "0")}-${String(date.day).padStart(2, "0")}`; }
