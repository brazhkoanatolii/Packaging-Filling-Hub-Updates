/**
 * Splits the people selected at a production line.  The same rule is used by
 * the application statistics and by the Google-report exporter, so a number
 * is not interpreted differently in the two places.
 */
export function splitProductionParticipants(value) {
  return [...new Set(String(value || "").split(/\s*(?:;|\||\+)\s*/).map(item => item.trim()).filter(Boolean))].slice(0, 3);
}

/**
 * A second-mechanic interval is meaningful only when two people are assigned
 * to the line and the stored interval has a real duration. Older Google rows
 * can contain the display default 00:00–00:00 even though no one was selected.
 */
export function hasProductionSecondMechanicInterval(record) {
  const people = splitProductionParticipants(record?.operator);
  const replacement = String(record?.operatorReplacement || "").trim();
  if (people.length < 2 || (replacement && people[1] === replacement)) return false;
  const start = timeMinutes(record?.operatorSecondStartTime);
  const end = timeMinutes(record?.operatorSecondEndTime);
  return Number.isFinite(start) && Number.isFinite(end) && end > start;
}

export function productionShiftKey(record) {
  return `${String(record?.date || "").trim()}:${String(record?.shift || "").trim().toUpperCase()}`;
}

export function productionLineCode(record) {
  const value = String(record?.machineLine || record?.line || "").trim().toUpperCase();
  const match = value.match(/(?:^|[-\s])([A-Z])(?:$|[-\s])/);
  return match?.[1] || value;
}

const SHIFT_NON_PRODUCTION_INTERVALS = Object.freeze([
  ["07:30", "07:45"], // preparation before launch
  ["09:30", "09:35"],
  ["12:00", "12:30"],
  ["14:00", "14:05"],
  ["16:00", "16:30"],
  ["18:00", "18:05"],
  ["19:00", "19:30"] // cleanup after production
]);

const SHIFT_PRODUCTION_START = "07:30";
const SHIFT_PRODUCTION_END = "19:00";

function timeMinutes(value) {
  const match = String(value || "").trim().match(/^(?:[01]\d|2[0-3]):[0-5]\d$/);
  return match ? Number(match[0].slice(0, 2)) * 60 + Number(match[0].slice(3, 5)) : null;
}

function productiveMinutes(start, end) {
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return 0;
  return SHIFT_NON_PRODUCTION_INTERVALS.reduce((minutes, [pauseStart, pauseEnd]) => {
    const overlap = Math.max(0, Math.min(end, timeMinutes(pauseEnd)) - Math.max(start, timeMinutes(pauseStart)));
    return minutes - overlap;
  }, end - start);
}

function explicitInterval(record, startField, endField) {
  const start = timeMinutes(record?.[startField]);
  const end = timeMinutes(record?.[endField]);
  return Number.isFinite(start) && Number.isFinite(end) && end > start ? { start, end } : null;
}

function operatorIntervals(record) {
  const people = splitProductionParticipants(record?.operator);
  const recordStart = timeMinutes(record?.startTime);
  const recordEnd = timeMinutes(record?.time);
  if (!people.length || !Number.isFinite(recordStart) || !Number.isFinite(recordEnd) || recordEnd <= recordStart) return [];

  const replacementName = String(record?.operatorReplacement || "").trim();
  const replacementIndex = replacementName ? people.indexOf(replacementName) : -1;
  const secondName = people[1] && replacementIndex !== 1 ? people[1] : "";
  const replacement = replacementName || (people.length > 2 ? people[2] : "");
  const bounded = ({ name, kind, interval }) => interval && ({
    name, kind, start: Math.max(recordStart, interval.start), end: Math.min(recordEnd, interval.end)
  });

  const firstInterval = replacement
    ? explicitInterval(record, "operatorStartTime", "operatorEndTime")
    : { start: recordStart, end: recordEnd };
  const intervals = [bounded({ name: people[0], kind: "first", interval: firstInterval })];
  if (secondName) intervals.push(bounded({ name: secondName, kind: "second", interval: explicitInterval(record, "operatorSecondStartTime", "operatorSecondEndTime") || { start: recordStart, end: recordEnd } }));
  if (replacement) intervals.push(bounded({ name: replacement, kind: "replacement", interval: explicitInterval(record, "operatorReplacementStartTime", "operatorReplacementEndTime") }));
  return intervals.filter(item => item?.name && item.end > item.start);
}

function mergeIntervals(intervals) {
  const ordered = intervals
    .filter(({ start, end }) => Number.isFinite(start) && Number.isFinite(end) && end > start)
    .sort((left, right) => left.start - right.start);
  const merged = [];
  ordered.forEach(interval => {
    const previous = merged.at(-1);
    if (previous && interval.start <= previous.end) previous.end = Math.max(previous.end, interval.end);
    else merged.push({ ...interval });
  });
  return merged;
}

function lineWorkIntervals(record) {
  return operatorIntervals(record).map(({ name, start, end }) => ({ name, start, end }));
}

function shiftProductiveMinutes() {
  return productiveMinutes(timeMinutes(SHIFT_PRODUCTION_START), timeMinutes(SHIFT_PRODUCTION_END));
}

/**
 * Groups records by a shift and returns the people assigned to a whole-shift
 * role. A person can simultaneously be a shift mechanic and temporarily work
 * at a line; their two credits are deliberately kept separate.
 */
export function productionShiftGroups(records = []) {
  const groups = new Map();
  records.forEach(record => {
    const key = productionShiftKey(record);
    const group = groups.get(key) || { key, records: [], shiftAssignees: new Set() };
    group.records.push(record);
    [record?.seniorMechanic, record?.mechanic]
      .map(value => String(value || "").trim())
      .filter(Boolean)
      .forEach(name => group.shiftAssignees.add(name));
    groups.set(key, group);
  });
  return [...groups.values()];
}

/**
 * Returns the people who receive a particular line record and their shares.
 * This does not use the person's official role: a mechanic-operator,
 * mechanic, or senior mechanic standing at a line follows the same rule.
 */
export function productionLineCredits(record, shiftAssignees = new Set()) {
  const people = splitProductionParticipants(record?.operator);
  if (people.length === 1) return [{ name: people[0], fraction: 1 }];
  const recordStart = timeMinutes(record?.startTime);
  const recordEnd = timeMinutes(record?.time);
  const totalMinutes = productiveMinutes(recordStart, recordEnd);
  const intervals = operatorIntervals(record);

  // Entries made before time fields existed retain the original full-record
  // split. New entries always contain a real record interval.
  if (!intervals.length || !totalMinutes) {
    if (people.length !== 2) return people.map(name => ({ name, fraction: 1 / people.length }));
    const [firstDuringOverlap, secondDuringOverlap] = ["L", "M"].includes(productionLineCode(record)) ? [2 / 3, 1 / 3] : [1 / 2, 1 / 2];
    return [{ name: people[0], fraction: firstDuringOverlap }, { name: people[1], fraction: secondDuringOverlap }];
  }

  const result = new Map(people.map(name => [name, 0]));
  const points = [...new Set([recordStart, recordEnd, ...intervals.flatMap(({ start, end }) => [start, end])])].sort((left, right) => left - right);
  for (let index = 0; index < points.length - 1; index += 1) {
    const start = points[index], end = points[index + 1];
    const active = intervals.filter(item => item.start < end && item.end > start);
    const minutes = productiveMinutes(start, end);
    if (!minutes || !active.length) continue;
    if (active.length === 1) result.set(active[0].name, result.get(active[0].name) + minutes);
    else {
      const second = active.find(item => item.kind === "second");
      const secondShare = second && ["L", "M"].includes(productionLineCode(record)) ? 1 / 3 : 1 / active.length;
      active.forEach(item => {
        const share = item === second ? secondShare : second ? (1 - secondShare) / (active.length - 1) : 1 / active.length;
        result.set(item.name, result.get(item.name) + minutes * share);
      });
    }
  }
  return people.map(name => ({ name, fraction: (result.get(name) || 0) / totalMinutes })).filter(({ fraction }) => fraction > 0);
}

/**
 * Returns the share of a shift which remains for each selected senior mechanic
 * or mechanic after their factual work at a line. The line share is credited
 * as "mechanic-operator"; only the remaining productive time is credited in
 * the selected shift role. A leader who never stood at a line keeps 100% of
 * the shift as a leader.
 */
export function productionShiftRoleCredits(group) {
  const shiftMinutes = shiftProductiveMinutes();
  const intervalsByPerson = new Map();
  group.records.forEach(record => lineWorkIntervals(record).forEach(interval => {
    intervalsByPerson.set(interval.name, [...(intervalsByPerson.get(interval.name) || []), interval]);
  }));
  const roles = new Map();
  group.records.forEach(record => {
    [[record?.seniorMechanic, "senior-mechanic"], [record?.mechanic, "mechanic"]].forEach(([value, role]) => {
      const name = String(value || "").trim();
      if (name && !roles.has(name)) roles.set(name, role);
    });
  });
  return [...roles].map(([name, role]) => {
    const lineMinutes = mergeIntervals(intervalsByPerson.get(name) || [])
      .reduce((total, interval) => total + productiveMinutes(interval.start, interval.end), 0);
    return { name, role, fraction: shiftMinutes ? Math.max(0, 1 - lineMinutes / shiftMinutes) : 1 };
  }).filter(credit => credit.fraction > 0);
}
