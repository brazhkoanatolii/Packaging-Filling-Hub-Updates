import { getVilniusDate, makeId } from "../domain/scale-check.js";

const CACHE_KEY = "incidentJournalCache";

export class IncidentService {
  constructor(store, repository) { this.store = store; this.repository = repository; }
  async snapshot() {
    const cached = await this.store.preference(CACHE_KEY, null);
    return { records: cached?.records ?? [], dictionary: cached?.dictionary ?? { categories: [], statuses: [], templates: [] }, source: cached ? "cache" : "loading", cachedAt: cached?.cachedAt ?? null, error: null };
  }
  async refresh() {
    try {
      const result = await this.repository.list();
      const snapshot = { records: normalizeRecords(result.records), dictionary: normalizeDictionary(result.dictionary), cachedAt: new Date().toISOString() };
      await this.store.setPreference(CACHE_KEY, snapshot);
      return { ...snapshot, source: "google", error: null };
    } catch (error) {
      const cached = await this.snapshot();
      return { ...cached, error: error.message };
    }
  }
  async create(input, seniorMechanics) { return this.#save("create", input, seniorMechanics); }
  async update(id, input, seniorMechanics) { return this.#save("update", { ...input, id }, seniorMechanics); }
  async remove(id) {
    if (!id) throw new Error("Не найдена запись");
    await this.repository.remove(id);
    const current = await this.snapshot();
    await this.store.setPreference(CACHE_KEY, { ...current, records: current.records.filter(record => record.id !== id), cachedAt: new Date().toISOString() });
  }
  async #save(method, input, seniorMechanics = []) {
    const record = validate(input, seniorMechanics);
    const saved = normalizeRecord(await this.repository[method](record));
    const current = await this.snapshot();
    await this.store.setPreference(CACHE_KEY, { ...current, records: [saved, ...current.records.filter(item => item.id !== saved.id)], cachedAt: new Date().toISOString() });
    return saved;
  }
}

function validate(input, seniorMechanics) {
  const text = (key, label, limit = 5000) => { const value = String(input[key] || "").trim(); if (!value) throw new Error(`Заполните поле «${label}»`); if (value.length > limit) throw new Error(`Поле «${label}» слишком длинное`); return value; };
  const date = String(input.date || getVilniusDate());
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > getVilniusDate()) throw new Error("Дата должна быть сегодняшней или более ранней");
  const shift = text("shift", "Смена", 2).toUpperCase();
  if (!['A', 'B'].includes(shift)) throw new Error("Смена должна быть определена из табеля");
  const seniorMechanic = text("seniorMechanic", "Старший механик", 180);
  if (seniorMechanics.length && !seniorMechanics.includes(seniorMechanic)) throw new Error("Старший механик должен совпадать с назначением в текущем табеле");
  const status = text("status", "Статус", 80);
  if (!["Открыт", "В работе", "Закрыт"].includes(status)) throw new Error("Выберите статус из списка");
  return { id: String(input.id || ""), requestId: String(input.requestId || makeId("incident")), date, shift, equipment: text("equipment", "Линия или оборудование", 180), category: text("category", "Категория", 180), type: text("type", "Что случилось", 1000), description: text("description", "Фактическое описание инцидента"), immediateAction: text("immediateAction", "Меры сразу"), correctiveAction: text("correctiveAction", "Корректирующие действия"), seniorMechanic, status };
}
function normalizeRecords(records = []) { return records.map(normalizeRecord).filter(Boolean); }
function normalizeRecord(record) {
  if (!record?.id || !/^\d{4}-\d{2}-\d{2}$/.test(String(record.date || ""))) return null;
  return { id: String(record.id), requestId: String(record.requestId || ""), rowNumber: Number(record.rowNumber || 0), date: String(record.date), shift: String(record.shift || "").toUpperCase(), equipment: String(record.equipment || ""), category: String(record.category || ""), type: String(record.type || ""), description: String(record.description || ""), immediateAction: String(record.immediateAction || ""), correctiveAction: String(record.correctiveAction || ""), seniorMechanic: String(record.seniorMechanic || ""), status: String(record.status || "Открыт") };
}
function normalizeDictionary(value) {
  const templates = (value?.templates ?? []).map(item => ({ category: String(item?.category || "").trim(), type: String(item?.type || "").trim(), responsible: String(item?.responsible || "").trim(), detectionAndFix: String(item?.detectionAndFix || "").trim(), explanation: String(item?.explanation || "").trim(), reporter: String(item?.reporter || "").trim(), notify: String(item?.notify || "").trim(), immediateAction: String(item?.immediateAction || "").trim(), severity: String(item?.severity || "").trim(), note: String(item?.note || "").trim() })).filter(item => item.category && item.type);
  return { categories: [...new Set((value?.categories?.length ? value.categories : templates.map(item => item.category)).map(item => String(item || "").trim()).filter(Boolean))], statuses: [...new Set((value?.statuses ?? []).map(item => String(item || "").trim()).filter(Boolean))], templates };
}
